// RabbitMQ WebSocket
var rmqSock = new function () {
    var _this = this;

    // Stomp connection url
     _this.connectionUrl= 'http://192.168.7.81:15674/stomp';

    // RabbitMQ data received from stomp
    _this.liveData = null;

    // RabbitMQ connection object
    _this.clientObj = null;

 _this.TwoMinDatExc = '/exchange/TwoMinData';
    _this.TwoMinDataQueue =  '/queue/TwoMinData';

    _this.AllDataExc = '/exchange/AllData1';
    _this.AllDataQueue = '/queue/AllData1';

    _this.alertExc = '/exchange/RT_ALERTS/5-realtimeAlerts';
    _this.alertQueue ='/queue/FMALertsUI';

    // Connection authentication parameters
    _this.mqUsername = 'guest';
    _this.mqPassword = 'guest';
    _this.mqVhost = '/';


    /**
     @function: init()
     @params: null
     @returns: null
     @Details: invoke init method to get connection and data.
     **/
    _this.init = function () {
        _this.makeConnection();
    };


    /**
     @function: makeConnection()
     @params: url
     @returns: null
     @Details: get connection.
     **/
    _this.makeConnection = function () {
        var ws = new SockJS(_this.connectionUrl);
        _this.clientObj = Stomp.over(ws);
        //SockJS does not support heart-beat: disable heart-beats
        _this.clientObj.heartbeat.incoming = 0;
        _this.clientObj.heartbeat.outgoing = 0;
        //makes connection and generates/add alert on the page
        _this.clientObj.connect(_this.mqUsername, _this.mqPassword, _this.onConnect, _this.onError, _this.mqVhost);
    };


    /**
     @function: onConnect()
     @params: url
     @returns: null
     @Details: subscribe to exchange queue after connection and generates/add alerts.
     **/
    _this.onConnect = function () {
        _this.clientObj.subscribe(_this.TwoMinDataQueue, function (d) {
            console.log("Data two min",d);
            if ((d.body != null) && (d.body != '') && (d.body != undefined)) {
                var data = JSON.parse(d.body);
               if(data.length||data.sumPayLoaDCount!=null){
		 twoMinDataQueueObj = data;
                defaultTwoMinDataObj.ifReceived = true;
                checkForQueueData();
}

            }
        });

        _this.clientObj.subscribe(_this.AllDataQueue, function (d) {
            console.log("SDf")
            if ((d.body != null) && (d.body != '') && (d.body != undefined)) {
                var data = JSON.parse(d.body);
                console.log("Data all",data);
		if(data.length||data.sumPayLoaDCount!=null){                
		allDataQueueObj = data;
                defaultAllDataObj.ifReceived = true;
                checkForQueueData();
}
            }
        });

        _this.clientObj.subscribe(_this.alertQueue, function (d) {
            if ((d.body != null) && (d.body != '') && (d.body != undefined)) {
                var data = {message: d.body};

                if(data.message.indexOf("stopped either")<1)
                getAlertData();
            }


        });
    };

    /**
     @function: onError()
     @params: url
     @returns: null
     @Details: return message and reconnect to rabittmq until successful connection.
     **/
    _this.onError = function () {
        console.log('RabbitMq Stomp Connection Error!');
    }

    /**
     @function: onReceive()
     @params: null
     @returns: null
     @Details: function to track on receive action.
     **/
    _this.onReceive = function () {
        // default receive callback to get message from temporary queues
        _this.clientObj.onreceive = function (m) {
            console.log("body", m.body);
        }
    };
};

$(document).ready(function () {
    rmqSock.init();
});
