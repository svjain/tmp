set standard_conforming_strings = off;

update component  set component_json =  '{
		"id": "aggregation-function-processor",
		"name": "AggregationFunctionProcessor",
		"label": "AggregationFunction",
		"className": "com.streamanalytix.storm.core.bolt.EsperBolt",
		"config": [
			"isContextEnabled: false",
			"cep.query.messageName:tracemessage",
			"aggQuery:{}"
		],
		"messageTypeId": "tracemessage",
		"emitStreamIds": [],
		"groupings": [],
		"parallelism": 1,
		"taskCount": 1,
		"type": "processor",
		"coordinates": []
	}'
where component_id = 'AggregationFunctionProcessor';

commit;