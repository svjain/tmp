var cepQueryGetUrl = baseUrl + '/datafabric/dynacep/config';
var errorStream = 'saxErrorStream';
var addedSpoutsObj = new Object();
var addedBoltsObj = new Object();
var addedIds = [];
var streamIdConn = null;
var dragDropObj = {};
var criteriaData = [], msgOptions, pastGroupFields, allMessages=[], usedMessages=[], dynamicCEPCount=0, rootSpouts;
var pendingConfigKeys = {};
var errHndlrName = 'deadLaterChannel';
var deadLaterChannel = {};
var activeComp = {};
var cmpIDs = {
	'kafkachannel': 'kafka-channel',
	'rabbitmqchannel': 'rabbitmq-channel',
	'customchannel': 'custom-channel',
	'activemqchannel': 'activemq-channel',
	'replaychannel': 'replay-channel',
	'customprocessors': 'custom-processor',
	'persistenceprocessor': 'persistence-processor',
	'pmmlprocessor': 'pmml-processor',
	'validatorprocessor': 'validator-processor',
	'timerprocessor': 'timer-processor',
	'filterprocessor': 'filter-processor',
	'cepcustom': 'custom-cep-processor',
	'aggregationfunction': 'aggregation-function-processor',
	'dynamiccepprocessor': 'dynamic-cep-processor',
	'syncsortprocessor': 'dmxh-processor',
	'graphiteprocessor': 'graphite-processor',
	'analyticsprocessor': 'analytics-processor',
	'kafkaemitter': 'kafka-emitter',
	'activemqemitter': 'activemq-emitter',
	'routeremitter': 'router-emitter',
	'streamemitter': 'stream-emitter',
	'rabbitmqemitter': 'rabbitmq-emitter',
	'solremitter': 'solr-emitter',
	'elasticsearchemitter': 'elasticsearch-emitter',
	'cassandraemitter': 'cassandra-emitter',
	'hbaseemitter': 'hbase-emitter',
	'hdfsemitter': 'hdfs-emitter',
	'enricherprocessor' : 'enrich-processor',
	'jdbcprocessor' : 'jdbc-processor'
};
var functionSupportedComps = [cmpIDs.customprocessors, cmpIDs.enricherprocessor, cmpIDs.timerprocessor, cmpIDs.kafkaemitter, cmpIDs.rabbitmqemitter, cmpIDs.jdbcprocessor];

// Parsley Custom Validator for PATH
window.ParsleyValidator.addValidator('path', 
	function (value, requirement) {
		value = value.replace(/\\/g, '/');
		var patt = new RegExp("(^([a-zA-Z]:[\/]{1})+(([A-Za-z0-9_-]+(\|/)?)*)+(([.]{1}[A-Za-z0-9_-]+)*)$)|(^/(([A-Za-z0-9_-]+[/]?)*)+(([.]{1}[A-Za-z0-9_-]+)*)$)");
		return patt.test(value);
	}, 32)
	.addMessage('en', 'path', i18N['sax.notification.invalidPathPattern']);
// Parsley Custom Validator for PATH

// Parsley Custom Validator for blockSize
window.ParsleyValidator.addValidator('blockSize', 
	function (value, requirement) {
		value = (value%512 == 0) ? true : false;
		return value;
	}, 32)
	.addMessage('en', 'blockSize', i18N['sax.notification.blocksize']);
// Parsley Custom Validator for blockSize

// Parsley Custom Validator for duplicate properties
window.ParsleyValidator.addValidator('duplicateKeys', 
	function (value, requirement) {
		var count = 0;
		$('#configRowsWrap input.config-key').each(function(i, fld) {
			var fldVal = $(fld).val();
			if ( fldVal == value ) count++;
		});
		return (count > 1) ? false : true;
	}, 32)
	.addMessage('en', 'duplicateKeys', i18N['sax.notification.duplicateKeys']);
// Parsley Custom Validator for duplicate properties

// Parsley special character check in table name expression
window.ParsleyValidator.addValidator('tblNameExp', function (value, requirement) {
		var regexp = /^[a-zA-Z0-9\-\_]+$/;
		if (value.search(regexp) == -1)
			return false;
		else
			return true;
	}, 32).addMessage('en', 'tblNameExp', i18N['sax.notification.specialChar']);

var componentsProperties = {
	'kafka-channel': {
		'topicName': {
			'validation':'data-parsley-required="true" data-parsley-pattern="^[A-Za-z0-9._-]*$" data-parsley-pattern-message="'+ i18N['sax.parsley.message.charAllowed'] + '"',
			'type': 'text'
		},
		'zkRootPath': {
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'text'
		},
		'brokerZkRoot': {
			'validation': 'data-parsley-required="true" data-parsley-pattern="^\/{1}(([A-Za-z]+\/)|([A-Za-z]))*[A-Za-z]$" data-parsley-pattern-message="'+i18N['sax.label.InvalidPathPattern']+'"',
			'type': 'text'
		},
		'offsetMarker': {
			'validation': 'data-parsley-required="true" data-parsley-pattern="^[A-Za-z0-9._-]*$" data-parsley-pattern-message="'+ i18N['sax.parsley.message.charAllowed'] + '"',
			'type': 'text'
		},
		'replicationFactor': {
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1" data-parsley-max="9"',
			'type': 'text'
		},
		'partitions': {
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1" data-parsley-max="999"',
			'type': 'text'
		},
		'forceFromStart': {
			'fieldId': 'forceFromStartSelector',
			'wrapId': 'forceFromStartWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'fetch.size': {
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"',
			'placeholder': i18N['sax.placeholder.valueinkb'],
			'type': 'text'
		},
		'buffer.size': {
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"',
			'placeholder': i18N['sax.placeholder.valueinkb'],
			'type': 'text'
		}
	},
	'rabbitmq-channel': {
		'exchangeName': {
			'validation': 'data-parsley-required="true" data-parsley-pattern="^[A-Za-z0-9._-]*$" data-parsley-pattern-message="'+i18N['sax.parsley.message.charAllowed']+'"',
			'type': 'text'
		},
		'exchangeType': {
			'fieldId': 'exchangeTypeSelector',
			'wrapId': 'exchangeTypeWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'exchangeDurable': {
			'fieldId': 'exchangeDurableSelector',
			'wrapId': 'exchangeDurableWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'exchangeAutoDelete': {
			'fieldId': 'exchangeAutoDeleteSelector',
			'wrapId': 'exchangeAutoDeleteWrap',
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'select'
		},
		'routingKey': {
			'validation': 'data-parsley-required="true" data-parsley-pattern="^[A-Za-z0-9._-]*$" data-parsley-pattern-message="'+i18N['sax.parsley.message.charAllowed']+'"',
			'type': 'text'
		},
		'queueName': {
			'validation': 'data-parsley-required="true" data-parsley-pattern="^[A-Za-z0-9._-]*$" data-parsley-pattern-message="'+i18N['sax.parsley.message.charAllowed']+'"',
			'type': 'text'
		},
		'queueDurable': {
			'fieldId': 'queueDurableSelector',
			'wrapId': 'queueDurableWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'queueExclusive': {
			'fieldId': 'queueExclusiveSelector',
			'wrapId': 'queueExclusiveWrap',
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'select'
		},
		'queueAutoDelete': {
			'fieldId': 'queueAutoDeleteSelector',
			'wrapId': 'queueAutoDeleteWrap',
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'select'
		},
		'connectionType':{
			'style': 'display: none;',
			'type': 'text'
		},
		'configurableUIFields': true
	},
	'activemq-channel': {
		'topicConfig': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'channelPlugin': {
			'validation': '',
			'type': 'text',
			'style': 'display: none;'
		},
		'exchangeName': {
			'validation': '',
			'type': 'text',
			'style': 'display: none;'
		},
		'exchangeType': {
			'fieldId': 'exchangeTypeSelector',
			'wrapId': 'exchangeTypeWrap',
			'validation': '',
			'type': 'select',
			'style': 'display: none;'
		},
		'exchangeDurable': {
			'fieldId': 'exchangeDurableSelector',
			'wrapId': 'exchangeDurableWrap',
			'validation': '',
			'type': 'select',
			'style': 'display: none;'
		},
		'exchangeAutoDelete': {
			'fieldId': 'exchangeAutoDeleteSelector',
			'wrapId': 'exchangeAutoDeleteWrap',
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'select'
		},
		'routingKey': {
			'validation': 'data-parsley-pattern="^[A-Za-z0-9._-]*$" data-parsley-pattern-message="'+i18N['sax.parsley.message.charAllowed']+'"',
			'type': 'text'
		},
		'queueName': {
			'validation': '',
			'type': 'text',
			'style': 'display: none;'
		},
		'queueDurable': {
			'fieldId': 'queueDurableSelector',
			'wrapId': 'queueDurableWrap',
			'validation': '',
			'type': 'select',
			'style': 'display: none;'
		},
		'queueExclusive': {
			'fieldId': 'queueExclusiveSelector',
			'wrapId': 'queueExclusiveWrap',
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'select'
		},
		'queueAutoDelete': {
			'fieldId': 'queueAutoDeleteSelector',
			'wrapId': 'queueAutoDeleteWrap',
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'select'
		},
		'connectionType':{
			'style': 'display: none;',
			'type': 'text'
		},
		'configurableUIFields': true
	},
	'custom-channel': {
		'channelPlugin': {
			'validation': 'data-parsley-required="true" data-parsley-pattern="^([a-zA-Z][A-Za-z0-9_$]*[.]{1})*([A-Z][A-Za-z0-9_$]*)$" data-parsley-pattern-message="'+i18N['sax.notification.invalidValue']+'"',
			'type': 'text'
		},
		'configurableUIFields': true
	},
	'replay-channel': {
		'replayCount': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'topologyName': {
			'validation': '',
			'type': 'text',
			'style': 'display: none;'
		},
		'maxRetries': {
			'validation': 'data-parsley-required="true" data-parsley-type="number" data-parsley-required="true" data-parsley-min="1"',
			'type': 'text'
		},
		'x-message-ttl': {
			'validation': 'data-parsley-required="true" data-parsley-type="number" data-parsley-required="true" data-parsley-min="1"',
			'type': 'text'
		}
	},
	'custom-processor': {
		'executorPlugin': {
			'validation': 'data-parsley-required="true" data-parsley-pattern="^([a-zA-Z][A-Za-z0-9_$]*[.]{1})*([A-Z][A-Za-z0-9_$]*)$" data-parsley-pattern-message="'+i18N['sax.notification.invalidValue']+'"',
			'type': 'text'
		},
		'configurableUIFields': true
	},
	'persistence-processor': {
		'isBatchEnable': {
			'fieldId': 'batchEnableSelector',
			'wrapId': 'batchEnableWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'batchSize': {
			'wrapId': 'batchSizeWrap',
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"',
			'type': 'text'
		}
	},
	'pmml-processor': {
		'sax.pmml.file.path': {
			'validation': 'data-parsley-required="true" data-parsley-path=""',
			'type': 'text'
		},
		'pmml.messageName': {
			'fieldId': 'pmmlMsgSelector',
			'wrapId': 'pmmlMsgWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		}
	},
	'validator-processor': {
		'exchangeName': {
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'text'
		},
		'routingKey': {
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'text'
		}
	},
	'timer-processor': {
		'timerPlugin': {
			'validation': 'data-parsley-required="true" data-parsley-pattern="^([a-zA-Z][A-Za-z0-9_$]*[.]{1})*([A-Z][A-Za-z0-9_$]*)$" data-parsley-pattern-message="'+i18N['sax.notification.invalidValue']+'"',
			'type': 'text'
		},
		'tickFrequencyInSeconds': {
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"',
			'type': 'text'
		},
		'tupleQueueSize': {
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"',
			'style': 'display: none;',
			'type': 'text'
		},
		'configurableUIFields': true
	},
	'filter-processor': {
		'filterQuery': {
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'text'
		}
	},
	'custom-cep-processor': {
		'cep.query': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'cep.query.messageName': {
			'fieldId': 'customCEPMsgSelector',
			'wrapId': 'customCEPMsgWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'cepAction': {
			'validation': '',
			'style': 'display: none;',
			'type': 'text'
		}
	},
	'aggregation-function-processor': {
		'cep.query': {
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'text'
		},
		'cep.query.messageName': {
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'text'
		},
		'cepAction': {
			'validation': '',
			'style': 'display: none;',
			'type': 'text'
		}
	},
	'dynamic-cep-processor': {
		'messageNames': {
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'text'
		}
	},
	'hdfs-emitter': {
		'isBatchEnable': {
			'fieldId': 'batchEnableSelector',
			'wrapId': 'batchEnableWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'batchSize': {
			'wrapId': 'batchSizeWrap',
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"',
			'type': 'text'
		},
		'hdfsPath': {
			'validation': 'data-parsley-required="true" data-parsley-pattern="^/([A-Za-z0-9_-]+[/]?)*$" data-parsley-pattern-message="'+i18N['sax.label.InvalidPathPattern']+'"',
			'type': 'text'
		},
		'hdfsFilePrefix': {
			'validation': 'data-parsley-required="true" data-parsley-pattern="^[A-Za-z0-9]*$" data-parsley-pattern-message="'+i18N['sax.parsley.message.charAllowed']+'"',
			'placeholder': i18N['sax.placeholder.enterHDFSPrefix'],
			'type': 'text'
		},
		'syncSize': {
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"',
			'type': 'text'
		},
		'blockSize': {
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1048576" data-parsley-blockSize=""',
			'type': 'text'
		},
		'maxFileSize': {
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="0"',
			'type': 'text'
		},
		'controlFile': {
			'validation': '',
			'type': 'checkbox'
		},
		'replication': {
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1" data-parsley-max="9"',
			'type': 'text'
		},
		'outputType': {
			'fieldId': 'hdfsOutputTypeSelector',
			'wrapId': 'hdfsOutputTypeWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'delimiter': {
			'fieldId': 'configDelimiterWrapSelector',
			'wrapId': 'configDelimiterWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'compressionType': {
			'fieldId': 'hdfsCompressionTypeSelector',
			'wrapId': 'hdfsCompressionTypeWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'rotationPolicy': {
			'fieldId': 'hdfsRotationPolicyId',
			'wrapId': 'hdfsRotationPolicyIDWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'fields': {
			'fieldId': 'hdfsFieldsId',
			'wrapId': 'hdfsFieldsIdWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select',
			'multiple': true
		},
		'fileRotationTime': {
			'validation': 'data-parsley-required="true"',
			'type': 'text',
			'fieldId': 'hdfsFileRotationTimeId',
			'wrapId': 'hdfsFileRotationTimeIDWrap'
		},
		'fileRotationSize': {
			'validation': 'data-parsley-required="true"',
			'type': 'text',
			'fieldId': 'hdfsFileRotationSizeId',
			'wrapId': 'hdfsFileRotationSizeIDWrap'
		},
		'dataStore': {
			'fieldId': 'dataStore',
			'wrapId': 'dataStoreWrap',
			'type': 'text',
			'style': 'display: none;'
		}
	},
	'dmxh-processor': {
		'messageName': {
			'fieldId': 'syncsortMsgSelector',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'TaskFile': {
			'validation': 'data-parsley-required="true" data-parsley-required-message="'+i18N['sax.parsley.message.required.upload']+'" readonly="readonly"',
			'type': 'text'
		}
	},
	'analytics-processor': {
		
	},
	'kafka-emitter': {
		'topicName': {
			'validation':'data-parsley-required="true"',
			'type': 'text'
		},
		'replicationFactor': {
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1" data-parsley-max="9"',
			'type': 'text'
		},
		'partitions': {
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1" data-parsley-max="999"',
			'type': 'text'
		},
		'producerType': {
			'fieldId': 'configProducerTypeSelector',
			'wrapId': 'configProducerTypeWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'outputFormat': {
			'fieldId': 'configOutputFormatSelector',
			'wrapId': 'configOPFormatWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'delimiter': {
			'fieldId': 'configDelimiterSelector',
			'wrapId': 'configDelimiterWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'outputFields': {
			'fieldId': 'configOutputFieldsSelector',
			'wrapId': 'configOutputFieldsWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select',
			'multiple': true
		}
	},
	'router-emitter': {
	},
	'stream-emitter': {
		'rt_stream_criteria': {
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'text'
		},
		'zk.parent.node': {
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'text'
		},
		'zk.realtime.child.node': {
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'text'
		},
		'StreamId': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'routingKey': {
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'text'
		}
	},
	'rabbitmq-emitter': {
		'exchangeName': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'outputFormat': {
			'fieldId': 'configOutputFormatSelector',
			'wrapId': 'configOPFormatWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'delimiter': {
			'fieldId': 'configDelimiterSelector',
			'wrapId': 'configDelimiterWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'outputFields': {
			'fieldId': 'configOutputFieldsSelector',
			'wrapId': 'configOutputFieldsWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select',
			'multiple': true
		},
		'exchangeType': {
			'fieldId': 'exchangeTypeSelector',
			'wrapId': 'exchangeTypeWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'exchangeDurable': {
			'fieldId': 'exchangeDurableSelector',
			'wrapId': 'exchangeDurableWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'exchangeAutoDelete': {
			'fieldId': 'exchangeAutoDeleteSelector',
			'wrapId': 'exchangeAutoDeleteWrap',
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'select'
		},
		'routingKey': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'queueName': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'queueDurable': {
			'fieldId': 'queueDurableSelector',
			'wrapId': 'queueDurableWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'queueExclusive': {
			'fieldId': 'queueExclusiveSelector',
			'wrapId': 'queueExclusiveWrap',
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'select'
		},
		'queueAutoDelete': {
			'fieldId': 'queueAutoDeleteSelector',
			'wrapId': 'queueAutoDeleteWrap',
			'validation': 'data-parsley-required="true"',
			'style': 'display: none;',
			'type': 'select'
		},
		'configurableUIFields': true
	},
	'activemq-emitter' : {
		'topicConfig': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'outputFormat': {
			'fieldId': 'configOutputFormatSelector',
			'wrapId': 'configOPFormatWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'delimiter': {
			'fieldId': 'configDelimiterSelector',
			'wrapId': 'configDelimiterWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'outputFields': {
			'fieldId': 'configOutputFieldsSelector',
			'wrapId': 'configOutputFieldsWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select',
			'multiple': true
		},
		'exchangeName': {
			'validation': '',
			'type': 'text',
			'style': 'display: none;'
		},
		'exchangeType': {
			'validation': '',
			'type': 'select',
			'style': 'display: none;'
		},
		'exchangeAutoDelete': {
			'validation': '',
			'type': 'select',
			'style': 'display: none;'
		},
		'exchangeDurable': {
			'validation': '',
			'type': 'select',
			'style': 'display: none;'
		},
		'routingKey': {
			'validation': 'data-parsley-pattern="^[A-Za-z0-9._-]*$" data-parsley-pattern-message="'+i18N['sax.parsley.message.charAllowed']+'"',
			'type': 'text'		},
		'queueName': {
			'validation': '',
			'type': 'text',
			'style': 'display: none;'
		},
		'queueDurable': {
			'validation': '',
			'type': 'select',
			'style': 'display: none;'
		},
		'queueExclusive': {
			'validation': '',
			'type': 'select',
			'style': 'display: none;'
		},
		'queueAutoDelete': {
			'validation': '',
			'type': 'select',
			'style': 'display: none;'
		}
	},
	'cassandra-emitter': {
		'dataStore': {
			'wrapId': 'dataStoreWrap',
			'style': 'display: none;',
			'type': 'text'
		},
		'isBatchEnable': {
			'fieldId': 'batchEnableSelector',
			'wrapId': 'batchEnableWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'batchSize': {
			'wrapId': 'batchSizeWrap',
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"',
			'type': 'text'
		},
		'hosts': {
			'validation': 'data-parsley-required="true"',
			'type': 'text',
			'value' : ''
		},
		'username': {
			'validation': 'data-parsley-required="true"',
			'type': 'text',
			'value' : ''
		},
		'password': {
			'validation': 'data-parsley-required="true"',
			'type': 'password',
			'value' : ''
		},
		'tableNameExpression': {
			'validation': 'data-parsley-required="true" data-parsley-maxlength="255"',
			'type': 'textarea',
			'wrapId' : 'tableNameExpWrap'
		},
		'compression': {
			'value' : '',
			'wrapId' : 'compressionEnableWrap',
			'type': 'checkbox'
		},
		'replicationStrategy': {
			'validation': 'data-parsley-required="true"',
			'type': 'text',
			'value' : ''
		},
		'replicationFactor': {
			'validation': 'data-parsley-required="true"',
			'type': 'text',
			'value' : ''
		},
		'thriftClientRetries': {
			'validation': 'data-parsley-required="true"',
			'type': 'text',
			'value' : ''
		},
		'thriftClientRetriesIntervalInMs': {
			'validation': 'data-parsley-required="true"',
			'type': 'text',
			'value' : ''
		}
		
	},
	'hbase-emitter': {
		'dataStore': {
			'wrapId': 'dataStoreWrap',
			'style': 'display: none;',
			'type': 'text'
		},
		'isBatchEnable': {
			'fieldId': 'batchEnableSelector',
			'wrapId': 'batchEnableWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'batchSize': {
			'wrapId': 'batchSizeWrap',
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"',
			'type': 'text'
		},
		'zkHosts': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'zkPort': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'masterHost': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'hdfsUser': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'masterPort': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'tableNameExpression': {
			'validation': 'data-parsley-required="true" data-parsley-maxlength="255"',
			'type': 'textarea',
			'wrapId' : 'tableNameExpWrap'
		},
		'compression': {
			'value' : '',
			'wrapId' : 'compressionEnableWrap',
			'type': 'checkbox'
		},
		'regionSplittingDefinition':{
			'wrapId' : 'regnSplitDefWrap',
			'type' : 'radio'
		},
		'regionBoundaries':{
			'wrapId' : 'regBoundaryWrap',
			'fieldId' : 'regBoundaryFld',
			'type' : 'text'
		},
		'clientRetriesNumber': {
			'validation': 'data-parsley-required="true"',
			'type': 'text',
			'value' : ''
		},
		'zk.recovery.retry': {
			'validation': 'data-parsley-required="true"',
			'type': 'text',
			'value' : ''
		},
		'hbase.zk.parent.node': {
			'validation': 'data-parsley-required="true"',
			'type': 'text',
			'value' : ''
		},
		'excludeEmptyFields': {
			'value' : '',
			'wrapId' : 'excludeEmptyFieldsWrap',
			'type': 'checkbox'
		},
		'encoding': {
			'fieldId': 'encodingSelector',
			'wrapId': 'encodingWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		}
	},
	'solr-emitter': {
		'isBatchEnable': {
			'fieldId': 'batchEnableSelector',
			'wrapId': 'batchEnableWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'batchSize': {
			'wrapId': 'batchSizeWrap',
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"',
			'type': 'text'
		},
		'acrossFieldSearchEnabled': {
			'fieldId': 'acrossFieldSearchEnabled',
			'wrapId': 'acrossFieldSearchEnabledWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'indexNumberOfShards': {
			'fieldId': 'indexNumberofShards',
			'wrapId': 'indexNumberofShardsWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'indexReplicationFactor': {
			'fieldId': 'indexReplicationFactor',
			'wrapId': 'indexReplicationFactorWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'indexExpression': {
			'fieldId': 'indexExpression',
			'wrapId': 'indexExpressionWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'textarea'
		},
		'routingRequired': {
			'fieldId': 'routingRequired',
			'wrapId': 'routingRequiredWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'routingPolicy': {
			'fieldId': 'routingPolicy',
			'wrapId': 'routingPolicyWrap',
			'type': 'text',
			'placeholder': i18N['sax.placeholder.pleaseEnterJSONValue']
		},
		'timestamp_alias': {
			'fieldId': 'timestampAlias',
			'wrapId': 'timestampAliasWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'indexSource': {
			'fieldId': 'indexSource',
			'wrapId': 'indexSourceWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'indexStore': {
			'fieldId': 'indexStore',
			'wrapId': 'indexStoreWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		}
		
	},
	'elasticsearch-emitter': {
		'isBatchEnable': {
			'fieldId': 'batchEnableSelector',
			'wrapId': 'batchEnableWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'batchSize': {
			'wrapId': 'batchSizeWrap',
			'validation': 'data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"',
			'type': 'text'
		},
		'indexStore': {
			'fieldId': 'indexStore',
			'wrapId': 'indexStoreWrap',
			'validation': 'data-parsley-required="true"',
			'type' : 'text'
		},
		'acrossFieldSearchEnabled': {
			'fieldId': 'acrossFieldSearchEnabled',
			'wrapId': 'acrossFieldSearchEnabledWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'indexNumberOfShards': {
			'fieldId': 'indexNumberofShards',
			'wrapId': 'indexNumberofShardsWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'indexReplicationFactor': {
			'fieldId': 'indexReplicationFactor',
			'wrapId': 'indexReplicationFactorWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'indexExpression': {
			'fieldId': 'indexExpression',
			'wrapId': 'indexExpressionWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'textarea'
		},
		'routingRequired': {
			'fieldId': 'routingRequired',
			'wrapId': 'routingRequiredWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'routingPolicy': {
			'fieldId': 'routingPolicy',
			'wrapId': 'routingPolicyWrap',
			'type': 'text',
			'placeholder': i18N['sax.placeholder.pleaseEnterJSONValue']
		},
		'timestamp_alias': {
			'fieldId': 'timestampAlias',
			'wrapId': 'timestampAliasWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'indexSource': {
			'fieldId': 'indexSource',
			'wrapId': 'indexSourceWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'clusterName': {
			'fieldId': 'clusterName',
			'wrapId': 'clusterNameWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'componentType': {
			'fieldId': 'componentType',
			'wrapId': 'componentTypeWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		}
	},
	'jdbc-processor': {
		'messageName': {
			'fieldId': 'jdbcMsgSelector',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'executorPlugin': {
			'type': 'text',
			'style': 'display: none;'
		},
		'mappedSchema': {
			'type': 'text',
			'style': 'display: none;'
		},
		'databaseType': {
			'fieldId': 'databaseType',
			'wrapId': 'databaseTypeWrap',
			'validation': 'data-parsley-required="true"',
			'type': 'select'
		},
		'connectionURL': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'username': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		},
		'password': {
			'validation': 'data-parsley-required="true"',
			'type': 'password'
		},
		'tableName': {
			'validation': 'data-parsley-required="true"',
			'type': 'text'
		}
	},
	'funcCreateTextField': function(key, val, obj, curChnl) {
		var wrapperId = (obj.wrapId) ? obj.wrapId : '';
		var fieldId = (obj.fieldId) ? obj.fieldId : '';
		var style = (obj.style) ? obj.style : '';
		var placeholder = (obj.placeholder) ? obj.placeholder : i18N['sax.placeholder.pleaseEnterValue'];
		var disabledKey = (obj.type) ? 'disabled' : '';
		var validation = (obj.validation) ? obj.validation : 'data-parsley-required="true"';
		var type = obj.type
		var fieldHTML = '';
		
		/*if ( (curChnl.id == cmpIDs.rabbitmqchannel || curChnl.id == cmpIDs.rabbitmqemitter) && $.isEmptyObject(obj) ) {
			validation += ' data-parsley-pattern="^[A-Za-z0-9_-]*$" data-parsley-pattern-message="'+ i18N['sax.message.keyValueMsz'] +'"';
		}*/
		
		fieldHTML = '<div id="'+ wrapperId +'" class="config-row '+wrapperId+'" style="'+ style +'"><div class="col-sm-6"><input type="text" placeholder="'+i18N['sax.placeholder.property']+'" class="form-control config-key" value="'+ key +'" data-parsley-required="true" data-parsley-duplicateKeys="" '+ disabledKey +'></div><div class="col-sm-6"><input type="'+type+'" id="'+ fieldId +'" class="form-control config-value tt '+ key +'-fld" value="'+val+'" title="'+ val +'" placeholder="'+ placeholder +'" '+ obj.validation +'></div>';

		if ( key == 'TaskFile' )
			fieldHTML += '<span title="'+i18N['sax.title.uploadFile']+'" class="config-ico upload-syncsort-file tt"><i class="fa fa-upload"><input id="uploadSyncsortFile" type="file" name="files[]"></i></span>';
		
		return fieldHTML;
	},
	'funcCreateCBWithoutLabel' : function(key, val, obj){
		var fieldHTML = '';
		var disabledKey = (obj.type) ? 'disabled' : '';
		var isChecked = val == 'true' ? 'checked' : '';
		var wrapperId = (obj.wrapId) ? obj.wrapId : '';
		fieldHTML = '<div id="'+ wrapperId +'" class="config-row '+wrapperId+'"><div class="col-sm-6"><input type="text" placeholder="'+i18N['sax.placeholder.property']+'" class="form-control config-key" value="'+ key +'" '+ disabledKey +'></div><div class="col-sm-6"><input type="'+obj.type+'" class="checkbox config-value tt '+ key +'-fld" '+isChecked+'></div>';
		
		return fieldHTML;
	},
	'funcCreateCBWithLabel' : function(key, val, obj, lbl){
		var fieldHTML = '';
		var disabledKey = (obj.type) ? 'disabled' : '';
		var isChecked = val == 'true' ? 'checked' : '';
		var wrapperId = (obj.wrapId) ? obj.wrapId : '';
		fieldHTML = '<div id="'+ wrapperId +'" class="config-row '+wrapperId+'"><div class="col-sm-6"><input type="text" placeholder="'+i18N['sax.placeholder.property']+'" class="form-control config-key" value="'+ key +'" '+ disabledKey +'></div><div class="col-sm-6"> <input type="'+obj.type+'" class="checkbox config-value tt '+ key +'-fld" '+isChecked+' title="'+ lbl +'">' +'</div>';
		
		return fieldHTML;
	},
	'funcCreateTextarea' : function(key, val, obj) {
		var fieldHTML = '';
		var placeholder = (obj.placeholder) ? obj.placeholder : i18N['sax.placeholder.pleaseEnterValue'];
		var disabledKey = (obj.type) ? 'disabled' : '';
		var wrapperId = (obj.wrapId) ? obj.wrapId : '';
		var nsLabel = "";
		if( key == 'tableNameExpression' && $('#dataStoreWrap').find('.config-value').val() == 'hbase' ) {
			nsLabel = val == "" ? "'ns_"+ currentTenantId+":'" : "";
		} else if ( key == 'indexExpression' || key == 'tableNameExpression' ) {
			nsLabel = val == "" ? "'ns_"+ currentTenantId+"_'" : "";
		}
		
		fieldHTML = '<div id="'+ wrapperId +'" class="config-row '+wrapperId+'"><div class="col-sm-6"><input type="text" placeholder="'+i18N['sax.placeholder.property']+'" class="form-control config-key" value="'+ key +'" '+ disabledKey +'></div><div class="col-sm-6"><textarea placeholder="'+placeholder+'" class="form-control config-value tt '+ key +'-fld" '+obj.validation+'>'+ nsLabel + val +'</textarea></div>';
		
		return fieldHTML;
	},
	'funcCreateRadioFld' : function(key, val, opts, obj){
		var fieldHTML = '';
		var style = (obj.style) ? obj.style : '';
		var disabledKey = (obj.type) ? 'disabled' : '';
		var type = obj.type;
		var radioElements = '';
		var radioOpts = '';
		var isSelected = '';
		var wrapperId = (obj.wrapId) ? obj.wrapId : '';
		
		fieldHTML = '<div id="'+ wrapperId +'" class="config-row '+wrapperId+'" style="'+ style +'"><div class="col-sm-6"><input type="text" placeholder="'+i18N['sax.placeholder.property']+'" class="form-control config-key" value="'+ key +'" '+ disabledKey +'></div><div class="col-sm-6">'+ opts +'</div>';

		return fieldHTML;
	},
	'funcCreateSelectField': function(key, val, options, obj) {
		var wrapperId = (obj.wrapId) ? obj.wrapId : '';
		var fieldId = (obj.fieldId) ? obj.fieldId : '';
		var style = (obj.style) ? obj.style : '';
		var placeholder = (obj.placeholder) ? obj.placeholder : i18N['sax.placeholder.pleaseEnterValue'];
		var multiple = (typeof obj.multiple !== 'undefined' && obj.multiple) ? 'multiple' : '';
		
		return '<div id="'+ wrapperId +'" class="config-row '+wrapperId+'" style="'+ style +'"><div class="col-sm-6"><input type="text" placeholder="'+i18N['sax.placeholder.property']+'" class="form-control config-key" value="'+ key +'" disabled></div><div class="col-sm-6"><div><select id="'+ fieldId +'" class="form-control config-value tt '+ key +'-fld" title="'+ val +'" '+ obj.validation +' '+ multiple +'>'+ options +'</select></div></div>';
	}
};

var curSelectedObj = { 'title': '', 'item': {} };
var tplHolder = "#topologyGraph";
var tplParentHolder = "#topologyGraphWrap";
var lastAddedShap;
var isDelimited = false;
var editCmpID = null;
var connectorPaintStyle, sArea;
var sltrArea = {left:'', top:'', right:'', bottom:''}, objArea = {left:'', top:'', right:'', bottom:''};
var redrawObj=[], tmpSSData={}, pendingConn=[], boltsData;

jsPlumb.ready(function() {
	connectorPaintStyle = {
		lineWidth:5,
		strokeStyle:"#bbbbbb",
		joinstyle:"round",
		outlineColor:"white",
		outlineWidth:2
	},
	connectorHoverStyle = {
		lineWidth:5,
		strokeStyle:"#777777",
		outlineWidth:2,
		outlineColor:"white"
	},
	endpointHoverStyle = {
		fillStyle:"#777777",
		strokeStyle:"#777777"
	},
	sourceEndpoint = {
		//anchor: "RightMiddle",
		endpoint:"Dot",
		paintStyle:{ 
			strokeStyle:"#bbbbbb",
			fillStyle:"#ffffff",
			radius:6,
			lineWidth:2 
		},				
		isSource:true,
		maxConnections:10,
		connector:[ "Flowchart", { stub:[20, 20], gap:4, cornerRadius:4, alwaysRespectStubs:true } ],								                
		connectorStyle:connectorPaintStyle,
		dragOptions:{},
		overlays:[
			[ "Label", { 
				location:[0.5, 1.5], 
				label:"",
				cssClass:"endpointSourceLabel" 
			} ]
		]
	},		
	targetEndpoint = {
		endpoint:"Dot",					
		paintStyle:{ fillStyle:"#bbbbbb", radius:6 },
		maxConnections:-1,
		dropOptions:{ hoverClass:"hover", activeClass:"active" },
		isTarget:true,		
		overlays:[
			[ "Label", { location:[0.5, -0.5], label:"", cssClass:"endpointTargetLabel" } ]
		]
	};

		
	$('#streamIdFilterAddBtn').on("click", function() {
		filerCriteriaCls.initTemplate([], 'streamId');
		$('#streamIdFilterIntroWrap').hide();
		$('#streamIdFilterWrap').show();
		DFSubSytemDefination.initPopovers();
	});
	
	// Add new shape
	var errorMsgsLostFlag = false;
	$(document).on("click", "#ssToolbarAccordion ul.components-list div.cmp-item a", function(e){
		var role = $(this).attr("role");
		var analyticsAlgo = $(this).attr("algo-id");
		if ( role == "" ) {
			var randomId = createRandomNumber();
			var uiid = $(this).attr("ui-id");
			var shapeLabel = $(this).text();
			var cls = $(this).attr("class");
			var type = $(this).attr("ui-type");
			var isEmpty = $(tplHolder).is(":empty");
			var isCustom = $(this).attr("ui-custom");
			var isIconAva = $(this).attr("ui-icon-ava");
			var uiname = $(this).attr("ui-name");
			if ( isEmpty && type != "channel" ) {
				bootbox.alert(i18N['sax.notification.addChannel']);
				return false;

			}
			
			if ( uiid == cmpIDs.replaychannel ) {
				var hasReplayChannel = false;
				if ( $('#topologyGraph > div[ui-id="'+ cmpIDs.replaychannel +'"]').size() > 0 ) {
					hasReplayChannel = true;
				}
				
				if ( hasReplayChannel ) {
					bootbox.alert(i18N['sax.notification.alertMoreThanOneReplay']);
					return false;
				}
				
				if ( !$.isEmptyObject(tmpSSData) ) {
					for ( var i=0; i<tmpSSData.spouts.length; i++ ) {
						if ( tmpSSData.spouts[i].id == cmpIDs.replaychannel ) errorMsgsLostFlag = true;
					}
					
					if ( !hasReplayChannel && !errorMsgsLostFlag ) {
						bootbox.confirm(i18N["sax.notification.errorMessagesLost"], function(confirmation) {
							if ( confirmation ) {
								errorMsgsLostFlag = true;
								$("#ssToolbarAccordion a[ui-id='"+ uiid +"']").trigger("click");
							}
						});
						return false;
					}
					errorMsgsLostFlag = false;
				}
			}
			
			var isFeatureSupported = DFSubSytemDefination.checkComponentSupport(uiid);
			if ( !isFeatureSupported ) return false;

			var d = new Date();
			var lbl = shapeLabel.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '');
			lbl = lbl.toLowerCase().replace(/\b[a-z]/g, function(letter) {
				return letter.toUpperCase();
			});
			
			var shapeName;
			if ( editCmpID == null ) shapeName = lbl + '_' + randomId;
			else shapeName = editCmpID;
			var Div, pos = {};
			var imgSrc = '';
			if ( isCustom == 'true' || isCustom == true ) {
				if ( isIconAva == 'true' || isIconAva == true ) {
					imgSrc = baseUrl+'/resources/images/custom/'+uiname.toLowerCase()+'.png';
				} else {
					if ( type == "channel" ) {
						imgSrc = baseUrl+'/resources/images/component/channel-custom.png';
					} else {
						imgSrc = baseUrl+'/resources/images/component/processor-custom.png';
					}
				}
			} else {
				imgSrc = baseUrl+'/resources/images/component/'+uiid+'.png';
			}
			
			if ( jQuery.isEmptyObject(dragDropObj) ) {
				if ( lastAddedShap ) {
					pos = $("#"+lastAddedShap).position();
					pos.left += 250;
				} else {
					pos['left'] = 100;
					pos['top'] = 60;
				}
			} else {
				pos['left'] = dragDropObj.left;
				pos['top'] = dragDropObj.top;
			}
			
			if( $('#'+shapeName).size() == 0 ) {
				Div = $('<div>', { id: shapeName }).attr("pos-left", pos.left).attr("pos-top", pos.top).css({ left: pos.left, top: pos.top }).appendTo( tplHolder );
				$(Div).html('<img src="'+imgSrc+'"/><span>'+ shapeLabel +'</span>').attr({"class":cls+' '+uiid, "data-shape":cls, "ui-id": uiid, "ui-type": type}).addClass('shape');
			} else {
				Div = $('#'+shapeName);
			}
			
			var divW = $(Div).width();
			var txtW = $(Div).find("span").outerWidth();
			if ( txtW > divW ) $(Div).find("span").css("margin-left", -(txtW/2 - divW/2));
			var targetUUID = shapeName + "LeftMiddle";
			var sourceUUID = shapeName + "RightMiddle";
			
			if ( type != "channel" )
				jsPlumb.addEndpoint($(Div), targetEndpoint, {anchor: "LeftMiddle", uuid: targetUUID});
			jsPlumb.addEndpoint($(Div), sourceEndpoint, {anchor: "RightMiddle", uuid: sourceUUID});
			
			jsPlumb.draggable($(Div), { grid: [20, 20], 
				drag: function(e, ui) {
					var $this = $(this);
					if ( $this.hasClass("active") ) {
						var originalPos = ui.originalPosition;
						var pos = ui.position;
						pos.left = ( pos.left <= 0 ) ? 0 : pos.left;
						pos.top = ( pos.top <= 0 ) ? 0 : pos.top;
							
						$this.siblings(".shape.active").each(function(i, el) {
							var leftPos = parseInt( $(el).attr("pos-left") ) + (pos.left - originalPos.left);
							var topPos = parseInt( $(el).attr("pos-top") ) + (pos.top - originalPos.top);
							
							if ( topPos > 0 ) $(el).css({top: topPos});
							if ( leftPos > 0 ) $(el).css({left: leftPos});
						});
					} else {
						var pos = ui.position;
						if ( pos.left < 0 ) ui.position.left = 0;
						if ( pos.top < 0 ) ui.position.top = 0;
					}
					jsPlumb.repaintEverything();
				},
				stop: function(e, ui) {
					$(".shape").each(function(i, el) {
						var leftPos = $(el).css('left').replace('px', '');
						var topPos = $(el).css('top').replace('px', '');
						$(el).attr("pos-left", leftPos).attr("pos-top", topPos);
					});
					jsPlumb.repaintEverything();
				}
			});
			
			if ( editCmpID == null ) {
				for ( var i=0; i<allChannelsData[cls].length; i++ ) {
					if ( allChannelsData[cls][i].id == uiid ) {
						if ( type == "channel" ) {
							var curObj = jQuery.extend(true, {}, allChannelsData[cls][i]);
							addedSpoutsObj[shapeName] = curObj;
							addedSpoutsObj[shapeName].name = shapeName;
							addedSpoutsObj[shapeName].channelType = "multi";
						} else {
							var curObj = jQuery.extend(true, {}, allChannelsData[cls][i]);
							addedBoltsObj[shapeName] = curObj;
							addedBoltsObj[shapeName].name = shapeName;
							addedBoltsObj[shapeName].channelType = "multi";
						}
					}
				}
			}
			lastAddedShap = shapeName;
			setEnableButton();
			DFSubSytemDefination.scrollLeftWindow($(Div));
			if (uiid == cmpIDs.dynamiccepprocessor) dynamicCEPCount++;
			if ( analyticsAlgo ) addedBoltsObj[shapeName].algorithm = analyticsAlgo;
		}
	});
	
	// Select/Deselect Shape
	$(document).on("click", ".shape", function(e){
		curSelectedObj.title = "";
		curSelectedObj.item = new Object();
		
		$(this).siblings(".shape").removeClass("active");
		$(this).toggleClass("active");
		if ( $(this).hasClass("active") ) {
			curSelectedObj.title = "shape";
			curSelectedObj.item = jsPlumb.getSelector( $(this) );
		}
		var c = jsPlumb.getConnections();
		for(i=0; i<c.length; i++) {
			c[i].setPaintStyle( connectorPaintStyle );
		}
	});
	
	// Delete Shape/Connection
	$(document).keyup(function(e){
		if( (e.which == 46 || e.which == 68)&& curSelectedObj.title == "line" ) {
			jsPlumb.detach( curSelectedObj.item );
			$("#channelsModalWrap").modal("hide");
			$(".select2-display-none").hide();
			DFSubSytemDefination.setMessageTypes();
		} else if( (e.which == 46 || e.which == 68) && $(".shape.active").size() > 0 ) {
			$(".shape.active").each(function() {
				var $this = $(this);
				var id = $this.attr("id");
				var type = $this.attr("ui-type");
				var name;
				if ( type == "channel" ) {
					name = addedSpoutsObj[id].name;
					var wasAddedReplay = false;
					if ( !$.isEmptyObject(tmpSSData) && addedSpoutsObj[id].id == cmpIDs.replaychannel ) {
						for ( var i=0; i<tmpSSData.spouts.length; i++ ) {
							if ( tmpSSData.spouts[i].id == cmpIDs.replaychannel ) wasAddedReplay = true;
						}
					}
					if ( wasAddedReplay ) {
						bootbox.confirm(i18N["sax.notification.errorMessagesLost"], function(confirmation) {
							if ( confirmation ) {
								jsPlumb.detachAllConnections( jsPlumb.getSelector( $this ) );
								jsPlumb.removeAllEndpoints( jsPlumb.getSelector( $this ) );
								delete addedSpoutsObj[id];
								$this.remove();
								lastAddedShap = $(tplHolder).find(".shape:last").attr("id");
								setEnableButton();
							}
						});
					} else {
						jsPlumb.detachAllConnections( jsPlumb.getSelector( $this ) );
						jsPlumb.removeAllEndpoints( jsPlumb.getSelector( $this ) );
						delete addedSpoutsObj[id];
						$this.remove();
						lastAddedShap = $(tplHolder).find(".shape:last").attr("id");
						setEnableButton();
					}
				} else {
					jsPlumb.detachAllConnections( jsPlumb.getSelector( $this ) );
					jsPlumb.removeAllEndpoints( jsPlumb.getSelector( $this ) );
					name = addedBoltsObj[id].name;
					resetComponentsId(addedBoltsObj, name);
					DFAnalytics.removePMMLFile( 'pmmlFile' + name.split('_')[1] );
					delete addedBoltsObj[id];
					$this.remove();
					lastAddedShap = $(tplHolder).find(".shape:last").attr("id");
					setEnableButton();
				}
				
				$("#channelsModalWrap").modal("hide");
				$(".select2-display-none").hide();
			});
			var size = $(tplHolder).find(".shape").size();
			if ( size == 0 ) $("#saveSubSystemModalLink").addClass("disabled");
		}
		e.stopPropagation();
	});
	
	// Show Properties Modal
	$(document).bind('contextmenu', '.shape', function(e){ return false; });
	$(document).on("mousedown", ".shape", function(e){ 
		if( e.button == 2 ) {
			$(this).on('contextmenu', function(e){ e.preventDefault(); });
			if ( jQuery.inArray("shape", e.currentTarget.classList) > -1 ) {
				$('#channelProperties > .nav.nav-tabs').find('li:first a').trigger('click');
				$('#channelPropertiesForm > .modal-body').prepend('<div id="compPropertiesLoader" class="widget-loader">');
				$('#channelProperties').addClass('prop-visibility');
				var id = $(this).attr("id");
				var uiid = $(this).attr("ui-id");
				var type = $(this).attr("ui-type");
				var txt = $(this).text();
				var curChnl;
				$(".shape.active").removeClass('active');
				
				$("#curChannelId").val(uiid);
				$("#curChannelName").val(id);
				$("#curChannelLabel").val(txt);
				$('#channelErrorWrap').empty();
				$('#channelProperties, #saveChannelProp').show();
				$('#saveChannelProp').removeAttr('disabled');
				if ( type == "channel" ) {
					curChnl = addedSpoutsObj[id];
					$("#componentType").val("spout");
					$("#channelProperties").html(spoutEditHTML);
					$("#maxSpoutPending").val(curChnl.maxSpoutPending);
					
					if ( curChnl.channelType == "single" ) {
						$(".msgtype-radio[value='single']").trigger("click");
					} else if ( curChnl.channelType == "multi" ) {
						$(".msgtype-radio[value='multi']").trigger("click");
					}
					
					$("#messageTypeId").val(curChnl.messageTypes).trigger("change");
					
					if ( curChnl.id != cmpIDs.customchannel ) {
						var isSchemaId = false;
						for ( var i=0; i<allChannelsData.channels.length; i++ ) {
							var isSameChannel = (allChannelsData.channels[i].id == curChnl.id) ? true : false;
							var hasDiffIdentifier = (curChnl.schemaIdentifier != allChannelsData.channels[i].schemaIdentifier) ? true : false;
							var notContainNull = (curChnl.schemaIdentifier != null) ? true : false;
							if ( isSameChannel && hasDiffIdentifier && notContainNull )
								isSchemaId = true;
						}
						
						if ( isSchemaId ) {
							$('#schemaIdentifierCB').prop('checked', true).trigger('change');
							$('#schemeIdFld').val(curChnl.schemaIdentifier);
						}
					}
					if ( curChnl.id == cmpIDs.replaychannel ) {
						$('#messageTypeId').removeAttr('data-parsley-required');
					}
				} else {
					curChnl = addedBoltsObj[id];
					$("#componentType").val("bolt");
					$("#channelProperties").html(emitrConnEditHTML);
					if ( curChnl.id == cmpIDs.analyticsprocessor ) {
						$('a[href="#configTab21"]').text(i18N['sax.label.selectMessage']);
					} else {
						$('a[href="#configTab21"]').text(i18N['sax.label.configuration']);
					}
					
					if(currentFabricStatus=='ACTIVE'){
						$("#taskCount").val(curChnl.taskCount).attr("disabled", true);
					}else{
						$("#taskCount").val(curChnl.taskCount);
					}
					$("#messageTypeId").val(curChnl.messageTypes).trigger("change");
					
					// Check for message selected in Spout
					rootSpouts = [];
					getRootSpouts(curChnl);
					
					var hasMessageError = false, propErrorMsg='';
					if( $.isEmptyObject(addedSpoutsObj) ) {
						propErrorMsg = 'Please add atleast one Channel.';
						hasMessageError = true;
					} else if ( rootSpouts.length == 0 ) {
						propErrorMsg = i18N['sax.notification.dataFabricConnection'];
						hasMessageError = true;
					} else {
						propErrorMsg += i18N['sax.notification.selectMessage'];
						var propErrorChannles = [];
						for ( var i=0; i<rootSpouts.length; i++ ) {
							if ( addedSpoutsObj[rootSpouts[i]] && addedSpoutsObj[rootSpouts[i]].messageTypes.length == 0 && addedSpoutsObj[rootSpouts[i]].id != cmpIDs.replaychannel ) {
								propErrorChannles.push( '\''+ addedSpoutsObj[rootSpouts[i]].label +'\'' );
								hasMessageError = true;
							}
						}
						propErrorMsg = propErrorMsg + propErrorChannles.join(', ');
						
						if ( rootSpouts.length == 1 && addedSpoutsObj[rootSpouts[0]].id == cmpIDs.replaychannel ) {
							propErrorMsg = i18N['sax.notification.aloneReplayChnl'];
							hasMessageError = true;
						}
					}
					
					if ( hasMessageError ) {
						$('#channelErrorWrap').html('<div class="alert alert-danger">'+ propErrorMsg +'</div>');
						$('#channelProperties, #saveChannelProp').hide();
					}
				}
				
				activeComp = curChnl;
				
				DFSubSytemDefination.createFVAutoSuggestData(curChnl.messageTypes);
				$("#curChannelTitle span").text( txt );
				$("#channelName").val(curChnl.name);
				$("#className").val(curChnl.className);
				$("#parallelism").val(curChnl.parallelism);
				$('#channelsModalWrap .modal-dialog').width(900);
				$('#channelsModalWrap').modal({
					backdrop: 'static',
					keyboard: false
				});
				$('.modal-footer').find('button').removeClass('disabled');
				
				setTimeout(function() {
					var configKey='', configVal='';
					criteriaData = [];
					allMessages = curChnl.messageTypes;
					
					if ( curChnl.subtype && curChnl.subtype == "udf" ) {
						$('#curChannelTitle a').hide();
					} else {
						$('#curChannelTitle a').show();
					}
					
					if ( !hasMessageError ) {
						if ( curChnl.config != null ) {
							$("#configRows").empty();
							var DDValue='', isBatchEnable='true', propertyInfo='';
							var compType = $('#componentType').val();
							
							if ( curChnl.config.length > 0 ) {
								for ( var i=0; i<curChnl.config.length; i++ ) {
									var hasDD = false;
									var valPlaceholder = 'value';
									var configLen = curChnl.config[i].length;
									var colonIdx = curChnl.config[i].indexOf(":");
									configKey = curChnl.config[i].substring(0, colonIdx);
									configVal = curChnl.config[i].substring(colonIdx+1, configLen).trim();
									
									if ( configKey != "filterQuery" && configKey != "mvelfnclist" && configKey != "clusterName" && configKey != "componentType" && configKey != "zkHosts" && configKey != "zkPort" && configKey != "connectionName" && configKey != "connectionId" && configKey != "expfldlst" && configKey != "hdfsUser" && configKey != "customParserVersion" ) {
										var configRowHTML = '';
										configKey = ( configKey == 'zkID' ) ? 'offsetMarker' : configKey;
										propertyInfo = '<a href="javascript:void(0)" tabindex="-1" class="po infoico propico" title="'+ configKey +'" content="'+ uiid +'_'+ configKey +'"><i class="fa fa-info-circle"></i></a>';
										
										if ( configKey != 'queueConfig' && configKey != 'hdfsPaths' && configVal.indexOf('"') > -1 ) {
											configVal = configVal.replace(/"/g, '\"');
											configVal = configVal.replace(/'/g, "\'");
											pendingConfigKeys[configKey] = configVal;
											configVal = '';
										}
										
										if ( (uiid == cmpIDs.rabbitmqchannel || uiid == cmpIDs.rabbitmqemitter) && configKey == 'queueConfig' ) {
											if ( configVal != '' ) {
												var queueConfig = configVal.split('|');
												for ( var j=0; j<queueConfig.length; j++ ) {
													var queueConfigLen = queueConfig[j].length;
													var commaIdx = queueConfig[j].indexOf(",");
													var queueConfigKey = queueConfig[j].substring(0, commaIdx);
													var queueConfigVal = queueConfig[j].substring(commaIdx+1, queueConfigLen).trim();
													
													if ( queueConfigVal.indexOf('"') > -1 ) {
														queueConfigVal = queueConfigVal.replace(/"/g, '\"');
														queueConfigVal = queueConfigVal.replace(/'/g, "\'");
														pendingConfigKeys[configKey] = queueConfigVal;
														queueConfigVal = '';
													}
										
													configRowHTML += componentsProperties.funcCreateTextField(queueConfigKey, queueConfigVal, {}, curChnl);
													configRowHTML += '<a href="javascript:void(0)" title="Remove" class="remove-config remove-config-row remove-ico tt"><i class="fa fa-times"></i></a>';
													if ( j != queueConfig.length-1 )
														configRowHTML += '</div>';
												}
											}
										} else if ( uiid == cmpIDs.hdfsemitter && configKey == 'hdfsPaths' ) {
											HDFSBolt.initHDFSFPaths(curChnl, configVal);
										} else if ( uiid == cmpIDs.cassandraemitter && (configKey == "username" || configKey == "hosts" ||  configKey == "password" ||  configKey == "connectionRetries" )) {
											configRowHTML += '';
										} else if ( ( uiid == cmpIDs.rabbitmqchannel || uiid == cmpIDs.rabbitmqemitter || uiid == cmpIDs.activemqchannel || uiid == cmpIDs.activemqemitter || uiid == cmpIDs.replaychannel )  && ( configKey == "hosts" || configKey == "username" ||  configKey == "password" )) {
											configRowHTML += '';
										} else if ( uiid == cmpIDs.replaychannel &&  ( configKey == "source" || configKey == "discardedExchangeName" || configKey == "discardedQueueName" || configKey == "exchangeName" || configKey == "queueName" || configKey == "routingKey" || configKey == "x-dead-letter-exchange" || configKey == "x-dead-letter-routing-key" || configKey == "requeueOnFail" )) {
											configRowHTML += '';
										} else if ( ( uiid == cmpIDs.kafkachannel || uiid == cmpIDs.kafkaemitter || uiid == cmpIDs.replaychannel ) &&  ( configKey == "zkHosts" || configKey == "kafkaBrokers" ) ) {
											configRowHTML += '';
										} else if ( uiid == cmpIDs.elasticsearchemitter && configKey == "hosts" ) {
											configRowHTML += '';
										} else if ( uiid == cmpIDs.hdfsemitter && ( configKey == "fsURI" || configKey == "username" || configKey == "haEnabled" || configKey == "nameservices" || configKey == "namenode1Name" || configKey == "namenode1Host" || configKey == "namenode1RPCAddress" || configKey == "namenode2Name" || configKey == "namenode2Host" || configKey == "namenode2RPCAddress" ) ) {
											configRowHTML += '';
										} else if ( uiid == cmpIDs.hbaseemitter && ( configKey == "zkRecoveryRetry" || configKey == "zkParentNode" || configKey == "clientRetriesNumber") ) {
											configRowHTML += '';
										} else {
											if ( componentsProperties[uiid] && componentsProperties[uiid][configKey] ) {
												if ( componentsProperties[uiid][configKey].type == 'text' || componentsProperties[uiid][configKey].type == 'password' ) {
													configRowHTML = componentsProperties.funcCreateTextField(configKey, configVal, componentsProperties[uiid][configKey], curChnl);
												} else if ( componentsProperties[uiid][configKey].type == 'select' ) {
													hasDD = true;
													if ( configVal.indexOf('^^^') > -1 )
														configVal = configVal.split('^^^')[0];
													var options = createPropertyOptions(configKey, curChnl);
													configRowHTML = componentsProperties.funcCreateSelectField(configKey, configVal, options, componentsProperties[uiid][configKey]);
													if ( configVal != ',' && configVal.indexOf(',') > -1 )
														configVal = configVal.split(',');
												} else if ( (configKey == 'compression' || configKey == 'excludeEmptyFields') && componentsProperties[uiid][configKey].type == 'checkbox' ) {
													configRowHTML = componentsProperties.funcCreateCBWithoutLabel(configKey, configVal, componentsProperties[uiid][configKey]);
												} else if ( componentsProperties[uiid][configKey].type == 'textarea' ){
													configRowHTML = componentsProperties.funcCreateTextarea(configKey, configVal, componentsProperties[uiid][configKey]);
												} else if ( componentsProperties[uiid][configKey].type == 'radio' ) {
													if ( configVal.indexOf('^^^') > -1 )
														configVal = configVal.split('^^^')[0];
													var options = createRadioBtnOptions(configKey, configVal, curChnl);
													configRowHTML = componentsProperties.funcCreateRadioFld(configKey, configVal, options, componentsProperties[uiid][configKey]);
												}
												configRowHTML += propertyInfo;
											} else if ( componentsProperties[uiid] && componentsProperties[uiid].configurableUIFields ) {
												configRowHTML = componentsProperties.funcCreateTextField(configKey, configVal, {}, curChnl);
												//configRowHTML += '<a href="javascript:void(0)" title="'+i18N['sax.label.remove']+'" class="remove-config remove-config-row remove-ico tt"><i class="fa fa-times"></i></a>';
											} else {
												if ( configKey == "channelPlugin" || configKey == "executorPlugin" ) {
													configRowHTML = componentsProperties.funcCreateTextField(configKey, configVal, {'validation': 'data-parsley-required="true" readonly="readonly"', 'type': 'text'}, curChnl);
												} else if ( curChnl.subtype && curChnl.subtype == 'custom' ) {
													configRowHTML = componentsProperties.funcCreateTextField(configKey, configVal, {}, curChnl);
													//configRowHTML += '<a href="javascript:void(0)" title="'+i18N['sax.label.remove']+'" class="remove-config remove-config-row remove-ico tt"><i class="fa fa-times"></i></a>';
												} else {
													configRowHTML = componentsProperties.funcCreateTextField(configKey, configVal, {'validation': 'data-parsley-required="true"', 'type': 'text'}, curChnl);
												}
											}
											
											if ( componentsProperties[uiid] && typeof componentsProperties[uiid][configKey] === 'undefined' ) {
												configRowHTML += '<a href="javascript:void(0)" title="'+i18N['sax.label.remove']+'" class="remove-config remove-config-row remove-ico tt"><i class="fa fa-times"></i></a>';
											} else if( curChnl.subtype) {
												configRowHTML += '<a href="javascript:void(0)" title="'+i18N['sax.label.remove']+'" class="remove-config remove-config-row remove-ico tt"><i class="fa fa-times"></i></a>';
											}
										}
										
										configRowHTML += '</div>';
										$("#configRows").append(configRowHTML);
										if ( curChnl.subtype ) {
											$('#configRows').find('.config-row:first').find('.remove-config').remove();
										}
										if (hasDD) $("#"+ componentsProperties[uiid][configKey].fieldId).val(configVal);
									}
									
									if ( configKey == "filterQuery" ) {
										criteriaData = JSON.parse(configVal);
									}									
									
									if ( ($.inArray(activeComp.id, functionSupportedComps) > -1) || (typeof activeComp.subtype !== 'undefined' && activeComp.subtype == 'custom' && activeComp.type != 'channel') ) {
										$("#configRowsWrap input.config-value").each(function() {
											$(this).initQueryBuilder({data: fvAutoSuggestData});
										});
									}
									
									if ( ($.inArray(activeComp.id, functionSupportedComps) > -1) || (typeof activeComp.subtype !== 'undefined' && activeComp.subtype == 'custom' && activeComp.type != 'channel') ) {
										$("#persisterConfigContent input.config-value").each(function() {
											$(this).initQueryBuilder({data: fvAutoSuggestData});
										});
									}
									
								}
								$("#configRows").find("select").trigger("change");
								setTimeout(function(){
									$('#configRows input.config-value').each(function(){
										$(this).trigger('focus');
										$(this).trigger('blur');
									});
								},100);
								
								
								setTimeout(function() {
									$('.config-value.radio:checked').trigger('change');
									/*if ( componentsProperties[uiid] && componentsProperties[uiid].configurableUIFields )
										$('#configRows .config-row[style=""]:last').append('<a href="javascript:void(0)" title="'+i18N['sax.label.add']+'" class="add-config add-config-row add-ico tt"><i class="fa fa-plus"></i></a>');
									if ( curChnl.subtype && curChnl.subtype == 'custom' )
										$('#configRows .config-row[style=""]:last').append('<a href="javascript:void(0)" title="'+i18N['sax.label.add']+'" class="add-config add-config-row add-ico tt"><i class="fa fa-plus"></i></a>');
									*/
									
									if ( uiid != cmpIDs.cepcustom )
										$('#configRows .config-row[style=""]:last').append('<a href="javascript:void(0)" title="'+i18N['sax.label.add']+'" class="add-config add-config-row add-ico tt"><i class="fa fa-plus"></i></a>');
									
									$.each(pendingConfigKeys, function(pName, pVal) {
										$('.'+pName+'-fld').val(pVal);
										$('.'+pName+'-fld').attr("data-original-title", pVal);
									});
									pendingConfigKeys = {};
									
								}, 500);
								
							}
							
							if ( uiid == cmpIDs.validatorprocessor || uiid == cmpIDs.filterprocessor || uiid == cmpIDs.dynamiccepprocessor || uiid == cmpIDs.routeremitter || uiid == cmpIDs.analyticsprocessor || uiid == cmpIDs.aggregationfunction )
								$('#configRowsWrap').hide();

							if ( curChnl.id == cmpIDs.aggregationfunction || curChnl.id == cmpIDs.enricherprocessor || curChnl.id == cmpIDs.filterprocessor || curChnl.id == cmpIDs.validatorprocessor || curChnl.id == cmpIDs.dynamiccepprocessor || curChnl.id == cmpIDs.routeremitter ) {
								$('a[href="#configTab21"]').closest('li').remove();
								setTimeout(function(){
									$('#channelProperties > .nav.nav-tabs').find('li:first a').trigger('click');
								},50);
							}
						}
						
						// Filter Tab
						if ( uiid == cmpIDs.filterprocessor ) {
							filerCriteriaCls.initTemplate(criteriaData, 'filterbolt');

						}
						
						// For all CEPs set Parallelism and Task Count
						var streamGrouping = '';
						if ( uiid == cmpIDs.cepcustom || uiid == cmpIDs.aggregationfunction || uiid == cmpIDs.dynamiccepprocessor ) {
							for ( var i=0; i<curChnl.groupings.length; i++ ) {
								if ( streamGrouping != 'fields' )
									streamGrouping = curChnl.groupings[i].type;
							}
							
							if ( streamGrouping == 'fields' ) {
								$("#parallelism, #taskCount").prop("disabled", false);
							} else {
								$("#parallelism, #taskCount").val("1");
								$("#parallelism, #taskCount").prop("disabled", true);
							}
						}
						
						// CEP Custom
						if ( uiid == cmpIDs.cepcustom ) {
							customCEPBolt.init(curChnl);
						}
						
						// Hide AGGREGATION FUNCTION Query tab
						if ( uiid != cmpIDs.aggregationfunction ) {
							$("a[href='#configTab24']").closest("li").remove();
							$("#configTab24").remove();
						} else {
							if ( typeof curChnl.messageTypes !== "undefined" ) {
								$("a[href='#configTab24']").removeClass("disabled-tab");
								$("a[href='#configTab24']").attr("data-toggle", "tab");
								statisticalCEPBolt.initQueryTmpl(curChnl, streamGrouping);
							} else {
								$("a[href='#configTab24']").addClass("disabled-tab");
								$("a[href='#configTab24']").removeAttr("data-toggle");
							}
						}
						
						// Hide CEP DYNAMIC Query tab
						if ( uiid != cmpIDs.dynamiccepprocessor ) {
							$("a[href='#configTab25']").closest("li").remove();
							$("#configTab25").remove();
							$("#componentId").empty();
						} else {
							
							var subsystemName = $("#subSystemName").val();
							if ( ssId != 'null' && ssId!='' )
								$("#componentId").html('Component Id: <span class="text-primary">' + subsystemName + '_' + id + '</span>' );
							else	
								$("#componentId").html('Component Id: <span class="text-primary">subsystemName_' + id + '</span>' );
							
							if ( typeof curChnl.messageTypes !== "undefined" ) {
								$("a[href='#configTab25']").removeClass("disabled-tab");
								$("a[href='#configTab25']").attr("data-toggle", "tab");
								if ( ssId != 'null' && ssId != '' ) {
									dynamicCEPBolt.initCEPDynamicQueryFunc(curChnl, subsystemName);
								} else {
									$("#cepDynamicQueryWrap").empty();
								}
							} else {
								$("a[href='#configTab25']").addClass("disabled-tab");
								$("a[href='#configTab25']").removeAttr("data-toggle");
							}
						}
						
						$("select").select2({placeholder: i18N['sax.placeholder.pleaseSelect']});
						
						// Init Lookup Function
						if ( uiid == cmpIDs.customprocessors || uiid == cmpIDs.timerprocessor || uiid == cmpIDs.enricherprocessor || uiid == cmpIDs.kafkaemitter || uiid == cmpIDs.rabbitmqemitter || curChnl.subtype == "custom" ) {
							lookupClass.init(curChnl);
						}
						
						// Persister Tab
						if ( uiid == cmpIDs.hbaseemitter || uiid == cmpIDs.cassandraemitter || uiid == cmpIDs.hdfsemitter ){
							$('#configRowsWrap').hide();
							if ( $('a[href="#persisterConfigTab1"]').size() == 0 ) {
								persisterIndexerClass.init( curChnl );
							}
						}
						
						// Active MQ Tab
						if ( uiid == cmpIDs.activemqchannel || uiid == cmpIDs.activemqemitter ) {
							$('a[href="#configTab13"]').closest('li').remove();
							$('#configRowsWrap').hide();
							if ( $('a[href="#persisterConfigTab1"]').size() == 0 ) {
								persisterIndexerClass.init( curChnl );
							}
						}
						
						if ( uiid == cmpIDs.rabbitmqchannel || uiid == cmpIDs.rabbitmqemitter || uiid == cmpIDs.kafkachannel || uiid == cmpIDs.kafkaemitter ){
							$('a[href="#configTab13"]').closest('li').remove();
							$('#configRowsWrap').hide();
							if ( $('a[href="#persisterConfigTab1"]').size() == 0 ) {
								persisterIndexerClass.init( curChnl );
							}
						}
						if ( uiid == cmpIDs.replaychannel ) {
							$('a[href="#configTab13"]').closest('li').remove();
							$('a[href="#configTab12"]').closest('li').remove();
							$('#configRowsWrap').hide();
							if ( $('a[href="#persisterConfigTab1"]').size() == 0 ) {
								persisterIndexerClass.init( curChnl );
								replayLogsClass.createFields(curChnl);
							}
						}
						
						if ( uiid == cmpIDs.elasticsearchemitter || uiid == cmpIDs.solremitter ) {
							if ( $('a[href="#persisterConfigTab1"]').size() == 0 ) {
								persisterIndexerClass.init( curChnl );
							}
							$('#configRowsWrap').hide();
							$('select#routingRequired').trigger('change');
							$('#indexStoreWrap').hide();
						}
						
						// JDBC Processor
						if ( uiid == cmpIDs.jdbcprocessor ) {
							jdbcProcessorCls.init(curChnl);
						}
						
						// Enricher Tab
						if ( uiid == cmpIDs.enricherprocessor ) {
							$('#configRowsWrap').hide();
							enrichProcessorCls.createTab(curChnl);
						}
						
						// Init Analytics Bolt
						if ( uiid == cmpIDs.analyticsprocessor ) {
							curChnl.label = txt;
							DFAnalytics.initAlgorithm(curChnl);
						}
					}
					
					if ( curChnl.subtype ) {
						$('#curChannelTitle a').hide();
					} else {
						$('#curChannelTitle a').show();
					}
				
					$(".tt").tooltip();
					DFSubSytemDefination.initPopovers();
					
					$('#compPropertiesLoader').remove();
					$('#channelProperties').removeClass('prop-visibility');
				}, 600);
			}
			return false; 
		}
		return true; 
	});
	
	// Deselect selection
	$(document).on("mousedown", tplHolder, function(e){
		if ( e.target.id == "topologyGraph" ) {
			deselectAllConnection();
		}
	});
	
	/* AREA SELECTOR START */
	
	$('body').append('<div id="sltrArea">&nbsp;</div>');
	sArea = $('#sltrArea');
	
	$container = $(tplParentHolder);
	$container.mousedown(function(e) {
		var wrapHeight = $('#topologyGraph').height();
		if ( e.target.tagName != "svg" && e.target.tagName != "circle" && e.target.tagName != "path" && e.target.className.indexOf("shape") == -1 && e.target.parentNode.className.indexOf("shape") == -1 && (wrapHeight >= e.offsetY) ) {
			x = e.pageX-2;
			y = e.pageY-2;
			sArea.css({"left":x, "top":y}).show();
			$(this).bind("mousemove", function(e) {
				createSltrArea(e,x,y);
			});
		}
		e.preventDefault();
	}).mouseup(function() {
		$(this).unbind("mousemove");
		sArea.css({"width":0, "height":0, "display":"none", top:0, left:0 });
	}).scroll(function(e) {
		sArea.css({"width":0, "height":0, "display":"none", top:0, left:0 });
	});

	sArea.mouseup(function() {
		$container.unbind("mousemove");
		sArea.css({"width":0, "height":0, "display":"none", top:0, left:0 });
	});

	$('body').mouseup(function() {
		$container.unbind("mousemove");
		sArea.css({"width":0, "height":0, "display":"none", top:0, left:0 });
	});

	$(document).on("change", "#configOutputFormatSelector", function() {
		var value = $(this).val();
		$("#configDelimiterWrap").hide();
		if ( value.toLowerCase() == "delimited" ) {
			$("#configDelimiterWrap").show();
		}
	});
	bindJsPlumbEvents();
	
	//setTimeout(function() {
		if ( ssId != "" ) {
			if ( allSubSystemData.length > 0 ) {
				for ( var i=0; i<allSubSystemData.length; i++ ) {
					if ( ssId == allSubSystemData[i].name ) {
						tmpSSData = jQuery.extend(true, {}, allSubSystemData[i]);
						redrawPipeline(tmpSSData);
					}
				}		
			}
			
			if ( $.isEmptyObject(tmpSSData) )
				$('#topologyGraph').html('<div class="alert alert-info alert-dismissable margin-t">'+ i18N['sax.notification.pipelinenotexist'] +'</div>');
		}
	//}, 300);
});

// Attaching jsPlumb Events
function bindJsPlumbEvents() {
	// On Create Connection
	jsPlumb.bind("connection", function(c) {
		var srcCmpId;
		if ( c.sourceId != c.targetId ) {
			var sourceObj, targetObj;
			var sourceType = '', targetType = '';
			
			for ( var i=0; i<c.source.attributes.length; i++ ) {
				if ( c.source.attributes[i].name == "ui-type" )
					sourceType = c.source.attributes[i].value;
			}
			
			for ( var i=0; i<c.target.attributes.length; i++ ) {
				if ( c.target.attributes[i].name == "ui-type" )
					targetType = c.target.attributes[i].value;
			}
			

			if ( sourceType == "channel" ) {
				sourceObj = addedSpoutsObj[c.sourceId];
				srcCmpId = addedSpoutsObj[c.sourceId].name;
			} else {
				sourceObj = addedBoltsObj[c.sourceId];
				srcCmpId = addedBoltsObj[c.sourceId].name;
			}

			if ( targetType == "channel" )
				targetObj = addedSpoutsObj[c.targetId];
			else
				targetObj = addedBoltsObj[c.targetId];
			
			targetObj.messageTypeId = sourceObj.messageTypeId;
			targetObj.channelType = sourceObj.channelType;
			
			// SET Message Types
			if ( typeof targetObj.messageTypes === 'undefined' ) {
				targetObj.messageTypes = [];
			}
			if ( typeof sourceObj.messageTypes === 'undefined' ) {
				sourceObj.messageTypes = [];
			}
			targetObj.messageTypes = $.merge(targetObj.messageTypes, sourceObj.messageTypes);
			targetObj.messageTypes = DFSubSytemDefination.unique(targetObj.messageTypes);
			
			// Adding StreamIds
			var strIdObj = new Object();
			var hasEmitStreamId = false, sourceStreamId = 'defaultStream';
			if ( sourceObj.groupings && sourceObj.groupings.length > 0 ) {
				sourceStreamId = sourceObj.groupings[0].streamId;
			}
			
			for ( var i=0; i<sourceObj.emitStreamIds.length; i++ ) {
				if ( sourceObj.emitStreamIds[i].applyFilter )
					strIdObj[sourceObj.emitStreamIds[i].emitStreamId] = sourceObj.emitStreamIds[i].filterCriteria;
					
				if ( !hasEmitStreamId && sourceObj.emitStreamIds[i].componentId == targetObj.name ) {
					hasEmitStreamId = true;
					sourceStreamId = sourceObj.emitStreamIds[i].emitStreamId;
				}
				
				if ( sourceType == "channel" && sourceObj.emitStreamIds[i].emitStreamId != errorStream ) {
					sourceStreamId = sourceObj.emitStreamIds[i].emitStreamId;
				}
			}
			
			// Adding "streamIds" in outputFields in channel
			var opFields;
			if ( typeof sourceObj.type === 'undefined' || sourceObj.type === 'channel' ) {
				opFields = [sourceObj.messageTypeId, "streamIds"];
			} else {
				opFields = [sourceObj.messageTypeId];
			}
			
			if ( !hasEmitStreamId ) {
				sourceObj.emitStreamIds.push({
					"emitStreamId": sourceStreamId,
					"outputFields": opFields, //[sourceObj.messageTypeId],
					"applyFilter": false,
					"filterCriteria": [],
					"componentId": targetObj.name
				});
				
				if ( typeof sourceObj.type === 'undefined' || sourceObj.type === 'channel' ) {
					sourceObj.emitStreamIds = jQuery.grep(sourceObj.emitStreamIds, function(obj) {
						return errorStream != obj.emitStreamId;
					});
				}
			}
			
			// Adding Groupings
			var hasGroupings = false;
			for ( var i=0; i<targetObj.groupings.length; i++ ) {
				if ( targetObj.groupings[i].componentId == srcCmpId )
					hasGroupings = true;
			}
			if ( !hasGroupings ) {
				targetObj.groupings.push({
					"type": "shuffle",
					"componentId": srcCmpId,
					"groupFields": [],
					"streamId": sourceStreamId
				});
			}
			
			var sortStreamId = (sourceStreamId.length > 18) ? (sourceStreamId.substr(0, 15)+'...') : sourceStreamId;
			for ( var i=0; i<sourceObj.emitStreamIds.length; i++ ) {
				var sourceId = ( addedSpoutsObj[c.sourceId] ) ? addedSpoutsObj[c.sourceId].name : addedBoltsObj[c.sourceId].name;
				var targetId = addedBoltsObj[c.targetId].name;
				
				if ( (sourceObj.emitStreamIds[i].emitStreamId != errorStream) && (sourceId == sourceObj.name) && (targetId == sourceObj.emitStreamIds[i].componentId) ) {
					c.connection.removeOverlay( c.targetId+'Filter' );
					if ( (strIdObj[sourceObj.emitStreamIds[i].emitStreamId]) && strIdObj[sourceObj.emitStreamIds[i].emitStreamId].length > 0 ) {
						sourceObj.emitStreamIds[i].applyFilter = true;
						sourceObj.emitStreamIds[i].filterCriteria = strIdObj[sourceObj.emitStreamIds[i].emitStreamId];
						c.connection.addOverlay( [ "Label", { id: (c.targetId+'Filter'), location: 0.5, cssClass:"fa fa-filter filter-symbol" } ] );
					} else {
						sourceObj.emitStreamIds[i].applyFilter = false;
					}
					c.connection.removeOverlay( c.targetId+'StrId' );
					c.connection.addOverlay( [ "Custom", { create:function(component) { return $('<div><span title="'+ sourceStreamId +'">'+sortStreamId+'</span></div>'); }, label:sourceStreamId, id: (c.targetId+'StrId'), location: 0.5, cssClass:"str-label" } ] );
				}
			}
			
			// SET messageTypeId, messageTypes and channelType for all child bolts
			var childBolts = DFSubSytemDefination.getChildBolts(sourceObj, []);
			for ( var i=0; i<childBolts.length; i++ ) {
				if ( addedBoltsObj[childBolts[i]] ) {
					addedBoltsObj[childBolts[i]].messageTypeId = sourceObj.messageTypeId;
					addedBoltsObj[childBolts[i]].channelType = sourceObj.channelType;
					
					if ( typeof addedBoltsObj[childBolts[i]].messageTypes === 'undefined' ) {
						addedBoltsObj[childBolts[i]].messageTypes = [];
					}
					if ( typeof sourceObj.messageTypes === 'undefined' ) {
						sourceObj.messageTypes = [];
					}
					addedBoltsObj[childBolts[i]].messageTypes = $.merge(addedBoltsObj[childBolts[i]].messageTypes, sourceObj.messageTypes);
					addedBoltsObj[childBolts[i]].messageTypes = DFSubSytemDefination.unique(addedBoltsObj[childBolts[i]].messageTypes);
					
				}
			}
			
			setEnableButton();
		} else {
			setTimeout(function() {
				jsPlumb.detach(c.connection);
			}, 50);
		}
	});
	
	// On Move Connection
	jsPlumb.bind("connectionMoved", function(c) {
		var sourceObj = (addedSpoutsObj[c.originalSourceId]) ? addedSpoutsObj[c.originalSourceId] : addedBoltsObj[c.originalSourceId];
		var targetObj = addedBoltsObj[c.originalTargetId];
		
		sourceObj.emitStreamIds = jQuery.grep(sourceObj.emitStreamIds, function(o) {
			return o.componentId != targetObj.name;
		});
		
		targetObj.groupings = jQuery.grep(targetObj.groupings, function(o) {
			return o.componentId != sourceObj.name;
		});
		
		DFSubSytemDefination.setMessageTypes();
	});
	
	// On Delete Connection
	jsPlumb.bind("connectionDetached", function(c) {
		if ( typeof addedBoltsObj[c.targetId] !== 'undefined' ) {
			var sourceObj = (addedSpoutsObj[c.sourceId]) ? addedSpoutsObj[c.sourceId] : addedBoltsObj[c.sourceId];
			var targetObj = addedBoltsObj[c.targetId];
			
			if ( addedBoltsObj[c.targetId].groupings.length < 2 ) {
				delete addedBoltsObj[c.targetId].messageTypes;
			}
			
			sourceObj.emitStreamIds = jQuery.grep(sourceObj.emitStreamIds, function(o) {
				return o.componentId != targetObj.name;
			});
			
			targetObj.groupings = jQuery.grep(targetObj.groupings, function(o) {
				return o.componentId != sourceObj.name;
			});
			
			DFSubSytemDefination.setMessageTypes();
		}

		setEnableButton();
	});
	
	// Select/Deselect Connection
	jsPlumb.bind('click', function(connection, e) {
		e.preventDefault();
		if ( connection.idPrefix == '_jsplumb_c_' ) {
			curSelectedObj.title = "";
			curSelectedObj.item = new Object();
			var id = connection.id;
			var c = jsPlumb.getConnections();
			for(i=0; i<c.length; i++) {
				if ( c[i].id != id ) {
					c[i].setPaintStyle( connectorPaintStyle );
				}
			}
			$(".shape").removeClass("active");
			
			if ( connection.getPaintStyle().strokeStyle == "#bbbbbb" ) {
				connection.setPaintStyle( connectorHoverStyle );
				curSelectedObj.title = "line";
				curSelectedObj.item = connection;
			} else {
				connection.setPaintStyle( connectorPaintStyle );
			}	
		}
	});
	
	// StreamID Functionality START
	jsPlumb.bind('contextmenu', function(c, e) {
		e.preventDefault();
		streamIdConn = c;
		var hasMessageError = false, propErrorMsg='';
		rootSpouts = [], criteriaData = [], usedMessages = [], allMessages = [];
		getRootSpouts( addedBoltsObj[c.targetId] );
		var sourceCmp = (addedSpoutsObj[c.sourceId]) ? addedSpoutsObj[c.sourceId] : addedBoltsObj[c.sourceId];
		var targetCmp = addedBoltsObj[c.targetId];
		
		deselectAllConnection();
		
		// Reset the parsley validation errors
		$('#streamModalForm ul[class="parsley-errors-list filled"]').each(function() {					
			$('#streamModalForm').parsley().destroy();			
			return false;
		});
		
		$("select").select2('destroy').select2({placeholder: i18N['sax.placeholder.pleaseSelect']});
		$('#streamModalLabel').html( sourceCmp.label + '&nbsp;<i class="fa fa-long-arrow-right"></i>&nbsp;' + targetCmp.label );
		$('#streamIdErrorWrap').empty();
		$('#streamIdContentWrap, #saveStreamBtn').show();
		$('#streamIdContentWrap .nav-tabs li:first a').trigger('click');
		$('#rulesTabs, #rulesTabContent').empty();
			
		propErrorMsg += i18N['sax.notification.selectMessage'];
		for ( var i=0; i<rootSpouts.length; i++ ) {
			if ( addedSpoutsObj[rootSpouts[i]] && typeof addedSpoutsObj[rootSpouts[i]].messageTypes === 'undefined' ) {
				if ( i>0 ) propErrorMsg += ', ';
				propErrorMsg += '\''+ addedSpoutsObj[rootSpouts[i]].label +'\'';
				hasMessageError = true;
			}
		}
		
		if ( hasMessageError ) {
			$('#streamIdErrorWrap').html('<div class="alert alert-danger">'+ propErrorMsg +'</div>');
			$('#streamIdContentWrap, #saveStreamBtn').hide();
		} else {
			var streamId, groupFields, streamType;
			allMessages = sourceCmp.messageTypes;
			
			for ( var i=0; i<targetCmp.groupings.length; i++ ) {
				if ( targetCmp.groupings[i].componentId == sourceCmp.name ) {
					streamId = targetCmp.groupings[i].streamId;
					groupFields = targetCmp.groupings[i].groupFields;
					streamType = targetCmp.groupings[i].type;
					
					if ( streamId == 'defaultStream' || streamId == '' ) {
						$('.stream-type-radio[value="default"]').prop('checked', true).trigger('click');
						streamId = 'defaultStream';
					} else {
						$('.stream-type-radio[value="custom"]').prop('checked', true).trigger('click');
					}
					
					$('#streamNameFld').val( streamId );
					$('#streamNameOld').val( streamId );
					$('#grouping').val( streamType ).trigger('change');
					$('#groupFields').val( groupFields ).trigger('change');
				}
			}
			
			for ( var i=0; i<sourceCmp.emitStreamIds.length; i++ ) {
				if ( (sourceCmp.emitStreamIds[i].emitStreamId != errorStream) && (sourceCmp.emitStreamIds[i].componentId == targetCmp.name) ) {
					if ( sourceCmp.emitStreamIds[i].filterCriteria.length == 0 ) {
						$('#streamIdFilterIntroWrap').show();
						$('#streamIdFilterWrap').hide();
					} else {
						$('#streamIdFilterIntroWrap').hide();
						$('#streamIdFilterWrap').show();
						var filterCriteriaData = {
							'rules': sourceCmp.emitStreamIds[i].filterCriteria
						};
						criteriaData = filterCriteriaData;
						if ( filterCriteriaData.rules && filterCriteriaData.rules.length > 0 )
							filerCriteriaCls.initTemplate(filterCriteriaData, 'streamId');
					}
				}
			}
			
			if ( allMessages.length == 0 ) {
				$('#streamIdFilterAddBtn').addClass('disabled');
			} else {
				$('#streamIdFilterAddBtn').removeClass('disabled');
			}
		}
		
		$('#streamModalWrap .modal-dialog').width(900);
		$('#streamModalWrap').modal({
						backdrop: 'static',
						keyboard: false
					});
	});
}

// Deselect All Connection
function deselectAllConnection() {
	curSelectedObj.title = "";
	curSelectedObj.item = new Object();

	var c = jsPlumb.getConnections();
	for(i=0; i<c.length; i++) {
		c[i].setPaintStyle( connectorPaintStyle );
	}
	$(".shape").removeClass("active");
}

function resetComponentsId(cmpObjects, name) {
	$.each(cmpObjects, function(key, obj) {
		if ( obj.groupings.length > 0 ) {
			obj.groupings = jQuery.grep(obj.groupings, function(o) {
				return name != o.componentId;
			});
		}
	});
};

function createPropertyOptions(key, channelObj) {
	var opts='';
		if ( key == 'delimiter' && channelObj.id == 'hdfs-emitter' ) key = 'hdfs-emitter-delimiter';
		if ( key == 'delimiter' && channelObj.id == 'kafka-emitter' ) key = 'kafka-emitter-delimiter';
		if ( key == 'delimiter' && channelObj.id == 'rabbitmq-emitter' ) key = 'rabbitmq-emitter-delimiter';
		if ( key == 'delimiter' && channelObj.id == 'activemq-emitter' ) key = 'activemq-emitter-delimiter';
		
		switch (key) {
			case 'forceFromStart':
				opts = '<option value="true">'+i18N['sax.option.text.true']+'</option><option value="false">'+i18N['sax.option.text.false']+'</option>';
				break;
			case 'isBatchEnable':
				opts = '<option value="false">'+i18N['sax.option.text.false']+'</option><option value="true">'+i18N['sax.option.text.true']+'</option>';
				break;
			case 'messageName':
				if ( channelObj.messageTypes ) {
					for ( var j=0; j<channelObj.messageTypes.length; j++ ) {
						opts += '<option value="'+ channelObj.messageTypes[j] +'">'+ channelObj.messageTypes[j] +'</option>';
					}
				}
				break;
			case 'rotationPolicy':
				opts = createConfigOptions(cmpIDs.hdfsemitter, 'rotationPolicy');
				break;
			case 'pmml.messageName':
				if ( channelObj.messageTypes ) {
					for ( var j=0; j<channelObj.messageTypes.length; j++ ) {
						opts += '<option value="'+ channelObj.messageTypes[j] +'">'+ channelObj.messageTypes[j] +'</option>';
					}
				}
				break;
			case 'cep.query.messageName':
				if ( channelObj.messageTypes ) {
					for ( var j=0; j<channelObj.messageTypes.length; j++ ) {
						opts += '<option value="'+ channelObj.messageTypes[j] +'">'+ channelObj.messageTypes[j] +'</option>';
					}
				}
				break;
			case 'outputType':
				opts = createConfigOptions(cmpIDs.hdfsemitter, key);
				break;
			case 'hdfs-emitter-delimiter':
				opts = createConfigOptions(cmpIDs.hdfsemitter, 'delimiter');
				break;
			case 'compressionType':
				opts = createConfigOptions(cmpIDs.hdfsemitter, key);
				break;
			case 'producerType':
				opts = '<option value="sync">'+i18N['sax.option.text.sync']+'</option><option value="async">'+i18N['sax.option.text.async']+'</option>';
				break;
			case 'outputFormat':
				opts = '<option value="json">'+i18N['sax.json']+'</option><option value="jsonarray">'+i18N['sax.option.text.jsonarray']+'</option><option value="DELIMITED">'+i18N['sax.option.text.delimited']+'</option>';
				break;
			case 'kafka-emitter-delimiter':
				opts = '<option value=",">'+i18N['sax.commaSeparated']+'</option><option value="\\t">'+i18N['sax.tabSeparated']+'</option><option value=":">'+i18N['sax.colonSeparated']+'</option><option value=";">'+i18N['sax.semicolonSeparated']+'</option><option value="|">'+i18N['sax.pipeSeparated']+'</option>';
				break;
			case 'rabbitmq-emitter-delimiter':
				opts = '<option value=",">'+i18N['sax.commaSeparated']+'</option><option value="\\t">'+i18N['sax.tabSeparated']+'</option><option value=":">'+i18N['sax.colonSeparated']+'</option><option value=";">'+i18N['sax.semicolonSeparated']+'</option><option value="|">'+i18N['sax.pipeSeparated']+'</option>';
				break;
			
			case 'activemq-emitter-delimiter':
				opts = '<option value=",">'+i18N['sax.commaSeparated']+'</option><option value="\\t">'+i18N['sax.tabSeparated']+'</option><option value=":">'+i18N['sax.colonSeparated']+'</option><option value=";">'+i18N['sax.semicolonSeparated']+'</option><option value="|">'+i18N['sax.pipeSeparated']+'</option>';
				break;
			case 'outputFields':
				var outputFlds = DFSubSytemDefination.getUnionFields(channelObj.messageTypes);
				for ( var k = 0; k<outputFlds.length; k++ ) {
					opts += '<option value="'+ outputFlds[k].fieldName +'">'+ outputFlds[k].fieldLabel +'</option>';
				}
				break;
			case 'exchangeType':
				opts = '<option value="direct">DIRECT</option><option value="topic">TOPIC</option><option value="fanout">FANOUT</option>';
				break;
			case 'exchangeDurable':
				opts = '<option value="true">TRUE</option><option value="false">FALSE</option>';
				break;
			case 'exchangeAutoDelete':
				opts = '<option value="true">TRUE</option><option value="false">FALSE</option>';
				break;
			case 'queueDurable':
				opts = '<option value="true">TRUE</option><option value="false">FALSE</option>';
				break;
			case 'queueExclusive':
				opts = '<option value="true">TRUE</option><option value="false">FALSE</option>';
				break;
			case 'queueAutoDelete':
				opts = '<option value="true">TRUE</option><option value="false">FALSE</option>';
				break;
			case 'acrossFieldSearchEnabled':
				opts = '<option value="true">'+i18N['sax.option.text.true']+'</option><option value="false">'+i18N['sax.option.text.false']+'</option>';
				break;
			
			case 'routingRequired':
				opts = '<option value="false">'+i18N['sax.option.text.false']+'</option><option value="true">'+i18N['sax.option.text.true']+'</option>';
				break;
			
			case 'indexSource':
				opts = '<option value="false">'+i18N['sax.option.text.false']+'</option><option value="true">'+i18N['sax.option.text.true']+'</option>';
				break;
			
			case 'encoding':
				opts = '<option value="utf-8">UTF-8</option><option value="base64">Base64</option>';
				break;
				
			case 'databaseType':
				opts = '<option value="mysql">MYSQL</option><option value="postgresql">POSTGRESQL</option><option value="oracle">ORACLE</option>';
				break;
			
		}
		return opts;
};

function createSltrArea(e,x,y) {
	xPos = x;
	yPos = y;
	sltrareaW = e.pageX - xPos;
	sltrareaH = e.pageY - yPos;
	if(sltrareaW < 0) {
		sltrareaW = Math.abs(sltrareaW);
		xPos = e.pageX;
		sArea.css({"left":xPos+2});
	}else {
		sArea.css({"left":x});
	}

	if(sltrareaH < 0) {
		sltrareaH = Math.abs(sltrareaH);
		yPos = e.pageY;
		sArea.css({"top":yPos+2});
	}else {
		sArea.css({"top":y});
	}
	sArea.css({"width":sltrareaW-2, "height":sltrareaH-2});

	sltrArea = {
		left: xPos, 
		top: yPos,
		right: xPos+sltrareaW,
		bottom: yPos+sltrareaH
	}
	sltByArea();
}

function sltByArea() {
	$('.shape').each(function() {
		$(this).removeClass('active');
	});
	
	$('.shape').each(function() {
		objArea = {
			left: $(this).offset().left, 
			top: $(this).offset().top,
			right: $(this).offset().left + $(this).width(),
			bottom: $(this).offset().top + $(this).height()
		}
		var intersect = intersectRect(sltrArea, objArea);
		if(intersect) {
			$(this).addClass('active');
		}
	});
}

function intersectRect(r1, r2) {
  return !(r2.left > r1.right || 
		   r2.right < r1.left || 
		   r2.top > r1.bottom ||
		   r2.bottom < r1.top);
}
/* AREA SELECTOR END */

// GET ROOT SPOUT
function getRootSpouts(chnl) {
	if ( chnl.groupings.length > 0 ) {
		for ( var i=0; i<chnl.groupings.length; i++ ) {
			var parentNode = chnl.groupings[i].componentId;
			
			$.each( addedBoltsObj, function(key, obj) {
				if ( obj.name == parentNode )
					parentNode = key;
			});
			
			$.each( addedSpoutsObj, function(key, obj) {
				if ( obj.name == parentNode )
					parentNode = key;
			});
			
			if ( typeof addedBoltsObj[parentNode] !== 'undefined' ) {
				getRootSpouts(addedBoltsObj[parentNode]);
			} else {
				rootSpouts.push(parentNode);
			}
		}
	}
}

// Redraw Graph
function redrawPipeline(ssObj) {
	tmpSSData = jQuery.extend(true, {}, ssObj);
	lastAddedShap = undefined;
	redrawObj = [];
	streamIdConn = null;
	addedSpoutsObj = new Object();
	addedBoltsObj = new Object();
	addedIds = [];
	dynamicCEPCount = 0;
	pendingConn = [];
	customJarName = tmpSSData.customJarName;
	originalCustomJarName = (tmpSSData.originalCustomJarName) ? tmpSSData.originalCustomJarName : '';
	tempConnections = tmpSSData.connections;
	
	if ( originalCustomJarName != '' ) {
		$('#uploadedJarNameWrap').show();
		$('#uploadedJarNameWrap .uploadedJarName').text(originalCustomJarName);
		DFSubSytemDefination.setChannesToolbarHeight();
	}
	
	jsPlumb.reset();
	$('#topologyGraph').empty();
	bindJsPlumbEvents();
	
	ssObj = esperHABolt.removeEsperHAEntries(ssObj); // Removing esperHA emitstreamids while editing
	$("#subSystemName").val(ssObj.name).attr("disabled", true);
	$("#workerCount").val(ssObj.workerCount);
	$("#ackersCount").val(ssObj.ackersCount);
	$("#esperHAFld").prop('checked', ssObj.esperHAEnabled).trigger('change');
	$("#supervisorFld").val(ssObj.topologySupervisors).trigger('change');
	
	for ( var i=0; i<ssObj.spouts.length; i++ ) {
		redrawObj.push({
			level: 1,
			data: [ ssObj.spouts[i] ]
		});
		boltsData = ssObj.bolts;
		getChildNodes( i, ssObj.spouts[i].name );
	}
	reDrawComponents();
	// for pending connection, Nodes which was not added in DOM
	for ( i=0; i<pendingConn.length; i++ ) {
		var sourceObj, targetObj, applyFilter = false;
		if ( addedSpoutsObj[pendingConn[i][0]] )
			sourceObj = addedSpoutsObj[pendingConn[i][0]];
		else
			sourceObj = addedBoltsObj[pendingConn[i][0]];
		
		targetObj = addedBoltsObj[pendingConn[i][1]];
			
		if ( targetObj.coordinates && targetObj.coordinates.length > 0 ) {
			targetObj.coordinates[0] = (targetObj.coordinates[0] < 0) ? 0 : targetObj.coordinates[0];
			targetObj.coordinates[1] = (targetObj.coordinates[1] < 0) ? 0 : targetObj.coordinates[1];
			$("#"+targetObj.name).css({left: targetObj.coordinates[0], top: targetObj.coordinates[1]}).attr({"pos-left": targetObj.coordinates[0], "pos-top": targetObj.coordinates[1]});
		} else {
			pos = $("#"+sourceObj.name).position();
			$("#"+targetObj.name).css({left: pos.left+250, top: pos.top}).attr({"pos-left": pos.left+250, "pos-top": pos.top});
		}
		
		var sourceUUID = pendingConn[i][0] + "RightMiddle";
		var targetUUID = pendingConn[i][1] + "LeftMiddle";
		var newConn = jsPlumb.connect({uuids:[sourceUUID, targetUUID], editable:true});
		jsPlumb.repaintEverything();
	}
	
	$('#topologyGraphWrap').scrollLeft(0);
}

function getChildNodes(index, s) {
	var childNodes = [];
	var len = boltsData.length;
	for ( var i=0; i<len; i++ ) {
		if ( /*boltsData[i].name.indexOf(esperHACloneId) == -1 &&*/ boltsData[i].groupings.length > 0 ) {
			var groupings = boltsData[i].groupings;
			for ( var j=0; j<groupings.length; j++ ) {
				var groupingId = groupings[j].componentId;
				if ( jQuery.inArray(boltsData[i], redrawObj[index].data) == -1 ) {
					childNodes.push( boltsData[i] );
					redrawObj[index].data.push( boltsData[i] );
				}
			}
		}
	}
	
	if ( childNodes.length > redrawObj[index].level ) redrawObj[index].level = childNodes.length;
	
	for ( var j=0; j<childNodes.length; j++ ) {
		boltsData = jQuery.grep(boltsData, function(o) {
			return childNodes[j] != o
		});
		if ( boltsData.length > 0 ) {
			getChildNodes( index, childNodes[j].name );
		}
	}
}

function createRandomNumber() {
	var random = Math.round( Math.random()*1000000 + 1 );
	if ( $.inArray(random, addedIds) == -1 ) {
		addedIds.push( random );
		return random;
	} else {
		createRandomNumber();
	}
}

function setComponentLabel(id, lbl) {
	$("#"+id).find("span").text( lbl );
	var $divW = $("#"+id).width();
	var $lblW = $("#"+id).find("span").outerWidth();
	var diff;
	if ( $lblW > $divW ) {
		diff = ($divW-$lblW)/2;
		$("#"+id).find("span").css("margin-left", diff+"px");
	} else {
		$("#"+id).find("span").css("margin-left", "0px");
	}
}

function reDrawComponents() {
	var lastAdded = new Object();
	var level = 0;
	
	for ( var i=0; i<redrawObj.length; i++ ) {
		var d = redrawObj[i].data;
		addedIds.push( d[0].name.split("_")[1] );
		editCmpID = d[0].name;
		$("#ssToolbarAccordion ul.components-list a[ui-id='"+ d[0].id +"']").trigger("click");
		// SET last position
		if ( d[0].coordinates && d[0].coordinates.length > 0 ) {
			d[0].coordinates[0] = (d[0].coordinates[0] < 0) ? 0 : d[0].coordinates[0];
			d[0].coordinates[1] = (d[0].coordinates[1] < 0) ? 0 : d[0].coordinates[1];
			$("#"+d[0].name).css({left: d[0].coordinates[0], top: d[0].coordinates[1]}).attr({"pos-left": d[0].coordinates[0], "pos-top": d[0].coordinates[1]});
		} else {
			$("#"+d[0].name).css({left: 100, top: 60 + level*i*150}).attr({"pos-left": 100, "pos-top": 60 + level*150});
		}
		
		level = redrawObj[i].level;
		addedSpoutsObj[d[0].name] = d[0];
		setComponentLabel(d[0].name, d[0].label);
		setDeadLaterChannel(d[0]);
	}
	
	for ( var i=0; i<redrawObj.length; i++ ) {
		var d = redrawObj[i].data;
		for ( var j=1; j<d.length; j++ ) {
			var dataTarget = d[j].id;
			var sourceIds = [], targetId = d[j].name;
			editCmpID = targetId;
			addedBoltsObj[d[j].name] = d[j];

			if ( d[j].id == cmpIDs.analyticsprocessor ) {
				$("#ssToolbarAccordion ul.components-list a[ui-id='"+ dataTarget +"'][algo-id='"+ d[j].algorithm +"']").trigger("click");
			} else {
				if ( $("#topologyGraph").find("#"+targetId).size() == 0 )
					$("#ssToolbarAccordion ul.components-list a[ui-id='"+ dataTarget +"']").trigger("click");
			}
			
			setComponentLabel(d[j].name, d[j].label);
			var pos;
			
			for ( var l=0; l<d[j].groupings.length; l++ ) {
				sourceIds.push( d[j].groupings[l].componentId );
			}
			for ( var k=0; k<sourceIds.length; k++ ) {
				if ( $("#"+sourceIds[k]).size() > 0 ) {
					var hasSourceId = false;
					if ( !$.isEmptyObject(lastAdded) ) {
						for ( var l=0; l<lastAdded.groupings.length; l++ ) {
							hasSourceId = ( lastAdded.groupings[l].componentId == sourceIds[k] ) ? true : false;
						}
					}
					
					if ( hasSourceId ) {
						var lastTargetId = lastAdded.name;
						if ( targetId != lastTargetId ) {
							// SET last position
							if ( d[j].coordinates && d[j].coordinates.length > 0 ) {
								d[j].coordinates[0] = (d[j].coordinates[0] < 0) ? 0 : d[j].coordinates[0];
								d[j].coordinates[1] = (d[j].coordinates[1] < 0) ? 0 : d[j].coordinates[1];
								$("#"+targetId).css({left: d[j].coordinates[0], top: d[j].coordinates[1]}).attr({"pos-left": d[j].coordinates[0], "pos-top": d[j].coordinates[1]});
							} else {
								pos = $("#"+lastTargetId).position();
								$("#"+targetId).css({left: pos.left, top: pos.top+150}).attr({"pos-left": pos.left, "pos-top": pos.top+150});
							}
						}
					} else {
						// SET last position
						if ( d[j].coordinates && d[j].coordinates.length > 0 ) {
							d[j].coordinates[0] = (d[j].coordinates[0] < 0) ? 0 : d[j].coordinates[0];
							d[j].coordinates[1] = (d[j].coordinates[1] < 0) ? 0 : d[j].coordinates[1];
							$("#"+targetId).css({left: d[j].coordinates[0], top: d[j].coordinates[1]}).attr({"pos-left": d[j].coordinates[0], "pos-top": d[j].coordinates[1]});
						} else {
							pos = $("#"+sourceIds[k]).position();
							$("#"+targetId).css({left: pos.left+250, top: pos.top}).attr({"pos-left": pos.left+250, "pos-top": pos.top});
						}
					}

					var isConnected = false;
					var c = jsPlumb.getConnections();
					for ( var l=0; l<c.length; l++) {
						if ( c[l].sourceId == sourceIds[k] && c[l].targetId == targetId ) {
							isConnected = true;
						}
					}
					
					if ( !isConnected ) {
						var sourceUUID = sourceIds[k] + "RightMiddle";
						var targetUUID = targetId + "LeftMiddle";
						var newConn = jsPlumb.connect({uuids:[sourceUUID, targetUUID], editable:true});
					}
					
					// Add Filter icon on edge
					var sourceObj, applyFilter = false;
					if ( addedSpoutsObj[sourceIds[k]] )
						sourceObj = addedSpoutsObj[sourceIds[k]];
					else
						sourceObj = addedBoltsObj[sourceIds[k]];

				} else {
					pendingConn.push([sourceIds[k], targetId]);
				}
			}
			jsPlumb.repaintEverything();
			lastAdded = d[j];
			
			// For Dynamic CEP
			if ( d[j].label == cmpIDs.dynamiccepprocessor ) {
				var tmpCEPArr;
				var configArr = d[j].config;
				for ( var k=0; k<configArr.length; k++ ) {
					if ( configArr[k].indexOf('component') > -1 ) {
						var cLen = configArr[k].length;
						var cIdx = configArr[k].indexOf(":");
						var cVals = configArr[k].substring(cIdx+1, cLen);
						tmpCEPArr = JSON.parse(cVals);
					}
				}
				
				dynamicCEPCount++;
			}
			
			setDeadLaterChannel(d[j]);
		}
	}
	editCmpID = null;
}

function setEnableButton() {
	var allConnected = true;
	$.each(addedBoltsObj, function(key, obj) {
		if ( obj.groupings.length == 0 )
			allConnected = false;
	});

	if ( jQuery.isEmptyObject(addedBoltsObj) )
		allConnected = false;
	
	if ( allConnected )
		$("#saveSubSystemModalLink").removeClass("disabled");
	else
		$("#saveSubSystemModalLink").addClass("disabled");
	
}

function createConfigOptions(cmpLabel, configKey) {
	var cOpts='';
	for ( var m=0; m<allChannelsData.emitters.length; m++ ) {
		if ( allChannelsData.emitters[m].id == cmpLabel ) {
			var c = allChannelsData.emitters[m].config;
			for ( var n=0; n<c.length; n++ ) {
				if ( c[n].indexOf(configKey) == 0 ) {
					var cLen = c[n].length;
					var cIdx = c[n].indexOf(":");
					var cVals = c[n].substring(cIdx+1, cLen).split('^^^');
					for ( var p=0; p<cVals.length; p++ ) {
						cVals[p] = $.trim(cVals[p]);
						cOpts += '<option value="'+ cVals[p] +'">'+ cVals[p] +'</option>';
					}
				}
			}
		}
	}
	return cOpts;
}

function createRadioBtnOptions(key, value, channelObj) {
	var radioElements = '';
	var radioOpts = [];
	var chnlType = ( typeof channelObj.type == 'undefined' ) ? 'channels' : channelObj.type + 's';
		
	for ( var m=0; m<allChannelsData[chnlType].length; m++ ) {
		if ( allChannelsData[chnlType][m].id == cmpIDs.hbaseemitter ) {
			var c = allChannelsData[chnlType][m].config;
			for ( var n=0; n<c.length; n++ ) {
				if ( c[n].indexOf(key) == 0 ) {
					var cLen = c[n].length;
					var cIdx = c[n].indexOf(":");
					var cVals = c[n].substring(cIdx+1, cLen).split('^^^');
					for ( var p=0; p<cVals.length; p++ ) {
						cVals[p] = $.trim(cVals[p]);
						var isChecked = ( cVals[p] == value ) ? 'checked' : '';
						radioElements += '<div class="radio-inline"><label><input class="radio config-value '+key+'-fld" name="'+key+'" type="radio" value="'+cVals[p]+'" '+ isChecked +'>'+cVals[p]+'</label></div>';
					}
				}
			}
		}
	}
	return radioElements;
}

function setDeadLaterChannel(obj) {
	if ( obj.errorConfig ) {
		for ( var i=0; i<obj.errorConfig.length; i++ ) {
			var len = obj.errorConfig[i].length;
			var idx = obj.errorConfig[i].indexOf(":");
			var key = obj.errorConfig[i].substring(0, idx);
			var val = obj.errorConfig[i].substring(idx+1, len);
			
			if ( key == 'componentType' ) {
				deadLaterChannel['id'] = val + '-emitter';
			}
			
			if ( key == 'connectionId' ) {
				deadLaterChannel['connectionId'] = val;
			}
			
			if ( key == 'connectionName' ) {
				deadLaterChannel['connectionName'] = val;
			}
		}
		
		var errorConfig = obj.errorConfig.join(',');
		if ( errorConfig.indexOf('connectionId:') > -1 ) {
			if ( typeof deadLaterChannel.connectedChannels === 'undefined' ) {
				deadLaterChannel['connectedChannels'] = [];
			}
			
			if ( typeof deadLaterChannel.connectedBolts === 'undefined' ) {
				deadLaterChannel['connectedBolts'] = [];
			}
		
			if ( addedSpoutsObj[obj.name] ) {
				isDeadLaterAva = true;
				deadLaterChannel['connectedChannels'].push(obj.name);
			}
			if ( addedBoltsObj[obj.name] ) {
				isDeadLaterAva = true;
				deadLaterChannel['connectedBolts'].push(obj.name);
			}
		}
	}
}