/*
 * Class
 * Data Fabric Sub System Defination Configuration
 * Date - 2014-03-26
 * 
 */
/*This class is containing all functions used in Data Fabric Sub System Defination Configuration */

var allChannelsData, allSubSystemData=[], curSubSystemData, messagesFieldsVersionData, allMessagesData, functionsData, variablesData, lookupFunctions=[], spoutEditHTML='', emitrConnEditHTML='', configHTML='', allMsgOptions='',currentFabricStatus='', addedCEPBolt=false, isFormSubmition=false, actionRebalance=false, esperHACloneId='_esperHA', fvAutoSuggestData = {}, maxSubSystemVersion = 1,selectedSubsystemVersion='', finalVersionNumber ='', selectedVrsnVal='', isModifiedSS = false, curSubSystemObj, displayVersion=1,restrictedComponents, customJarName="", originalCustomJarName="", contentMap={}, isUploadedJar=false, exchangeNameVal = "", tempConnections=[];
var testRDBMSConn = baseUrl + '/datafabric/dbms/conn/status';
var updateConnStatusUrl = baseUrl+'/datafabric/subsystem/status';
var DFSubSytemDefination = function (el) {
    var self = this, tenetSubsystemData, myTimeout, versionTable ;
	var allChannelsUrl = baseUrl+'/datafabric/component/list';
	var queueNameUrl = baseUrl+'/datafabric/rabbitMQ/queues/availability';
	var exchangeNameUrl = baseUrl+'/datafabric/rabbitMQ/exchanges/availability';
	var HDFSPathNameUrl = baseUrl+'/datafabric/hdfs/path/availability';
	var topicNameUrl = baseUrl+'/datafabric/kafka/topics/availability';
	var allSubSystemUrl = baseUrl+'/datafabric/subsystem/list';
	var allMessagesUrl = baseUrl+'/datafabric/msgfield/name/list'; 
	var saveSubSystemUrl = baseUrl+'/datafabric/subsystem/create';	
	var updateSubSystemUrl = baseUrl+'/datafabric/subsystem/update';
	var ssListingPageUrl = baseUrl+'/adminui/subsystem/list';
	var getSubSystemsStatusUrl = baseUrl+'/datafabric/subsystem/status/list';
	var rebalanceUrl = baseUrl+'/datafabric/subsystem/rebalance';
	var cepQuerySaveUrl = baseUrl+'/datafabric/dynacep/config';
	var isSubsystemAvailableUrl = baseUrl+'/datafabric/subsystem/availability';
	var uploadSyncsortFileUrl = baseUrl+'/file/uploadSyncsortFile';

	var tenetSubsystemUrl = baseUrl+'/tenant/supervisors/'+currentTenantId;
	var subSystemVersionsUrl = baseUrl+'/datafabric/subsystem/version/list/'+ssId;
	var subSystemVersionDataUrl = baseUrl+'/datafabric/subsystem/';
	var subSystemMaxVersionURL = baseUrl+'/datafabric/subsystem/';
	var subSystemLoadURL = baseUrl+'/datafabric/upload/subsystem/';//*/version/*';
	var functionsList = baseUrl+'/datafabric/func/list';
	var variablesList = baseUrl+'/datafabric/variable/list';
	var restrictedComponentsUrl = baseUrl+'/freemium-disabled-feature';

	var rebalancePageDelay = 10000;
	var uploadsubsystemJarUrl = baseUrl+'/file/load/custom/jar';
	var updateSubsystemStatusUrl = baseUrl+'/datafabric/subsystem/status/update';
	var subSystemJarStatusUrl = baseUrl+'/datafabric/jar/status';
	var versionDetailsUrl = baseUrl+'/datafabric/subsystem/';
	var versionMsgUrl = baseUrl+'/datafabric/messageAvailability/subsystem/';//*/version/*'
	var custCompCompatibleUrl = baseUrl+'/datafabric/custom/component/isCompatible';
	
	types.string.push({name: 'matches', label: 'matches', fields: ['string']});
	
	contentMap = {
		'parallelism': i18N['sax.notification.parallelism'],
		'maxSpoutPending': i18N['sax.notification.maxSpoutPending'],
		'taskCount': i18N['sax.notification.taskCount'],
		'messageName': i18N['sax.notification.messageName'],
		'configurationType': i18N['sax.notification.configurationType'],
		'streamGrouping': i18N['sax.notification.streamGrouping'],
		'partitionByFields': i18N['sax.notification.partitionByFields'],
		'schemaIdentifier': i18N['sax.notification.schemaIdentifier'],
		'expression': i18N['sax.notification.expression'],
		'filterRule': i18N['sax.notification.filterRule'],
		'filterMessageName': i18N['sax.notification.filterMessageName'],
		'statisticalMessageName': i18N['sax.notification.statisticalMessageName'],
		'statisticalFields': i18N['sax.notification.statisticalField'],
		'statisticalTimeWindow': i18N['sax.notification.statisticalTimeWindow'],
		'statisticalWindowDuration': i18N['sax.notification.statisticalWindowDuration'],
		'statisticalGroupBy': i18N['sax.notification.statisticalGroupBy'],
		'statisticalGroupFields': i18N['sax.notification.statisticalGroupFields'],
		'dynamicCEPHelp': i18N['sax.notification.dynamicCEPHelp'],
		'dynamicAction': i18N['sax.notification.dynamicAction'],
		'dynamicClassName': i18N['sax.notification.dynamicClassName'],
		'dynamicExchangeName': i18N['sax.notification.dynamicExchangeName'],
		'dynamicRoutingKey': i18N['sax.notification.dynamicRoutingKey'],
		'dynamicURL': i18N['sax.notification.dynamicURL'],
		'dynamicMethod': i18N['sax.notification.dynamicMethod'],
		'dynamicHeaderParams': i18N['sax.notification.dynamicHeaderParams'],
		'dynamicRequestParams': i18N['sax.notification.dynamicRequestParams'],
		'dynamicInitParams': i18N['sax.notification.dynamicInitParam'],
		'kafka-channel_topicName': i18N['sax.notification.kafka-channel_topicName'], // Channels
		'kafka-channel_brokerZkRoot': i18N['sax.notification.kafka-channel_brokerZkRoot'],
		'kafka-channel_offsetMarker': i18N['sax.notification.kafka-channel_offsetMarker'],
		'kafka-channel_replicationFactor': i18N['sax.notification.kafka-channel_replicationFactor'],
		'kafka-channel_partitions': i18N['sax.notification.kafka-channel_partitions'],
		'kafka-channel_forceFromStart': i18N['sax.notification.kafka-channel_forceFromStart'],
		'kafka-channel_fetch.size': i18N['sax.notification.kafka-channel_fetch.size'],
		'kafka-channel_buffer.size': i18N['sax.notification.kafka-channel_buffer.size'],
		'rabbitmq-channel_queueConfig': i18N['sax.notification.rabbitmq-channel_queueConfig'],
		'rabbitmq-channel_exchangeName': i18N['sax.notification.rabbitmq-channel_exchangeName'],
		'custom-channel_channelPlugin': i18N['sax.notification.custom-channel_channelPlugin'] ,
		'custom-processor_executorPlugin': i18N['sax.notification.custom-processor_executorPlugin'], // Processors
		'solr-emitter_isBatchEnable': i18N['sax.notification.index-emitter_isBatchEnable'],
		'solr-emitter_batchSize': i18N['sax.notification.index-emitter_batchSize'],
		'elasticsearch-emitter_isBatchEnable': i18N['sax.notification.index-emitter_isBatchEnable'],
		'elasticsearch-emitter_batchSize': i18N['sax.notification.index-emitter_batchSize'],
		'persistence-processor_isBatchEnable':i18N['sax.notification.persistence-processor_isBatchEnable'],
		'persistence-processor_batchSize': i18N['sax.notification.persistence-processor_batchSize'],
		'pmml-processor_sax.pmml.file.path': i18N['sax.notification.pmml-processor_sax.pmml.file.path'],
		'pmml-processor_pmml.messageName': i18N['sax.notification.pmml-processor_pmml.messageName'],
		'timer-processor_timerPlugin': i18N['sax.notification.timer-processor_timerPlugin'],
		'timer-processor_tickFrequencyInSeconds': i18N['sax.notification.timer-processor_tickFrequencyInSeconds'],
		'hdfs-emitter_isBatchEnable': i18N['sax.notification.hdfs-emitter_isBatchEnable'],
		'hdfs-emitter_batchSize': i18N['sax.notification.hdfs-emitter_batchSize'],
		'hdfs-emitter_hdfsPaths': i18N['sax.notification.hdfs-emitter_hdfsPaths'],
		'hdfs-emitter_hdfsFilePrefix': i18N['sax.notification.hdfs-emitter_hdfsFilePrefix'],
		'hdfs-emitter_syncSize': i18N['sax.notification.hdfs-emitter_syncSize'],
		'hdfs-emitter_blockSize': i18N['sax.notification.hdfs-emitter_blockSize'],
		'hdfs-emitter_maxFileSize': i18N['sax.notification.hdfs-emitter_maxFileSize'],
		'hdfs-emitter_replication': i18N['sax.notification.hdfs-emitter_replication'],
		'hdfs-emitter_outputType': i18N['sax.notification.hdfs-emitter_outputType'],
		'hdfs-emitter_delimiter': i18N['sax.notification.hdfs-emitter_delimiter'],
		'hdfs-emitter_compressionType': i18N['sax.notification.hdfs-emitter_compressionType'],
		'hdfs-emitter_hdfsFSURIId': i18N['sax.notification.hdfs-emitter_hdfsFSURIId'],
		'hdfs-emitter_hdfsUsernameId':i18N['sax.notification.hdfs-emitter_hdfsUsernameId'],
		'hdfs-emitter_hdfsEnableHAId':i18N['sax.notification.hdfs-emitter_hdfsEnableHAId'],
		'hdfs-emitter_hdfsNameServicesId':i18N['sax.notification.hdfs-emitter_hdfsNameServicesId'],
		'hdfs-emitter_hdfsNameNode1NameId':i18N['sax.notification.hdfs-emitter_hdfsNameNode1NameId'],
		'hdfs-emitter_hdfsNamenode1RPCAddressId':i18N['sax.notification.hdfs-emitter_hdfsNamenode1RPCAddressId'],
		'hdfs-emitter_hdfsNameNode2NameId':i18N['sax.notification.hdfs-emitter_hdfsNameNode2NameId'],
		'hdfs-emitter_hdfsNamenode2RPCAddressId':i18N['sax.notification.hdfs-emitter_hdfsNamenode2RPCAddressId'],
		'hdfs-emitter_hdfsPath':i18N['sax.notification.hdfs-emitter_hdfsPaths'],
		'hdfs-emitter_fields':i18N['sax.notification.hdfs-emitter_fields'],
		'hdfs-emitter_controlFile':i18N['sax.notification.hdfs-emitter_controlFile'],
		'hdfs-emitter_rotationPolicy':i18N['sax.notification.hdfs-emitter_rotationPolicy'],
		'hdfs-emitter_fileRotationSize':i18N['sax.notification.hdfs-emitter_fileRotationSize'],
		'hdfs-emitter_fileRotationTime':i18N['sax.notification.hdfs-emitter_fileRotationTime'],
		'custom-cep-processor_cep.query': i18N['sax.notification.custom-cep-processor_cep.query'],
		'custom-cep-processor_cep.query.messageName': i18N['sax.notification.custom-cep-processor_cep.query.messageName'],
		'custom-cep-processor_cep.delegate': i18N['sax.notification.custom-cep-processor_cep.delegate'],
		'statistical-cep-processor_cep.delegate': i18N['sax.notification.statistical-cep-processor_cep.delegate'],
		'kafka-emitter_topicName': i18N['sax.notification.kafka-emitter_topicName'] ,
		'kafka-emitter_replicationFactor': i18N['sax.notification.kafka-emitter_replicationFactor'],
		'kafka-emitter_partitions': i18N['sax.notification.kafka-emitter_partitions'],
		'kafka-emitter_producerType': i18N['sax.notification.kafka-emitter_producerType'],
		'kafka-emitter_outputFormat': i18N['sax.notification.kafka-emitter_outputFormat'],
		'kafka-emitter_delimiter': i18N['sax.notification.kafka-emitter_delimiter'],
		'kafka-emitter_outputFields': i18N['sax.notification.kafka-emitter_outputFields'],
		'stream-emitter_StreamId': i18N['sax.notification.stream-emitter_StreamId'],
		'rabbitmq-emitter_exchangeName': i18N['sax.notification.rabbitmq-emitter_exchangeName'],
		'rabbitmq-emitter_queueConfig': i18N['sax.notification.rabbitmq-emitter_queueConfig'],
		'rabbitmq-emitter_outputFormat': i18N['sax.notification.rabbitmq-emitter_outputFormat'],
		'rabbitmq-emitter_delimiter': i18N['sax.notification.rabbitmq-emitter_delimiter'],
		'rabbitmq-emitter_outputFields': i18N['sax.notification.rabbitmq-emitter_outputFields'],
		'cassandra-emitter_connectionName': i18N['sax.notification.connectionName'],
		'cassandra-emitter_hosts': i18N['sax.notification.hosts'],
		'cassandra-emitter_username': i18N['sax.notification.loginName'],
		'cassandra-emitter_password': i18N['sax.notification.loginPassword'],
		'hbase-emitter_connectionName': i18N['sax.notification.connectionName'],
		'hbase-emitter_hdfsUser':i18N['sax.notification.hdfsUser'],
		'hbase-emitter_zkHosts':i18N['sax.notification.zkHosts'],
		'hbase-emitter_zkPort': i18N['sax.notification.zkPort'],
		
		'filterNegate': i18N['sax.notification.filterNegate'],
		'cassandra-emitter_tableNameExpression': i18N['sax.desc.cassandraTableNameExpression'],
		'cassandra-emitter_authenticate':i18N['sax.desc.cassandraEmitterAuthenticate'],
		'cassandra-emitter_batchSize': i18N['sax.notification.persistence-emitter_batchSize'],
		'cassandra-emitter_isBatchEnable': i18N['sax.notification.persistence-emitter_isBatchEnable'],
		'cassandra-emitter_compression': i18N['sax.desc.compression'],
		'hbase-emitter_tableNameExpression': i18N['sax.desc.hbaseTableNameExpression'],
		'hbase-emitter_compression': i18N['sax.desc.compression'],
		'hbase-emitter_regionSplittingDefinition': i18N['sax.desc.regionSplittingDefinition'],
		'hbase-emitter_regionBoundaries': i18N['sax.desc.hBaseRegionBoundries'],
		'hbase-emitter_batchSize': i18N['sax.notification.persistence-emitter_batchSize'],
		'hbase-emitter_isBatchEnable': i18N['sax.notification.persistence-emitter_isBatchEnable'],
		'hdfs-emitter_rotationAction': i18N['sax.notification.hdfs-emitter_rotationAction'],
		'database':"<p>Content regarding database</p>",
		'msgRegSptDef':"<p>Content of Region Splitting Definition</p>",
		'msgHBaseRegBound':"<p>Content of  Region Boundaries</p>",
		'descDriverClass' : "Driver Class Description",
		'descURL' : "URL Field Description",
		'descUsername' : "Username Description",
		'descPassword' : "Password Description",
		'descWSParams' :"Description regarding WS Params",
		'descContentType' : "Content Type Description",
		'descMethodType' : "Method Type Description",
		'descEndPoint' : "End Point Description",
		'descArgument' : "Argument Description",
		'rabbitmq-channel_exchangeType': i18N['sax.notification.rabbitmq_exchangeType'],
		'rabbitmq-channel_exchangeDurable': i18N['sax.notification.rabbitmq_exchangeDurable'],
		'rabbitmq-channel_exchangeAutoDelete': i18N['sax.notification.rabbitmq_exchangeAutoDelete'],
		'rabbitmq-channel_routingKey': i18N['sax.notification.rabbitmq_routingKey'],
		'rabbitmq-channel_queueName': i18N['sax.notification.rabbitmq_queueName'],
		'rabbitmq-channel_queueDurable': i18N['sax.notification.rabbitmq_queueDurable'],
		'rabbitmq-channel_queueExclusive': i18N['sax.notification.rabbitmq_queueExclusive'],
		'rabbitmq-channel_queueAutoDelete': i18N['sax.notification.rabbitmq_queueAutoDelete'],
		'rabbitmq-emitter_exchangeType': i18N['sax.notification.rabbitmq_exchangeType'],
		'rabbitmq-emitter_exchangeDurable': i18N['sax.notification.rabbitmq_exchangeDurable'],
		'rabbitmq-emitter_exchangeAutoDelete': i18N['sax.notification.rabbitmq_exchangeAutoDelete'],
		'rabbitmq-emitter_routingKey': i18N['sax.notification.rabbitmq_routingKey'],
		'rabbitmq-emitter_queueName': i18N['sax.notification.rabbitmq_queueName'],
		'rabbitmq-emitter_queueDurable': i18N['sax.notification.rabbitmq_queueDurable'],
		'rabbitmq-emitter_queueExclusive': i18N['sax.notification.rabbitmq_queueExclusive'],
		'rabbitmq-emitter_queueAutoDelete': i18N['sax.notification.rabbitmq_queueAutoDelete'],
		'elasticsearch-emitter_hosts':i18N['sax.desc.esHost'],
		'elasticsearch-emitter_clusterName':i18N['sax.desc.esClusterName'],
		'elasticsearch-emitter_connectionName':i18N['sax.notification.connectionName'],
		'elasticsearch-emitter_acrossFieldSearchEnabled':i18N['sax.desc.searchAcrossField'],
		'elasticsearch-emitter_indexNumberOfShards' :i18N['sax.desc.numberOfShards'],
		'elasticsearch-emitter_indexReplicationFactor' :i18N['sax.desc.replicationFactor'],
	 	'elasticsearch-emitter_indexExpression':i18N['sax.desc.indexNameExpression'],
	 	'elasticsearch-emitter_routingRequired':i18N['sax.desc.routingRequired'],
	 	'elasticsearch-emitter_routingPolicy':i18N['sax.desc.routingPolicy'],
	 	'elasticsearch-emitter_indexSource':i18N['sax.desc.sourceEnable'],
	 	'solr-emitter_connectionName':i18N['sax.notification.connectionName'],
	 	'solr-emitter_acrossFieldSearchEnabled' :i18N['sax.desc.searchAcrossField'],
		'solr-emitter_indexNumberOfShards' :i18N['sax.desc.numberOfShards'],
		'solr-emitter_indexReplicationFactor' :i18N['sax.desc.replicationFactor'],
	 	'solr-emitter_indexExpression':i18N['sax.desc.indexNameExpression'],
	 	'solr-emitter_routingRequired':i18N['sax.desc.routingRequired'],
	 	'solr-emitter_routingPolicy':i18N['sax.desc.routingPolicy'],
	 	'solr-emitter_indexSource':i18N['sax.desc.sourceEnable'],
		'solr-emitter_zkHosts':i18N['sax.desc.solrZkHosts'],
		'solr-emitter_zkPort':i18N['sax.desc.solrZkPort'],
		'kafka-channel_connectionName':i18N['sax.notification.connectionName'],
		'rabbitmq-channel_connectionName':i18N['sax.notification.connectionName'],
		'rabbitmq-channel_username': i18N['sax.notification.rabbitMqLoginName'],
		'rabbitmq-channel_password': i18N['sax.notification.rabbitMqPassword'],
		'rabbitmq-channel_hosts': i18N['sax.notification.rabbitMqhosts'],
		'kafka-channel_zkHosts': i18N['sax.notification.kafkazkhosts'],
		'kafka-channel_kafkaBrokers': i18N['sax.notification.kafkaBrokers'],
		'replay-channel_discardedExchangeName': i18N['sax.notification.discardedExchangeName'],
		'replay-channel_discardedQueueName': i18N['sax.notification.discardedQueueName'],
		'replay-channel_x-message-ttl': i18N['sax.notification.x-message-ttle'],
		'replay-channel_maxRetries': i18N['sax.notification.maxRetries'],
		'activemq-channel_topicConfig': i18N['sax.notification.topicConfigChannel'],
		'activemq-emitter_topicConfig': i18N['sax.notification.topicConfigEmitter'],
		'activemq-channel_routingKey': i18N['sax.notification.activemq_routingKey'],
		'activemq-emitter_routingKey': i18N['sax.notification.activemq_routingKey'],
		'activemq-emitter_outputFormat': i18N['sax.notification.rabbitmq-emitter_outputFormat'],
		'activemq-emitter_outputFields': i18N['sax.notification.rabbitmq-emitter_outputFields'],
		'cepEnableContext': '',
		'cepContextName': 'Identifier of the ESPER Context',
		'cepStartTime': 'User can specify the time of Day When he would like to start executing the queries which are using this Context',
		'cepEndTime': 'User can specify the time of Day When he would like to stop executing the queries which are using this Context',
		'cepApplyFilterCriteria': '',
		'cepApplyGroupBy': '',
		'cepApplyGroupByFilter': '',
		'cepOutput': '',
		'cepFlushResults': ''
	};
	
	var schemeName = {
		kafka: {
			single: 'com.streamanalytix.storm.core.scheme.TraceMessageMultiScheme',
			multi: 'com.streamanalytix.storm.core.scheme.MultiTraceMessageMultiScheme'
		},
		rabbitmq: {
			single: 'com.streamanalytix.storm.core.scheme.TraceMessageScheme',
			multi: 'com.streamanalytix.storm.core.scheme.MultiTraceMessageScheme'
		}
	};
	
	var boltsValidation = {};
		boltsValidation[cmpIDs.customchannel] = { 'messageTypes': null };
		boltsValidation[cmpIDs.kafkachannel] = { 'messageTypes': null };
		boltsValidation[cmpIDs.rabbitmqchannel] = { 'messageTypes': null };
		boltsValidation[cmpIDs.filterprocessor] = { 'config': 'filterQuery:{}' };
		boltsValidation[cmpIDs.aggregationfunction] = { 'query': 'undefined' };
		boltsValidation[cmpIDs.hdfsemitter] = { 'config': 'hdfsPaths:{hdfsPath: ""}' };
		boltsValidation[cmpIDs.rabbitmqemitter] = { 'config': 'outputFields:tracemessage' };
		boltsValidation[cmpIDs.kafkaemitter] = { 'config': 'outputFields:tracemessage' };
		boltsValidation[cmpIDs.cepcustom] = { 'config': 'cep.query.messageName:tracemessage' };
		boltsValidation[cmpIDs.customprocessors] = { 'config': 'executorPlugin:' };
		boltsValidation[cmpIDs.enricherprocessor] = { 'config': 'enrichFlds:{}' };
		boltsValidation[cmpIDs.timerprocessor] = { 'config': 'timerPlugin:' };

	var duplicateNameErrorObj = { isDuplicate: false, lastEnteredName: '' };
	var DUPLICATE_NAME_ERROR = i18N['sax.notification.duplicateNameError'];
	var NULL_NAME_ERROR = i18N['sax.notification.nullNameError'];
	
	self.init = function () {
		window.ParsleyValidator.addValidator('ge', 
			function (value, requirement) {
				return parseFloat(value) >= parseFloat($(requirement).val());
			}, 32)
			.addMessage('en', 'ge', i18N['sax.notification.ge']);
			
		window.ParsleyValidator.addValidator('connNameVal', function (value, requirement) {
			var regexp = /^[a-zA-Z0-9\_\-]+$/;
			if (value.search(regexp) == -1)
				return false;
			else
				return true;
		}, 32).addMessage('en', 'connNameVal', i18N['sax.notification.specialChar']);
		
		window.ParsleyValidator.addValidator('sameIPVal', function (value, requirement) {
			value = value.replace(/\s/g, '');
			if (value.indexOf(',') > -1 ){
				value = value.split(',');
				var sameIPArr = [];
				for ( var i = 0; i < value.length; i++ ) {
					if ( $.inArray(value[i], sameIPArr) != -1 ) {
						return false;
					}else {
						sameIPArr.push(value[i]);
					}
				}
			}
			return true;
		}, 32).addMessage('en', 'sameIPVal', i18N['sax.notification.sameIP']);
		
		window.ParsleyValidator.addValidator('hostPortVal', function (value, requirement) {
			//var regexp = /^[a-zA-Z0-9\_\.\-]+\:\d{1,5}$/;
			var regexp = /^(((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))|([A-Za-z0-9]+((\.?[A-Za-z0-9])|(\-?[A-Za-z0-9]))*[A-Za-z0-9]+))+([:][0-9]{1,5})$/;
			value = value.replace(/\s/g, '');
			if (value.indexOf(',') > -1 ){
				value = value.split(',');
				for ( var i = 0; i < value.length; i++ ) {
					if (value[i].search(regexp) == -1) {
						return false;
					}
				}
			} else {
				if (value.search(regexp) == -1) {
					return false;
				}
			}
			return true;
		}, 32).addMessage('en', 'hostPortVal', i18N['sax.notification.hostPortVal']);
		
		window.ParsleyValidator.addValidator('hostVal', function (value, requirement) {
			var regexp = /^(((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))|([A-Za-z0-9]+((\.?[A-Za-z0-9])|(\-?[A-Za-z0-9]))*[A-Za-z0-9]+))+$/;
			value = value.replace(/\s/g, '');
			if (value.indexOf(',') > -1 ){
				value = value.split(',');
				for ( var i = 0; i < value.length; i++ ) {
					if (value[i].search(regexp) == -1) {
						return false;
					}
				}
			} else {
				if (value.search(regexp) == -1) {
					return false;
				}
			}
			return true;
		}, 32).addMessage('en', 'hostVal', i18N['sax.notification.hostVal']);
		
		// Set canvas height
		self.resizeCanvas();
		
		messagesFieldsVersionData = self.getAjaxData(allMessagesUrl);
		if ( messagesFieldsVersionData.AllMessages ) {
			allMessagesData = messagesFieldsVersionData.AllMessages;
		} else {
			allMessagesData = [];
		}
		getSubSystemsStatusData = self.getAjaxData(getSubSystemsStatusUrl);
		tenetSubsystemData = self.getAjaxData(tenetSubsystemUrl);
		rebalSupervisorData = self.getAjaxData(tenetSubsystemUrl);
		functionsData = self.getAjaxData(functionsList);
		variablesData = self.getAjaxData(variablesList);
		
		$("#supervisorFld").empty().select2('destroy').select2({placeholder: i18N['sax.placeholder.supervisorField']});
		for ( var i=0; i<tenetSubsystemData.length; i++ ) {
			$("#supervisorFld").append('<option value="'+ tenetSubsystemData[i] +'" selected>' + tenetSubsystemData[i] + '</option>')
		}

		$("#rebalanceSupervisorFld").empty().select2('destroy').select2({placeholder: i18N['sax.placeholder.supervisorField']});
		for ( var i=0; i<rebalSupervisorData.length; i++ ) {
			$("#rebalanceSupervisorFld").append('<option value="'+ rebalSupervisorData[i] +'" selected>' + rebalSupervisorData[i] + '</option>')
		}
			
		for ( var i=0; i<getSubSystemsStatusData.length; i++ ) {
			if ( getSubSystemsStatusData[i].topologyName == ssId && ( getSubSystemsStatusData[i].status == "ACTIVE" || getSubSystemsStatusData[i].status == "INACTIVE" )) {
				currentFabricStatus=getSubSystemsStatusData[i].status;
				$('#supervisorFld').prop('disabled', true); 
				$('#loadVersionLink').addClass("disabled");
				break;
			} else {
				currentFabricStatus='STOPPED';
			}
		}
		
		if(currentFabricStatus != 'ACTIVE'){
			$('#rebalanceModalLink').addClass('disabled');	
		}
				
		restrictedComponents = self.postAjaxData(restrictedComponentsUrl);
		allChannelsData = self.getAjaxData(allChannelsUrl);
		
		if ( typeof allChannelsData.thrownError !== "undefined" ) {
			$('#dataFabricErrorWrap').html('<div class="alert alert-error alert-dismissable">' + errorObj.TABLE_RENDERING + '</div>');
			$("#subSystemDefWgdLoader, #dataFabricContent").hide();
			return;
		} else if ( allChannelsData.length == 0 ) {
			$('#dataFabricErrorWrap').html('<div class="alert alert-info alert-dismissable">' + errorObj.NO_DATA + '</div>');
			$("#subSystemDefWgdLoader, #dataFabricContent").hide();
			return;
		}
		
		$("#dataFabricContent").show();
		$('#dataFabricErrorWrap').empty();
		
		if ( ssId != 'null' && ssId != '' ) {
			allSubSystemData = self.getAjaxData(allSubSystemUrl);
			for ( var i=0; i<allSubSystemData.length; i++ ) {
				if ( allSubSystemData[i].name == ssId )
					curSubSystemData = allSubSystemData[i];
			}
		} else {
			$('#subSystemName').focus();
		}
		
		self.createAllChannesToolbar();
		self.setChannesToolbarHeight();
		$("#subSystemDefWgdLoader").hide();
		
		$('#componentsMenubar').on("click", function() {
			$(this).toggleClass('active');
			$("#ssToolbarWrap").toggleClass('in');
		});
		
		$("#curChannelTitle a").on("click", function() {
			var valLen = $("#curChannelLabel").val().length;
			$("#curChannelLabel").show().focus();
			$("#curChannelTitle").hide();
			$('#curChannelLabel').caret(valLen, valLen);
		});
		
		$("#curChannelLabel").on("keypress", function(e) {
			var keyCodes = [0, 8, 13, 46];
			if ( jQuery.inArray(e.which, keyCodes) == -1 ) {
				var regex = new RegExp("^[a-zA-Z0-9]+$");
				var key = String.fromCharCode(!e.charCode ? e.which : e.charCode);
				if ( !regex.test(key) ) {
				   e.preventDefault();
				   return false;
				}
			}
		});
		
		$("#curChannelLabel").on("blur keyup", function(e) {
			if ( (e.type == 'keyup' && e.which == 13) || e.type == 'blur' ) {
				var actualLable;
				var type = $("#componentType").val();
				var id = $("#curChannelName").val();
				var uuid = $("#curChannelId").val();
				var value = $(this).val();
				var lbl = value.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '');
				
				actualLable = ( type == "spout" ) ? addedSpoutsObj[id].label : addedBoltsObj[id].label;
				lbl = (lbl.length == 0) ? actualLable : lbl;
				
				var randomId = id.split("_")[1];
				var name = lbl + '_' + randomId;
				
				$(this).val(lbl);
				$("#curChannelLabel").hide();
				$("#curChannelTitle").find("span").text(lbl).end().show();
				$("#"+id).find("span").text(lbl);
				
				var $divW = $("#"+id).width();
				var $lblW = $("#"+id).find("span").outerWidth();
				var diff;
				if ( $lblW > $divW ) {
					diff = ($divW-$lblW)/2;
					$("#"+id).find("span").css("margin-left", diff+"px");
				} else {
					$("#"+id).find("span").css("margin-left", "0px");
				}
				
				if ( type == "spout" ) {
					addedSpoutsObj[id].name = name;
					addedSpoutsObj[id].label = lbl;
				} else {
					addedBoltsObj[id].name = name;
					addedBoltsObj[id].label = lbl;
				}
				
				$.each(addedSpoutsObj, function(key, obj) {
					for ( var i=0; i<obj.emitStreamIds.length; i++ ) {
						if ( obj.emitStreamIds[i].componentId.indexOf( randomId ) > -1 )
							obj.emitStreamIds[i].componentId = name;
					}
					
					if ( deadLaterChannel.connectedChannels ) {
						var compRandomId = obj.name.split('_')[1];
						for ( var i=0; i<deadLaterChannel.connectedChannels.length; i++ ) {
							if ( deadLaterChannel.connectedChannels[i].indexOf(compRandomId) > -1 ) {
								deadLaterChannel.connectedChannels[i] = obj.name;
							}
						}
					}
				});
				
				$.each(addedBoltsObj, function(key, obj) {
					for ( var i=0; i<obj.emitStreamIds.length; i++ ) {
						if ( obj.emitStreamIds[i].componentId.indexOf( randomId ) > -1 )
							obj.emitStreamIds[i].componentId = name;
					}
					
					if ( deadLaterChannel.connectedBolts ) {
						var compRandomId = obj.name.split('_')[1];
						for ( var i=0; i<deadLaterChannel.connectedBolts.length; i++ ) {
							if ( deadLaterChannel.connectedBolts[i].indexOf(compRandomId) > -1 ) {
								deadLaterChannel.connectedBolts[i] = obj.name;
							}
						}
					}
				});
				
				$.each(addedBoltsObj, function(key, obj) {
					for ( var i=0; i<obj.groupings.length; i++ ) {
						if ( obj.groupings[i].componentId.indexOf( randomId ) > -1 )
							obj.groupings[i].componentId = name;
					}
				});
				
				if ( uuid == cmpIDs.dynamiccepprocessor ) {
					var subsystemName = $("#subSystemName").val();
					if ( ssId != 'null' && ssId!='' )
						$("#componentId").html('Component Id: <span class="text-primary">' + subsystemName + '_' + name + '</span>' );
					else	
						$("#componentId").html('Component Id: <span class="text-primary">subsystemName_' + name + '</span>' );
				}
			}
		});
		
		$(document).on("hover", 'a[content="cassandra-emitter_tableNameExpression"]', function() {
			$(this).attr('data-content', i18N['sax.desc.cassandraTableNameExpression1']+ currentTenantId +i18N['sax.desc.cassandraTableNameExpression2']);
		});
		
		$("#cancelSubSystem").on("click", function() {
			window.onbeforeunload = null;
			window.location.href = ssListingPageUrl;					
		});
		
		$.each(allMessagesData, function(key, arr) {
			allMsgOptions += '<option value="'+ key +'">'+ key +'</option>';
		});
		
		$(document).on("change", "#grouping", function() {
			self.createFieldsOption("#groupFields");
			if ( $(this).val() == 'fields' ) {
				$("#groupFields").attr('data-parsley-required', 'true');
				$("#groupFieldsWrap").show();
				$("#groupFields").select2("destroy").select2({placeholder: i18N['sax.placeholder.pleaseSelect']});
			} else {
				$("#groupFields").attr('data-parsley-required', 'false');
				$("#groupFieldsWrap").hide();
			}
		});
		
		// StreamID Functionality START
		$('.stream-type-radio').on("click", function() {
			var streamType = $('.stream-type-radio:checked').val();
			var curStreamName = $('#streamNameFld').val();
			
			if ( streamType == 'default' ) {
				$('#streamIdCustomWrap').hide();
				$('#streamNameFld').val('defaultStream');
			} else {
				$('#streamIdCustomWrap').show();
				if ( curStreamName == 'defaultStream' ) $('#streamNameFld').val('');
			}
		});
		
		$('#saveStreamBtn').on('click', function() {
			// Validatation for Filter BETWEEN operator
			self.filterBetweenValidation();
			
			var validate = $('#streamModalForm').parsley().validate();
			if (validate) {
				var streamId, oldStreamId, sortStreamId, outputFields = [], groupFields, streamType, messageType, isSourceChannel = false;
				var conn = jsPlumb.getConnections();
				streamId = $('#streamNameFld').val();
				oldStreamId = $('#streamNameOld').val();
				//outputFields = $('#groupFields').val();
				groupFields = $('#groupFields').val();
				streamType = $('#grouping').val();
				sortStreamId = (streamId.length > 18) ? (streamId.substr(0, 15)+'...') : streamId;

				messageType = 'tracemessage'; //addedSpoutsObj[rootSpouts[0]].messageTypeId;
				isSourceChannel = (addedSpoutsObj[streamIdConn.sourceId]) ? true : false;
				var sourceCmp = (addedSpoutsObj[streamIdConn.sourceId]) ? addedSpoutsObj[streamIdConn.sourceId] : addedBoltsObj[streamIdConn.sourceId];
				var targetCmp = addedBoltsObj[streamIdConn.targetId];
				var errorStreamId = errorStream;
				
				if ( groupFields == 'null' || groupFields == null ) {
					groupFields = [];
				}
				
				outputFields.push(messageType);
				// Adding "streamIds" in outputFields in channel
				if ( typeof sourceCmp.type === 'undefined' && jQuery.inArray("streamIds", outputFields) == -1 ) {
					outputFields.push("streamIds");
				}
				
				outputFields = outputFields.concat(groupFields);
				
				var filterData = self.getFileterRules();
				filterData = JSON.parse(filterData);
				
				var isMatched = false;
				for ( var i=0; i<sourceCmp.emitStreamIds.length; i++ ) {
					if ( isSourceChannel && sourceCmp.emitStreamIds[i].emitStreamId != errorStream ) {
						sourceCmp.emitStreamIds[i].emitStreamId = streamId;
					}
					
					if ( !isMatched && sourceCmp.emitStreamIds[i].componentId == targetCmp.name ) {
						sourceCmp.emitStreamIds[i].emitStreamId = streamId;
						sourceCmp.emitStreamIds[i].outputFields = outputFields;
						isMatched = true;
					}
					
					if ( sourceCmp.emitStreamIds[i].emitStreamId == streamId || sourceCmp.emitStreamIds[i].emitStreamId == errorStream ) {
						sourceCmp.emitStreamIds[i].filterCriteria = filterData.rules;
					}
					
					if ( streamId == sourceCmp.emitStreamIds[i].emitStreamId ) {
						for ( var c=0; c<conn.length; c++ ) {
							var sourceId = ( addedSpoutsObj[conn[c].sourceId] ) ? addedSpoutsObj[conn[c].sourceId].name : addedBoltsObj[conn[c].sourceId].name;
							var targetId = addedBoltsObj[conn[c].targetId].name;
							if ( sourceId == sourceCmp.name && targetId == sourceCmp.emitStreamIds[i].componentId ) {
								if ( sourceCmp.emitStreamIds[i].componentId == targetId ) {
									conn[c].removeOverlay( conn[c].targetId+'Filter' );
									if ( filterData.rules.length > 0 ) {
										sourceCmp.emitStreamIds[i].filterCriteria = filterData.rules;
										sourceCmp.emitStreamIds[i].applyFilter = true;
										conn[c].addOverlay( [ "Label", { id: (conn[c].targetId+'Filter'), location: 0.5, cssClass:"fa fa-filter filter-symbol" } ] );
									} else {
										sourceCmp.emitStreamIds[i].applyFilter = false;
									}
								}
								
								conn[c].removeOverlay( conn[c].targetId+'StrId' );
								conn[c].addOverlay( [ "Custom", { create:function(component) { return $('<div><span title="'+ streamId +'">'+sortStreamId+'</span></div>'); }, id: (conn[c].targetId+'StrId'), location: 0.5, cssClass:"str-label" } ] );
							}
							
							if ( isSourceChannel ) {
								for ( var k=0; k<addedBoltsObj[conn[c].targetId].groupings.length; k++ ) {
									if ( addedBoltsObj[conn[c].targetId].groupings[k].componentId == sourceCmp.name ) {
										addedBoltsObj[conn[c].targetId].groupings[k].streamId = streamId;
									}	
								}
								
								var trgCmp = addedBoltsObj[sourceCmp.emitStreamIds[i].componentId];
								self.resetStreamId(trgCmp, sourceCmp.emitStreamIds[i].componentId, streamId, oldStreamId);
							}
						}
					}
				}
				
				var streamGrouping = '';
				for ( var i=0; i<targetCmp.groupings.length; i++ ) {
					if ( targetCmp.groupings[i].componentId == sourceCmp.name ) {
						if ( streamGrouping != 'fields' )
							streamGrouping = streamType;
								
						targetCmp.groupings[i].streamId = streamId;
						targetCmp.groupings[i].groupFields = groupFields;
						targetCmp.groupings[i].type = streamType;
					}	
				}
				
				// For all CEPs set Parallelism and Task Count
				if ( targetCmp.id == cmpIDs.cepcustom || targetCmp.id == cmpIDs.aggregationfunction || targetCmp.id == cmpIDs.dynamiccepprocessor ) {
					if ( streamGrouping != 'fields' ) {
						targetCmp.parallelism = 1;
						targetCmp.taskCount = 1;
						if ( targetCmp.id == cmpIDs.aggregationfunction && targetCmp.query ) {
							targetCmp.query.groupBy = 'N';
							targetCmp.query.groupFields = [];
							for ( var i=0; i<targetCmp.config.length; i++ ) {
								if ( targetCmp.config[i].indexOf('cep.query:') == 0 ) {
									var conf = targetCmp.config[i].replace('cep.query:', '');
									var groupbyArr = conf.split(' group by ');
									var replaceStr = groupbyArr[1] + ',';
									var groupbyStr = groupbyArr[0].replace(replaceStr, "");
									targetCmp.config[i] = 'cep.query:' + groupbyStr;
								}
							}
						}
					} else {
						if ( targetCmp.id == cmpIDs.aggregationfunction && targetCmp.query ) {
							targetCmp.query.groupBy = 'Y';
							if ( targetCmp.query.groupFields.join(',') != groupFields.join(',') )
								delete targetCmp.query;
						}
					}
				}
				
				for ( var i=0; i<targetCmp.emitStreamIds.length; i++ ) {
					self.resetStreamId(targetCmp, targetCmp.emitStreamIds[i].componentId, streamId, oldStreamId);
				}
				
				$('#streamModalWrap').modal('hide');
				streamIdConn = null, rootSpouts = [], criteriaData = [], usedMessages = [], allMessages = [];
			} else {
				$(".tab-pane").each(function() {
					var errs = $(this).find(".parsley-errors-list li").size();
					if ( errs > 0 ) {
						var id = $(this).attr("id");
						$("a[href='#"+ id +"']").trigger("click");
					}
				});
			}
		});
		// StreamID Functionality END
	
		$(document).on("click", ".add-config-row", function(e) {
			e.preventDefault();
			var compType = $('#componentType').val();
			
			var _parent = $(this).closest('#configRows');
			_parent.append(configHTML);
			$(this).remove();
			$(".tooltip").remove();
			$(".tt").tooltip();
			
			var curChannelId = $('#curChannelId').val();
			if ( curChannelId == cmpIDs.rabbitmqchannel || curChannelId == cmpIDs.rabbitmqemitter ) {
				_parent.find('.config-row:last .config-value').attr({
					'data-parsley-pattern': '^[A-Za-z0-9_-]*$',
					'data-parsley-pattern-message': i18N['sax.message.keyValueMsz']
				});
			}
			
			if ( ($.inArray(activeComp.id, functionSupportedComps) > -1) || (typeof activeComp.subtype !== 'undefined' && activeComp.subtype == 'custom' && activeComp.type != 'channel') ) {
				_parent.find("input.config-value:last").initQueryBuilder({data: fvAutoSuggestData});
			}
		});
		
		$(document).on("click", ".remove-config-row", function(e) {
			e.preventDefault();
			var rowCnt = $(this).closest('.config-row').siblings('.config-row:visible').size();
			var addCnt = $(this).closest('.config-row').find(".add-config-row:visible").size();
			if ( addCnt > 0 ) {
				$(this).closest('.config-row').prevAll(":visible:first").append('<a href="javascript:void(0)" title="'+i18N['sax.label.add']+'" class="add-config add-config-row add-ico tt"><i class="fa fa-plus"></i></a>');
			}
			
			if ( rowCnt == 0 ) {
				$(this).closest('.config-row').parent().append('<a href="javascript:void(0)" title="'+i18N['sax.label.add']+'" class="add-config add-config-row add-ico tt"><i class="fa fa-plus"></i></a>');
			}
			$(this).closest('.config-row').remove();
			$(".tt").tooltip();
		});		

		$(document).on("click", "#cancelChannelProp", function(e) {
			var curChnlId = $('#curChannelName').val();
			var fldId = curChnlId.split('_')[1];
			$('#pmmlFile'+fldId).val('');
		});
		
		$(document).on("click", "#saveChannelProp", function(e) {
			var curChnl, flag = true, validate = true, chnlValidated = true;
			var componentType = $("#componentType").val();
			var curChannelName = $("#curChannelName").val();
			var curChannelId = $("#curChannelId").val();
			curChnl = ( componentType == 'spout' ) ? addedSpoutsObj[curChannelName] : addedBoltsObj[curChannelName];
			
			// Remove Extra Tabs of LookupFunctions
			lookupClass.removeExtraTabs();
			
			// VALIDATE CEPs
			if ( curChannelId == cmpIDs.cepcustom || curChannelId == cmpIDs.dynamiccepprocessor || curChannelId == cmpIDs.aggregationfunction ) {
				$('#addParamBtn').trigger('click');
			}
			
			// VALIDATE ANALYTICS BOLT
			if ( curChannelId == cmpIDs.analyticsprocessor ) {
				$('#testModalVars').empty();
				validate = DFAnalytics.validateAnalytics(curChnl, 'save');
				var msgName = $('select#analyticsMessage').val();
				$('.inputMessageName-fld').val(msgName);
				curChnl.config[3] = "inputMessageName:"+msgName;
			}
									
			// Validatation for Filter BETWEEN operator
			self.filterBetweenValidation();
				
			$("#channelProperties [data-parsley-required='true']").each(function() {
				flag = $(this).parsley().validate();
				if ( flag != true ) validate = false;
			});
			
			if ( validate ) {
				$("#channelProperties .parsley-errors-list").empty();
				var channelType = $(".msgtype-radio:checked").val();
				var messageTypes;
				if ( componentType == 'spout' ) {
					var msgTypeId = 'tracemessage';
					if ( channelType == "single" ) {
						$("#messageTypeId").removeAttr("multiple");
						messageTypes = $("#messageTypeId").val();

						// msgTypeId = messageTypes;
						messageTypes = [messageTypes];
					} else if ( channelType == "custom" && messageTypes.length == 1 ) {
						messageTypes = $("#messageTypeId").val();
						// msgTypeId = messageTypes[0];
						messageTypes = [msgTypeId];
					} else {
						messageTypes = $("#messageTypeId").val();
						// msgTypeId = 'tracemessage';
					}
					
					if ( curChnl.id != cmpIDs.customchannel ) {
						var isSchemaId = $('#schemaIdentifierCB').prop('checked');
						if ( isSchemaId ) {
							curChnl.schemaIdentifier = $('#schemeIdFld').val();
						} else {
							if ( channelType == "single" ) {
								curChnl.schemaIdentifier = null;
							} else {
								for ( var i=0; i<allChannelsData.channels.length; i++ ) {
									if ( allChannelsData.channels[i].id == curChnl.id )
										curChnl.schemaIdentifier = allChannelsData.channels[i].schemaIdentifier;
								}
							}
						}
					}
					
					curChnl.maxSpoutPending = $("#maxSpoutPending").val();
					curChnl.scheme = $("#scheme").val();
					curChnl.channelType = channelType;
					var hasSameMessage = false;
					$.each(addedBoltsObj, function(key, obj) {
						obj.messageTypeId = msgTypeId;
						var spoutsMessages = [];
						
						if ( obj.messageTypes ) {
							hasSameMessage = true;
							rootSpouts = [];
							getRootSpouts(obj);
							spoutsMessages = jQuery.extend(true, [], messageTypes);
							
							for ( var i=0; i<rootSpouts.length; i++ ) {
								if ( curChnl.name != rootSpouts[i] ) {
									spoutsMessages = $.merge(spoutsMessages, addedSpoutsObj[rootSpouts[i]].messageTypes);
								}
							}
						
							for ( var i=0; i<obj.messageTypes.length; i++ ) {
								if ( $.inArray(obj.messageTypes[i], spoutsMessages) == -1 )
									hasSameMessage = false;
							}
						}
						
						if ( !hasSameMessage ) {
							if ( obj.id == cmpIDs.aggregationfunction && typeof obj.messageTypes !== 'undefined' && obj.messageTypes.join(',') != messageTypes.join(',') ) {
								delete obj.query; // reset query tab on message change
							} else if ( obj.id == cmpIDs.filterprocessor && obj.messageTypes != messageTypes ) {
								var filterQuery = obj.config[0].replace('filterQuery:', '');
								filterQuery = JSON.parse(filterQuery);
								if ( !$.isEmptyObject(filterQuery) ) {
									filterQuery.rules = $.grep(filterQuery.rules, function(obj) {
										return $.inArray(obj.message, spoutsMessages) > -1;
									});
								}
								
								obj.config = ( filterQuery.rules && filterQuery.rules.length == 0 ) ? ['filterQuery:{}'] : ['filterQuery:'+ JSON.stringify(filterQuery)];
							}
							
							if ( obj.id == cmpIDs.dynamiccepprocessor ) { // reset config for dynamic processors on message change
								obj.config = ["messageNames:"+messageTypes.join(',')];
							}
							
							if ( obj.id == cmpIDs.analyticsprocessor && typeof obj.config[3] !== 'undefined' ) { // reset config for analytics processors on message change
								var usedMsg = obj.config[3].replace("inputMessageName:","");
								if ( $.inArray(usedMsg, messageTypes) == -1 ) 
									obj.config[3] = "inputMessageName:";
							}
							
							// reset config for KAFKA Emitter
							if ( obj.id == cmpIDs.kafkaemitter ) {
								for ( var i=0; i<obj.config.length; i++ ) {
									if ( obj.config[i].indexOf('outputFields:') == 0 )
										obj.config[i] = 'outputFields:tracemessage';
								}
							}
							
							// reset config for RMQ Emitter
							if ( obj.id == cmpIDs.rabbitmqemitter ) {
								for ( var i=0; i<obj.config.length; i++ ) {
									if ( obj.config[i].indexOf('outputFields:') == 0 )
										obj.config[i] = 'outputFields:tracemessage';
								}
							}
							
							for ( var i=0; i<obj.groupings.length; i++ ) {
								obj.groupings[i].type = "shuffle";
								obj.groupings[i].groupFields = [];
							}
						
							for ( var i=0; i<obj.emitStreamIds.length; i++ ) {
								obj.emitStreamIds[i].outputFields = [msgTypeId];
							}
						}
						
						obj.channelType = channelType;
					});
					
					if ( !hasSameMessage ) {
						for ( var i=0; i<curChnl.emitStreamIds.length; i++ ) {
							curChnl.emitStreamIds[i].outputFields = [msgTypeId, "streamIds"];
						}
					}
					
					self.resetFiltersOnMsgChange(curChnl, messageTypes);
					
					$.each(addedSpoutsObj, function(key, obj) {
						if (obj.id == cmpIDs.replaychannel ) {
							obj.messageTypes = messageTypes;
						}
					});
					
				} else {
					var msgTypeId = 'tracemessage';
					curChnl.taskCount = $("#taskCount").val();
					var channelType = curChnl.channelType;
					
					if ( channelType == "single" ) {
						$("#messageTypeId").removeAttr("multiple");
						messageTypes = $("#messageTypeId").val();
						//msgTypeId = messageTypes;
						messageTypes = [messageTypes];
					} else if ( channelType == "custom" && messageTypes.length == 1 ) {
						messageTypes = $("#messageTypeId").val();
						//msgTypeId = messageTypes[0];
						messageTypes = [msgTypeId];
					} else {
						messageTypes = $("#messageTypeId").val();
						//msgTypeId = 'tracemessage';
					}
				}
				
				curChnl.messageTypeId = msgTypeId;
				curChnl.messageTypes = messageTypes;
				self.setMessageTypes();
				
				curChnl.className = $("#className").val();
				curChnl.parallelism = $("#parallelism").val();
				
				if ( curChannelId == cmpIDs.dynamiccepprocessor ) {
					$("#configRows input.messageNames-fld").val( messageTypes.join(',') );
					var queryJSON = self.createDynamicCEPQueryData();
					self.postAjaxData( cepQuerySaveUrl, JSON.stringify(queryJSON) );
				}
				
				if ( curChannelId == cmpIDs.aggregationfunction ) {
					chnlValidated = self.validateCEPStatistical();
					if ( chnlValidated ) {
						var queryObj = statisticalCEPBolt.createFieldsQuery(curChnl);
						curChnl["query"] = queryObj.query;
					
						$("#configRows input[class~='isContextEnabled-fld']").val(queryObj.query.enableContext);
						$("#configRows input[class~='aggQuery-fld']").val( JSON.stringify(queryObj.aggQuery) );
						$("#configRows input[class~='cep.query.messageName-fld']").val(queryObj.query.message);
					}
				}
				
				if ( curChannelId == cmpIDs.jdbcprocessor ) {
					var mappedSchema = jdbcProcessorCls.getSchemaResults();
					$("#configRows input[class~='mappedSchema-fld']").val(mappedSchema);
				}
				
				curChnl.config = [];
				var queueConfig = [];
				$("#configRows .config-row").each(function() {
					var $row = $(this);
					var val = '';
					var key = $row.find(".config-key").val();
					
					if ( curChannelId == cmpIDs.cepcustom && key == 'cepAction' ) {
						var cepAction = customCEPBolt.createActionData();
						curChnl.config.push(key+":"+cepAction);
					} else {
						val = $row.find(".config-value:not(.select2-container)").val();
						
						if ( $row.find(".config-value.checkbox").size() > 0 )
							val = $row.find(".config-value.checkbox").prop('checked');
							
						if ( $row.find(".config-value.radio").size() > 0 )
							val = $row.find(".config-value.radio:checked").val();
						
						key = ( key == 'offsetMarker' ) ? 'zkID' : key;
						
						if ( curChannelId == cmpIDs.rabbitmqchannel && typeof componentsProperties[curChannelId][key] === 'undefined' ) {
							queueConfig.push(key+","+val);
						} else if ( curChannelId == cmpIDs.rabbitmqemitter && typeof componentsProperties[curChannelId][key] === 'undefined' ) {
							queueConfig.push(key+","+val);
						} else {
							curChnl.config.push(key+":"+val);
						}
					}
				});
				
				if ( curChannelId == cmpIDs.enricherprocessor ) {
					curChnl.config = [];
					/* var selectFld = enrichProcessorCls.saveSelectedFields();
					for ( var u = 0; u < selectFld.length; u++ ) {
						curChnl.config.push(selectFld[u]);
					} */
					var enrichValue = enrichProcessorCls.saveEnrich();
					curChnl.config.push('enrichFlds: ' + enrichValue);
				}
				
				if ( curChannelId == cmpIDs.hdfsemitter ) {
					var obj = HDFSBolt.createHDFSPathObj();
					curChnl.config.push("hdfsPaths:"+JSON.stringify(obj));
				}
				
				if ( curChannelId == cmpIDs.replaychannel ) {
					curChnl.config = replayLogsClass.createReplayChnlData();
				}
					
				if ( (curChannelId == cmpIDs.rabbitmqchannel || curChannelId == cmpIDs.rabbitmqemitter) ) {
					curChnl.config.push( 'queueConfig:' + queueConfig.join('|') );
				}
				
				var jsonVal = '', selectConnChk = true;
				if ( curChannelId == cmpIDs.cassandraemitter || curChannelId == cmpIDs.rabbitmqchannel || curChannelId == cmpIDs.rabbitmqemitter || curChannelId == cmpIDs.activemqchannel || curChannelId == cmpIDs.activemqemitter || curChannelId == cmpIDs.replaychannel ) {
					var cassandraVal = $('#selectConnObj').val();
					if ( typeof cassandraVal == 'string' && cassandraVal != "" ) {
						cassandraVal = JSON.parse(cassandraVal);
					} else {
						selectConnChk = false;
					}
					
					$.each( cassandraVal, function( Key, Value ) {
						 if ( Key == "connectionJson" ) {
							if ( typeof Value == 'string' ) {
								jsonVal = JSON.parse(Value);
							} else {
								jsonVal = Value;
							}
							
							if ( !$.isEmptyObject(jsonVal) ) {
								curChnl.config.push( "hosts:" + jsonVal.hosts);
								curChnl.config.push( "username:" + jsonVal.username);
								curChnl.config.push( "password:" + jsonVal.password);
							}
							
							if ( curChannelId == cmpIDs.cassandraemitter ) {
								curChnl.config.push( "connectionRetries:" + jsonVal.connectionRetries);								
							}
						} else if ( Key == "connectionName" ) {
								if ( Value == "" ) {
									selectConnChk = false;
								}
								curChnl.config.push( "connectionName:" + Value);
						} else if ( Key == "connectionId" ) {
							curChnl.config.push( "connectionId:" + Value);
						}
					});
				}
				
				if ( curChannelId == cmpIDs.kafkachannel || curChannelId == cmpIDs.kafkaemitter ) {
					var kafkaVal = $('#selectConnObj').val();
					var queryString = "";
					if ( typeof kafkaVal == 'string' && kafkaVal != "" ) {
						kafkaVal = JSON.parse(kafkaVal);
					} else {
						selectConnChk = false;
					}
					
					$.each( kafkaVal, function( Key, Value ) {
						if ( Key == "connectionJson" ) {
							if ( typeof Value == 'string' ) {
								jsonVal = JSON.parse(Value);
								queryString = "name="+ $('.config-value.topicName-fld').val() +"&zkHosts="+jsonVal.zkHosts;
							} else {
								jsonVal = Value;
							}
							self.checkAvailability(topicNameUrl, queryString, '');
							curChnl.config.push( "zkHosts:" + jsonVal.zkHosts);
							curChnl.config.push( "kafkaBrokers:" + jsonVal.kafkaBrokers);
						} else if ( Key == "connectionName" ) {
							if ( Value == "" ) {
								selectConnChk = false;
							}
							curChnl.config.push( "connectionName:" + Value);
						} else if ( Key == "connectionId" ) {
							curChnl.config.push( "connectionId:" + Value);
						}
					});
				} 
				
				if ( curChannelId == cmpIDs.hbaseemitter ) {
					var hbaseVal = $('#selectConnObj').val();
					if ( typeof hbaseVal == 'string' && hbaseVal != "" ) {
						hbaseVal = JSON.parse(hbaseVal);
					}  else {
						selectConnChk = false;
					}
						
					$.each( hbaseVal, function(Key, Value ) {
						if ( Key == "connectionJson" ) {
							if ( typeof Value == 'string' ) {
								jsonVal = JSON.parse(Value);
							} else {
								jsonVal = Value
							}
							
							var zkRecoveryRetry = (jsonVal.zkRecoveryRetry) ? jsonVal.zkRecoveryRetry : '';
							var zkParentNode = (jsonVal.zkParentNode) ? jsonVal.zkParentNode : '';
							var clientRetriesNumber = (jsonVal.clientRetriesNumber) ? jsonVal.clientRetriesNumber : '';
							
							curChnl.config.push( "zkHosts:" + jsonVal.zkHosts);
							curChnl.config.push( "zkPort:" + jsonVal.zkPort);
							curChnl.config.push( "hdfsUser:" + jsonVal.hdfsUser);
							curChnl.config.push( "zkRecoveryRetry:" + zkRecoveryRetry);
							curChnl.config.push( "zkParentNode:" + zkParentNode);
							curChnl.config.push( "clientRetriesNumber:" + clientRetriesNumber);
						} else if ( Key == "connectionName" ) {
							if ( Value == "" ) {
								selectConnChk = false;
							}
							curChnl.config.push( "connectionName:" + Value);
						} else if ( Key == "connectionId" ) {
							curChnl.config.push( "connectionId:" + Value);
						}
					});
				}
				
				if ( curChannelId == cmpIDs.solremitter ) {
					var solrVal = $('#selectConnObj').val();
					if ( typeof solrVal == 'string' && solrVal != "" ) {
						solrVal = JSON.parse(solrVal);
					} else {
						selectConnChk = false;
					}
					
					$.each( solrVal, function( Key, Value ) {
						if ( Key == "connectionJson" ) {
							if ( typeof Value == 'string' ) {
								jsonVal = JSON.parse(Value);
							} else {
								jsonVal = Value
							}
							curChnl.config.push( "zkHosts:" + jsonVal.zkHosts);
						} else if ( Key == "connectionName" ) {
							if ( Value == "" ) {
								selectConnChk = false;
							}
							curChnl.config.push( "connectionName:" + Value);
						} else if ( Key == "connectionId" ) {
							curChnl.config.push( "connectionId:" + Value);
						}
					});
				} 
				
				if ( curChannelId == cmpIDs.elasticsearchemitter ) {
					var elasticsearVal = $('#selectConnObj').val();
					if ( typeof elasticsearVal == 'string' && elasticsearVal != "" ) {
						elasticsearVal = JSON.parse(elasticsearVal);
					} else {
						selectConnChk = false;
					}
						
					$.each( elasticsearVal, function( Key, Value ) {
						if ( Key == "connectionJson" ) {
							if ( typeof Value == 'string' ) {
								jsonVal = JSON.parse(Value);
							} else {
								jsonVal = Value;
							}
							curChnl.config.push( "hosts:" + jsonVal.hosts);
							curChnl.config.push( "clusterName:" + jsonVal.clusterName);
						} else if ( Key == "connectionName" ) {
							if ( Value == "" ) {
								selectConnChk = false;
							}
							curChnl.config.push( "connectionName:" + Value);
						} else if ( Key == "connectionId" ) {
							curChnl.config.push( "connectionId:" + Value);
						}
					});
				} 
				
				if ( curChannelId == cmpIDs.hdfsemitter ) {
					var hdfsVal = $('#selectConnObj').val();
					if ( typeof hdfsVal == 'string' && hdfsVal != "" ) {
						hdfsVal = JSON.parse(hdfsVal);
					}  else {
						selectConnChk = false;
					}
					
					$.each( hdfsVal, function( Key, Value ) {
						if ( Key == "connectionJson" ) {
							if ( typeof Value == 'string' ) {
								jsonVal = JSON.parse(Value);
							} else {
								jsonVal = Value;
							}
							
							var namenode1Name = (jsonVal.namenode1Name) ? jsonVal.namenode1Name : '';
							var namenode1RPCAddress = (jsonVal.namenode1RPCAddress) ? jsonVal.namenode1RPCAddress : '';
							var namenode2Name = (jsonVal.namenode2Name) ? jsonVal.namenode2Name : '';
							var namenode2RPCAddress = (jsonVal.namenode2RPCAddress) ? jsonVal.namenode2RPCAddress : '';
							var nameservices = (jsonVal.nameservices) ? jsonVal.nameservices : '';
							
							curChnl.config.push( "fsURI:" + jsonVal.fsURI);
							curChnl.config.push( "haEnabled:" + jsonVal.haEnabled);
							curChnl.config.push( "namenode1Name:" + namenode1Name);
							curChnl.config.push( "namenode1RPCAddress:" + namenode1RPCAddress);
							curChnl.config.push( "namenode2Name:" + namenode2Name);
							curChnl.config.push( "namenode2RPCAddress:" + namenode2RPCAddress);
							curChnl.config.push( "nameservices:" + nameservices);
							curChnl.config.push( "username:" + jsonVal.username);
						} else if ( Key == "connectionName" ) {
							if ( Value == "" ) {
								selectConnChk = false;
							}
							curChnl.config.push( "connectionName:" + Value);
						} else if ( Key == "connectionId" ) {
							curChnl.config.push( "connectionId:" + Value);
						}
					});
				} 
				
				if ( curChannelId == cmpIDs.filterprocessor ) {
					curChnl.config.push( "filterQuery:"+ self.getFileterRules() );
				}
				
				// For Lookup Functions
				var lookData = lookupClass.saveLookupFunctions();
				curChnl.config.push( 'mvelfnclist:' + lookData.mvelfnclist );
				curChnl.config.push( 'expfldlst:' + lookData.expfldlst );
				
				if ( curChannelId == cmpIDs.persistenceprocessor ) {
					var persisterTabArr = persisterClass.persisterDataOnSave();
				}
				
				// SAVE ANALYTICS BOLT
				if ( curChannelId == cmpIDs.analyticsprocessor ) {
					curChnl.config = DFAnalytics.saveAnalytics(curChnl, true);
					if ( curChnl.config == false )
						chnlValidated = false;
				}
				
				if ( selectConnChk == false && ( curChannelId == cmpIDs.cassandraemitter ||  curChannelId == cmpIDs.hdfsemitter || curChannelId == cmpIDs.elasticsearchemitter || curChannelId == cmpIDs.hbaseemitter || curChannelId == cmpIDs.solremitter || curChannelId == cmpIDs.kafkachannel || curChannelId == cmpIDs.kafkaemitter || curChannelId == cmpIDs.rabbitmqchannel || curChannelId == cmpIDs.rabbitmqemitter || curChannelId == cmpIDs.activemqchannel || curChannelId == cmpIDs.activemqemitter || curChannelId == cmpIDs.replaychannel ) ) {
					$('a[href="#persisterConfigTab1"]').trigger('click');
					$('#channelErrorWrap').html('<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> '+ i18N['sax.notification.selectConnection'] +' </div>');
					chnlValidated = false;
					setTimeout( function() {
						$('#channelErrorWrap').empty();
					}, 20000)
				}
				
				if ( chnlValidated )
					$('#channelsModalWrap').modal('hide');
			} else {
				$("#channelProperties > .tab-content > .tab-pane").each(function() {
					var errs = $(this).find(".parsley-errors-list li").size();
					if ( errs > 0 ) {
						var id = $(this).attr("id");
						$("#channelProperties > .nav-tabs a[href='#"+ id +"']").trigger("click");
						
						if ( curChnl.id == cmpIDs.hdfsemitter ) {
							var isVisible = $(this).find(".parsley-errors-list li").closest('.panel-hdfs-collapse').hasClass('in');
							if ( !isVisible )
								$(this).find(".parsley-errors-list li").closest('.panel-hdfs').find('a.path-title').trigger('click');
						} else {
							var tabId = $(this).find(".parsley-errors-list li").closest('.tab-pane').attr('id');
							$('a[href="#'+ tabId +'"]').trigger('click');
						}
						return false;
					}
				});
			}
		});
		
		$('#saveSubSystemModalLink').on("click", function() {
			var validateBolts = true;
			var isDisabled = $(this).hasClass('disabled');
			if ( selectedSubsystemVersion < maxSubSystemVersion && tmpSSData.status == 'ACTIVE' ) {
				bootbox.alert(i18N['sax.notification.stopRunnigPipeling']);
				return false;
			}

			if ( $.isEmptyObject(tmpSSData) ) {
				$('#subSystemName').val('');
				$('#workerCount').val('');
				$('#ackersCount').val('');
				$('#supervisorFld').trigger('change');
				$('#esperHAFld').prop('checked', false).trigger('change');
			} else {
				$('#workerCount').val( tmpSSData.workerCount );
				$('#ackersCount').val( tmpSSData.ackersCount );
				if ( typeof tmpSSData.esperHAEnabled !== 'undefined' ) {
					$('#esperHAFld').prop('checked', tmpSSData.esperHAEnabled).trigger('change');
				}
			}
			
			if ( !isDisabled ) {
				var usedMessages = [], numberOfChnl = 0;;
				var customComponentsObj = new Object();
				var scrollLeft = $('#topologyGraphWrap').scrollLeft();
				var scrollTop = $('#topologyGraphWrap').scrollTop();
				$.each(addedSpoutsObj, function(key, obj) {
					numberOfChnl += 1;
				});
				$.each(addedSpoutsObj, function(key, obj) {
					if ( numberOfChnl == 1 && obj.id == cmpIDs.replaychannel ) {
						bootbox.alert(i18N['sax.notification.aloneReplayChnl']);
						validateBolts = false;
						return;
					}
					
					var position = $('#'+ key).position();
					if ( typeof obj.coordinates === 'undefined' )
						obj.coordinates = [];
					obj.coordinates = [scrollLeft + position.left, scrollTop + position.top];	
					
					if ( typeof boltsValidation[obj.id] !== 'undefined' ) {
						if ( typeof obj.messageTypes === 'undefined' || obj.messageTypes.length == 0 ) {
							self.showBoltsError(obj.name);
							validateBolts = false;
						}
					}
					// Persister And Indexer Emitter
					if ( obj.id == cmpIDs.kafkachannel || obj.id == cmpIDs.rabbitmqchannel|| obj.id == cmpIDs.replaychannel ) {
						var validPersisterIndexer = true;
						var persisterIndexerConf = '';
						for ( var j = 0; j < obj.config.length; j++ ) {
							if ( obj.config[j].indexOf('connectionId:') > -1 ) {
								persisterIndexerConf = obj.config[j];
							}
						}
						if ( persisterIndexerConf != '' ) {
							persisterIndexerConf = persisterIndexerConf.replace("connectionId:", "");
							if ( persisterIndexerConf == "" ) {
								validPersisterIndexer = false;
							}
							if ( !validPersisterIndexer ) {
								self.showBoltsError(obj.name);
								validateBolts = false;
							}
						}
					}
				});
			
				$.each(addedBoltsObj, function(key, obj) {
					var position = $('#'+ key).position();
					if ( typeof obj.coordinates === 'undefined' )
						obj.coordinates = [];
					obj.coordinates = [scrollLeft + position.left, scrollTop + position.top];
					
					if ( validateBolts ) {
						// CEP CUSTOM
						if ( obj.id == cmpIDs.cepcustom && obj.config.indexOf(boltsValidation[cmpIDs.cepcustom].config) > -1 ) {
							self.showBoltsError(obj.name);
							validateBolts = false;
						}
						
						// Filter Processor
						if ( obj.id == cmpIDs.filterprocessor && obj.config[0] == boltsValidation[cmpIDs.filterprocessor].config ) {
							self.showBoltsError(obj.name);
							validateBolts = false;
						}
						
						// AGGREGATION FUNCTION Processor
						if ( (obj.id == cmpIDs.aggregationfunction && typeof obj.query === 'undefined') ) {
							self.showBoltsError(obj.name);
							validateBolts = false;
						}
						
						// HDFS Processor
						if ( obj.id == cmpIDs.hdfsemitter ) {
							var validHDFS = true;
							var hdfsPathConf = '', connectionId = '';
							for ( var j=0; j<obj.config.length; j++ ) {
								if ( obj.config[j].indexOf('hdfsPaths:') > -1 )
									hdfsPathConf = obj.config[j].replace('hdfsPaths:', '');
									
								if ( obj.config[j].indexOf('connectionId:') > -1 )
									connectionId = obj.config[j].replace('connectionId:', '');
							}
							
							if ( hdfsPathConf != '' ) {
								hdfsPathConf = JSON.parse(hdfsPathConf);
								for ( var j=0; j<hdfsPathConf.length; j++ ) {
									if ( hdfsPathConf[j].hdfsPath == "" )
										validHDFS = false;
								}
							}
							
							if ( connectionId == '' ) {
								validHDFS = false;
							}
							
							if ( !validHDFS ) {
								self.showBoltsError(obj.name);
								validateBolts = false;
							}
						}
						
						// Dynamic CEP Processor
						if ( obj.id == cmpIDs.dynamiccepprocessor ) {
							obj.config = ["messageNames:"+obj.messageTypes.join(',')];
						}
						
						// RMQ Emitter
						if ( obj.id == cmpIDs.rabbitmqemitter && obj.config.indexOf(boltsValidation[cmpIDs.rabbitmqemitter].config) > -1 ) {
							self.showBoltsError(obj.name);
							validateBolts = false;
						}
						
						// KAFKA Emitter
						if ( obj.id == cmpIDs.kafkaemitter && obj.config.indexOf(boltsValidation[cmpIDs.kafkaemitter].config) > -1 ) {
							self.showBoltsError(obj.name);
							validateBolts = false;
						}
						
						// Analytics Processors
						if ( obj.id == cmpIDs.analyticsprocessor ) {
							var usedMsg = '';
							if ( obj.config.length > 0 && typeof obj.config[3] !== 'undefined' ) { 
								usedMsg = obj.config[3].replace("inputMessageName:", "");
							}
							if ( obj.config.length == 0 || usedMsg == "" ) {
								self.showBoltsError(obj.name);
								validateBolts = false;
							}
						}
						
						// Enricher Processor
						if ( obj.id == cmpIDs.enricherprocessor && obj.config[0] == boltsValidation[cmpIDs.enricherprocessor].config ) {
							self.showBoltsError(obj.name);
							validateBolts = false;
						}
						
						// Custom Processors
						if ( obj.id == cmpIDs.customprocessors && obj.config[0] == boltsValidation[cmpIDs.customprocessors].config ) {
							self.showBoltsError(obj.name);
							validateBolts = false;
						}
						
						// Timer Processors
						if ( obj.id == cmpIDs.timerprocessor && obj.config[0] == boltsValidation[cmpIDs.timerprocessor].config ) {
							self.showBoltsError(obj.name);
							validateBolts = false;
						}
						
						// Persister And Indexer Emitter
						if ( obj.id == cmpIDs.cassandraemitter || obj.id == cmpIDs.hbaseemitter || obj.id == cmpIDs.elasticsearchemitter || obj.id == cmpIDs.solremitter || obj.id == cmpIDs.kafkaemitter || obj.id == cmpIDs.rabbitmqemitter ) {
							var validPersisterIndexer = true;
							var persisterIndexerConf = '';
							for ( var j = 0; j < obj.config.length; j++ ) {
								if ( obj.config[j].indexOf('connectionId:') > -1 ) {
									persisterIndexerConf = obj.config[j];
								}
							}
							if ( persisterIndexerConf != '' ) {
								persisterIndexerConf = persisterIndexerConf.replace("connectionId:", "");
								if ( persisterIndexerConf == "" ) {
									validPersisterIndexer = false;
								}
								if ( !validPersisterIndexer ) {
									self.showBoltsError(obj.name);
									validateBolts = false;
								}
							}
						}
					}
				});
			
				if ( !validateBolts ) return;
				
				var validDF = self.validateDataFabric();
				if ( !validDF ) {
					bootbox.alert(i18N['sax.notification.connectDataPipeline']);
					return;
				}
				
				// For Custom Components START
				$.each(addedSpoutsObj, function(key, obj) {
					if ( obj.subtype && obj.subtype == 'custom' ) {
						if ( typeof customComponentsObj[obj.jarName] === 'undefined' )
							customComponentsObj[obj.jarName] = [];
							
						customComponentsObj[obj.jarName].push({
							customComponentName: obj.label,
							version: obj.version,
							jarName: obj.jarName
						});
					}
					
					var customParserVersion = new Object();
					if ( messagesFieldsVersionData.RegisteredParserMessages ) {
						for ( var j=0; j<obj.messageTypes.length; j++ ) {
							var msgWithVersion = messagesFieldsVersionData.RegisteredParserMessages[obj.messageTypes[j]];
							if ( msgWithVersion ) {
								customParserVersion[obj.messageTypes[j]] = msgWithVersion;
							}
						}
					}
					
					if ( !$.isEmptyObject(customParserVersion) ) {
						for ( var j=0; j<obj.config.length; j++ ) {
							if ( obj.config[j].indexOf('registeredParserInfo:') > -1 ) {
								obj.config.splice(j, 1);
							}
						}
						obj.config.push('registeredParserInfo:'+JSON.stringify(customParserVersion));
					}
					
					usedMessages = $.merge(usedMessages, obj.messageTypes);
					usedMessages = self.unique(usedMessages);
				});
				
				$.each(addedBoltsObj, function(key, obj) {
					if ( obj.subtype && obj.subtype == 'custom' ) {
						if ( typeof customComponentsObj[obj.jarName] === 'undefined' )
							customComponentsObj[obj.jarName] = [];
							
						customComponentsObj[obj.jarName].push({
							customComponentName: obj.label,
							version: obj.version,
							jarName: obj.jarName
						});
					}
				});
				
				if ( messagesFieldsVersionData.RegisteredParserMessages ) {
					for ( var i=0; i<usedMessages.length; i++ ) {
						var msgWithVersion = messagesFieldsVersionData.RegisteredParserMessages[usedMessages[i]];
						if ( msgWithVersion ) {
							if ( typeof customComponentsObj[msgWithVersion.jarName] === 'undefined' )
								customComponentsObj[msgWithVersion.jarName] = [];
								
							customComponentsObj[msgWithVersion.jarName].push({
								customComponentName: msgWithVersion.componentName,
								version: msgWithVersion.version,
								jarName: msgWithVersion.jarName
							});
						}
					}
				}
				
				$('#saveSubSystem').prop('disabled', false);
				$("#duplicateNameError").empty();
				if ( !$.isEmptyObject(customComponentsObj) ) {
					var custCompRes = self.postAjaxData(custCompCompatibleUrl, JSON.stringify(customComponentsObj));
					custCompRes = JSON.parse(custCompRes);
					if ( custCompRes.status == "FAILURE" ) {
						$("#duplicateNameError").html('<div class="alert alert-error">'+ custCompRes.message +'</div>').show();
						$('#saveSubSystem').prop('disabled', true);
					}
				} 
				// For Custom Components END
				
				if( ssId != ''){
					var curComponentsList = [], selComponentsList = [];
					for ( var i=0; i<allSubSystemData.length; i++ ) {
						if ( ssId == allSubSystemData[i].name ) {
							curSubSystemObj = jQuery.extend(true, {}, allSubSystemData[i]);
						}
					}
					
					$.each(addedSpoutsObj, function(key, obj) {
						var o = jQuery.extend(true, {}, obj);
						delete o.coordinates;
						curComponentsList.push(o);
					});
					
					$.each(addedBoltsObj, function(key, obj) {
						var o = jQuery.extend(true, {}, obj);
						delete o.coordinates;
						curComponentsList.push(o);
					});
					
					$.each(tmpSSData.spouts, function(key, obj) {
						var o = jQuery.extend(true, {}, obj);
						delete o.coordinates;
						selComponentsList.push(o);
					});
					
					$.each(tmpSSData.bolts, function(key, obj) {
						var o = jQuery.extend(true, {}, obj);
						delete o.coordinates;
						selComponentsList.push(o);
					});
				if( (selectedSubsystemVersion < maxSubSystemVersion ) || (displayVersion < selectedSubsystemVersion)  ) {
						if ( JSON.stringify(curComponentsList) == JSON.stringify(selComponentsList) ) {
							isModifiedSS = false;
							$('#saveSubSystem').css('display', 'none', 'important');
							$('#forceLoadSubSystem, #cancelVersionBtn').css('display', 'none', 'important');
							$('#loadSubSystem').css('display', 'inline-block', 'important');
							$('#workerCount, #ackersCount').prop('disabled', true); 
							$('#versionRow, #commentWrap').hide();
						} else {
							isModifiedSS = true;
							$('#versionRow, #commentWrap').show();
							$('input[type="radio"][value="existing"]').attr('disabled',true);
							$('input[type="radio"][value="existing"]').parent().attr('class','gray-txt');
							if( selectedSubsystemVersion < maxSubSystemVersion ) {
								$('input[name="version"][value="create"]').trigger('click');
							}
							else{
								$('input[type="radio"][value="existing"]').attr('disabled',false);
								$('input[type="radio"][value="existing"]').parent().attr('class','');
								$('input[name="version"][value="existing"]').trigger('click');
							}
							$('#workerCount, #ackersCount').prop('disabled', false); 
							$('#saveSubSystem').css('display', 'inline-block', 'important');
							$('#forceLoadSubSystem, #cancelVersionBtn, #loadSubSystem').css('display', 'none', 'important');
						}
					}else{
						isModifiedSS = true;
						$('input[type="radio"][value="existing"]').attr('disabled',false);
						$('input[type="radio"][value="existing"]').parent().attr('class','');
						$('input[name="version"][value="existing"]').trigger('click');
						$('#workerCount, #ackersCount').prop('disabled', false); 
						$('#saveSubSystem').css('display', 'inline-block', 'important');
						$('#forceLoadSubSystem, #cancelVersionBtn, #loadSubSystem').css('display', 'none', 'important');
					}
				}
				esperHABolt.isEsperHABoltAdded();
				self.removeParsleyErrors();
				
				if ( !$.isEmptyObject(tmpSSData) && tmpSSData.customJarName !== "" && !isUploadedJar ) {
					self.confirmExistingJar();
				} else {
					$("#errorHandlerMessage").empty();
					$("#erroHandlingStep").addClass("hidden");
					$("#definitionStep").removeClass("hidden");
					if ( $.isEmptyObject(tmpSSData) || deadLaterChannel.id ) {
						$('#errorHandlerFld').prop('checked', true);
						$("#errorProcessorType").trigger("change");
						$('#editErrHandlr').html('<small>('+ i18N['sax.label.configure'] +')</small>');
					}
					$("#ssDefinitionWrap").modal();
				}
				if ( ssId != 'null' && ssId != '' && tmpSSData.status != 'STOPPED' &&  selectedSubsystemVersion == maxSubSystemVersion ) {
				$('#versionRow').show();
				$('input[type="radio"][value="existing"]').attr('disabled',false);
				$('input[type="radio"][value="existing"]').parent().attr('class','');
				$('input[type="radio"][value="create"]').attr('disabled',true);
				$('input[type="radio"][value="create"]').parent().attr('class','gray-txt');
				$('input[name="version"][value="existing"]').trigger('click');
			}
			}
		});
		
		$(document).on("click", "#loadSubSystem", function(e) {	
			var result = self.getAjaxData(versionMsgUrl+ssId+'/version/'+selectedSubsystemVersion );
			if(result.message){
				$('#definitionStep').find('.force-load-res').remove();
				$("#subSystemFieldsWrap").hide();
				$('#saveSubSystem, #loadSubSystem, #cancelSubSystemModal').css('display', 'none', 'important');
				$('#forceLoadSubSystem, #cancelVersionBtn').css('display', 'inline-block', 'important');
				if(result.status && result.status.toUpperCase() == "SUCCESS"){
					$('#definitionStep').append('<div class="force-load-res alert alert-warning">'+result.message+'</div>');
				}else if(result.status && result.status.toUpperCase() == "FAILURE"){
					$('#definitionStep').append('<div class="force-load-res alert alert-danger">'+result.message+'</div>');
				}
			}else{
				//$('#forceLoadSubSystem, #cancelVersionBtn').css('display', 'none', 'important');
				$('#forceLoadSubSystem').trigger('click');
			}
		});
		
		$(document).on("click", "#cancelVersionBtn", function(e) {
			$('#definitionStep').find('.force-load-res').remove();
			$("#subSystemFieldsWrap").show();
			$("#subSystemVersionMsgWrap").hide();
			$('#loadSubSystem, #cancelSubSystemModal').css('display', 'inline-block', 'important');
			$('#forceLoadSubSystem, #cancelVersionBtn').css('display', 'none', 'important');
		});
		
		$(document).on("click", "#cancelSubSystemModal", function(e) {
			if ( !$.isEmptyObject(tmpSSData) ) {
				$('#workerCount').val( tmpSSData.workerCount );
				$('#ackersCount').val( tmpSSData.ackersCount );
			} else {
				$('#workerCount').val('');
				$('#ackersCount').val('');
			}
		});
		
		$('#ssDefinitionWrap').on('hidden.bs.modal', function () {
			if ( !$.isEmptyObject(tmpSSData) ) {
				$('#workerCount').val( tmpSSData.workerCount );
				$('#ackersCount').val( tmpSSData.ackersCount );
			} else {
				$('#workerCount').val('');
				$('#ackersCount').val('');
			}
		});
		
		$(document).on("click", "#saveSubSystem, #forceLoadSubSystem", function(e) {
			$('#definitionStep').find('.force-load-res').remove();
			var flag=true, validate=true, isCheckedEsperHA=false, status='STOPPED';
			$("#subSystemFieldsWrap .parsley-validate").each(function() {
				flag = $(this).parsley().validate();
				if ( flag != true ) {
					validate = false;
				}
			});
			
			if ( esperHAEnable ) {
				isCheckedEsperHA = $('#esperHAFld').prop('checked');
			}
			
			if ( duplicateNameErrorObj.isDuplicate ) {
				validate = false;
				$("#duplicateNameError").html('<div class="alert alert-error msg-failure alert-dismissable new-error">'+ DUPLICATE_NAME_ERROR +'</div>').show().find('.alert').show();
			}
			
			if ( ssId == '' ) {
				finalVersionNumber = 1;
			} else {
				status = tmpSSData.status;
			}
			
			if( maxSubSystemVersion == selectedSubsystemVersion &&  ssId != '') {
				$('input[name="version"]:checked').trigger('change');
				selectedVrsnVal = $('input[name="version"]:checked').val();
				finalVersionNumber = selectedVrsnVal == 'existing' ? maxSubSystemVersion : maxSubSystemVersion + 1;
			} else if( selectedSubsystemVersion != maxSubSystemVersion &&  ssId != '') {
				finalVersionNumber = maxSubSystemVersion + 1;
			}
			
			if ( validate ) {
				$.each(addedSpoutsObj, function(key, comp) {
					if ( comp.id == cmpIDs.replaychannel ) {
						var isErrorHandling = $('#errorHandlerFld').prop('checked');
						if ( !isErrorHandling ) {
							validate = false;
							$("#errorHandlerMessage").html('<div class="alert alert-error">'+ i18N['sax.notification.enableErrorHandler'] +'</div>');
						}
					}
				});
			}
			
			if ( validate ) {
				self.checkErrorHandlerEnable();
				var ssJSON = {
					id: ssId,
					name: $("#subSystemName").val(),
					status: status,
					config: null,
					workerCount: $("#workerCount").val(),
					ackersCount: $("#ackersCount").val(),
					scheduling: null,
					spouts: [],
					bolts: [],
					esperHAEnabled: isCheckedEsperHA,
					topologySupervisors:[],
					versionNumber: finalVersionNumber,
					description: $('#commentVersion').val(),
					customJarName: customJarName,
					originalCustomJarName: originalCustomJarName,
					sessionId: sessionId,
					connections:[],
					isReplayAlter: false
				}
			
				$('#subSystemDefWgdLoader').show();
				$('#ssDefinitionWrap').modal('hide');
				
				var isPMMLUploaded = true;
				tempConnections = [];
				$.each(addedBoltsObj, function(key, comp) {
					for ( var i=0; i<comp.config.length; i++ ) {
						var configLen = comp.config[i].length;
						var colonIdx = comp.config[i].indexOf(":");
						var configKey = comp.config[i].substring(0, colonIdx);
						var configVal = comp.config[i].substring(colonIdx+1, configLen).trim();
						if ( configKey == 'connectionId' ) {
							if ( $.inArray(configVal,tempConnections) == -1 ){
								tempConnections.push(configVal);
							}
						}
					}
					ssJSON.bolts.push( comp );
					esperHABolt.insertEsperHAEntries(ssJSON, comp, isCheckedEsperHA);
					if ( comp.id == cmpIDs.analyticsprocessor ) {
						isPMMLUploaded = DFAnalytics.uploadAndSavePMMLFile(comp);
						var confStr = comp.config.join(',');
						if ( confStr.indexOf('tenantId:') == -1 ) {
							comp.config.push("tenantId:"+currentTenantId);
							comp.config.push("subsystemName:"+$("#subSystemName").val());
						}
					}
				});
				
				if ( !isPMMLUploaded ) return;
				var hasReplayChannel = '', wasReplayChannel = '';
				$.each(addedSpoutsObj, function(key, comp) {
					for ( var i=0; i<comp.config.length; i++ ) {
						var configLen = comp.config[i].length;
						var colonIdx = comp.config[i].indexOf(":");
						var configKey = comp.config[i].substring(0, colonIdx);
						var configVal = comp.config[i].substring(colonIdx+1, configLen).trim();
						if ( configKey == 'connectionId' ) {
							if ( $.inArray(configVal,tempConnections) == -1 ){
								tempConnections.push(configVal);
							}
						}
						if ( comp.id == cmpIDs.replaychannel ) {
							if ( configKey == 'exchangeName' && configVal == "" ) {
								comp.config[i] = "exchangeName:" + $("#subSystemName").val()+ "_replay";
								comp.config[i+1] = "queueName:" + $("#subSystemName").val()+ "_replay";
								comp.config[i+2] = "routingKey:" + $("#subSystemName").val()+ "_replay";
							}
							if ( configKey == 'topologyName' && configVal == "" ) {
								comp.config[i] = "topologyName:" + $("#subSystemName").val();
							}
						}
					}
					ssJSON.spouts.push( comp );
					
					if ( comp.id == cmpIDs.replaychannel ) {
						hasReplayChannel = comp.name;
						if ( comp["className"] == "" )
							comp["className"] = comp["replay-config"].source[0].className;
					}
				});
				
				if ( !$.isEmptyObject(tmpSSData) ) {
					for ( var i=0; i<tmpSSData.spouts.length; i++ ) {
						if ( tmpSSData.spouts[i].id == cmpIDs.replaychannel ) wasReplayChannel = tmpSSData.spouts[i].name;
					}
					
					if ( hasReplayChannel != wasReplayChannel )
						ssJSON.isReplayAlter = true;
				}
					
				ssJSON.connections = tempConnections;
				ssJSON.topologySupervisors = $("#supervisorFld").val();

				if ( ssJSON.topologySupervisors == null ) {
					ssJSON.topologySupervisors = [];
				}
				
				isFormSubmition = true;
				var result, params;
				if ( ssId != 'null' && ssId != '' ) {
					// Check for Modification
					if ( !isModifiedSS ) {
						result = self.getAjaxData( subSystemLoadURL+ssId+'/version/'+selectedSubsystemVersion );
						result = JSON.stringify(result);
						params = 'subsystemupdated='+result;
					} else {
						result = self.postAjaxData( updateSubSystemUrl, JSON.stringify(ssJSON) );
						params = 'subsystemupdated='+result;
					}
				} else {
					result = self.postAjaxData( saveSubSystemUrl, JSON.stringify(ssJSON) );
					params = 'subsystemcreated='+result;
				}
				result = JSON.parse(result);
				result.currentTenantId = currentTenantId;
				result.msgTime = new Date().getTime();
				localStorage.setItem("result", JSON.stringify(result));
				window.location.href = ssListingPageUrl;
			} else {
				$(document).scrollTop(0);
			}
		});
			
		// REbalance :: START
		$("#rebalanceModalLink").on("click", function(e) {
			var isDisabled = $(this).hasClass('disabled');
			if ( !isDisabled ) {
				var wCount = $("#workerCount").val();
				var aCount = $("#ackersCount").val();
				$("#rbWorkerCount").val( wCount );
				$("#rbAckersCount").val( aCount );
				$('#ssRebalanceWrap').modal();
				var rebalanceSupervisorVal = $("#supervisorFld").val();
				if(rebalanceSupervisorVal != "")
					$('#rebalanceSupervisorFld').val(rebalanceSupervisorVal).trigger('change');
				
			}
		});
		
		$("#rebalanceSubSystem").on("click", function(e) {
			actionRebalance = true;
			var flag=true, validate=true, isCheckedEsperHA=false;
			$("#subSystemRebalanceWrap .parsley-validate").each(function() {
				flag = $(this).parsley().validate();
				if ( flag != true ) {
					validate = false;
				}
			});
		
			if ( duplicateNameErrorObj.isDuplicate ) {
				validate = false;
				$("#duplicateNameError").html('<div class="alert alert-error msg-failure alert-dismissable new-error">'+ DUPLICATE_NAME_ERROR +'</div>').show().find('.alert').show();
			}
			
			if ( esperHAEnable ) {
				isCheckedEsperHA = $('#esperHAFld').prop('checked');
			}
			
			if ( validate ) {
				$('#ssRebalanceWrap').modal('hide');
				bootbox.confirm(i18N['sax.notification.rebalance'], function(confirmation) {
					if ( !confirmation ) {
						return;
					}
		
					var ssJSON = {
						id: ssId,
						name: $("#subSystemName").val(),
						status: "inactive",
						config: null,
						workerCount: $("#rbWorkerCount").val(),
						ackersCount: $("#rbAckersCount").val(),
						scheduling: null,
						spouts: [],
						bolts: [],
						esperHAEnabled: isCheckedEsperHA,
						versionNumber: parseInt($(".versionCombo").text()),
						topologySupervisors: $("#supervisorFld").val(),
						description: $('#commentVersion').val(),
						customJarName: customJarName,
						originalCustomJarName: originalCustomJarName,
						sessionId: sessionId						
					}

					ssJSON.topologySupervisors = $("#rebalanceSupervisorFld").val();

					if ( ssJSON.topologySupervisors == null ) {
						ssJSON.topologySupervisors = [];
					}


					$.each(addedSpoutsObj, function(key, obj) {
						if ( typeof obj.messageTypes === 'undefined' ) {
							var tempElem = $('<select>').html(allMsgOptions);
							var message = tempElem.find("option:first").val();
							obj.messageTypes = [message];
							tempElem.end().remove();
						}
					});
					
					$.each(addedBoltsObj, function(key, obj) {
						if ( typeof obj.messageTypes === 'undefined' ) {
							var tempElem = $('<select>').html(allMsgOptions);
							var message = tempElem.find("option:first").val();
							obj.messageTypes = [message];
							tempElem.end().remove();
						}
					});
					
					$("#topologyGraph").find(".shape").each(function() {
						var id = $(this).attr("id");
						var type = $(this).attr("ui-type");
						if ( type == "channel" )
							ssJSON.spouts.push( addedSpoutsObj[id] );
						else
							ssJSON.bolts.push( addedBoltsObj[id] );
					});
					
					var result, params;
					if ( ssId != 'null' && ssId!='' ) {
						result = self.postAjaxData( updateSubSystemUrl, JSON.stringify(ssJSON) );
						result = JSON.parse(result);
						if(result.status == 'SUCCESS' || result.status == 'success'){
							var rebalanceresp = self.postAjaxData(rebalanceUrl, JSON.stringify(ssJSON));
							rebalanceresp = JSON.parse(rebalanceresp);
							rebalanceresp.currentTenantId = currentTenantId;
							rebalanceresp.msgTime = new Date().getTime();
							localStorage.setItem("result", JSON.stringify(rebalanceresp));
							if(rebalanceresp.status == 'SUCCESS' || rebalanceresp.status == 'success'){
								result='SUCCESS';
							}else{
								result='FAILURE';
							}
						}else{
							result.currentTenantId = currentTenantId;
							result.msgTime = new Date().getTime();
							localStorage.setItem("result", JSON.stringify(result));

						}
						params = 'subsystemrebalanced='+result;				
					} else {
						result = self.postAjaxData( saveSubSystemUrl, JSON.stringify(ssJSON) );
						result.currentTenantId = currentTenantId;
						result.msgTime = new Date().getTime();
						localStorage.setItem("result", JSON.stringify(result));
						params = 'subsystemcreated='+result;
					}
					
					$('#subSystemDefWgdLoader').show();
					// $(".tab_container").hide();
					setTimeout(function() {
						window.location.href = ssListingPageUrl;
					}, (rebalancePageDelay));
				});
			} else {
				$(document).scrollTop(0);
			}
		});
		// REBALANCE :: END
		
		$("#errorHandlerFld").on("change", function() {
			var isChecked = $(this).prop('checked');
			$("#errorHandlerMessage").empty();
			if ( isChecked ) {
				$('#ssDefinitionWrap .modal-header h4.modal-title').text(i18N['sax.label.errorHandlerConfiguration']);
				$('#errorProcessorType').trigger('change');
				$('#cancelSubSystemModal, #saveSubSystem, #definitionStep').addClass('hidden');
				$('#backToDefinition, #applyConfiguration, #erroHandlingStep').removeClass('hidden');
			} else {
				$('#editErrHandlr').empty();
				deadLaterChannel = {};
			}
		});
		
		$("#editErrHandlr").on("click", function() {
			$('#ssDefinitionWrap .modal-header h4.modal-title').text(i18N['sax.label.errorHandlerConfiguration']);
			$('#errorProcessorType').trigger('change');
			$('#cancelSubSystemModal, #saveSubSystem, #definitionStep').addClass('hidden');
			$('#backToDefinition, #applyConfiguration, #erroHandlingStep').removeClass('hidden');
		});
		
		$("#applyConfiguration").on("click", function() {
			var selectedChannels = $('#errorHndlrConnectChannels').val();
			var selectedBolts = $('#errorHndlrConnectBolts').val();
			
			if ( selectedChannels == null && selectedBolts == null ) {
				$("#errorHandlerFld").prop('checked', false).trigger('change');
				$('#ssDefinitionWrap .modal-header h4.modal-title').text(i18N['sax.subSystemDefinition']);
				$('#cancelSubSystemModal, #saveSubSystem, #definitionStep').removeClass('hidden');
				$('#backToDefinition, #applyConfiguration, #erroHandlingStep').addClass('hidden');
			} else {
				var isValid = $("#erroHandlingForm").parsley().validate();
				if ( isValid ) {
					$('#ssDefinitionWrap .modal-header h4.modal-title').text(i18N['sax.subSystemDefinition']);
					$('#cancelSubSystemModal, #saveSubSystem, #definitionStep').removeClass('hidden');
					$('#backToDefinition, #applyConfiguration, #erroHandlingStep').addClass('hidden');
					var selComp = $('#errorProcessorType option:selected').text();
					$('#editErrHandlr').html('<small>('+ i18N['sax.label.configure'] +')</small>');
					deadLaterChannel['id'] = $('#errorProcessorType').val();
					deadLaterChannel['connectedChannels'] = selectedChannels;
					deadLaterChannel['connectedBolts'] = selectedBolts;
					deadLaterChannel['connectionName'] = $('#errHndlrConnSel').val();
				}
			}
		});
		
		$("#backToDefinition").on("click", function() {
			var selectedChannels = $('#errorHndlrConnectChannels').val();
			var selectedBolts = $('#errorHndlrConnectBolts').val();
			if ( $.isEmptyObject(deadLaterChannel) || (selectedChannels == null && selectedBolts == null) ) {
				$("#errorHandlerFld").prop('checked', false).trigger('change');
			} else {
				$('#errorHndlrConnectChannels').val( deadLaterChannel['connectedChannels'] );
				$('#errorHndlrConnectBolts').val( deadLaterChannel['connectedBolts'] );
			}
			
			$('#ssDefinitionWrap .modal-header h4.modal-title').text(i18N['sax.subSystemDefinition']);
			$('#cancelSubSystemModal, #saveSubSystem, #definitionStep').removeClass('hidden');
			$('#backToDefinition, #applyConfiguration, #erroHandlingStep').addClass('hidden');
		});
		
		$("#errorProcessorType").on("change", function() {
			var errorProcType = $(this).val();
			
			if ( !$.isEmptyObject(deadLaterChannel) && deadLaterChannel.id == errorProcType ) {
				errorProcType = deadLaterChannel.id;
			}
		
			$('#erroHandlingForm').parsley().destroy();
			if ( errorProcType != "" ) {
				self.createErrorHandlerConfig(errorProcType);
			} else {
				setTimeout(function() {
					$("#errorProcessorType").select2("destroy").select2();
				}, 300);
			}
		});
		
		$(document).on("click", ".msgtype-radio", function() {
			var curChannelId = $("#curChannelId").val();
			var value = $(this).val();
			var scheme = '';
			var isMultiple = true;
			if ( value == "single" ) {
				scheme = (curChannelId == cmpIDs.kafkachannel) ? schemeName.kafka.single : schemeName.rabbitmq.single;
				if ( curChannelId == cmpIDs.replaychannel ) {
					scheme = replayLogsClass.schemeValue();
				}
				isMultiple = false;
				$('#schemaIdentifierWrap').hide();
			} else if ( value == "multi" ) {
				scheme = (curChannelId == cmpIDs.kafkachannel) ? schemeName.kafka.multi : schemeName.rabbitmq.multi;
				isMultiple = true;
				$('#schemaIdentifierWrap').show();
			}
			
			$("#scheme").val(scheme);
			$('#schemaIdentifierCB').prop('checked', false).trigger('change');
			$("#messageTypeId")
				.prop("multiple", isMultiple)
				.select2("destroy")
				.select2({placeholder: i18N['sax.placeholder.pleaseSelect']})
				.trigger("change");
		});
		
		$(document).on("change", "#messageTypeId", function() {
			var value = $(this).val();
			var compType = $('#componentType').val();
			var curChannelId = $('#curChannelId').val();
			if ( value == null ) {
				self.createFVAutoSuggestData([]);
			} else {
				if ( typeof value === 'string' ) {
					self.createFVAutoSuggestData([value]);
				} else {
					self.createFVAutoSuggestData(value);
				}
			}
			
			if ( ($.inArray(activeComp.id, functionSupportedComps) > -1) || (typeof activeComp.subtype !== 'undefined' && activeComp.subtype == 'custom' && activeComp.type != 'channel') ) {
				$("#configRowsWrap input.config-value").each(function() {
					$(this).initQueryBuilder({data: fvAutoSuggestData});
				});
			}
		});
		
		$(document).on("keyup", ".config-value", function() {
			var value = $(this).val();
			$(this).attr("data-original-title", value);
		});
		
		$(document).on("keyup", ".topicName-fld", function() {
			var value = $(this).val();
			$(this).closest("#configRows").find(".offsetMarker-fld").val( value ).attr("data-original-title", value).trigger('keyup');
		});
		
		$(document).on("keyup", ".routingKey-fld", function() {
			var value = $(this).val();
			var curChnlId = $('#curChannelId').val();
			if ( curChnlId == cmpIDs.activemqchannel || curChnlId == cmpIDs.activemqemitter ) {
				$(this).parsley().destroy();
				if ( value != null && value.trim() == "" ){
					$(this).removeAttr('data-parsley-required');					
				}
				else {
					$(this).attr('data-parsley-required',true);
				}
			}
		});

		
		$(document).on("change", "select.config-value", function() {
			var value = $(this).val();
			$(this).attr("data-original-title", value);
			$(this).siblings('.select2-container').attr("data-original-title", value);
		});
		
		$(document).on("click", "#channelProperties .nav-tabs li a", function(e) {
			e.preventDefault();
		});
		
		$(document).on('change', 'select#syncSortMsgSel', function() {
			$('.TaskFile-fld').val('');
			$('#channelErrorWrap').empty();
		});
		
		$(document).on('change', 'select#batchEnableSelector', function() {
			var val = $(this).val();
			if ( val == 'true' ) {
				$('#batchSizeWrap').show();
			} else {
				$('#batchSizeWrap').hide();
				$('#batchSizeWrap input.config-value').val('1');
			}
		});
		
		$(document).on('change', 'select#routingRequired', function() {
			var val = $(this).val();
			if (val == 'true') {
				$('#routingPolicyWrap').show();
				$('#routingPolicy').attr('data-parsley-required',true);
				$('#routingPolicy').addClass('margin-bm');
			} else {
				$('#routingPolicy').val('');
				$('#routingPolicy').removeAttr('data-parsley-required');
				$('#routingPolicyWrap').hide();							
			}
		});
		$(document).on('change', '.regionSplittingDefinition-fld', function() {
			var val = $(this).val();
			$('#regBoundaryFld').val('');
			$('#regBoundaryFld').parsley().destroy();
			if ( val == 'Default' ) {
				$('#regBoundaryWrap').hide();
				$('#regBoundaryFld').removeAttr('data-parsley-required');
			} else if ( val == 'Based on Region Boundaries' ) {
				$('#regBoundaryWrap').show();
				$('#regBoundaryFld').attr('data-parsley-required', true);
			}
		});
		
		$(document).on("click", "#uploadSyncsortFile", function() {
			var componentName = $("#curChannelName").val();
			var messageName = $("#configRows select.messageName-fld").val();
			var elem = $(this);
			
			$('.tooltip').remove();
			elem.fileupload({
				url: uploadSyncsortFileUrl,
				dataType: 'json',
				add: function (e, data) {
					isUploadingFile = true;
					data.formData =  {componentName: componentName, messageName: messageName};
					var uploadFile = data.files[0];
					if (uploadFile.size > 500000) { // 500Kb
						bootbox.alert(i18N['sax.notification.maxUpload']);
						isUploadingFile = false;
					}
					if (isUploadingFile == true) {
						data.submit();
					}
				},
				success: function (data, textStatus, jqXHR){
					if ( data.status == 'ERROR' ) {
						$('#channelErrorWrap').html('<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> '+i18N['sax.notification.fileUploadFailed']+'</div>');
					} else {
						$('.TaskFile-fld').val(data.fileName);
						$('#channelErrorWrap').html('<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> '+i18N['sax.notification.fileUploadSuccess']+'</div>');
					}
					isUploadingFile = false;
				},
				progressall: function (e, data) {
					
				}
			});
		});
		
		// Upload
		$(document).on('click', '#customJarUploadLink', function() {
			$("#customJarFileupload").fileupload({
				url: uploadsubsystemJarUrl,
				dataType: 'json',
				add: function (e, data) {
					isUploadingJar = true;
					data.formData =  {subSystemName: ssId, sessionId: sessionId};
					var uploadFile = data.files[0];
					if (!(/\.(jar)$/i).test(uploadFile.name)) {
						bootbox.alert(i18N['sax.notification.selectJarFile']);
						isUploadingJar = false;
					}
					if (uploadFile.size > 200000000) { // 2mb
						bootbox.alert(i18N['sax.notification.maxUploadSize']);
						isUploadingJar = false;
					}
					if (isUploadingJar == true) {
						data.submit();
						$('#jarUploadingModal').modal({
							backdrop: 'static',
							keyboard: true
						}); 
					}
				},
				done: function (e, data) {
					//progress_elem.hide();
					//upload_status_elem.html(i18N['sax.label.uploading']).show();
					customJarName = data.result.data;
					originalCustomJarName = data.files[0].name;
					isUploadingJar = false;
					isUploadedJar = true;
					//$('#jarUploadingModal').modal('hide');
					$('#jarUploadingModalClose').trigger('click'); 
					$('#versionload').show();
					$('#versionload > div').hide();
					$('#uploadedJarNameWrap').show();
					if ( data.result ) {
						if ( data.result.status == 'SUCCESS' )
							$('#uploadedJarNameWrap .uploadedJarName').text(originalCustomJarName);
						else
							$('#uploadedJarNameWrap .uploadedJarName').text(data.result.data);
					}
					self.setChannesToolbarHeight();
				}
			});
		});


		$(document).on('change', '#schemaIdentifierCB', function() {
			var isChecked = $(this).prop('checked');
			if ( isChecked ) {
				$('#schemaIdWrap').show();
				$('#schemeIdFld').attr('data-parsley-required', 'true');
			} else {
				$('#schemaIdWrap').hide();
				$('#schemeIdFld').removeAttr('data-parsley-required');
			}
		});
		
		$('#esperHAFld').on('change', function() {
			var isChecked = $(this).prop('checked');
			if ( isChecked ) {
				$('#esperHAInfo').show();
				$('#workerCount').attr('data-parsley-min', '2');
			} else {
				$('#esperHAInfo').hide();
				$('#workerCount').attr('data-parsley-min', '1');	
			}
			$('#workerCount').trigger('keyup');
		});
		
		$(window).on("beforeunload", function(e) {			
			var isMsgEdited = self.isEdited();
			if(actionRebalance){
				return;
			}
			if ( isSessionTimedout ) {
				return;
			} else if( !isFormSubmition && isMsgEdited ){
				e.preventDefault();
				return i18N['sax.notification.noDataSave'];
			}		
		});
		
		self.initPopovers();
		
		spoutEditHTML = '<ul class="nav nav-tabs"> <li class="active"> <a href="#configTab12" data-toggle="tab"> '+i18N['sax.label.selectMessage']+' </a></li> <li> <a href="#configTab13" data-toggle="tab"> '+i18N['sax.label.configuration']+' </a></li><li> <a href="#configTab11" data-toggle="tab"> '+i18N['sax.label.concurrency']+' </a></li> </ul> <div class="tab-content"> <div class="tab-pane" id="configTab11"> <div class="form-group" style="display: none;"> <div class="col-sm-3 control-label"> '+i18N['sax.label.name']+' </div> <div class="col-sm-8"> <input type="text" id="channelName" placeholder="'+i18N['sax.placeholder.name'] +'" class="form-control" data-parsley-required="true"> </div> </div> <div class="form-group" style="display: none;"> <div class="col-sm-3 control-label"> '+i18N['sax.label.className']+' </div> <div class="col-sm-8"> <input type="text" id="className" placeholder="'+i18N['sax.placeholder.className']+'" class="form-control" data-parsley-required="true"> </div> </div> <div class="form-group"> <div class="col-sm-3 control-label">'+i18N['sax.label.parallelism']+' <span class="req">*</span> </div> <div class="col-sm-8"> <input type="text" id="parallelism" placeholder="'+i18N['sax.placeholder.parallelism']+'" class="form-control" data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"> </div> <a content="parallelism" title="'+i18N['sax.label.parallelism']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group"> <div class="col-sm-3 control-label"> '+i18N['sax.label.maxSpoutPending']+' <span class="req">*</span> </div> <div class="col-sm-8"> <input type="text" id="maxSpoutPending" placeholder="'+i18N['sax.placeholder.maxSpoutPending']+'" class="form-control" data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"> </div> <a content="maxSpoutPending" title="'+i18N['sax.label.maxSpoutPending']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div>  </div> <div class="tab-pane active" id="configTab12"> <div class="form-group"> <div class="col-sm-3 control-label"> '+i18N['sax.label.messageType']+' </div> <div class="col-sm-8"> <div class="radio-inline"> <label> <input type="radio" checked name="msgTypeRadio" class="msgtype-radio" value="single">'+i18N['sax.label.single']+'</label> </div> <div class="radio-inline"> <label> <input type="radio" name="msgTypeRadio" class="msgtype-radio" value="multi"> '+i18N['sax.label.multi'] +'</label> </div> <div class="radio-inline" style="display:none"> <label> <input type="radio" name="msgTypeRadio" class="msgtype-radio" value="custom"> '+i18N['sax.label.custom']+' </label> </div> </div> <a content="configurationType" title="'+i18N['sax.label.messageType']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group hidden-elem" id="schemeFld"> <div class="col-sm-3 control-label"> '+i18N['sax.label.scheme']+' <span class="req">*</span> </div> <div class="col-sm-8"> <input type="text" id="scheme" placeholder="'+i18N['sax.placeholder.scheme']+'" class="form-control"> </div> </div> <div class="form-group"> <div class="col-sm-3 control-label"> '+i18N['sax.label.messageName']+' <span class="req">*</span> </div> <div class="col-sm-8"> <div> <select id="messageTypeId" class="form-control" data-parsley-required="true"> '+ allMsgOptions +' </select> </div> </div> <a content="messageName" title="'+i18N['sax.label.messageName']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div>  <div id="schemaIdentifierWrap" class="form-group hidden-elem"> <div class="col-sm-3 control-label"> '+i18N['sax.label.schemaIdentifier']+' </div> <div class="col-sm-8"> <div class="checkbox-inline"> <input type="checkbox" value="" class="" id="schemaIdentifierCB"> </div> </div> <a content="schemaIdentifier" title="'+i18N['sax.label.schemaIdentifier']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group hidden-elem" id="schemaIdWrap"> <div class="col-sm-3 control-label"> </div> <div class="col-sm-8"> <input type="text" id="schemeIdFld" placeholder="'+i18N['sax.placeholder.schemaIdentifier']+'" class="form-control"> </div> </div> </div><div class="tab-pane" id="configTab13"> <div class="form-group" id="configRowsWrap"><div class="col-md-11 config-rows" id="configRows"> <a href="javascript:void(0)" title="'+i18N['sax.label.add']+'" class="add-config add-config-row add-ico tt"> <i class="fa fa-plus"> </i> </a> </div> </div>  </div>    </div>  </div>';
		

		emitrConnEditHTML = '<div class="component-id" id="componentId"></div> <ul class="nav nav-tabs"> <li class="active"><a href="#configTab21" data-toggle="tab"> '+i18N['sax.label.configuration']+' </a></li> <li><a href="#configTab24" data-toggle="tab"> '+i18N['sax.label.query']+' </a></li> <li><a href="#configTab25" data-toggle="tab"> '+i18N['sax.label.queryConfig']+' </a></li> <li><a href="#configTab26" data-toggle="tab"> '+i18N['sax.label.concurrency']+' </a></li> </ul> <div class="tab-content"> <div class="tab-pane config-tab-pane active" id="configTab21"> <div class="form-group" style="display: none;"> <div class="col-sm-2 control-label">'+i18N['sax.label.name']+'</div> <div class="col-sm-9"><input type="text" id="channelName" placeholder="'+i18N['sax.placeholder.name']+'" class="form-control" data-parsley-required="true"></div> </div> <div class="form-group" style="display: none;"> <div class="col-sm-2 control-label">'+i18N['sax.label.className']+'</div> <div class="col-sm-9"><input type="text" id="className" placeholder="'+i18N['sax.placeholder.className']+'" class="form-control" data-parsley-required="true"></div> </div> <div class="form-group" id="configRowsWrap"> <div class="col-sm-2 control-label">'+i18N['sax.label.config']+' <span class="req">*</span></div> <div class="col-sm-9 config-rows" id="configRows"><a href="javascript:void(0)" title="Add" class="add-config add-config-row add-ico tt"><i class="fa fa-plus"></i></a></div> </div> <div class="form-group" style="display: none;"> <div class="col-sm-3 control-label">'+i18N['sax.label.messageType']+'</div> <div class="col-sm-8"> <div><select id="messageTypeId" class="form-control" data-parsley-required="true" multiple disabled>'+ allMsgOptions +'</select></div> </div> </div> </div> <div class="tab-pane" id="configTab24"> <div class="form-group"> <div class="col-sm-3 control-label">'+i18N['sax.label.messageName']+'</div> <div class="col-sm-4"><select id="queryMessages" name="queryMessages"></select></div> <a content="statisticalMessageName" title="'+i18N['sax.label.messageName']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group"> <div class="col-sm-3 control-label">'+i18N['sax.label.groupBy']+'</div> <div class="col-sm-8"> <div class="radio-inline"><label><input type="radio" value="N" class="groupby-radio" name="querygroupby">'+i18N['sax.label.No']+'</label></div> <div class="radio-inline"><label><input type="radio" value="Y" class="groupby-radio" name="querygroupby">'+i18N['sax.lable.Yes']+'</label></div> </div> <a content="statisticalGroupBy" title="'+i18N['sax.label.groupBy']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group "> <div class="col-sm-3 control-label">'+i18N['sax.groupFields']+' <span class="req">*</span></div> <div class="col-sm-8" id="queryGroupFieldsWrap"></div> <a content="statisticalGroupFields" title="'+i18N['sax.groupFields']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group"> <div class="col-sm-3 control-label">Enable Context</div> <div class="col-sm-5"> <div class="checkbox-inline"> <input type="checkbox" id="enableContext" /> </div> </div> <a content="cepEnableContext" title="Enable Context" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div id="contextWrap" class="hidden"> <div class="form-group"> <div class="col-sm-3 control-label">Context Name</div> <div class="col-sm-5"> <input type="text" id="contextName" placeholder="'+i18N['sax.placeholder.pleaseEnterValue']+'" class="form-control"> </div> <a content="cepContextName" title="Context Name" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group"> <div class="col-sm-3 control-label">Start Time</div> <div class="col-sm-5"> <input type="text" id="startTime" placeholder="(Minute,Hour,DayofMonth,Month,DayofWeek)" class="form-control"> </div> <a content="cepStartTime" title="Start Time" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group"> <div class="col-sm-3 control-label">End Time</div> <div class="col-sm-5"> <input type="text" id="endTime" placeholder="(Minute,Hour,DayofMonth,Month,DayofWeek)" class="form-control"> </div> <a content="cepEndTime" title="End Time" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> </div> <div class="panel-group" id="queryAccordion" role="tablist" aria-multiselectable="true"></div> <div class="form-group"> <div class="col-sm-12"><a href="javascript:void(0)" id="addQueryAccordion" class="pull-right disabled"><i class="fa fa-plus-circle"></i> Add Query</a></div> </div> </div> <div class="tab-pane" id="configTab25"> <div class="text-info margin-b"><strong>'+i18N['sax.label.restClientURL']+' </strong>http://&lt;&lt;IP:PORT&gt;&gt;/StreamAnalytix/datafabric/dynacep/query/register <a content="dynamicCEPHelp" title="'+i18N['sax.help']+'" tabindex="-1" class="po infoico" href="javasript:void(0)"><i class="fa fa-info-circle"></i></a></div> <div class="clearfix"></div> <div id="cepDynamicQueryWrap" class="panel-group" role="tablist" aria-multiselectable="true"></div> </div> <div class="tab-pane" id="configTab26"> <div class="form-group"> <div class="col-sm-2 control-label">'+i18N['sax.label.parallelism']+' <span class="req">*</span></div> <div class="col-sm-9"><input type="text" id="parallelism" placeholder="'+i18N['sax.placeholder.parallelism']+'" class="form-control" data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1"></div> <a content="parallelism" title="'+i18N['sax.label.parallelism']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group"> <div class="col-sm-2 control-label">'+ i18N['sax.label.taskCount'] +' <span class="req">*</span></div> <div class="col-sm-9"><input type="text" id="taskCount" placeholder="'+i18N['sax.placeholder.taskcount']+'" class="form-control" data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1" data-parsley-ge="#parallelism"></div> <a content="taskCount" title="'+i18N['sax.label.taskCount']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> </div> </div>';
		configHTML = '<div class="config-row"><div class="col-sm-6"><input type="text" placeholder="'+i18N['sax.placeholder.property']+'" class="form-control config-key" data-parsley-required="true" data-parsley-duplicateKeys=""></div><div class="col-sm-6"><input type="text" placeholder="'+i18N['sax.placeholder.value']+'" class="form-control config-value tt" data-parsley-required="true"></div><a href="javascript:void(0)" title="'+i18N['sax.label.remove']+'" class="remove-config remove-config-row remove-ico tt"><i class="fa fa-times"></i></a><a href="javascript:void(0)" title="'+i18N['sax.label.add']+'" class="add-config add-config-row add-ico tt"><i class="fa fa-plus"></i></a></div></div>';
		
		self.hideProcessors();
		self.checkForDuplicateMessage();
		self.createFVAutoSuggestData();
		
		$(document).on('blur', '#configRowsWrap input.config-key', function(){
			$('#configRowsWrap input.config-key').trigger('keyup');
		});
		
		// Check Availability START
		var topicFieldVal = "", queueNameFieldVal = "", pathFieldVal = "";
		
		$(document).on('focus', '.config-value.queueName-fld', function(){
			queueNameFieldVal = $(this).val();
		});
		
		$(document).on('blur', '.config-value.queueName-fld', function(){
			var value = $(this).val();
			if ( queueNameFieldVal != value )
				self.checkAvailability(queueNameUrl, value, 'name');
		});
		
		$(document).on('focus', '.config-value.exchangeName-fld', function(){
			exchangeNameVal = $(this).val();
		});

		$(document).on('blur', '.config-value.exchangeName-fld', function(){
			var value = $(this).val();
			if(exchangeNameVal != value){
				self.checkAvailability(exchangeNameUrl, value, 'name');
			}
		});
		
		/*$(document).on('focus', '.config-value.topicName-fld', function(){
			topicFieldVal = $(this).val();
		});
		
		$(document).on('blur', '.config-value.topicName-fld', function(){
			var value = $(this).val();
			var zkHostJSON = $('#selectConnObj').val();
			if ( typeof zkHostJSON == 'string' && zkHostJSON != "" ) {
						zkHostJSON = JSON.parse(zkHostJSON);
					}
			if ( topicFieldVal != value ) 
				self.checkAvailability(topicNameUrl, value, 'name');
		});*/
		
		$(document).on('focus', '.config-value.path-fld', function(){
			pathFieldVal = $(this).val();
		});
		
		$(document).on('blur', '.config-value.path-fld', function(){
			var value = $(this).val();
			if ( pathFieldVal != value )
				self.checkAvailability(HDFSPathNameUrl, value, 'path');			
		});
		// Check Availability END

		$(document).on("click", "#loadVersionLink", function(e) {
			if ( $(this).is(".disabled") ) {
			    return false;
			}
			$('#versionDataTable_filter input').val('').trigger('keyup');
			$('#versionModalWrap').modal('show');
			$("#versionModalWrap .modal-dialog").width(900);
		});
		
		$(document).on("change",'input[name = "subSystemVersion"]', function() {
			var selectedSSVersion = $('input[name=subSystemVersion]:checked').val();
			if( maxSubSystemVersion == selectedSSVersion ) {
				$('#versionRow, #commentWrap').show();
			}else {
				$('#versionRow, #commentWrap').hide();
			}
		});
		$(document).on("click", "#cancelVersion", function(){
			var selectedSSVersion =  $('.versionCombo').text();
			$("input[name=subSystemVersion][value="+selectedSSVersion+"]").prop("checked",true);
			
		});
		$(document).on("click", "#loadVersionBtn", function() {
			selectedSubsystemVersion = $('input[name=subSystemVersion]:checked').val();
			$('.versionCombo').text(selectedSubsystemVersion);
			//$('.versionCreatedDate').text($('input[name=sSVersionCreatedDate]').val());
			$('.versionModifiedDate').text($('input[name=sSVersionModifiedDate]').val());
			$('.versionCreatedUser').text($('input[name=sSVersionCreatedBy]').val());
			var url = subSystemVersionDataUrl + ssId +"/version/"+selectedSubsystemVersion;
			var selectedVersionData = self.getAjaxData(url)
			var result = selectedVersionData;
			if ( result != '' ) {
				$('#versionModalWrap').modal('hide');
				redrawPipeline(result);
			} else {			
				$('#versionFailureMsz').html('<div class="alert alert-error alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+result+'</div>').fadeIn(1000);
			}
				clearTimeout(myTimeout);
				myTimeout = setTimeout(function() { $("#versionFailureMsz").fadeOut(2500); }, 20000);
		});
		
		Array.prototype.max = function() {
		  return Math.max.apply(null, this);
		};
		if(ssId != ""){
			var maxVersionURL = subSystemMaxVersionURL + ssId +"/maxversion";
			maxSubSystemVersion = self.getAjaxData(maxVersionURL);
			if(typeof(maxSubSystemVersion) == 'Object' || maxSubSystemVersion == 0){
				maxSubSystemVersion = 1;
			}
			self.updateSubstemVersion();
			self.LoadSubSystemVersionData();
			$("input[name=subSystemVersion][value="+selectedSubsystemVersion+"]").prop("checked",true);
			$('#rebalanceModalLink, #loadVersionLink, #versionload').show();
			$('#pipelineActionMenu > a').removeClass('col-md-4');
			$('#pipelineActionMenu > a').addClass('col-md-5th');
		}
		else{
			$("#commentWrap").show();
			$('#rebalanceModalLink, #loadVersionLink, #versionload').hide();
			$('#pipelineActionMenu > a').addClass('col-md-4');
			$('#pipelineActionMenu > a').removeClass('col-md-5th');
		}
		if(maxSubSystemVersion == selectedSubsystemVersion){
			if( maxSubSystemVersion >= 1){
				$('#versionRow, #commentWrap').show();
			}else{
				$('#versionRow, #commentWrap').hide();
			}
		}else{
			$('#versionRow').hide();
		}
		
		$('#channelsModalWrap').on('hidden.bs.modal', function() {
			$('#channelProperties').empty();
		});

		$('#streamModalWrap').on('hidden.bs.modal', function() {
			$('#streamIdFilterWrap').empty();
		});
	
	};
	
	self.unique = function(arr) {
		return $.grep(arr, function(el, index) {
			return index == $.inArray(el, arr);
		});
	};
	
	self.filterBetweenValidation = function() {
		$('.criteria_wrap').each(function(i, row) {
			var inputSize = $(row).find(".criteria_fields > span[class^='input_']").size();
			if ( inputSize == 2 ) {
				var firstVal = $(row).find(".criteria_fields > span[class^='input_']:first input").val();
				$(row).find(".criteria_fields > span[class^='input_']:last input").attr("data-parsley-min", firstVal);
			}
		});
	};
	
	self.removeParsleyErrors = function()  {
		$('#erroHandlingForm').parsley().destroy();
		$('#subSystemFieldsWrap').parsley().destroy();
	};
	
	self.confirmExistingJar = function() {
		bootbox.confirm({
			closeButton: false,
			title: i18N['sax.label.confirmation'],
			message: '<div class="alert alert-warning" role="alert"><b><i class="fa fa-info-circle"></i></b> ' + i18N['sax.notification.useExistingJar'] +'</div>',
			buttons: {
				'cancel': {
					label: i18N['sax.no'],
					className: 'btn-default'
				},
				'confirm': {
					label: i18N['sax.yes'],
					className: 'btn-primary'
				}
			},
			callback: function(result) {
				customJarName = (result) ? customJarName : "";
				originalCustomJarName = (result) ? originalCustomJarName : "";
				if ( !$.isEmptyObject(deadLaterChannel) ) {
					$('#errorHandlerFld').prop('checked', true);
					$('#errorProcessorType').val(deadLaterChannel.id).trigger('change');
					var selComp = $('#errorProcessorType option[value="'+ deadLaterChannel.id +'"]').text();
					$('#editErrHandlr').html('<small>('+ i18N['sax.label.configure'] +')</small>');
				}
				$("#erroHandlingStep").addClass("hidden");
				$("#definitionStep").removeClass("hidden");
				$("#ssDefinitionWrap").modal();
			}
		});
	};
	
	self.updateSubstemVersion = function() {
		selectedSubsystemVersion = selectedSubsystemVersion == '' ? maxSubSystemVersion : $('.versionCombo').text();
		//displayVersion = 1;
		
		for ( var i=0; i<allSubSystemData.length; i++ ) {
			if ( ssId == allSubSystemData[i].name ) {
			    if(allSubSystemData[i].versionNumber){
					displayVersion = allSubSystemData[i].versionNumber == '' ? 1 :  allSubSystemData[i].versionNumber;
				}else{
					displayVersion = 1;
				}
			}else if( ssId == ''){
				displayVersion = 1;
			}
		}
		selectedSubsystemVersion = displayVersion;
		$('.versionCombo').text(displayVersion);
		
		var versionDetails = self.getAjaxData(versionDetailsUrl+ssId+'/version/'+selectedSubsystemVersion+'/detail');
		if (versionDetails) {
			//var cDate = moment(versionDetails.date_created).format('YYYY-MM-DD h:mm:ss');
			//var mDate = moment(versionDetails.date_modified).format('YYYY-MM-DD h:mm:ss');
			//$('.versionCreatedDate').text(cDate);
			$('.versionModifiedDate').text( versionDetails.date_modified);
			$('.versionCreatedUser').text(versionDetails.modifiedby);
		}
	};
	
	self.LoadSubSystemVersionData = function() 	{
		var versionData = self.getAjaxData(subSystemVersionsUrl);
		var jsonObj = versionData.SubsystemVersionList;
		if ( versionTable )
			$("#versionDataTable").dataTable().fnDestroy();
		if ( typeof jsonObj.thrownError !== "undefined" ) {
			$("#versionErrWrap").html('<div class="alert alert-danger margin-t">' + errorObj.TABLE_RENDERING + '</div>');
			} else if ( jsonObj == 'null' || jsonObj.length == 0 ) {
				$("#versionErrWrap").html('<div class="alert alert-info margin-t">' + errorObj.NO_DATA + '</div>');
			} else {			
				
				versionTable = $("#versionDataTable").dataTable({
					"aaData": jsonObj,
					"bJQueryUI": false,
					"bAutoWidth": false,
					"bFilter": true,
					"bPaginate": true,
					"iDisplayLength": 10,
					"sDom": 'ftip',
					"sPaginationType": "full_numbers",
					"aoColumns": [
						{"mData": function(obj) {
							var cDate = obj.date_created;
							var mDate = obj.date_modified;
							return'<input type = "radio" value= "'+obj.jar_version+'" class="radio-inline" name="subSystemVersion" checked=""/><input type="hidden" name="sSVersionCreatedDate" value="'+cDate+'"/><input type="hidden" name="sSVersionModifiedDate" value="'+mDate+'"/><input type="hidden" name="sSVersionCreatedBy" value="'+obj.modifiedby+'"/>' ;
						}},
						{ "mData": "jar_version", "sTitle": i18N['sax.title.versionDataTab'] },
						{"sTitle": i18N['sax.title.dateCreated'],"mData": function(obj) {
							if(obj)
								//var mDate = moment(obj.date_created).format('YYYY-MM-DD h:mm:ss');
							   return obj.date_created;

						}},
						{"sTitle": i18N['sax.title.dateModified'],"mData": function(obj) {
							if(obj)
								//var mDate = moment(obj.date_modified).format('YYYY-MM-DD h:mm:ss');
							   return obj.date_modified;

						}},
						{ "mData": "createdby", "sTitle": i18N['sax.title.createdBy'] },
						{ "mData": "modifiedby", "sTitle": i18N['sax.title.modifiedBy'] },
						{ "mData": "description", "sTitle": i18N['sax.title.description'] }
					],
					"fnDrawCallback": function(o) {
						if ( o.aiDisplay.length == 0 ) {
							$('#loadVersionBtn').prop('disabled', true);
						} else {
							$('#loadVersionBtn').prop('disabled', false);
						}
					}
				});
				versionTable.fnSort( [ [1,'desc'] ] );
			}
	};
	
	self.regExAutoComplete = function(strs) {
		return function findMatches(q, cb) {
			var matches, substringRegex;
			matches = [];
			$.each(strs, function(k, v) {
				if ( v.key.indexOf(q) > -1 )
					matches.push({ key: v.key, value: v.value });
			});
			cb(matches);
		};
	};
	
	self.checkSpecialCharacter = function(path){
		var regex = /^[a-zA-Z0-9/_]+$/;
		var pathValue = path;
			if (regex.test(pathValue)) {
				return true;
			}
			else {
				return false;
			}
	};
	
	self.resizeCanvas = function() {
		var winH = $(window).height();
		var headerH = $('.page-head').outerHeight(true);
		var footerH = $('#footer').outerHeight(true);
		$('#topologyGraphWrap').height( winH - headerH - footerH + 20 );
		self.setChannesToolbarHeight();
		
		$(window).one('resize', function() {
			self.resizeCanvas();
		});
	};
	
	self.isEdited = function(){
		var isEdited = false;		
		$('#subSystemFieldsWrap').find('input').each(function(){
			if($(this).val() != ''){
				isEdited = true;
			}
		});
		if($('#topologyGraph').find('._jsPlumb_endpoint').length > 0){
			isEdited = true;
		}
		return isEdited;
	};
	
	self.checkForDuplicateMessage  = function() {
		$("#subSystemName").on("blur", function() {
			var name = $(this).val();
			name = jQuery.trim(name);
			if(name.toLowerCase() == 'null' && duplicateNameErrorObj.lastEnteredName != name){
				$("#duplicateNameError").html('<div class="alert alert-error msg-failure alert-dismissable new-error">'+ NULL_NAME_ERROR +'</div>').show().find('.alert').show();				
				duplicateNameErrorObj.lastEnteredName = name;
				return;
			}
			if ( name.length > 0 && duplicateNameErrorObj.lastEnteredName != name ) {
				$.ajax({
					type: "GET",
					url: isSubsystemAvailableUrl+'?subsystemName='+name,
					beforeSend: function (xhr) {},
					success: function (data) {
					data=JSON.parse(data);
						if ( data.status.toUpperCase() == 'AVAILABLE' ) {
							$("#duplicateNameError").html('<div class="alert alert-error msg-failure alert-dismissable new-error">'+ data.message +'</div>').show().find('.alert').show();
							duplicateNameErrorObj.isDuplicate = true;
							duplicateNameErrorObj.lastEnteredName = name;
						}  else if ( data.status.toUpperCase() == 'FAILURE' ) {
							$("#duplicateNameError").html('<div class="alert alert-error msg-failure alert-dismissable new-error">'+ data.message +'</div>').show().find('.alert').show();
							duplicateNameErrorObj.isDuplicate = true;
							duplicateNameErrorObj.lastEnteredName = name;
						} else {
							$("#duplicateNameError").empty().hide();
							duplicateNameErrorObj.isDuplicate = false;
							duplicateNameErrorObj.lastEnteredName = name;
						}
					},
					error: function (xhr, ajaxOptions, thrownError) {
						return false;
					}
				});
			}
		});
	};
	
	// GET AJAX
	self.getAjaxData = function (url, options) {
        var rt; 
        $.ajax({
            type: "GET",
            dataType: "json",
			contentType:"application/json; charset=utf-8",
			data:options,
            async: false,
            url: url,
            beforeSend: function (xhr) {},
            success: function (data) {
                rt = data;
            },
            error: function (xhr, ajaxOptions, thrownError) {
            	userAuth.chechAuthStatus(xhr);
                rt = {};
				rt["thrownError"] = thrownError;
				console.log(thrownError);
            }
        });
        return rt;
    };
	
	// POST AJAX
	self.postAjaxData = function (url, params) {
        var rt; 
        $.ajax({
            type: "POST",
			contentType: "application/json; charset=utf-8",
			data: params,
            async: false,
            url: url,
            beforeSend: function (xhr) {},
            success: function (response) {
				rt = response;
            },
            error: function (xhr, ajaxOptions, thrownError) {
            	userAuth.chechAuthStatus(xhr);
				rt = {};
				rt["thrownError"] = thrownError;
				console.log(thrownError);
            }
        });
        return rt;
    };
	
	self.checkComponentSupport = function(componentId) {
		var isFeatureSupported = true;
		if ( jQuery.inArray(componentId, restrictedComponents) > -1 ) {
			isFeatureSupported = licenseAuth.getFeatureContent(componentId, "modal", '');
		}
		return isFeatureSupported;
	};

	self.checkAvailability  = function(url, value, queryString) {
		value = jQuery.trim(value);
		var urlString = "";
		if ( queryString == "" )
			urlString = url+"?"+value;
		else
			urlString = url+'?'+queryString+'='+value;
		var checkAvaiForComp = $('#curChannelName').val();
		
		if ( value.length > 0 && duplicateNameErrorObj.lastEnteredName != value ) {
			$.ajax({
				type: "GET",
				url: urlString,
				beforeSend: function (xhr) {},
				success: function (data) {
					response = JSON.parse(data);
					var currentComp = $('#curChannelName').val();
					if ( checkAvaiForComp == currentComp ) {
						if ( response.status.toUpperCase() == 'AVAILABLE' ) {
							$("#channelErrorWrap").html('<div class="col-sm-12 alert alert-warning alert-dismissible msg-failure new-error"><span class="glyphicon glyphicon-warning-sign"></span> '+ response.message +'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>').show().find('.alert').show();
						}  else if ( response.status.toUpperCase() == 'FAILURE' ) {
							$("#channelErrorWrap").html('<div class="alert alert-error msg-failure alert-dismissable new-error">'+ response.message +'</div>').show().find('.alert').show();
						} else {
							$("#channelErrorWrap").empty();
						}
					}
				},
				error: function (xhr, ajaxOptions, thrownError) {
					return false;
				}
			});
		}
	};
	
	self.setChannesToolbarHeight = function() {
		setTimeout(function() {
			var dpToolbarWrapH = $('#ssToolbarWrap').height();
			var dpActionBarH = $('#dpActionBar').height();
			var panelHeadingH = $('#ssToolbarAccordion > .panel:first > .panel-heading').height();
			var panelH = (dpToolbarWrapH - dpActionBarH) - (panelHeadingH*3);
			$('#ssToolbarAccordion .panel-collapse').css('max-height', panelH);
		}, 300);
	};
	
	self.createAllChannesToolbar = function() {
		$("#ssToolbarAccordion").empty();
		var counter = 0;
		$.each(allChannelsData, function(key, arr) {
			if ( arr.length > 0 ) {
				var id = key+"Tools";
				var isExpand = (counter == 0) ? 'in' : '';
				var $panel = $('<div>', {class: "panel panel-default"}).appendTo('#ssToolbarAccordion');
				var $panelHead = $('<div>', {class: "panel-heading", role: "tab"}).appendTo($panel);
				var $panelHeadHTML = '<h4 class="panel-title"><a data-toggle="collapse" data-parent="#ssToolbarAccordion" href="#'+ id +'" aria-expanded="true" aria-controls="'+ id +'"><span class="margin-ls">'+ i18N['sax.label.'+key] +'</span></a></h4>'; //<span class="cmp-icon '+ key +'-icon"></span>
				$panelHead.html( $panelHeadHTML );
				var $panelCont = $('<div>', {id: id, class: "panel-collapse collapse "+ isExpand, role: "tabpanel"}).appendTo($panel);
				var $panelBody = $('<div>', {class: "panel-body"}).appendTo($panelCont);
				var $compList = $('<ul>', {id: "componentsList", class: "components-list subsystem-toolbar"}).appendTo($panelBody);
				
				var addedCEP = false;
				var addedPersister = false;
				var addedChannels = false;
				var addedOthers = false;
				for ( var i=0; i<arr.length; i++ ) {
					var type = ( arr[i].type ) ? arr[i].type : 'channel';
					var compId = arr[i].id;
					var compIdCustom = arr[i].id;
					var compLabel = arr[i].label;
					var restrictCls = '';
					var imgSrc = "";
					var isCustom = false;
					var isIconAva = false;
					imgSrc = baseUrl+'/resources/images/component/'+compId+'-small.png';
					if ( arr[i].subtype ) {
						compId = compId + '-v' + arr[i].version;
						compLabel = compLabel + '-v' + arr[i].version;
						arr[i].id = compId;
						arr[i].label = compLabel;
						if ( arr[i].icon ) {
							imgSrc = baseUrl+'/resources/images/custom/'+compIdCustom.toLowerCase()+'-small.png';
							isIconAva = true;
						} else {
							if ( key == 'channels' ) {
								imgSrc = baseUrl+'/resources/images/component/channel-custom-small.png';
							} else {
								imgSrc = baseUrl+'/resources/images/component/processor-custom-small.png';
							}
						}
						isCustom = true;
					}
					
					var displayLbl = (compLabel.length > 12) ? (compLabel.substr(0, 9) + '...') : compLabel;
					
					if ( $.inArray(arr[i].id, restrictedComponents) > -1 ) {
						restrictCls = ' unsupported';
					}
					
					if ( compId == cmpIDs.cassandraemitter || compId == cmpIDs.hbaseemitter || compId == cmpIDs.hdfsemitter ) {
						if ( !addedPersister ) {
							$compList.append( '<li id="persisterCompsWrap"><div class="subtitle">'+ i18N['sax.label.persister'] +'</div></li>' );
						}
						$('#persisterCompsWrap').append( '<div class="cmp-item tt" title="'+ compLabel +'"><a href="javascript:void(0)" class="'+ key +'" role="" ui-type="'+ type +'" ui-id="'+ compId +'"><img src="'+imgSrc+'"/><div class="lbl">'+ compLabel +'</div></a></div>' );
						addedPersister = true;
					} else if ( compId == cmpIDs.elasticsearchemitter || compId == cmpIDs.solremitter ) {
						if ( !addedCEP ) {
							$compList.append( '<li id="indexerCompsWrap"><div class="subtitle">'+ i18N['sax.label.indexer'] +'</div></li>' );
						}
						$('#indexerCompsWrap').append( '<div class="cmp-item tt" title="'+ compLabel +'"><a href="javascript:void(0)" class="'+ key +'" role="" ui-type="'+ type +'" ui-id="'+ compId +'"><img src="'+imgSrc+'"/><div class="lbl">'+ compLabel +'</div></a></div>' );
						addedCEP = true;
					} else if ( compId == cmpIDs.cepcustom || compId == cmpIDs.dynamiccepprocessor ) {
						if ( !addedCEP ) {
							$compList.append( '<li id="cepCompsWrap"><div class="subtitle">'+ i18N['sax.label.cep'] +'</div></li>' );
						}
						$('#cepCompsWrap').append( '<div class="cmp-item tt" title="'+ compLabel +'"><a href="javascript:void(0)" class="'+ key + restrictCls +'" role="" ui-type="'+ type +'" ui-id="'+ compId +'"><img src="'+imgSrc+'"/><div class="lbl">'+ compLabel +'</div></a></div>' );
						addedCEP = true;
					} else if ( compId == cmpIDs.analyticsprocessor ) {
						$compList.append( '<li id="analyticsCompsWrap"><div class="subtitle">'+ i18N['sax.label.analytics'] +'</div></li>' );
						
						for ( var j=0; j<arr[i].algorithms.length; j++ ) {
							compLabel = arr[i].algorithms[j].name;
							$('#analyticsCompsWrap').append( '<div class="cmp-item tt" title="'+ compLabel +'"><a href="javascript:void(0)" class="'+ key +'" role="" ui-type="'+ type +'" ui-id="'+ compId +'" algo-id="'+ arr[i].algorithms[j].id +'"><img src="'+imgSrc+'"/><div class="lbl">'+ compLabel +'</div></a></div>' );
						}
					} else if ( key == 'channels' ) {
						if ( !addedChannels ) {
							$compList.prepend( '<li id="'+ key +'CompsWrap"></li>' );
						}
						$("#"+ key +"CompsWrap").append( '<div class="cmp-item tt" title="'+ compLabel +'"><a href="javascript:void(0)" ui-custom="'+isCustom+'" ui-icon-ava="'+isIconAva+'" class="'+ key +'" role="" ui-type="'+ type +'" ui-id="'+ compId +'" ui-name="'+ compIdCustom +'"><img src="'+imgSrc+'"/><div class="lbl">'+ compLabel +'</div></a></div>' );
						addedChannels = true;
					} else {
						if ( !addedOthers ) {
							$compList.prepend( '<li id="'+ key +'CompsWrap"></li>' );
						}
						$("#"+ key +"CompsWrap").append( '<div class="cmp-item tt" title="'+ compLabel +'"><a href="javascript:void(0)" class="'+ key +'" role="" ui-type="'+ type +'" ui-custom="'+isCustom+'" ui-icon-ava="'+isIconAva+'" ui-id="'+ compId +'" ui-name="'+ compIdCustom +'"><img src="'+imgSrc+'"/><div class="lbl">'+ compLabel +'</div></a></div>' );
						addedOthers = true;
					}
				}
				
				counter ++;
			}
		});
		
		// Init show/hide sub-menu functionality
		$('#componentsList a.sub-cmps-link').on('click', function(e) {
			e.preventDefault();
			var target = $(this).attr('href');
			$(target).toggleClass('hidden-elem');
			$(this).find('i.fa').toggleClass('fa-angle-left').toggleClass('fa-angle-down');
		});
		
		// Initialize DRAG n DROP functionality
		$( "ul.components-list div.cmp-item" ).draggable({
			appendTo: "#ssWidgetContainer",
			drag: function( event, ui ) {
				var cloneOffset = {
					left: ui.offset.left, 
					top: ui.offset.top,
					right: ui.offset.left + $(ui.helper).width(),
					bottom: ui.offset.top + $(ui.helper).height()
				};
				
				var toolBarOffset = {
					left: $('#ssToolbarWrap').offset().left, 
					top: $('#ssToolbarWrap').offset().top,
					right: $('#ssToolbarWrap').offset().left + $('#ssToolbarWrap').width(),
					bottom: $('#ssToolbarWrap').offset().top + $('#ssToolbarWrap').height()
				};
				
				var overlap = !(cloneOffset.left > toolBarOffset.right || 
							   cloneOffset.right < toolBarOffset.left || 
							   cloneOffset.top > toolBarOffset.bottom ||
							   cloneOffset.bottom < toolBarOffset.top);
				
				if ( overlap )
					$('.shape.cmp-clone').addClass('undroppable');
				else
					$('.shape.cmp-clone').removeClass('undroppable');
			},
			helper: function() {
				var label = $(this).find('a').text();
				var cls = $(this).find('a').attr("class");
				cls += ' ' + $(this).find('a').attr("ui-id");
				return $('<div class="cmp-clone shape '+ cls +'"><span>'+ label +'</span></div>');
			}
		});
		$( "#topologyGraphWrap" ).droppable({
			activeClass: "",
			hoverClass: "",
			//tolerance: "touch",
			accept: ":not(.ui-sortable-helper)",
			drop: function( event, ui ) {
				var isUnDroppable = $(ui.helper).hasClass('undroppable');
				if ( !isUnDroppable ) {
					var scrollLeft = $('#topologyGraphWrap').scrollLeft();
					var scrollTop = $('#topologyGraphWrap').scrollTop();
					dragDropObj['component'] = ui.draggable;
					dragDropObj['left'] = ui.position.left + scrollLeft;
					dragDropObj['top'] = ui.position.top + scrollTop;
					$(ui.draggable).find('a').trigger('click');
					dragDropObj = {};
				} else {
					return false;
				}
			}
		});
	};
	
	self.createFieldsOption = function(select) {
		var sourceCmp = (addedSpoutsObj[streamIdConn.sourceId]) ? addedSpoutsObj[streamIdConn.sourceId] : addedBoltsObj[streamIdConn.sourceId];
		var opts = [];
		opts = sourceCmp.messageTypes;
		
		$(select).empty();
		var intersection = self.getIntersectFields(opts);
		
		if ( intersection.length > 0 ) {
			for ( var j=0; j<intersection.length; j++ ) {
				$('<option data-type="'+ intersection[j].dataType +'" value="'+ intersection[j].fieldName +'">'+ intersection[j].fieldLabel +'</option>').appendTo(select);
			}
		}
	};
	
	self.getIntersectFields = function(opts) {
		var objects = {};
		var counter = {};
		var selFieldsArr = [];
		
		$.each(allMessagesData, function(key, arr) {
			if ( jQuery.inArray(key, opts) > -1 ) {
				selFieldsArr.push(arr);
			}
		});
		
		selFieldsArr.map(function(ary, n) {
			ary.map(function(obj) {
				var key = obj.fieldName+obj.fieldLabel;
				objects[key] = obj;
				counter[key] = (counter[key] || 0) | (1 << n);
			});
		});

		var intersection = [];
		Object.keys(counter).map(function(key) {
			if(counter[key] == (1 << selFieldsArr.length) - 1)
				intersection.push(objects[key]);
		});
		return intersection;
	};
	
	self.getUnionFields = function(msgs) {
		var fieldsArr = [];
		var tmpFieldsArr = [];
		
		if ( typeof msgs !== 'undefined' ) {
			for ( var i=0; i<msgs.length; i++ ) {
				if (msgs[i] != null ) {
					var fields = allMessagesData[msgs[i]];
					for ( var j=0; j<fields.length; j++ ) {
						if ( jQuery.inArray(fields[j].fieldName, tmpFieldsArr) == -1 ) {
							tmpFieldsArr.push( fields[j].fieldName );
							fieldsArr.push( fields[j] );
						}
					}
				}
			}
		}
		return fieldsArr;
	}
	
	//---hide certain processors
	self.hideProcessors = function() {
		$(".processors").each(function(){
		   var inner_text=$(this).find(".lbl").html();
		   if(inner_text=="AlertAggregation" || inner_text=="AlertConsumer")
		   {
			 $(this).hide();
		   }
		});
	};
	
	self.initPopovers = function() {
		$(".po").each(function() {
			var elm = $(this);
			var title = elm.attr('title');
			var content = elm.attr('content');
			elm.popover({
				html: true,
				container: 'body',
				placement: 'left',
				trigger: 'hover',
				delay: { show: 300, hide: 500 },
				title: title,
				content: function() {
					return contentMap[content];
				}
			});
		});
	};
	
	self.getFileterRules = function() {
		var rulesObj = {"rules": []};
		$("#rulesTabContent .alertCriteriaWrap .parsley-errors-list").remove();
		$("#rulesTabContent .alertCriteriaWrap").each(function() {
			var messageName = $(this).find("select.msgTypeList").val();
			var filterNegate = $(this).find("select.filterNegateSel").val();
			filterNegate = (filterNegate == 'true') ? true : false;
			var rule = {};
			rule.message = messageName;
			rule.filterNegate = filterNegate;
			rule.filterQuery = $(this).find(".alertFilterQuery").val();
			rule.filterJSON = [];
			var rows = $(this).find(".alertCriteria").find(".criteria_wrap");
			
			for ( var i=0; i<rows.length; i++ ) {
				var operand = $(rows[i]).find("select.operand_select").find("option:selected").val();
				var field = $(rows[i]).find("select.context_select").find("option:selected").val();
				var operator = $(rows[i]).find("select.comparitor_select").find("option:selected").val();
				var fieldValue = $(rows[i]).find(".criteria_fields > span[class^='input_']:first input").val();
				var fieldValue2 = $(rows[i]).find(".criteria_fields > span[class^='input_']:last input").val();
				var inputSize = $(rows[i]).find(".criteria_fields > span[class^='input_']").size();
				var fldValue = fieldValue;
				fldValue += ( inputSize > 1 ) ? (',' + fieldValue2) : '';
				rule.filterJSON.push({
					operand: operand,
					expressionsInfo: {
						field: field,
						operator: operator,
						fieldValue: fldValue
					}
				});
				
				if ( i==0 )
					rule.filterQueryFields = field;
				else
					rule.filterQueryFields += "," + field;
			}
			
			rulesObj.rules.push(rule);
		});
		return JSON.stringify(rulesObj);
	};
	
	self.getUniqueMessageFields = function(msgs) {
		var selFieldsArr = [];
		$.each(allMessagesData, function(key, arr) {
			if ( jQuery.inArray(key, msgs) > -1 ) {
				for ( var i=0; i<arr.length; i++ ) {
					if ( $.inArray(arr[i], selFieldsArr) == -1 )
						selFieldsArr.push(arr[i].fieldName + ':' + arr[i].fieldLabel);
				}				
			}
		});
		return selFieldsArr;
	};
	
	self.validateCEPStatistical = function() {
		var allFunctions = [];
		var hasSameFunc = false;
		var applyGroupBy = false;
		$('#channelErrorWrap').empty();

		$("#queryAccordion > .panel").each(function(i, panel) {
			allFunctions = [];
			$(panel).find(".queryFieldsWrap .row").each(function(j, fieldRow) {
				var functn = $(fieldRow).find("select.queryfunction").val();
				
				if ( allFunctions.indexOf(functn) > -1 ) hasSameFunc = true;
				allFunctions.push( functn );
			});
		});

		if ( hasSameFunc ) {
			$('#channelProperties ul.nav-tabs a[href="#configTab24"]').trigger('click');
			$('#channelErrorWrap').html('<div class="alert alert-danger">'+i18N['sax.notification.sameFunction']+'</div>');
			return false;
		}
		
		$('#queryAccordion > .panel').each(function(i, panel) {
			var applied = $(panel).find('.applyGroupBy').prop('checked');
			if ( applied ) applyGroupBy = true;
		});
		var groupBy = $(".groupby-radio:checked").val();
		
		if ( groupBy == 'Y' && !applyGroupBy ) {
			$('#channelProperties ul.nav-tabs a[href="#configTab24"]').trigger('click');
			$('#channelErrorWrap').html('<div class="alert alert-danger">Group By clause not applied on any query. Kindly remove Group By clause.</div>');
			return false;
		}
		
		return true;
	};
	
	self.createDynamicCEPQueryData = function() {
		var exchangeName, routingKey, url, method, className, headerParams={}, requestParams={}, initParams={};
		var subsystemName = $("#subSystemName").val();
		var componentId = $("#curChannelName").val();

		var AllQueries = {
				"subsystemName": subsystemName,
				"cepComponent": [
					{
						"componentId": subsystemName+'_'+componentId,
						"cepConfig": []
					}
				]
			};
		
		$("#cepDynamicQueryWrap .query-panel").each(function(i, qElem) {
			var queryId = $(qElem).find('.queryid').val();
			var queryObj = {
				"cepQueryId": queryId,
				"cepAction": []
			};
			
			$(qElem).find('.action-panel').each(function(j, aElem) {
				var action = $(aElem).find('select.queryAction').val();
				if ( action == 'PUBLISH_TO_RABBITMQ' ) {
					exchangeName = $(aElem).find('.exchangename').val();
					routingKey = $(aElem).find('.routingKey').val();
					queryObj.cepAction.push({
						actionName: action,
						params: {
							exchangeName: exchangeName,
							routingKey: routingKey
						}
					});
				} else if ( action == 'INVOKE_WEBSERVICE_CALL' ) {
					url = $(aElem).find('.url').val();
					method = $(aElem).find('select.method').val();
					
					$(aElem).find('ul.headerparams li').each(function(k, p) {
						var params = $(p).text().split(":");
						headerParams[params[0]] = params[1];
					});
					
					$(aElem).find('ul.requestparams li').each(function(k, p) {
						var params = $(p).text().split(":");
						requestParams[params[0]] = params[1];
					});
					
					queryObj.cepAction.push({
						actionName: action,
						params: {
							url: url,
							method: method,
							headerParams: headerParams,
							requestParams: requestParams
						}
					});
				} else if ( action == 'CUSTOM_ACTION' ) {
					className = $(aElem).find('.delegate').val();
					
					$(aElem).find('ul.initparams li').each(function(k, p) {
						var params = $(p).text().split(":");
						initParams[params[0]] = params[1];
					});
					
					queryObj.cepAction.push({
						actionName: action,
						params: {
							className: className,
							initParams: initParams
						}
					});
				}
			});
			
			AllQueries.cepComponent[0].cepConfig.push(queryObj);
		});
		
		return AllQueries;
	};
	
	self.showBoltsError = function(id) {
		var e = $.Event('mousedown');
		e.button = 2;
		$('#'+id).trigger(e);
		setTimeout(function() {
			$('#saveChannelProp').trigger('click');
		}, 700);
	};
	
	self.getComponentObject = function(compName) {
		var boltObj = new Object();
		$.each(addedSpoutsObj, function(key, obj) {
			if ( obj.name == compName )
				boltObj = obj;
		});
		
		if ( $.isEmptyObject(boltObj) ) {
			$.each(addedBoltsObj, function(key, obj) {
				if ( obj.name == compName )
					boltObj = obj;
			});
		}
		
		return boltObj;
	};
	
	self.resetStreamId = function(comp, compName, streamId, oldStreamId) {
		var boltObj = self.getComponentObject(compName);
		if ( !$.isEmptyObject(boltObj) ) {
			var emitStreamIds = boltObj.emitStreamIds;
			var groupings = boltObj.groupings;
			var sortStreamId = (streamId.length > 18) ? (streamId.substr(0, 15)+'...') : streamId;
			var conn = jsPlumb.getConnections();
			for ( var i=0; i<groupings.length; i++ ) {
				if ( comp.name == groupings[i].componentId && groupings[i].streamId == oldStreamId ) {
					groupings[i].streamId = streamId;
					
					for ( var c=0; c<conn.length; c++ ) {
						var sourceId = ( addedSpoutsObj[conn[c].sourceId] ) ? addedSpoutsObj[conn[c].sourceId].name : addedBoltsObj[conn[c].sourceId].name;
						var targetId = addedBoltsObj[conn[c].targetId].name;
						if ( sourceId == comp.name && targetId == compName ) {
							conn[c].removeOverlay( conn[c].targetId+'StrId' );
							conn[c].addOverlay( [ "Custom", { create:function(component) { return $('<div><span title="'+ streamId +'">'+sortStreamId+'</span></div>'); }, id: (conn[c].targetId+'StrId'), location: 0.5, cssClass:"str-label" } ] );
						}
					}
				}
			}
			
			for ( var i=0; i<comp.emitStreamIds.length; i++ ) {
				if ( comp.emitStreamIds[i].componentId == compName && comp.emitStreamIds[i].emitStreamId == oldStreamId ) {
					comp.emitStreamIds[i].emitStreamId = streamId;
				}
			}
			
			for ( var i=0; i<emitStreamIds.length; i++ ) {
				if ( emitStreamIds[i].emitStreamId == oldStreamId ) {
					emitStreamIds[i].emitStreamId = streamId;
					self.resetStreamId(boltObj, emitStreamIds[i].componentId, streamId, oldStreamId);
				}
			}
		}
	};
	
	self.resetFiltersOnMsgChange = function(component, messageTypes) {
		for ( var i=0; i<component.emitStreamIds.length; i++ ) {
			var filterCriteria = component.emitStreamIds[i].filterCriteria;
			var newFilterCriteria = [];
			for ( var j=0; j<filterCriteria.length; j++ ) {
				if ( jQuery.inArray(filterCriteria[j].message, messageTypes) > -1 ) {
					newFilterCriteria.push( filterCriteria[j] );
				}
			}
			
			filterCriteria = newFilterCriteria;
			component.emitStreamIds[i].filterCriteria = filterCriteria;
			
			if ( filterCriteria.length == 0 ) {
				component.emitStreamIds[i].applyFilter = false;
				
				var conn = jsPlumb.getConnections();
				for ( var c=0; c<conn.length; c++ ) {
					if ( conn[c].targetId == component.emitStreamIds[i].componentId )
						conn[c].removeOverlay( conn[c].targetId+'Filter' );
				}
			}
			
			var obj = self.getComponentObj( 'bolts', component.emitStreamIds[i].componentId );
			if ( obj ) {
				self.resetFiltersOnMsgChange(obj, messageTypes);
			}
		}
	};
	
	self.validateDataFabric = function() {
		var spoutsCount = 0, childsObj = [], mappedArr = [];
		$.each(addedSpoutsObj, function(k, o) {
			spoutsCount++;
			childsObj.push( self.getChildBolts(o, []) );
		});
		
		if ( spoutsCount > 1 ) {
			for ( var i=0; i<childsObj.length; i++ ) {
				mappedArr[i] = [];
				for ( var j=0; j<childsObj.length; j++ ) {
					if ( i != j ) {
						var c, t, a=childsObj[i], b=childsObj[j];
						if (b.length > a.length) t = b, b = a, a = t; // indexOf to loop over shorter
						var c = a.filter(function(e) {
							if (b.indexOf(e) !== -1) return true;
						});
					
						mappedArr[i] = mappedArr[i].concat(c);
					}
				}
			}
		
			mappedArr = mappedArr.filter(function(e) {
				if ( e.length > 0 ) return true;
			});

			if ( spoutsCount == mappedArr.length )
				return true;
			else
				return false;
		} else {
			return true;
		}
	};
	
	// SET MessageType of Chlld Bolts
	self.setMessageTypes = function() {
		$.each(addedBoltsObj, function(k, obj) {
			var messageTypes = [];
			rootSpouts = [];
			getRootSpouts(obj);
			for ( var i=0; i<rootSpouts.length; i++ ) {
				messageTypes = $.merge(messageTypes, addedSpoutsObj[rootSpouts[i]].messageTypes);
				messageTypes = self.unique(messageTypes);
			}
			obj.messageTypes = messageTypes;
			
			if ( obj.id == cmpIDs.aggregationfunction ) {
				if ( obj.query && $.inArray(obj.query.message, messageTypes) == -1 )
					delete obj.query;
			}
			
			if ( obj.id == cmpIDs.filterprocessor ) {
				var filterQuery = obj.config[0].replace('filterQuery:', '');
				filterQuery = JSON.parse(filterQuery);
				if ( !$.isEmptyObject(filterQuery) ) {
					filterQuery.rules = $.grep(filterQuery.rules, function(obj) {
						return $.inArray(obj.message, messageTypes) > -1;
					});
					
					obj.config = ( filterQuery.rules.length == 0 ) ? ['filterQuery:{}'] : ['filterQuery:'+ JSON.stringify(filterQuery)];
				}
			}
		});
	};
	
	// GET CHILD NODES
	self.getChildBolts = function(o, arr) {
		for ( var i=0; i<o.emitStreamIds.length; i++ ) {
			//o.emitStreamIds[i].componentId = o.emitStreamIds[i].componentId.replace(esperHACloneId, "");
			if ( jQuery.inArray(o.emitStreamIds[i].componentId, arr) == -1 ) {
				arr.push( o.emitStreamIds[i].componentId );
				var obj = self.getComponentObj( 'bolts', o.emitStreamIds[i].componentId );

				if ( obj ) self.getChildBolts( obj, arr );

			}
		}
		
		return arr;
	};
	
	self.getComponentObj = function(type, id) {
		var objInstance, obj;
		if ( type == 'bolts' ) {
			objInstance = addedBoltsObj;
		} else {
			objInstance = addedSpoutsObj;
		}
		
		if ( objInstance[id] ) {
			obj = objInstance[id];
		} else {
			$.each(objInstance, function(k, o) {
				if ( o.name == id )
					obj = o;
			});
		}

		return obj;
	};
	
	self.scrollLeftWindow = function(elem) {
		var elemPos = $(elem).position().left + $(elem).width();
		var ssCanvasWrap = $('#topologyGraphWrap');
		var diff = elemPos - ssCanvasWrap.width() + 50;
		diff = ( diff < 0 ) ? 0 : diff;
		ssCanvasWrap.scrollLeft(diff);
	};
	
	self.createFVAutoSuggestData = function(messageTypes) {
		var selMessages = [];
		
		if ( messageTypes && messageTypes.length > 0 ) {
			selMessages = messageTypes;
		} else {
			$.each(allMessagesData, function(msg, fields) {
				selMessages.push(msg);
			});
		}
		
		fvAutoSuggestData = {
			"@": {
				"data": []
			},
			"$": {
				"data": []
			}
		};
		
		var addedScopes = {};
		for ( var i=0; i<variablesData.length; i++ ) {
			if ( variablesData[i].scope != 'Pipeline' ) {
				if ( typeof addedScopes[variablesData[i].scope] === 'undefined' ) {
					addedScopes[variablesData[i].scope] = fvAutoSuggestData["@"].data.length;
					fvAutoSuggestData["@"].data.push({
						value: variablesData[i].scope,
						signature: '{'+ variablesData[i].scope +'}',
						data: []
					});
				}
				
				var idx = addedScopes[variablesData[i].scope];
				fvAutoSuggestData["@"].data[idx].data.push({
					value: variablesData[i].name,
					signature: variablesData[i].name
				});
			} else if ( variablesData[i].scope == 'Pipeline' && variablesData[i].topology == ssId ) {
				if ( typeof addedScopes[variablesData[i].scope] === 'undefined' ) {
					addedScopes[variablesData[i].scope] = fvAutoSuggestData["@"].data.length;
					fvAutoSuggestData["@"].data.push({
						value: variablesData[i].scope,
						signature: '{'+ variablesData[i].scope +'}',
						data: []
					});
				}
				
				var idx = addedScopes[variablesData[i].scope];
				fvAutoSuggestData["@"].data[idx].data.push({
					value: variablesData[i].name,
					signature: variablesData[i].name
				});
			}
		}
		
		$.each(allMessagesData, function(msg, fields) {
			if ( $.inArray(msg, selMessages) > -1 ) {
				var fieldsArr = [];
				for ( var i=0; i<fields.length; i++ ) {
					fieldsArr.push({
						value: fields[i].fieldName,
						signature: fields[i].fieldName,
						data: []
					});
				}
				
				fvAutoSuggestData["@"].data.push({
					value: msg,
					signature: '{'+ msg +'}',
					data: fieldsArr
				});
			}
		});
		
		for ( var i=0; i<functionsData.length; i++ ) {
			fvAutoSuggestData["$"].data.push({
				value: functionsData[i].functionName,
				signature: functionsData[i].functionName + '('+ functionsData[i].argsNames +')'
			});
		}
		
	};
	
	// Error Handling Configuration Functionality
	self.createErrorHandlerConfig = function(uiid) {
		$('#errHndlrLoader').show();
		$('#errorHndlrConnectChannels, #errorHndlrConnectBolts').empty();
		$.each(addedSpoutsObj, function(key, obj) {
			if ( obj.id != cmpIDs.replaychannel && obj.id != cmpIDs.kafkachannel && obj.id != cmpIDs.rabbitmqchannel && obj.id != cmpIDs.activemqchannel ) {
				$('#errorHndlrConnectChannels').append('<option value="'+ obj.name +'">'+ obj.label +'</option>');
			} else if ( obj.id == cmpIDs.kafkachannel || obj.id == cmpIDs.rabbitmqchannel || obj.id == cmpIDs.activemqchannel )
			{
				$('#errorHndlrConnectChannels').append('<option value="'+ obj.name +'">'+ obj.label +'</option>');
			}
		});
		
		$.each(addedBoltsObj, function(key, obj) {
			if ( obj.id != cmpIDs.kafkaemitter && obj.id != cmpIDs.rabbitmqemitter && obj.id != cmpIDs.activemqemitter )
			$('#errorHndlrConnectBolts').append('<option value="'+ obj.name +'">'+ obj.label +'</option>');
			else
				$('#errorHndlrConnectBolts').append('<option value="'+ obj.name +'">'+ obj.label +'</option>');
		});
		
		var connOpts = '';
		var compType = (uiid == 'rabbitmq-emitter') ? 'rabbitmq' : 'activemq';
		var connUrl = baseUrl+'/connections/'+compType+'/connection/list';
		var connList = self.getAjaxData(connUrl);
		for ( var c=0; c<connList.length; c++ ) {
			connOpts += '<option value="'+ connList[c].connectionName +'">'+ connList[c].connectionName +'</option>';
		}
		
		$("#errHndlrConnSel").html(connOpts);
		setTimeout(function() {
			$('#errHndlrLoader').hide();
			$("select").select2({placeholder: i18N['sax.placeholder.pleaseSelect']});
			$('#errHndlrConnSel').on('change', function() {
				var selConn = $(this).val();
				for ( var c=0; c<connList.length; c++ ) {
					if ( selConn == connList[c].connectionName ) {
						$('#errHndlrConnObj').val( JSON.stringify(connList[c]) );
					}
				}
			});
			
			$("#errHndlrConnSel").trigger("change");
			
			if ( !$.isEmptyObject(deadLaterChannel) ) {
				$('#errorHndlrConnectChannels').val(deadLaterChannel.connectedChannels).trigger('change');
				$('#errorHndlrConnectBolts').val(deadLaterChannel.connectedBolts).trigger('change');
				$('select#errHndlrConnSel').val(deadLaterChannel.connectionName).trigger('change');
			} else {
				$('#errorHndlrConnectChannels').find('option').prop('selected', true).end().trigger('change');
				$('#errorHndlrConnectBolts').find('option').prop('selected', true).end().trigger('change');
			}
		}, 300);
	};
	
	// Error Handler
	self.checkErrorHandlerEnable = function() {
		var errorConfig = [];
		var enableErrHndlr = $('#errorHandlerFld').prop('checked');
		
		$.each(addedSpoutsObj, function(key, obj) {
			obj.emitStreamIds = $.grep(obj.emitStreamIds, function(o) {
				return o.componentId != errHndlrName;
			});
			
			obj.emitStreamIds.push({
				"emitStreamId": errorStream, 
				"outputFields": ["tracemessage", "streamIds"], 
				"applyFilter": false, 
				"filterCriteria": [], 
				"componentId": errHndlrName
			});
			
			if ( obj.id == cmpIDs.replaychannel ) {
				for ( var i=0; i<obj.config.length; i++ ) {
					var cLen = obj.config[i].length;
					var cIdx = obj.config[i].indexOf(":");
					var cKey = obj.config[i].substring(0, cIdx);
					var cVal = obj.config[i].substring(cIdx+1, cLen).trim();
					
					if ( cKey == 'x-message-ttl' ) {
						var pipelineName = $("#subSystemName").val();
						errorConfig.push('x-dead-letter-exchange:'+pipelineName+'_replay');
						errorConfig.push('x-dead-letter-routing-key:'+pipelineName+'_replay');
						errorConfig.push('x-message-ttl:'+cVal);
					}
				}
			}
			
			obj.errorConfig = $.extend([], errorConfig);
		});
		
		$.each(addedBoltsObj, function(key, obj) {
			obj.errorConfig = $.extend([], errorConfig);;
			obj.emitStreamIds = $.grep(obj.emitStreamIds, function(o) {
				return o.componentId != errHndlrName;
			});
			
			obj.emitStreamIds.push({
				"emitStreamId": errorStream, 
				"outputFields": ["tracemessage", "streamIds"], 
				"applyFilter": false, 
				"filterCriteria": [], 
				"componentId": errHndlrName
			});
		});
			
		if ( enableErrHndlr ) {
			var errHndlrConnObj = $('#errHndlrConnObj').val();
			errHndlrConnObj = JSON.parse(errHndlrConnObj);
			var errHndlrConnJSON = JSON.parse(errHndlrConnObj.connectionJson);
			var connArr = [];
			connArr.push('connectionName:'+errHndlrConnObj.connectionName);
			connArr.push('connectionId:'+errHndlrConnObj.connectionId);
			connArr.push('componentType:'+errHndlrConnObj.componentType);
			connArr.push('isErrorHandlingRequired:true');
			
			$.each(errHndlrConnJSON, function(key, val) {
				connArr.push(key+':'+val);
			});
			
			var connectChannels = $('#errorHndlrConnectChannels').val();
			if ( connectChannels != null ) {
				for ( var i=0; i<connectChannels.length; i++ ) {
					var connectToComp = self.getComponentObject(connectChannels[i]);
					connectToComp['errorConfig'] = $.merge($.extend([], errorConfig), connArr);
				}
			}
			
			$.each(addedSpoutsObj, function(key, obj) {
				if ( obj.id == cmpIDs.replaychannel ) {
					obj['errorConfig'] = $.merge($.extend([], errorConfig), connArr);
				}
			});
			
			var connectBolts = $('#errorHndlrConnectBolts').val();
			if ( connectBolts != null ) {
				for ( var i=0; i<connectBolts.length; i++ ) {
					var connectToComp = self.getComponentObject(connectBolts[i]);
					connectToComp['errorConfig'] = $.merge($.extend([], errorConfig), connArr);
				}
			}
		}
	};
	
	self.init();
};

// esperHA Processor Functionality
var esperHABolt = new function() {
	var self = this;
	
	self.init = function() {
		
	};
	
	self.isEsperHABoltAdded = function() {
		var hasEsperHABolt = false;
		$.each(addedBoltsObj, function(key, obj) {
			if ( obj.id == cmpIDs.cepcustom || obj.id == cmpIDs.aggregationfunction || obj.id == cmpIDs.dynamiccepprocessor ) {
				hasEsperHABolt = true;
			}
		});
		
		if ( esperHAEnable && hasEsperHABolt ) {
			$('#esperHAFldWrap').show();
		} else if (esperHAEnable) {
			$('#esperHAFldWrap').hide();
			$('#esperHAFld').prop('checked', false);
			$('#workerCount').attr('data-parsley-min', '1');
		}
	};
	
	self.insertEsperHAEntries = function(ssJSON, comp, isCheckedEsperHA) {
		if ( esperHAEnable && isCheckedEsperHA ) {
			if ( comp.id == cmpIDs.cepcustom || comp.id == cmpIDs.aggregationfunction || comp.id == cmpIDs.dynamiccepprocessor ) {
				var cloneEsperHA = jQuery.extend({}, comp);
				cloneEsperHA.name += esperHACloneId;
				ssJSON.bolts.push( cloneEsperHA );
				
				// Inserting Grouping entry
				if ( cloneEsperHA.emitStreamIds && cloneEsperHA.emitStreamIds.length > 0 ) {
					for ( var i=0; i<cloneEsperHA.emitStreamIds.length; i++ ) {
						var compId = cloneEsperHA.emitStreamIds[i].componentId;
						var trgComp = addedBoltsObj[compId];
						if ( trgComp ) {
							var cloneGroupings = jQuery.extend([], trgComp.groupings);
							for ( var j=0; j<cloneGroupings.length; j++ ) {
								var cloneEsperHAName = cloneEsperHA.name.replace(esperHACloneId, '');
								if ( cloneGroupings[j].componentId == cloneEsperHAName ) {
									var cloneGroup = jQuery.extend({}, cloneGroupings[j]);
									cloneGroup.componentId = cloneEsperHA.name;
									trgComp.groupings.splice(j+1, 0, cloneGroup);
								}
							}
						}
					}
				}
				
				// Inserting EmitStreamIds entry
				if ( cloneEsperHA.groupings && cloneEsperHA.groupings.length > 0 ) {
					for ( var i=0; i<cloneEsperHA.groupings.length; i++ ) {
						var compId = cloneEsperHA.groupings[i].componentId;
						var srcComp = ( addedSpoutsObj[compId] ) ? addedSpoutsObj[compId] : addedBoltsObj[compId];
						if ( srcComp ) {
							var cloneEmitStreamIds = jQuery.extend([], srcComp.emitStreamIds);
						
							for ( var j=0; j<cloneEmitStreamIds.length; j++ ) {
								var errStrName = errorStream;
								var cloneEsperHAName = cloneEsperHA.name.replace(esperHACloneId, '');
								if ( cloneEmitStreamIds[j].emitStreamId != errStrName && cloneEmitStreamIds[j].componentId == cloneEsperHAName ) {
									var cloneEmitStreamId = jQuery.extend({}, cloneEmitStreamIds[j]);
									cloneEmitStreamId.componentId = cloneEsperHA.name;
									srcComp.emitStreamIds.splice(j+1, 0, cloneEmitStreamId);
								}
							}
						}
					}
				}
			}
		}
	};
	
	self.removeEsperHAEntries = function(ssData) {
		var spoutsArr = ssData.spouts;
		var boltsArr = ssData.bolts;
		
		ssData.bolts = $.grep(ssData.bolts, function(o) {
			return o.name.indexOf(esperHACloneId) == -1;
		});
		
		for ( var i=0; i<spoutsArr.length; i++ ) {
			spoutsArr[i].emitStreamIds = $.grep(spoutsArr[i].emitStreamIds, function(o) {
				return o.componentId.indexOf(esperHACloneId) == -1;
			});
		}
		
		for ( var i=0; i<boltsArr.length; i++ ) {
			// Removing from emitStreamIds
			boltsArr[i].emitStreamIds = $.grep(boltsArr[i].emitStreamIds, function(o) {
				return o.componentId.indexOf(esperHACloneId) == -1;
			});
			
			// Removing from groupings
			boltsArr[i].groupings = $.grep(boltsArr[i].groupings, function(o) {
				return o.componentId.indexOf(esperHACloneId) == -1;
			});
		}
		
		return ssData;
	};
	
	self.init();
};

// HDFS Processor Functionality
var HDFSBolt = new function() {
	var self = this, HDFSPathProperties = {}, rotationActionsOpt = '';
	var curHDFSObj = {};
	
	self.init = function() {
		
		$(document).on('click', '#addHDFSPath', function() {
			var panelSize = $('#hdfsPathsWrap > .panel.panel-default').size();
			self.createHFDSPathTemplate(HDFSPathProperties, panelSize);
			$('#hdfsPathsWrap a.remove-hdfs-path').show();
			$('#hdfsPathsWrap > .panel.panel-default:last .path-title').trigger('click');
		});
		
		$(document).on('click', 'a.remove-hdfs-path', function() {
			$(this).closest('.panel').remove();
			var pathSize = $('#hdfsPathsWrap > .panel').size();
			if ( pathSize == 1 )
				$('#hdfsPathsWrap > .panel:first a.remove-hdfs-path').hide();
		});
		
		$(document).on('change', 'select.rotationPolicy-fld', function() {
			var rotationPolicy = $(this).val();
			$(this).closest('.hdfsRotationPolicyIDWrap').siblings('.hdfsFileRotationTimeIDWrap').show();
			$(this).closest('.hdfsRotationPolicyIDWrap').siblings('.hdfsFileRotationSizeIDWrap').show();
			
			if ( rotationPolicy == 'SizeBased' ) {
				$(this).closest('.hdfsRotationPolicyIDWrap').siblings('.hdfsFileRotationTimeIDWrap').hide();
			} else if ( rotationPolicy == 'TimeBased' ) {
				$(this).closest('.hdfsRotationPolicyIDWrap').siblings('.hdfsFileRotationSizeIDWrap').hide();
			}
		});
		
		$(document).on("click", ".select-all-fields", function(e) {
			var isChecked = $(this).prop('checked');
			if ( isChecked ) {
				$(this).closest('.row').find('select').find('option').prop('selected', true).end().trigger('change');
			} else {
				$(this).closest('.row').find('select').find('option').prop('selected', false).end().trigger('change');
			}
		});
		
		$(document).on('change', 'select.dd-config-value-hdfs-fields', function(){
			var hdfsFieldsArr = $(this).val();
			hdfsFieldsArr = (hdfsFieldsArr == null) ? [] : hdfsFieldsArr;
			var hdfsFields = DFSubSytemDefination.getUnionFields(curChannelObj.messageTypes);
			if ( hdfsFieldsArr.length > 0 ) {
				if ( hdfsFieldsArr.length != hdfsFields.length ) {
					$('.select-all-fields').removeAttr('checked');
				} else {
					$('.select-all-fields').attr('checked', true);
				}
			}
		});
		
		$(document).on("blur", ".hdfsPath-fld", function(e) {
			e.preventDefault();
			var path = $(this).val();
			if ( path != '' ) {
				$(this).closest('.panel').find('a.path-title').text(i18N['sax.label.hdfsPath'] + " : " + path);
			} else {
				$(this).closest('.panel').find('a.path-title').text( i18N['sax.label.hdfsPath'] );
			}
		});
		
		/*$(document).on("click", ".path-title", function(e) {
			e.preventDefault();
			$('#hdfsPathsWrap > .panel .panel-collapse').removeClass('in');
		});*/
		
		$(document).on("click", ".add-hdfs-action", function(e) {
			e.preventDefault();
			var pathSize = $(this).closest('.rotation-actions-wrap').find(".r-action-row").size();
			
			if ( pathSize == 0 ) {
				$(this).closest('.rotation-actions-wrap').append('<div class="r-action-row panel panel-default">' +
					'<div class="panel-body">' +
						'<a class="remove-ico tt pull-right remove-hdfs-action" href="javascript: void(0)" title="'+ i18N['sax.label.removeAction'] +'"> <i class="fa fa-times"></i></a>' +
						'<div class="form-group">' +
							'<div class="col-sm-3 control-label">'+ i18N['sax.label.rotationAction'] +'</div>' +
							'<div class="col-sm-4"><select data-parsley-required="true" class="r-action-fld min-w-120">'+ rotationActionsOpt +'</select></div>' +
						'</div>' +
						'<div class="hdfs-action-wrap"></div>' +
					'</div>' +
				'</div>');
				
				$(this).closest('.rotation-actions-wrap').find('select.r-action-fld').select2('destroy').select2();
				$(this).closest('.rotation-actions-wrap').find('select.r-action-fld:last').trigger('change');
				$(this).addClass('disabled');
			}
		});
		
		$(document).on("change", "select.r-action-fld", function(e) {
			var actionParams = '';
			var action = $(this).val();
			$(this).closest('.panel-body').find('.hdfs-action-wrap').empty();
			$.each(HDFSPathProperties.rotationActionTemplates, function(k, actionObj) {
				if ( k == action ) {
					$.each(actionObj, function(param, value) {
						var validPattern = '';
						
						if ( param == 'location' )
							validPattern = 'data-parsley-pattern="^/([A-Za-z0-9_-]+[/]?)*$" data-parsley-pattern-message="'+i18N['sax.label.InvalidPathPattern']+'"';
						else if ( param == 'locations' )
							validPattern = 'data-parsley-pattern="^(/([A-Za-z0-9_-]+[/]?)*)+(,{1}/([A-Za-z0-9_-]+[/]?)*)*$" data-parsley-pattern-message="'+i18N['sax.label.InvalidPathPattern']+'"';
						else if ( param == 'metastoreUrl' )
							validPattern = 'data-parsley-pattern="^[a-zA-Z]+(:\/\/)+(((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))|([A-Za-z0-9]+((\.?[A-Za-z0-9])|(\-?[A-Za-z0-9]))*[A-Za-z0-9]+))+([:][0-9]{1,5})$" data-parsley-pattern-message="'+ i18N['sax.label.parsley.pattern'] +'"';
						else if ( param == 'databaseName' || param == 'tableName' )
							validPattern = 'data-parsley-pattern="^[a-zA-Z0-9]+$" data-parsley-pattern-message="'+ i18N['sax.label.parsley.alphanum'] +'"';
						
						actionParams += '<div class="form-group"><div class="col-sm-3 control-label">'+ param +'</div>' +
										'<div class="col-sm-4"><input type="text" class="form-control action-param-val" value="'+ value +'" data-key="'+ param +'" placeholder="'+ i18N['sax.placeholder.pleaseEnterValue'] +'" data-parsley-required="true" '+ validPattern +'></div></div>';
					});
				}
			});
			
			$(this).closest('.panel-body').find('.hdfs-action-wrap').html(actionParams);
		});
		
		$(document).on("click", ".remove-hdfs-action", function(e) {
			e.preventDefault();
			$(this).closest('.rotation-actions-wrap').find('a.add-hdfs-action').removeClass('disabled');
			$(this).closest('.r-action-row').remove();
		});
		
		$(document).on("click", ".remove-hdfs-field", function(e) {
			e.preventDefault();
			var keyInput = $('.hdfs-field-row:first').find('input.config-key');
			$(this).closest('.hdfs-field-row').remove();
			$('.hdfs-field-row:first .col-sm-6:first').html(keyInput);
			$('.hdfs-field-row:first, .hdfs-field-row:first .col-md-12').removeClass('margin-tm');
			var rowCount = $('.hdfs-field-row').size();
			if ( rowCount == 1 ) $(".remove-hdfs-field").hide();
			else $(".remove-hdfs-field").show();
		});
	};
	
	self.initHDFSFPaths = function(curChnl, configVal) {
		rotationActionsOpt = '';
		curHDFSObj = curChnl;
		
		setTimeout(function() {
			$('#persisterConfigTab1').append('<div id="hdfsPathsTab" class="margin-t"> <a href="javascript: void(0)" id="addHDFSPath" class="add-ico tt pull-left margin-bm"> <i class="fa fa-plus"></i> '+ i18N['sax.label.addNewPath'] +'</a> <div class="clearfix"> </div> <div id="hdfsPathsWrap" class="panel-group" role="tablist" aria-multiselectable="true"> </div> </div>');
			self.getHDFSPathProperties();
			self.createHDFSFieldPathPanel(configVal);
		}, 300);
	};
	
	self.getHDFSPathProperties = function() {
		for ( var m=0; m<allChannelsData.emitters.length; m++ ) {
			if ( allChannelsData.emitters[m].id == cmpIDs.hdfsemitter ) {
				var c = allChannelsData.emitters[m].config;
				for ( var n=0; n<c.length; n++ ) {
					var cLen = c[n].length;
					var cIdx = c[n].indexOf(":");
					var cKey = c[n].substring(0, cIdx);
					if ( cKey == 'hdfsPaths' ) {
						var cVal = c[n].substring(cIdx+1, cLen);
						HDFSPathProperties = JSON.parse(cVal)[0];
					}
				}
			}
		}
		
		$.each(HDFSPathProperties.rotationActionTemplates, function(k, o) {
			rotationActionsOpt += '<option value="'+ k +'">'+ k +'</option>';
		});
	};
	
	self.createHDFSPathOptions = function(key, vals) {
		var cOpts='';
		if ( !$.isEmptyObject(HDFSPathProperties) ) {
			var pVals = HDFSPathProperties[key];
			if ( !jQuery.isArray(HDFSPathProperties[key]) )
				pVals = HDFSPathProperties[key].split('^^^');
			
			if ( !jQuery.isArray(vals) ) {
				vals = [vals];
			}
					
			for ( var p=0; p<pVals.length; p++ ) {
				if ( pVals[p] == '\t' ) {
					pVals[p] = '\\t';
				}
				pVals[p] = $.trim(pVals[p]);
				var selected = ( $.inArray(pVals[p], vals) > -1 ) ? 'selected' : '';
				cOpts += '<option value="'+ pVals[p] +'" '+ selected +'>'+ pVals[p] +'</option>';
			}
		}
		
		return cOpts;
	};
	
	self.createHFDSPathTemplate = function (hdfsPathMap, index) { 
		var pathId = 'hdfsPath' + createRandomNumber();
		var pathTitle = (hdfsPathMap.hdfsPath == "") ? i18N['sax.label.hdfsPath'] : i18N['sax.label.hdfsPath'] + " : " + hdfsPathMap.hdfsPath;
		var htmlStr = '', hdfsProperties = '';
		var cls = (index == 0) ? 'in' : '';
		
		$.each(hdfsPathMap, function(key, val) {
			if ( key == 'rotationActions' ) {
				hdfsProperties += self.createRotationActions(val);
			} else if ( componentsProperties[curHDFSObj.id][key] ) {
				if ( componentsProperties[curHDFSObj.id][key].type == 'select' ) {
					var options = '';
					
					if ( key == 'fields' ) {
						var fldsOpts = [];
						var hdfsFields = DFSubSytemDefination.getUnionFields(curHDFSObj.messageTypes);
						for ( var k = 0; k<hdfsFields.length; k++ ) {
							var selected = '';
							if ( $.inArray(hdfsFields[k].fieldName, val) > -1 ) {
								fldsOpts.push(hdfsFields[k].fieldName);
								selected = 'selected';
							}
							
							options += '<option value="'+ hdfsFields[k].fieldName +'" '+ selected +'>'+ hdfsFields[k].fieldLabel +'</option>';
						}
						val = fldsOpts.join(',');
					} else {
						if ( val.indexOf('^^^') > -1 )
							val = val.split('^^^')[0];
						
						options = self.createHDFSPathOptions(key, val);
					}
					
					hdfsProperties += componentsProperties.funcCreateSelectField(key, val, options, componentsProperties[curHDFSObj.id][key]);
					hdfsProperties += '<a href="javascript:void(0)" tabindex="-1" class="po infoico propico" title="'+ key +'" content="'+ curHDFSObj.id +'_'+ key +'"><i class="fa fa-info-circle"></i></a></div>';
				}
				
				if ( componentsProperties[curHDFSObj.id][key].type == 'checkbox' ) {
					var lbl = ( key == 'controlFile' ) ? i18N['sax.label.enableControlFile'] : key;
					val = val.toString();
					hdfsProperties += componentsProperties.funcCreateCBWithLabel(key, val, componentsProperties[curHDFSObj.id][key], lbl);
					hdfsProperties += '<a href="javascript:void(0)" tabindex="-1" class="po infoico propico" title="'+ key +'" content="'+ curHDFSObj.id +'_'+ key +'"><i class="fa fa-info-circle"></i></a></div>';
				}
				
				if ( componentsProperties[curHDFSObj.id][key].type == 'text' ) {
					hdfsProperties += componentsProperties.funcCreateTextField(key, val, componentsProperties[curHDFSObj.id][key], curHDFSObj);
					hdfsProperties += '<a href="javascript:void(0)" tabindex="-1" class="po infoico propico" title="'+ key +'" content="'+ curHDFSObj.id +'_'+ key +'"><i class="fa fa-info-circle"></i></a></div>';
				}
			}
		});
		
		htmlStr += '<div class="panel panel-default panel-hdfs">' +
						'<div role="tab" class="panel-heading">' +
							'<h4 class="panel-title">' +
								'<a class="path-title" aria-controls="'+ pathId +'" aria-expanded="true" href="#'+ pathId +'" data-parent="#hdfsPathsWrap" data-toggle="collapse" role="button">' +
									pathTitle +
								'</a>' +
								'<a class="remove-ico tt pull-right remove-hdfs-path" href="javascript: void(0)" title="'+ i18N['sax.label.removePath'] +'"> <i class="fa fa-times"></i></a>' +
							'</h4>' +
						'</div>' +
						'<div aria-labelledby="" role="tabpanel" class="panel-collapse collapse panel-hdfs-collapse '+ cls +'" id="'+ pathId +'">' +
							'<div class="panel-body">' +
								'<div class="col-md-11">' +
									hdfsProperties +
								'</div>' +
							'</div>' +
						'</div>' +
					'</div>';
		
		$('#hdfsPathsWrap').append(htmlStr);
		$('#hdfsPathsWrap select').select2('destroy').select2({ placeholder: i18N['sax.placeholder.pleaseSelect'] });
		
		
		setTimeout(function() {
			var pathSize = $('#hdfsPathsWrap > .panel').size();
			if ( pathSize == 1 )
				$('#hdfsPathsWrap > .panel:first a.remove-hdfs-path').hide();
			
			
			var $panel = $('#hdfsPathsWrap > .panel').eq(index);
			$panel.find('select').trigger('change');
			$('.tt').tooltip();
			
			var idx = 0;
			$.each(hdfsPathMap.rotationActions, function(action, paramObj) {
				$panel.find('.r-action-row').eq(idx).find('select.r-action-fld').val(action).trigger('change');
				$.each(paramObj, function(param, value) {
					$panel.find('.r-action-row').eq(idx).find('input.action-param-val[data-key="'+ param +'"]').val(value);
				});
				idx++;
			});
			
			DFSubSytemDefination.initPopovers();
		}, 500);
	};
	
	self.createHDFSFieldPathPanel = function(configVal) {
		var data = JSON.parse(configVal);
		
		for ( var i=0; i<data.length; i++ ) {
			self.createHFDSPathTemplate(data[i], i);
		}
	};
	
	self.createHDFSPathObj = function() {
		var hdfsPaths = [];
		
		$('#hdfsPathsWrap > .panel').each(function(i, panel) {
			var pathObj = {};
			$(panel).find('div.config-row').each(function(j, row) {
				var key, val;
				key = $(row).find('.config-key').val();
				
				if ( componentsProperties[curHDFSObj.id][key].type == 'select' ) {
					val = $(row).find('select.config-value').val();
				} else if ( componentsProperties[curHDFSObj.id][key].type == 'checkbox' ) {
					val = $(row).find('.config-value').prop('checked');
				} else {
					val = $(row).find('.config-value').val();
				}
				
				pathObj[key] = val;
			});
			
			pathObj['rotationActions'] = {};
			$(panel).find('div.r-action-row').each(function(j, row) {
				var action = $(row).find('select.r-action-fld').val();
				pathObj['rotationActions'][action] = {};
				
				$(row).find('input.action-param-val').each(function(k, param) {
					var paramName = $(this).data('key');
					var paramVal = $(this).val();
					pathObj['rotationActions'][action][paramName] = paramVal;
				});
				
			});
			
			hdfsPaths.push(pathObj);
		});
		
		return hdfsPaths;
	};
	
	self.createRotationActions = function(obj) {
		var cls = ( $.isEmptyObject(obj) ) ? '' : 'disabled';
		
		var actionStr = '<div class="rotation-actions-wrap query-panel"><a href="javascript: void(0)" class="add-hdfs-action add-ico tt pull-left margin-t margin-bm '+ cls +'"> <i class="fa fa-plus"></i> '+ i18N['sax.label.addAction'] +'</a> <a content="hdfs-emitter_rotationAction" tabindex="-1" class="po infoico propico" href="javascript:void(0)" title="'+ i18N['sax.label.rotationAction'] +'"><i class="fa fa-info-circle"></i></a> <div class="clearfix"> </div>';
		
		$.each(obj, function(key, val) {
			actionStr += '<div class="r-action-row panel panel-default">' +
				'<div class="panel-body">' +
					'<a class="remove-ico tt pull-right remove-hdfs-action" href="javascript: void(0)" title="'+ i18N['sax.label.removeAction'] +'"> <i class="fa fa-times"></i></a>' +
					'<div class="form-group">' +
						'<div class="col-sm-3 control-label">'+ i18N['sax.label.action'] +'</div>' +
						'<div class="col-sm-4"><select data-parsley-required="true" class="r-action-fld min-w-120">'+ rotationActionsOpt +'</select></div>' +
					'</div>' +
					'<div class="hdfs-action-wrap"></div>' +
				'</div>' +
			'</div>';
		});
		
		actionStr += '</div>';
		
		return actionStr;
	};
	
	self.init();
};

// Dynamic CEP Processor Functionality
var dynamicCEPBolt = new function() {
	var self = this;
	self.cepQueryParamWrap = '<div class="add-param-wrap"> <h4></h4> <div class="form-group"> <div class="col-sm-3 control-label"> '+i18N['sax.label.name']+' <span class="req">*</span> </div> <div class="col-sm-4"> <input type="text" class="param-name form-control" value="" placeholder="'+i18N['sax.placeholder.name']+'" data-parsley-required="true"> </div> </div> <div class="form-group"> <div class="col-sm-3 control-label">'+i18N['sax.label.value']+' <span class="req">*</span> </div> <div class="col-sm-4"> <input type="text" class="param-value form-control" value="" placeholder="'+i18N['sax.placeholder.value']+'" data-parsley-required="true"> </div> </div> <div class="form-group"> <div class="col-sm-3 control-label"></div> <div class="col-sm-4"> <button id="addParamBtn" type="button" class="btn btn-primary">'+i18N['sax.ok']+'</button> <button id="cancelParamBtn" type="button" class="btn btn-default">'+i18N['sax.cancel']+'</button> </div> </div> </div>';
	self.dynamicCEPRMQ = '<div class="form-group"> <div class="col-sm-3 control-label"> '+i18N['sax.label.exchangeName']+' <span class="req">*</span> </div> <div class="col-sm-4"> <input type="text" class="exchangename form-control" value="" placeholder="'+i18N['sax.placeholder.exchangeName']+'" data-parsley-required="true"> </div> <a content="dynamicExchangeName" title="'+i18N['sax.label.exchangeName']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group"> <div class="col-sm-3 control-label"> '+i18N['sax.label.routingKey']+' <span class="req">*</span> </div> <div class="col-sm-4"> <input type="text" class="routingKey form-control" value="" placeholder="'+i18N['sax.placeholder.routingKey']+'" data-parsley-required="true"> </div> <a content="dynamicRoutingKey" title="'+i18N['sax.label.routingKey']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div>';
	self.dynamicCEPWEB = '<div class="form-group"> <div class="col-sm-3 control-label">'+i18N['sax.label.url']+' <span class="req">*</span> </div> <div class="col-sm-4"> <input type="text" class="url form-control" value="" placeholder="'+i18N['sax.placeholder.url']+'" data-parsley-required="true"> </div> <a content="dynamicURL" title="'+i18N['sax.label.url']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group"> <div class="col-sm-3 control-label"> '+i18N['sax.label.method']+' <span class="req">*</span> </div> <div class="col-sm-4"> <select class="method custom-select form-control" data-parsley-required="true"> <option value="">'+i18N['sax.placeholder.pleaseSelect']+'</option> <option value="POST">'+i18N['sax.label.post']+'</option> <option value="PUT">'+i18N['sax.label.put']+'</option> </select> </div> <a content="dynamicMethod" title="'+i18N['sax.label.method'] +'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group"> <div class="col-sm-3 control-label"> '+ i18N['sax.label.headerParams'] +' </div> <div class="col-sm-8"> <ul class="action-param-wrap headerparams"></ul> <a class="add-query-params tt" href="javascript:void(0)" title="'+i18N['sax.label.addHeaderParams']+'" ui-data="headerParam"><i class="fa fa-plus-circle"></i></a> </div> <a content="dynamicHeaderParams" title="'+i18N['sax.label.headerParams']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group"> <div class="col-sm-3 control-label"> '+i18N['sax.label.requesParams']+' </div> <div class="col-sm-8"> <ul class="action-param-wrap requestparams"></ul> <a class="add-query-params tt" href="javascript:void(0)" title="'+i18N['sax.label.addRequestParams']+'" ui-data="requestParam"><i class="fa fa-plus-circle"></i></a> </div> <a content="dynamicRequestParams" title="'+i18N['sax.label.requesParams']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div>';
	self.dynamicCEPDEL = '<div class="form-group"> <div class="col-sm-3 control-label"> '+i18N['sax.label.className']+' <span class="req">*</span> </div> <div class="col-sm-4"> <input type="text" class="delegate form-control" value="" placeholder="'+i18N['sax.placeholder.className']+'" data-parsley-required="true"> </div> <a content="dynamicClassName" title="'+i18N['sax.label.className']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="form-group"> <div class="col-sm-3 control-label"> '+i18N['sax.label.initParams']+' </div> <div class="col-sm-8"> <ul class="action-param-wrap initparams"></ul> <a class="add-query-params tt" href="javascript:void(0)" title="'+i18N['sax.label.addInitParams']+'" ui-data="initParam"><i class="fa fa-plus-circle"></i></a> </div> <a content="dynamicInitParams" title="'+i18N['sax.label.initParams']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div>';
	
	self.initCEPDynamicQueryFunc = function(d, subsystemName) {
		$('#channelProperties ul.nav-tabs a[href="#configTab25"]').trigger('click');
		var queryData = DFSubSytemDefination.getAjaxData(cepQueryGetUrl+'/'+subsystemName+'_'+d.name);
		
		for( var i=0; i<queryData.length; i++ ) {
			var id = 'query-'+ i;
			$('#cepDynamicQueryWrap').append('<div class="panel panel-default query-panel"><input type="hidden" class="queryid" value="'+ queryData[i].cepQueryId +'"> <div class="panel-heading"> <h4 class="panel-title"> <a class="collapsed" data-toggle="collapse" href="#'+ id +'" data-parent="#cepDynamicQueryWrap" > <i class="fa fa-angle-right"></i> '+ queryData[i].cepQuery +' </a> </h4> </div> <div id="'+ id +'" class="panel-collapse collapse"> <div class="panel-body"> <a class="add-query-panel" href="javascript:void(0)"><i class="fa fa-plus-circle"></i> '+i18N['sax.label.addAction']+'</a> <div class="clearfix"></div> </div> </div> </div>');
			
			var $wrap = $("#"+ id +" .panel-body");
			var actionsData = queryData[i].cepAction;
			self.setActionData(actionsData, $wrap);
			
			$wrap.find('.add-query-panel').on("click", function() {
				self.addActoinPanel( $(this).closest('.panel-body') );
				DFSubSytemDefination.initPopovers();
			});
		};
		
		$(document).on('click', '.remove-action-param', function() {
			$(this).closest('.action-param').remove();
		});
	};
	
	self.setActionData = function(actionsData, $wrap) {
		for( var j=0; j<actionsData.length; j++ ) {
			self.addActoinPanel($wrap);
			if ( actionsData[j].actionName == 'PUBLISH_TO_RABBITMQ' ) {
				$wrap.find('.action-panel:last .other-query-info').html(self.dynamicCEPRMQ);
				$wrap.find('.action-panel:last select.queryAction').val('PUBLISH_TO_RABBITMQ').trigger('change');
				$wrap.find('.action-panel:last .other-query-info .exchangename').val( actionsData[j].params.exchangeName );
				$wrap.find('.action-panel:last .other-query-info .routingKey').val( actionsData[j].params.routingKey );
			} else if ( actionsData[j].actionName == 'INVOKE_WEBSERVICE_CALL' ) {
				$wrap.find('.action-panel:last .other-query-info').html(self.dynamicCEPWEB);
				$wrap.find('.action-panel:last select.queryAction').val('INVOKE_WEBSERVICE_CALL').trigger('change');
				$wrap.find('.action-panel:last .other-query-info .url').val( actionsData[j].params.url );
				$wrap.find('.action-panel:last .other-query-info select.method').val( actionsData[j].params.method ).trigger('change');
				$.each(actionsData[j].params.headerParams, function(key, val) {
					$wrap.find('.action-panel:last .other-query-info ul.headerparams').append('<li class="action-param"><a class="remove-action-param" href="javascript:void(0)"><i class="fa fa-times"></i></a></a>'+ key +':'+ val +'</li>');
				});
				$.each(actionsData[j].params.requestParams, function(key, val) {
					$wrap.find('.action-panel:last .other-query-info ul.requestparams').append('<li class="action-param"><a class="remove-action-param" href="javascript:void(0)"><i class="fa fa-times"></i></a></a>'+ key +':'+ val +'</li>');
				});					
			} else if ( actionsData[j].actionName == 'CUSTOM_ACTION' ) {
				$wrap.find('.action-panel:last .other-query-info').html(self.dynamicCEPDEL);
				$wrap.find('.action-panel:last select.queryAction').val('CUSTOM_ACTION').trigger('change');
				$wrap.find('.action-panel:last .other-query-info .delegate').val( actionsData[j].params.className);
				$.each(actionsData[j].params.initParams, function(key, val) {
					$wrap.find('.action-panel:last .other-query-info ul.initparams').append('<li class="action-param"><a class="remove-action-param" href="javascript:void(0)"><i class="fa fa-times"></i></a></a>'+ key +':'+ val +'</li>');
				});	
			}
		}
	};
	
	self.addActoinPanel = function(panelBody) {
		panelBody.append('<div class="col-md-12 action-panel margin-tm"> <a class="remove-query-panel tt" href="javascript:void(0)" title="'+i18N['sax.label.removeAction']+'"><i class="fa fa-times-circle"></i></a> <div class="form-group margin-t"> <div class="col-sm-3 control-label"> '+i18N['sax.label.action'] +' <span class="req">*</span> </div> <div class="col-sm-4"> <select class="custom-select form-control queryAction" name="queryAction" data-parsley-required="true"> <option value="">'+i18N['sax.placeholder.pleaseSelect']+'</option> <option value="PUBLISH_TO_RABBITMQ">'+i18N['sax.label.publishToRmq']+'</option> <option value="INVOKE_WEBSERVICE_CALL">'+i18N['sax.label.invokeWebserviceCall']+'</option> <option value="CUSTOM_ACTION">'+i18N['sax.label.customDelegate']+'</option> </select> </div> <a content="dynamicAction" title="'+i18N['sax.label.action']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> <div class="other-query-info"> </div> </div>');
		
		$(panelBody).find(".action-panel:last select.queryAction").on("change", function() {
			var action = $(this).val();
			$(this).closest(".action-panel").find('.other-query-info').empty();
			
			if ( action == "PUBLISH_TO_RABBITMQ" ) {
				$(this).closest(".action-panel").find('.other-query-info').html(self.dynamicCEPRMQ);
			} else if ( action == "INVOKE_WEBSERVICE_CALL" ) {
				$(this).closest(".action-panel").find('.other-query-info').html(self.dynamicCEPWEB);
			} else if ( action == "CUSTOM_ACTION" ) {
				$(this).closest(".action-panel").find('.other-query-info').html(self.dynamicCEPDEL);
			}
			
			$(this).closest(".action-panel").find(".add-query-params").on("click", function() {
				var elem = $(this);
				var type = elem.attr('ui-data');
				self.addQueryParams(elem, type);
			});
		
			$(this).closest(".action-panel").find(".other-query-info select.custom-select").select2("destroy").select2();
			$('.tt').tooltip();
			DFSubSytemDefination.initPopovers();
		});
		
		$(panelBody).find(".action-panel:last .remove-query-panel").on("click", function() {
			var $this = $(this);
			var panelSize = $this.closest('.query-panel').find('.action-panel').size();
			
			if ( panelSize == 1 ) {
				bootbox.confirm(i18N["sax.notification.removingLastAction"], function(confirmation) {
					if ( confirmation ) {
						$this.closest('.query-panel').hide();
						$this.closest('.action-panel').remove();
					}
				});
			} else {
				$(this).closest('.action-panel').remove();
			}
		});
		
		$(panelBody).find(".action-panel:last .add-query-params").on("click", function() {
			var elem = $(this);
			var type = elem.attr('ui-data');
			self.addQueryParams(elem, type);
		});
		
		$(panelBody).find("select.custom-select").select2("destroy").select2();
		$('.tt').tooltip();
	};
		
	self.addQueryParams = function(elem, type) {
		var title = '';
		if ( type == 'headerParam' ) {
			title = i18N['sax.label.headerParam'];
		} else if ( type == 'requestParam' ) {
			title = i18N['sax.label.requestParam'];
		} else {
			title = i18N['sax.label.initParam'];
		}
		
		elem.closest('.action-panel').append(self.cepQueryParamWrap);
		elem.closest('.action-panel').find('h4').text(title);
		
		elem.closest('.action-panel').find('#cancelParamBtn').on('click', function() {
			$(this).closest('.add-param-wrap').remove();
		});
		
		elem.closest('.action-panel').find('#addParamBtn').on('click', function() {
			var validate=true, flag=true;
			
			$(this).closest('.add-param-wrap').find('input[data-parsley-required="true"]').each(function() {
				flag = $(this).parsley().validate();
				if ( flag != true ) validate = false;
			});
			
			if ( validate ) {
				var name = $(this).closest('.add-param-wrap').find('.param-name').val();
				var value = $(this).closest('.add-param-wrap').find('.param-value').val();
				elem.prev('.action-param-wrap').append('<li class="action-param"><a class="remove-action-param" href="javascript:void(0)"><i class="fa fa-times"></i></a></a>'+ name +':'+ value +'</li>');
				$(this).closest('.add-param-wrap').remove();
			}
		});
		
	};
};

// Statistical CEP Processor Functionality
var statisticalCEPBolt = new function() {
	var self = this;
	
	self.init = function() {
		$(document).on("click", ".groupby-radio", function() {
			self.setQueryGrouping();
		});
		
		$(document).on("click", ".add-query-field", function() {
			var queryFieldsWrap = $(this).closest(".queryFieldsWrap");
			self.createQueryFieldsTmpl(queryFieldsWrap);
		});
		
		$(document).on("click", ".remove-query-field", function() {
			var $panel = $(this).closest('.panel-body');
			var $wrap = $(this).closest(".queryFieldsWrap");
			$(this).closest(".row").remove();
			var rowSize = $wrap.find('.row').size();
			if ( rowSize == 1 ) $wrap.find(".remove-query-field").hide();
			self.updateHavingFilterCriteria($panel);
		});
		
		$(document).on("click", '.add-query-panel', function() {
			$(this).closest('.panel-body').find('.actionDataWrap').show();
			dynamicCEPBolt.addActoinPanel( $(this).closest('.panel-body').find('.actionDataWrap') );
			DFSubSytemDefination.initPopovers();
			self.toggleRemoveActionLink();
		});
		
		$(document).on('click', 'a.remove-query-panel', function() {
			self.toggleRemoveActionLink();
		});
		
		$(document).on('click', '.remove-action-param', function() {
			$(this).closest('.action-param').remove();
		});
		
		$(document).on('click', '#addQueryAccordion', function() {
			var isDisabled = $(this).hasClass('disabled');
			if ( !isDisabled ) {
				self.createQueryPanel();
			}
		});
		
		$(document).on('click', 'a.remove-query-accordion', function() {
			$(this).closest('.panel').remove();
			var accorSize = $('#queryAccordion > .panel').size();
			if ( accorSize == 1 ) {
				$('#queryAccordion .remove-query-accordion').addClass('hidden');
			}
		});
		
		$(document).on('change', '#enableContext', function() {
			var enable = $(this).prop('checked');
			if ( enable ) {
				$('#contextWrap').removeClass('hidden');
				$('#addQueryAccordion').removeClass('disabled');
				$('#contextName, #startTime, #endTime').attr('data-parsley-required', 'true');
			} else {
				$('#contextWrap').addClass('hidden');
				$('#addQueryAccordion').addClass('disabled');
				$('#queryAccordion .panel:not(:first) .remove-query-accordion').trigger('click');
				$('#contextName, #startTime, #endTime').val('').removeAttr('data-parsley-required');
			}
		});
		
		$(document).on('keyup', '#queryAccordion .queryOutput', function() {
			var val = $(this).val().trim();
			if ( val.length > 0 ) {
				$(this).closest('.panel').find('.flushResults').prop('disabled', false);
			} else {
				$(this).closest('.panel').find('.flushResults').prop('checked', false).prop('disabled', true);
			}
		});
		
		$(document).on('change', '#queryAccordion .applyFilterCriteria', function() {
			var enable = $(this).prop('checked');
			if ( enable ) {
				self.initWhereFilterCriteria( $(this).closest('.alertCriteriaWrap') );
				$(this).closest('.alertCriteriaWrap').find('.whereFilterCriteria').removeClass('hidden');
			} else {
				$(this).closest('.alertCriteriaWrap').find('.alertCriteria').empty();
				$(this).closest('.alertCriteriaWrap').find('.whereFilterCriteria').addClass('hidden');
			}
		});
		
		$(document).on('change', '#queryAccordion .applyGroupBy', function() {
			var enable = $(this).prop('checked');
			if ( enable ) {
				$(this).closest('.panel-body').find('.applyGroupByFilterWrap').removeClass('hidden');
			} else {
				$(this).closest('.panel-body').find('.applyGroupByFilter').prop('checked', false).trigger('change');
				$(this).closest('.panel-body').find('.applyGroupByFilterWrap').addClass('hidden');
			}
		});
		
		$(document).on('change', '#queryAccordion .applyGroupByFilter', function() {
			var enable = $(this).prop('checked');
			if ( enable ) {
				self.initHavingFilterCriteria( $(this).closest('.alertCriteriaWrap') );
				$(this).closest('.alertCriteriaWrap').find('.havingFilterCriteria').removeClass('hidden');
			} else {
				$(this).closest('.alertCriteriaWrap').find('.alertCriteria').empty();
				$(this).closest('.alertCriteriaWrap').find('.havingFilterCriteria').addClass('hidden');
			}
		});
		
		$(document).on('change', '#queryAccordion .queryfields', function() {
			var $panel = $(this).closest('.panel-body');
			self.updateHavingFilterCriteria($panel);
		});
		
		$(document).on('change', '#queryAccordion .queryfunction', function() {
			var $panel = $(this).closest('.panel-body');
			self.updateHavingFilterCriteria($panel);
		});
	};
	
	self.createQueryPanel = function() {
		var randomId = 'queryAccordion-' + Math.round( Math.random()*1000000 + 1 );
		var queryPanel = '<div class="panel panel-default">' +
							'	<div class="panel-heading" role="tab" id="">' +
							'		<h4 class="panel-title">' +
							'			<a class="query-title" role="button" data-toggle="collapse" data-parent="#queryAccordion" href="#'+ randomId +'" aria-expanded="true" aria-controls="'+ randomId +'">Query</a>' +
							'			<a href="javascript: void(0)" class="remove-ico tt pull-right remove-query-accordion hidden" title="'+ i18N['sax.label.remove'] +'"> <i class="fa fa-times"></i></a>' +
							'		</h4>' +
							'	</div>' +
							'	<div id="'+ randomId +'" class="panel-collapse collapse" role="tabpanel" aria-labelledby="">' +
							'		<div class="panel-body">' +
							'			<div class="form-group">' +
							'				<div class="col-sm-3 control-label">'+i18N['sax.fields']+' <span class="req">*</span></div>' +
							'				<div class="col-sm-8">' +
							'					<div class="query-fields-wrap queryFieldsWrap"></div>' +
							'				</div>' +
							'				<a content="statisticalFields" title="'+i18N['sax.fields']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a>' +
							'			</div>' +
							'			<div id="'+ randomId +'Where" class="alertCriteriaWrap">' +
							'				<div class="form-group margin-t-m">' +
							'					<div class="col-sm-3 control-label"></div>' +
							'					<div class="col-sm-8">' +
							'						<div class="checkbox">' +
							'							<label>' +
							'								<input class="applyFilterCriteria" type="checkbox"> Apply Filter Criteria' +
							'							</label>' +
							'						</div>' +
							'					</div>' +
							'					<a content="cepApplyFilterCriteria" title="Apply Filter Criteria" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a>' +
							'				</div>' +
							'				<div class="form-group whereFilterCriteria hidden">' +
							'					<div class="col-sm-3 control-label"></div>' +
							'					<div class="col-sm-9">' +
							'						<div id="'+ randomId +'WhereCriteria" class="alertCriteria" data-criteriatype="agg_where">' +
							'						</div>' +
							'					</div>' +
							'				</div>' +
							'			</div>' +
							'			<div class="form-group">' +
							'				<div class="col-sm-3 control-label">'+i18N['sax.label.timeWindow']+'</div>' +
							'				<div class="col-sm-4">' +
							'					<select class="queryTimeWindow" name="queryTimeWindow">' +
							'						<option value="time">'+i18N['sax.label.fixedLength']+'</option>' +
							'						<option value="batch">'+i18N['sax.label.slidingWindow']+'</option>' +
							'					</select>' +
							'				</div>' +
							'				<a content="statisticalTimeWindow" title="'+i18N['sax.label.timeWindow']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a>' +
							'			</div>' +
							'			<div class="form-group">' +
							'				<div class="col-sm-3 control-label">'+i18N['sax.label.windowDuration']+' <span class="req">*</span></div>' +
							'				<div class="col-sm-3">' +
							'					<input type="text" data-parsley-required="true" data-parsley-type="integer" data-parsley-min="1" class="form-control queryWindowDuration" placeholder="'+i18N['sax.placeholder.timeWindow']+'">' +
							'				</div>' +
							'				<div class="col-sm-3">' +
							'					<span class="margin-l-m margin-ts pull-left">seconds</span>' +
							'				</div>' +
							'				<a content="statisticalWindowDuration" title="'+i18N['sax.label.windowDuration']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a>' +
							'			</div>' +
							'			<div class="form-group">' +
							'				<div class="col-sm-3 control-label"></div>' +
							'				<div class="col-sm-8">' +
							'					<div class="checkbox">' +
							'						<label>' +
							'							<input class="applyGroupBy" type="checkbox"> Apply Group By' +
							'						</label>' +
							'					</div>' +
							'				</div>' +
							'				<a content="cepApplyGroupBy" title="Apply Group By" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a>' +
							'			</div>' +
							'			<div id="'+ randomId +'Having" class="alertCriteriaWrap">' +
							'				<div class="form-group margin-t-m applyGroupByFilterWrap hidden">' +
							'					<div class="col-sm-3 control-label"></div>' +
							'					<div class="col-sm-8">' +
							'						<div class="checkbox">' +
							'							<label>' +
							'								<input class="applyGroupByFilter" type="checkbox"> Apply Group By Filter' +
							'							</label>' +
							'						</div>' +
							'					</div>' +
							'					<a content="cepApplyGroupByFilter" title="Apply Group By Filter" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a>' +
							'				</div>' +
							'				<div class="form-group havingFilterCriteria hidden">' +
							'					<div class="col-sm-3 control-label"></div>' +
							'					<div class="col-sm-9">' +
							'						<div id="'+ randomId +'HavingCriteria" class="alertCriteria" data-criteriatype="agg_having">' +
							'						</div>' +
							'					</div>' +
							'				</div>' +
							'			</div>' +
							'			<div class="form-group">' +
							'				<div class="col-sm-3 control-label">Output</div>' +
							'				<div class="col-sm-3">' +
							'					<select class="outputRecord form-control">' +
							'						<option value="all">All Records</option>' +
							'						<option value="first">First Records</option>' +
							'						<option value="last">Last Records</option>' +
							'					</select>' +
							'				</div>' +
							'				<div class="col-sm-2">' +
							'					<input type="text" placeholder="'+i18N['sax.placeholder.pleaseEnterValue']+'" class="queryOutput form-control">' +
							'				</div>' +
							'				<div class="col-sm-3">' +
							'					<span class="margin-l-m margin-ts pull-left">seconds</span>' +
							/*'					<select class="outputWindow form-control">' +
							'						<option value="sec">Seconds</option>' +
							'						<option value="min">Minutes</option>' +
							'						<option value="hour">Hours</option>' +
							'					</select>' +*/
							'				</div>' +
							'				<a content="cepOutput" title="Output" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a>' +
							'			</div>' +
							'			<div class="form-group">' +
							'				<div class="col-sm-3 control-label"></div>' +
							'				<div class="col-sm-8">' +
							'					<div class="checkbox">' +
							'						<label>' +
							'							<input class="flushResults" type="checkbox" disabled> Flush results when window ends' +
							'						</label>' +
							'					</div>' +
							'				</div>' +
							'				<a content="cepFlushResults" title="Flush Results" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a>' +
							'			</div>' +
							'			<div class="form-group">' +
							'				<div class="col-sm-12 query-panel actionDataWrap"></div>' +
							'			</div>' +
							'			<div class="form-group">' +
							'				<div class="col-sm-12"><a href="javascript:void(0)" class="add-query-panel pull-right"><i class="fa fa-plus-circle"></i> '+i18N['sax.label.addAction']+'</a></div>' +
							'			</div>' +
							'		</div>' +
							'	</div>' +
							'</div>';
		
		$('#queryAccordion').append(queryPanel);
		$('#'+randomId).find('select').select2('destroy').select2({ placeholder: i18N['sax.placeholder.pleaseSelect'] });
		$('#'+randomId).find('.add-query-panel').trigger('click');
		self.createQueryFieldsTmpl( $('#'+randomId).find(".queryFieldsWrap") );
		var accorSize = $('#queryAccordion > .panel').size();
		if ( accorSize > 1 ) {
			$('#queryAccordion .remove-query-accordion').removeClass('hidden');
		}
		
		$('a.query-title[href="#'+ randomId +'"]').trigger('click');
		
		return '#'+randomId;
	};
	
	self.initQueryTmpl = function(d, streamGrouping) {
		$('#channelProperties ul.nav-tabs a[href="#configTab24"]').trigger('click');
		
		for( var i=0; i<d.messageTypes.length; i++ ) {
			$("#queryMessages").append('<option value="'+ d.messageTypes[i] +'">'+ d.messageTypes[i] + '</option>');
		}
		
		if ( streamGrouping == 'fields' )
			$(".groupby-radio[value='Y']").prop("checked", true);
		else
			$(".groupby-radio[value='N']").prop("checked", true);
		
		self.setQueryGrouping();
		
		if ( typeof d.query !== 'undefined' ) {
			$("#queryMessages").val( d.query.message );
			$("#enableContext").prop( 'checked', d.query.enableContext ).trigger('change');
			$("#contextName").val( d.query.contextName );
			$("#startTime").val( d.query.startTime );
			$("#endTime").val( d.query.endTime );
			
			var cepQueriesWithAction = d.query.cepQueriesWithAction;
			for ( var i=0; i<cepQueriesWithAction.length; i++ ) {
				$('#channelPropertiesForm > .modal-body').prepend('<div id="compPropertiesLoader" class="widget-loader">');
				var panelId = self.createQueryPanel();
				for ( var j=0; j<cepQueriesWithAction[i].queryFields.length; j++ ) {
					if ( j > 0 ) {
						$(panelId).find('.add-query-field:last').trigger('click');
					}
					$(panelId).find(".queryFieldsWrap .row:last select.queryfields").val( cepQueriesWithAction[i].queryFields[j].fields ).trigger("change");
					$(panelId).find(".queryFieldsWrap .row:last select.queryfunction").val( cepQueriesWithAction[i].queryFields[j]["function"] ).trigger("change");
				}
				$(panelId).find(".queryTimeWindow").val( cepQueriesWithAction[i].time ).trigger("change");
				$(panelId).find(".queryWindowDuration").val( cepQueriesWithAction[i].duration );
				$(panelId).find(".queryOutput").val( cepQueriesWithAction[i].output );
				//$(panelId).find("select.outputWindow").val( cepQueriesWithAction[i].outputWindow ).trigger('change');
				$(panelId).find("select.outputRecord").val( cepQueriesWithAction[i].outputRecord ).trigger('change');
				$(panelId).find(".applyGroupBy").prop( 'checked', cepQueriesWithAction[i].applyGroupBy ).trigger('change');
				$(panelId).find(".applyFilterCriteria").prop( 'checked', cepQueriesWithAction[i].applyWhereFilter ).trigger('change');
				$(panelId).find(".applyGroupByFilter").prop( 'checked', cepQueriesWithAction[i].applyHavingFilter ).trigger('change');
				$(panelId).find(".flushResults").prop( 'checked', cepQueriesWithAction[i].flushResults );
				if ( cepQueriesWithAction[i].output.length > 0 ) {
					$(panelId).find(".flushResults").prop('disabled', false);
				}
				
				if ( cepQueriesWithAction[i].cepAction.length > 0 ) {
					$(panelId).find('.actionDataWrap').empty();
					dynamicCEPBolt.setActionData(cepQueriesWithAction[i].cepAction, $(panelId).find('.actionDataWrap'));
					self.toggleRemoveActionLink();
				}
				
				if ( cepQueriesWithAction[i].whereFilters ) {
					var whereFilters = cepQueriesWithAction[i].whereFilters;
					/*if ( i == 0 ) {
						self.initWhereFilterCriteria( $(panelId+'Where') );
					}*/
					$(panelId+"WhereCriteria").empty();
					self.updateCriteria(whereFilters, $(panelId+"WhereCriteria"));
				}
				
				if ( cepQueriesWithAction[i].havingFilters ) {
					var havingFilters = cepQueriesWithAction[i].havingFilters;
					//self.initHavingFilterCriteria( $(panelId+'Having') );
					$(panelId+"HavingCriteria").empty();
					self.updateCriteria(havingFilters, $(panelId+"HavingCriteria"));
				}
				$('#compPropertiesLoader').remove();
			}
			
			setTimeout(function() {
				$('#queryAccordion .panel:not(:first) .panel-collapse').removeClass('in');
			}, 300);
			
			$(".groupby-radio[value='"+ d.query.groupBy +"']").prop("checked", true).trigger('click');
		} else {
			self.createQueryPanel();
		}
		
		$("#queryMessages").on("change", function() {
			$(".queryFieldsWrap").empty();
			self.createQueryFieldsTmpl( $(".queryFieldsWrap") );
		});
		
		var groupFields = new Array();
		for ( var i=0; i<d.groupings.length; i++ ) {
			groupFields = $.merge(groupFields, d.groupings[i].groupFields);
		}
		groupFields = DFSubSytemDefination.unique(groupFields);
		$("#queryGroupFields").val( groupFields ).trigger("change");
	};
	
	self.createQueryFieldsTmpl = function(queryFieldsWrap) {
		var msg = $("#queryMessages").val();
		var $fields='', $row;
		if ( allMessagesData[msg] ) {
			for( var i=0; i<allMessagesData[msg].length; i++ ) {
				var dType = allMessagesData[msg][i].dataType;
				if ( allMessagesData[msg][i].fieldName != 'indexId' && allMessagesData[msg][i].fieldName != 'rowId' && allMessagesData[msg][i].fieldName != 'type' && dType != "java.lang.String" && dType != "java.lang.Boolean" && dType != "java.util.Date" && dType != "geo_point" && dType != "ip" ) {
					$fields += '<option value="'+ allMessagesData[msg][i].fieldName +'">'+ allMessagesData[msg][i].fieldLabel + '</option>';
				}
			}
		}
		
		$row = $('<div>', {'class': 'row margin-bm'}).append('<div class="col-sm-8"> <div> <select class="queryfields form-control" name="queryfields" data-parsley-required="true" multiple>'+ $fields +'</select> </div> </div> <div class="inline margin-lm-m"> <select class="queryfunction" name="queryfunction" > <option value="avg">'+i18N['sax.label.average']+'</option> <option value="min">'+i18N['sax.label.min']+'</option> <option value="max">'+i18N['sax.label.max']+'</option> <option value="sum">'+i18N['sax.label.sum']+'</option> <option value="count">Count</option> </select> </div> <a title="'+i18N['sax.label.add']+'" class="add-ico add-query-field inline margin-ts tt" href="javascript:void(0)"><i class="fa fa-plus"></i></a> <a title="'+i18N['sax.label.remove']+'" class="remove-ico remove-query-field inline margin-ts tt" href="javascript:void(0)"><i class="fa fa-times"></i></a>');
		
		queryFieldsWrap.append($row);
		queryFieldsWrap.find(".row:last select").select2("destroy").select2({ placeholder: i18N['sax.placeholder.pleaseSelect'] });
		$(".tt").tooltip();
		
		var rowSize = queryFieldsWrap.find(".row").size();
		if ( rowSize > 1 ) queryFieldsWrap.find(".remove-query-field").show();
		else queryFieldsWrap.find(".remove-query-field").hide();
	};

	self.setQueryGrouping = function() {
		var msgSize = $("#queryMessages option").size();
		var curChannelId = $("#curChannelId").val();
		var grouping = $(".groupby-radio[name='querygroupby']:checked").val();
		
		if ( (curChannelId == cmpIDs.aggregationfunction) && msgSize > 0 ) {
			$("#queryGroupFieldsWrap").closest(".form-group").addClass("hidden-elem");
			$("#queryGroupFieldsWrap").empty();
			if ( grouping == "Y" ) {
				$("#parallelism, #taskCount").prop("disabled", false);
				$("#queryGroupFieldsWrap").closest(".form-group").removeClass("hidden-elem");
				$("#queryGroupFieldsWrap").append('<div><select id="queryGroupFields" class="form-control" name="queryGroupFields" data-parsley-required="true" multiple></select></div>');
				var msg = $("#queryMessages").val();
				for( var i=0; i<allMessagesData[msg].length; i++ ) {
					$("#queryGroupFields").append('<option value="'+ allMessagesData[msg][i].fieldName +'">'+ allMessagesData[msg][i].fieldLabel + '</option>');
				}
				$("#queryGroupFields").select2({ placeholder: i18N['sax.placeholder.selectFields']});
			} else {
				$("#parallelism, #taskCount").val("1");
				$("#parallelism, #taskCount").prop("disabled", true);
			}
		}
	};
	
	self.createFieldsQuery = function(curChnl) {
		var obj = {
				aggQuery: {
					contextQuery: '',
					cepQueriesWithAction: []
				},
				query: {
					enableContext: false,
					contextName: '',
					startTime: '',
					endTime: '',
					cepQueriesWithAction: []
				}
			};
		
		var cepQuery = '';
		var msg = $("#queryMessages").val();
		var groupBy = $(".groupby-radio:checked").val();
		var groupFields = [];
		var enableContext = $("#enableContext").prop('checked');
		var contextName = $("#contextName").val();
		var startTime = $("#startTime").val();
		var endTime = $("#endTime").val();
		if ( enableContext ) {
			obj.aggQuery.contextQuery = 'create context '+ contextName +' start '+ startTime +' end ' + endTime;
		}
		
		if ( groupBy == "Y" ) {
			groupFields = $("#queryGroupFields").val();
		}
		
		for ( var i=0; i<curChnl.groupings.length; i++ ) {
			if ( groupBy == "Y" ) {
				curChnl.groupings[i].type = 'fields';
				curChnl.groupings[i].groupFields = groupFields;
			} else {
				if ( curChnl.groupings[i].type == 'fields' ) {
					curChnl.groupings[i].type = 'shuffle';
					curChnl.groupings[i].groupFields = [];
				}
			}
		}
		
		$('#queryAccordion > .panel').each(function(p, panel) {
			cepQuery = '';
			var queryFields = [];
			var applyGroupBy = $(panel).find(".applyGroupBy").prop('checked');
			var applyWhereFilter = $(panel).find(".applyFilterCriteria").prop('checked');
			var applyHavingFilter = $(panel).find(".applyGroupByFilter").prop('checked');
			var time = $(panel).find("select.queryTimeWindow").val();
			var duration = $(panel).find(".queryWindowDuration").val();
			var queryOutput = $(panel).find(".queryOutput").val();
			//var outputWindow = $(panel).find("select.outputWindow").val();
			var outputRecord = $(panel).find("select.outputRecord").val();
			var flushResults = $(panel).find(".flushResults").prop('checked');
			var allFields = [];
			var whereFilters = [];
			var havingFilters = [];
			
			//var alias = [];
			var totalFieldRows = $(panel).find(".queryFieldsWrap .row").size();
			var fieldRowsCount = 0;
			
			$(panel).find(".queryFieldsWrap .row").each(function() {
				fieldRowsCount++;
				var fields = $(this).find("select.queryfields").val();
				var functn = $(this).find("select.queryfunction").val();
				queryFields.push({
					'fields': fields,
					'function': functn
				});
				
				if ( fields != null && fields != "null" ) {
					for ( var i=0; i<fields.length; i++ ) {
						if ( $.inArray(fields[i], allFields) == -1 )
							allFields.push( fields[i] );
							
						var ucField = fields[i].substr(0,1).toUpperCase()+fields[i].substr(1);
						cepQuery += functn + '('+ fields[i] +') as ' + functn + ucField;
						//alias.push(functn + ucField);
						if ( i != (fields.length-1) )
							cepQuery += ',';
					}
				}
				
				if ( fieldRowsCount != totalFieldRows )
					cepQuery += ',';
			});
			
			var sFields = $.grep(groupFields, function(v) {
				return ( $.inArray(v, allFields) == -1 )
			});
			
			if ( applyWhereFilter ) {
				whereFilters = self.getCriteriaData( $(this).find(".whereFilterCriteria").find(".alertCriteria") );
				var filterQuery = '', comparitor;
				for ( var c=0; c<whereFilters.length; c++ ) {
					filterQuery += (c == 0) ? '(' : ' ' + whereFilters[c].operand.toLowerCase() + ' (';
					comparitor = whereFilters[c].comparitor;
					comparitor = (comparitor == "equals") ? "=" : comparitor;
					comparitor = (comparitor == "not equal") ? "!=" : comparitor;
					comparitor = (comparitor == "less than") ? "<" : comparitor;
					comparitor = (comparitor == "greater than") ? ">" : comparitor;
					comparitor = (comparitor == "less than equal to") ? "<=" : comparitor;
					comparitor = (comparitor == "greater than equal to") ? ">=" : comparitor;
					var value = whereFilters[c].value;
					
					if ( whereFilters[c].type == 'string' ) {
						if ( comparitor == 'in' || comparitor == 'not in' ) {
							value = value.replace(/'/g, '');
							var valueArr = value.split(',');
							for ( var f=0; f<valueArr.length; f++ ) {
								valueArr[f] = "'" + valueArr[f].trim() + "'";
							}
							value = '(' + valueArr.join(', ') + ')';
						} else {
							value = value.replace(/'/g, '');
							value = "'" + value.trim() + "'";
						}
					} else {
						if ( comparitor == 'between' || comparitor == 'not between' ) {
							value = value.split(',')[0] + ' and ' + value.split(',')[1];
						}	
					}
					
					filterQuery += whereFilters[c].context + ' ' + comparitor + ' ' + value + ')';
				}
				
				cepQuery += ' from GenericEvent(' + filterQuery + ')';
			} else {
				cepQuery += ' from GenericEvent';
			}
			
			if ( time == 'time' )
				cepQuery += '.win:time_batch('+ duration +' sec)';
			else
				cepQuery += '.win:time('+ duration +' sec)';
			
			if ( applyGroupBy && groupFields.length > 0 ) {
				cepQuery += ' group by ';
				cepQuery += groupFields.join(",");
				cepQuery = 'select ' + sFields.join(",") + ',' + cepQuery;
				
				if ( applyHavingFilter ) {
					cepQuery += ' having ';
					havingFilters = self.getCriteriaData( $(this).find(".havingFilterCriteria").find(".alertCriteria") );
					var filterQuery = '', comparitor;
					for ( var c=0; c<havingFilters.length; c++ ) {
						filterQuery += (c == 0) ? '(' : ' ' + havingFilters[c].operand.toLowerCase() + ' (';
						comparitor = havingFilters[c].comparitor;
						comparitor = (comparitor == "equals") ? "=" : comparitor;
						comparitor = (comparitor == "not equal") ? "!=" : comparitor;
						comparitor = (comparitor == "less than") ? "<" : comparitor;
						comparitor = (comparitor == "greater than") ? ">" : comparitor;
						comparitor = (comparitor == "less than equal to") ? "<=" : comparitor;
						comparitor = (comparitor == "greater than equal to") ? ">=" : comparitor;
						var value = havingFilters[c].value;
						
						if ( comparitor == 'between' || comparitor == 'not between' ) {
							value = value.split(',')[0] + ' and ' + value.split(',')[1];
						}
						
						filterQuery += havingFilters[c].context + ' ' + comparitor + ' ' + value + ')';
					}
					cepQuery += filterQuery;
				}
			} else {
				cepQuery = 'select ' + allFields.join(',') + ', ' + cepQuery;
			}
			
			if ( enableContext ) {
				cepQuery = 'context ' + contextName + ' ' + cepQuery;
			}
				
			if ( queryOutput.trim().length > 0 ) {
				if ( outputRecord != 'all' ) {
					cepQuery = cepQuery + ' output '+ outputRecord +' every '+ queryOutput +' sec';
				} else {
					cepQuery = cepQuery + ' output every '+ queryOutput +' sec';
				}
				
				if ( flushResults ) {
					cepQuery = cepQuery + ' and when terminated';
				}
			} else {
				if ( outputRecord != 'all' ) {
					cepQuery = cepQuery + ' output '+ outputRecord;
				}
			}
			
			var actionData = self.createActionData($(panel));
			obj.aggQuery.cepQueriesWithAction.push({
				'cep.query': cepQuery,
				'cepAction': actionData
			});
			
			obj.query.cepQueriesWithAction.push({
				'applyWhereFilter': applyWhereFilter,
				'whereFilters': whereFilters,
				'applyHavingFilter': applyHavingFilter,
				'havingFilters': havingFilters,
				'applyGroupBy': applyGroupBy,
				'queryFields': queryFields,
				'time': time,
				'duration': duration,
				'output': queryOutput,
				'outputRecord': outputRecord,
				//'outputWindow': outputWindow,
				'flushResults': flushResults,
				'cepAction': JSON.parse(actionData)
			});
			
			//$("#configRows input[class~='cep.alias-fld']").val( alias.join(',') );
		});
		
		obj.query.message = msg;
		obj.query.groupBy = groupBy;
		obj.query.groupFields = groupFields;
		obj.query.enableContext = enableContext;
		obj.query.contextName = contextName;
		obj.query.startTime = startTime;
		obj.query.endTime = endTime;
		
		for ( var i=0; i<curChnl.groupings.length; i++ ) {
			var trgName = curChnl.name;
			var srcId = curChnl.groupings[i].componentId;
			var srcObj = DFSubSytemDefination.getComponentObject(srcId);
			var outputFields = jQuery.extend(true, [], groupFields);
			
			for ( var j=0; j<srcObj.emitStreamIds.length; j++ ) {
				if ( srcObj.emitStreamIds[j].componentId == trgName ) {
					if ( typeof srcObj.type === 'undefined' && $.inArray( "streamIds", outputFields ) == -1 )
						outputFields.unshift("streamIds");
					
					if ( $.inArray( "tracemessage", outputFields ) == -1 )
						outputFields.unshift("tracemessage");
					
					srcObj.emitStreamIds[j].outputFields = outputFields;
				}
			}
		}
		
		return obj;
	};
	
	self.setActionData = function(d) {
		for ( var i=0; i<d.config.length; i++ ) {
			var configLen = d.config[i].length;
			var colonIdx = d.config[i].indexOf(":");
			var configKey = d.config[i].substring(0, colonIdx);
			var configVal = d.config[i].substring(colonIdx+1, configLen).trim();
			if ( configKey == 'cepAction' && configVal != '' )	{
				configVal = configVal.replace(/'/g, '\"');
				var actionsData = JSON.parse(configVal);
				if ( actionsData.length > 0 ) {
					dynamicCEPBolt.setActionData(actionsData, $('.actionDataWrap'));
				} else {
					$('a.add-query-panel').trigger('click');
				}
				self.toggleRemoveActionLink();
			} else if ( configKey == 'cepAction' && configVal == '' )	{
				$('a.add-query-panel').trigger('click');
			}
		}
	};
	
	self.createActionData = function($panel) {
		var cepAction = new Array();
		
		$panel.find(".actionDataWrap").find(".action-panel").each(function(i, aElem) {
			var exchangeName, routingKey, url, method, className, headerParams={}, requestParams={}, initParams={};
			var action = $(aElem).find('select.queryAction').val();
			if ( action == 'PUBLISH_TO_RABBITMQ' ) {
				exchangeName = $(aElem).find('.exchangename').val();
				routingKey = $(aElem).find('.routingKey').val();
				cepAction.push({
					actionName: action,
					params: {
						exchangeName: exchangeName,
						routingKey: routingKey
					}
				});
			} else if ( action == 'INVOKE_WEBSERVICE_CALL' ) {
				url = $(aElem).find('.url').val();
				method = $(aElem).find('select.method').val();
				
				$(aElem).find('ul.headerparams li').each(function(k, p) {
					var params = $(p).text().split(":");
					headerParams[params[0]] = params[1];
				});
				
				$(aElem).find('ul.requestparams li').each(function(k, p) {
					var params = $(p).text().split(":");
					requestParams[params[0]] = params[1];
				});
				
				cepAction.push({
					actionName: action,
					params: {
						url: url,
						method: method,
						headerParams: headerParams,
						requestParams: requestParams
					}
				});
			} else if ( action == 'CUSTOM_ACTION' ) {
				className = $(aElem).find('.delegate').val();
				
				$(aElem).find('ul.initparams li').each(function(k, p) {
					var params = $(p).text().split(":");
					initParams[params[0]] = params[1];
				});
				
				cepAction.push({
					actionName: action,
					params: {
						className: className,
						initParams: initParams
					}
				});
			}
		});
		
		return JSON.stringify(cepAction);
	};
	
	self.toggleRemoveActionLink = function() {
		var curCompId = $('#curChannelId').val();
		if ( curCompId == cmpIDs.aggregationfunction ) {
			$('#queryAccordion > .panel').each(function() {
				var actionPanels = $(this).find('.actionDataWrap > .action-panel').size();
				if ( actionPanels == 1 ) {
					$(this).find('.actionDataWrap a.remove-query-panel').hide();
				} else {
					$(this).find('.actionDataWrap a.remove-query-panel').show();
				}
			});
		}
	};
	
	self.initWhereFilterCriteria = function($wrap) {
		var msg = $("#queryMessages").val();
		var id = $wrap.attr('id');
		available_criteria[id] = [];
		if ( allMessagesData[msg] ) {
			for( var i=0; i<allMessagesData[msg].length; i++ ) {
				var dType = allMessagesData[msg][i].dataType;
				if ( dType == "java.lang.String" || dType == "java.lang.Long" || dType == "java.lang.Double" ) {
					dType = dType.split(".");
					dType = dType[dType.length-1].toLowerCase();
					available_criteria[id].push({
						name: allMessagesData[msg][i].fieldName,
						label: allMessagesData[msg][i].fieldLabel,
						type: dType
					});
				}
			}
		}
		
		$("#"+id+"Criteria").add_criteria();
	};
	
	self.initHavingFilterCriteria = function($wrap) {
		var fields = [];
		var id = $wrap.attr('id');
		available_criteria[id] = [];
		var $fieldsWrap = $wrap.closest('.panel-body').find('.queryFieldsWrap');
		$fieldsWrap.find('.row').each(function(i, row) {
			var flds = $(row).find('select.queryfields').val();
			var func = $(row).find('select.queryfunction').val();
			for ( var j=0; j<flds.length; j++ ) {
				var fld = func + '('+ flds[j] +')';
				if ( $.inArray(fld, fields) == -1 ) {
					fields.push(fld);
					available_criteria[id].push({
						name: fields[i],
						label: fields[i],
						type: 'integer'
					});
				}
			}
		});
		
		$("#"+id+"Criteria").add_criteria();
	};
	
	self.updateHavingFilterCriteria = function($panel) {
		var applyGroupByFilter = $panel.find('.applyGroupByFilter').prop('checked');
		if ( applyGroupByFilter ) {
			var $fieldsWrap = $panel.find('.queryFieldsWrap');
			var fields = [];
			
			$fieldsWrap.find('.row').each(function(i, row) {
				var flds = $(row).find('select.queryfields').val();
				var func = $(row).find('select.queryfunction').val();
				if ( flds != null ) {
					for ( var j=0; j<flds.length; j++ ) {
						fields.push( func + '('+ flds[j] +')' );
					}
				}
			});
			
			fields = $.unique(fields);
			var id = $panel.parent().attr('id')+'Having';
			available_criteria[id] = [];
			for( var i=0; i<fields.length; i++ ) {
				available_criteria[id].push({
					name: fields[i],
					label: fields[i],
					type: 'integer'
				});
			}
			
			var selCriteria = self.getCriteriaData( $('#'+id+'Criteria') );
			if ( selCriteria.length > 0 ) {
				$("#"+id+"Criteria").empty();
				self.updateCriteria(selCriteria, $("#"+id+"Criteria"));
			}
		}
	};
	
	self.updateCriteria = function(data, $wrap) {
		setTimeout(function() {
			for ( var f=0; f<data.length; f++ ) {
				$wrap.add_criteria();
				var $crtRow = $wrap.find('.criteria_wrap').eq(f);
				$crtRow.find('select.operand_select').val(data[f].operand).trigger('change');
				$crtRow.find('select.context_select').val(data[f].context).trigger('change');
				$crtRow.find('select.comparitor_select').val(data[f].comparitor).trigger('change');
				if ( data[f].comparitor == 'between' || data[f].comparitor == 'not between' ) {
					var fValues = data[f].value.split(',');
					$crtRow.find('.criteria_fields > span:first input').val(fValues[0].trim())
					$crtRow.find('.criteria_fields > span:last input').val(fValues[1].trim())
				} else {
					$crtRow.find('.criteria_fields > span input').val(data[f].value)
				}
			}
		}, 100);
	};
	
	self.getCriteriaData = function($wrap) {
		var criteria = [];
		$wrap.find('.criteria_wrap').each(function(r, row) {
			var d_type = $(row).find("select.context_select").find("option:selected").attr("data-type");
			var operand = $(row).find('select.operand_select').val();
			var context = $(row).find('select.context_select').val();
			var comparitor = $(row).find('select.comparitor_select').val();
			var fldsSize = $(row).find('.criteria_fields > span').size();
			var fldFirst = $(row).find('.criteria_fields > span:first input').val();
			var fldLast = $(row).find('.criteria_fields > span:last input').val();
			criteria.push({
				type: d_type,
				operand: operand,
				context: context,
				comparitor: comparitor,
				value: (fldsSize > 1) ? (fldFirst + ',' + fldLast) : fldFirst
			});
		});
		
		return criteria;
	};
	
	self.init();
};

// CEP Custom Processor Functionality
var customCEPBolt = new function() {
	var self = this;
	
	self.init = function(curChnl) {
		$('#configRows').append('<div class="panel panel-default action-panel"><div class="col-md-12"><div class="margin-tm margin-bm">'+i18N['sax.label.customDelegate']+'</div><div class="form-group"><div class="col-sm-3 control-label"> '+i18N['sax.label.className']+' <span class="req">*</span> </div><div class="col-sm-8"><input type="text" id="custCEPClassName" class="form-control" value="" placeholder="'+i18N['sax.placeholder.className']+'" data-parsley-required="true"> </div> <a content="dynamicClassName" title="'+i18N['sax.label.className']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div><div class="form-group"><div class="col-sm-3 control-label"> '+i18N['sax.label.initParams']+' </div><div class="col-sm-8"> <a class="pull-left margin-ts add-custcep-params add-ico tt" href="javascript:void(0)" title="'+i18N['sax.label.addInitParams']+'"><i class="fa fa-plus"></i></a> </div> <a content="dynamicInitParams" title="'+i18N['sax.label.initParams']+'" tabindex="-1" class="po infoico margin-rm" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> </div> <div class="form-group"><div class="col-sm-3 control-label"></div><div class="col-sm-8"><div id="custCEPParamsWrap" class="row margin-tm-m"></div></div></div> <div class="clearfix"></div> </div>');
		
		$(document).on("click", ".add-custcep-params", function() {
			self.addInitPramaRow();
		});
		
		$(document).on('click', '.remove-custcep-param', function() {
			$(this).closest('.custcep-param-row').remove();
		});
		
		self.setActionData(curChnl);
	};
	
	self.addInitPramaRow = function(key, val) {
		key = (key) ? key : '';
		val = (val) ? val : '';
		$('#custCEPParamsWrap').append('<div class="custcep-param-row col-md-12 margin-tm"><div class="col-sm-6"><input type="text" placeholder="'+i18N['sax.placeholder.name']+'" class="form-control config-key" data-parsley-required="true" data-parsley-duplicateKeys="" value="'+ key +'"></div><div class="col-sm-6"><input type="text" placeholder="'+i18N['sax.placeholder.value']+'" class="form-control config-value tt" data-parsley-required="true" value="'+ val +'"></div><a href="javascript:void(0)" title="'+i18N['sax.label.remove']+'" class="remove-config remove-custcep-param remove-ico tt"><i class="fa fa-times"></i></a></div></div>');
	};
	
	self.createActionData = function() {
		var cepAction = new Array();
		var initParams = new Object();
		var className = $('#custCEPClassName').val();
		
		$('#custCEPParamsWrap .custcep-param-row').each(function() {
			var key = $(this).find('input.config-key').val();
			var val = $(this).find('input.config-value').val();
			initParams[key] = val;
		});
		
		cepAction.push({
			"actionName": "CUSTOM_ACTION", 
			"params": {
				"className": className, 
				"initParams": initParams
			}
		});
		
		return JSON.stringify(cepAction);
	};
	
	self.setActionData = function(d) {
		for ( var i=0; i<d.config.length; i++ ) {
			var configLen = d.config[i].length;
			var colonIdx = d.config[i].indexOf(":");
			var configKey = d.config[i].substring(0, colonIdx);
			var configVal = d.config[i].substring(colonIdx+1, configLen).trim();
			if ( configKey == 'cepAction' && configVal != '' )	{
				configVal = configVal.replace(/'/g, '\"');
				var actionsData = JSON.parse(configVal);
				actionsData = actionsData[0];
				$('#custCEPClassName').val( actionsData.params.className );
				$.each(actionsData.params.initParams, function(key, val) {
					self.addInitPramaRow(key, val);
				});
			}
		}
	};
};

// Look up functionality
var addedFunctions = {};
var lookupClass = new function() {
	var self = this, cacheFunctions = [], lookupData = {};
	var compType = $('#componentType').val();
	var curChannelId = $('#curChannelId').val();
	self.addEvents = function() {
		$(document).on("blur", ".config-value.ui-autocomplete-input", function() {
			var _this = $(this);
			self.checkLookFuncAdded(_this);
		});
		
		$(document).on("blur", "input.config-key", function() {
			var _this = $(this).closest('.config-row').find('.config-value.ui-autocomplete-input');
			self.checkLookFuncAdded(_this);
		});
		
		$(document).on("blur", ".saxtmpl-val.ui-autocomplete-input", function() {
			var _this = $(this);
			self.checkLookFuncAdded(_this);
		});
		
		$(document).on("blur", ".saxtmpl-key", function() {
			var _this = $(this).closest('.saxtmpl-row').find('.saxtmpl-val.ui-autocomplete-input');
			self.checkLookFuncAdded(_this);
		});
		
		$(document).on("click", "a.remove-config", function() {
			setTimeout(function() {
				addedFunctions = {};
				$("#configRowsWrap .config-value.ui-autocomplete-input").each(function(i, fld) {
					var _this = $(fld);
					self.checkLookFuncAdded(_this);
				});
			}, 200);
		});
		
		if ( ($.inArray(activeComp.id, functionSupportedComps) > -1) || (typeof activeComp.subtype !== 'undefined' && activeComp.subtype == 'custom' && activeComp.type != 'channel') ) {
			$("#configRowsWrap .config-value.ui-autocomplete-input").each(function() {
				var _this = $(fld);
				self.checkLookFuncAdded(_this);
				$(this).initQueryBuilder({data: fvAutoSuggestData});
			});
		}
		
		$(document).on('click','#lookupRDBMSTestConnBtn', function() { 
			var testLookupRDBMSJson = {}, validate = true;
			
			$("#tab_lookupRDBMS").find("[data-parsley-required='true']").each(function() {
				flag = $(this).parsley().validate();
				if ( flag != true ) validate = false;
			});
			
			if ( validate ) {
				$('#tab_lookupRDBMS').find('.saxtmpl-row').each(function(i, row){
					var type = $(row).find('.saxtmpl-type').val();
					var key = $(row).find('.saxtmpl-key').val();
					if ( type == 'select' ) {
						var value = $(row).find('select.saxtmpl-val').val();
					} else {
						var value = $(row).find('.saxtmpl-val').val();
					}
					testLookupRDBMSJson[key] = value;
				});
			
				var result = DFSubSytemDefination.postAjaxData(testRDBMSConn , JSON.stringify(testLookupRDBMSJson));
				result = JSON.parse(result);
				if ( result.status && result.status.toUpperCase() == "SUCCESS" ) {
					$('#lookupTestConnStatus').html('<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+ result.message +'</div>').fadeIn(1000);
				} else if ( result.status && result.status.toUpperCase() == "FAILURE" ) {
					$('#lookupTestConnStatus').html('<div class="alert alert-error alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+result.message+'</div>').fadeIn(1000);
				}
				setTimeout(function() {
					$("#lookupTestConnStatus").fadeOut(2500);
					$("#lookupTestConnStatus").empty();
				}, 10000);
			}
		});
		
		$(document).on('click','#testConnectionBtnLookup', function() {
			var _this = this, validate = true;
			var tabId = $(this).closest('.tab-pane.active').attr('id');
			switch(tabId) {
				case 'tab_lookupCassandra':
					componentType = 'cassandra';
					break;
				
				case 'tab_lookupHBase':
					componentType = 'hbase';
					break;
				
				case 'tab_lookupES':
					componentType = 'elasticsearch';
					break;
			}
			
			$('#'+tabId).find("[data-parsley-required='true']").each(function() {
				flag = $(this).parsley().validate();
				if ( flag != true ) validate = false;
			});
			
			if ( validate ) {
				var componentConnUrl = baseUrl+'/connections/'+componentType+'/connection/lookupTest/test';
				var testLookupJson = {}, connectionJson = {};
				testLookupJson["componentType"] = componentType;
				testLookupJson["connectionName"] = "lookupTest";
				testLookupJson["connectionId"] = "";
				testLookupJson["tenantId"] = currentTenantId;
				testLookupJson["connectionJson"] = "";
				$('#'+tabId).find('.saxtmpl-row').each(function(i, row){
					var type = $(row).find('.saxtmpl-type').val();
					var key = $(row).find('.saxtmpl-key').val();
					if ( type == 'select' ) {
						var value = $(row).find('select.saxtmpl-val').val();
					} else {
						var value = $(row).find('.saxtmpl-val').val();
					}
					connectionJson[key] = value;
				});
				testLookupJson["connectionJson"] = JSON.stringify(connectionJson);
				var result = DFSubSytemDefination.postAjaxData(componentConnUrl , JSON.stringify(testLookupJson));
				result = JSON.parse(result);
				if ( result.status && result.status.toUpperCase() == "SUCCESS" ) {
					$(_this).closest('.col-md-10').find('.lookupTestConnStatus').html('<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+ result.message +'</div>').fadeIn(1000);
				} else if ( result.status && ( result.status.toUpperCase() == "FAILURE" || result.status.toUpperCase() == "ERROR" ) ) {
					$(_this).closest('.col-md-10').find('.lookupTestConnStatus').html('<div class="alert alert-error alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+result.message+'</div>').fadeIn(1000);
				}
				setTimeout(function() {
					$(".lookupTestConnStatus").fadeOut(2500);
					$(".lookupTestConnStatus").empty();
				}, 10000);
			}
		});
	
		$(document).on('change', 'input.saxtmpl-val.cachingEnabled', function() {
			$('#channelErrorWrap').empty();
			var val = $(this).prop('checked');
			var row = $(this).closest('.saxtmpl-row');
			if ( val ) {
				$(this).val('true');
				row.siblings('.CacheExpTime-row').show().find('.saxtmpl-val.CacheExpTime').attr("data-parsley-required", "true");
				row.siblings('.refreshTime-row').show().find('.saxtmpl-val.refreshTime').attr("data-parsley-required", "true");
				row.siblings('.maxLimit-row').show().find('.saxtmpl-val.maxLimit').attr("data-parsley-required", "true");
			} else {
				$(this).val('false');
				row.siblings('.CacheExpTime-row').hide().find('.saxtmpl-val.CacheExpTime').removeAttr("data-parsley-required").val("").parsley().destroy();
				row.siblings('.refreshTime-row').hide().find('.saxtmpl-val.refreshTime').removeAttr("data-parsley-required").val("").parsley().destroy();
				row.siblings('.maxLimit-row').hide().find('.saxtmpl-val.maxLimit').removeAttr("data-parsley-required").val("").parsley().destroy();
			}
		});
	};
	
	self.init = function(curComp) {
		addedFunctions = {};
		cacheFunctions = [];
		self.getLookupData(curComp);
		self.createLookupTabs();
	};
	
	self.createLookupTabs = function() {
		$('#channelProperties > .nav.nav-tabs').append('<li class="hidden"> <a data-toggle="tab" href="#lookupTab"> '+ i18N['sax.label.function'] +' </a></li>');
		$('#channelProperties > .tab-content').append('<div id="lookupTab" class="tab-pane"> <div class="vertical-tabs row"> <div class="col-xs-3"> <ul class="nav nav-tabs tabs-left" id="luFuncTabs"> </ul> </div> <div class="col-xs-9"> <div class="tab-content" id="luFuncContent"> </div> </div> </div> </div>');
		
		var cachingArr = [
			{
				"propertyName": {
					"type": "label",
					"value": "cachingEnabled"
				},
				"propertyValue": {
					"type": "checkbox",
					"options": [{
						"value": "true"
					}],
					"value": ""
				}
			},
			{
				"propertyName": {
					"type": "label",
					"value": "CacheExpTime"
				},
				"propertyValue": {
					"type": "text",
					"value": ""
				}
			},
			{
				"propertyName": {
					"type": "label",
					"value": "maxLimit"
				},
				"propertyValue": {
					"type": "text",
					"value": ""
				}
			},
			{
				"propertyName": {
					"type": "label",
					"value": "refreshTime"
				},
				"propertyValue": {
					"type": "text",
					"value": ""
				}
			}
		];
		
		for ( var i=0; i < functionsData.length; i++ ) {
			var funcName = functionsData[i].functionName;
			var params = functionsData[i].parameters;
			var funcClass = functionsData[i].functionClass;
			var argsNames = functionsData[i].argsNames;
			var textConnBtn = '';
			if ( funcName == 'lookupRDBMS' ) {
				textConnBtn = '<div id="lookupTestConnStatus"> </div><button class="btn btn-default pull-right" type="button" id="lookupRDBMSTestConnBtn">'+ i18N['sax.label.testConnection'] +'</button>'
			} else if ( funcName == 'lookupCassandra' || funcName == 'lookupHBase' || funcName == 'lookupES' ) {
				textConnBtn = '<div class="lookupTestConnStatus"> </div><button class="btn btn-default pull-right" type="button" id="testConnectionBtnLookup">'+ i18N['sax.label.testConnection'] +'</button>'
			} else {
				textConnBtn = "";
			}		
			//lookupCassandra lookupHBase
			lookupFunctions.push( '$' + funcName );
			contentMap['function_'+funcName] = self.createDescPopover(functionsData[i]);
			
			var active = ( i == 0 ) ? 'active' : '';
			var cols = [5, 7];
			$('#luFuncTabs').append('<li class="first '+ active +'"><a data-toggle="tab" href="#tab_'+ funcName +'">'+ funcName +'</a></li>');
			
			var template = '<div class="form-horizontal">' +
								'<div class="col-md-10 margin-tl">' +
									'<input type="hidden" name="functionName" value="'+ funcName +'">' +
									'<input type="hidden" name="funcClass" value="'+ funcClass +'">' +
									'<input type="hidden" name="argument" value="'+ argsNames +'">';
			
			for ( var j=0; j<params.length; j++ ) {
				if ( lookupData[funcName] ) {
					var key = params[j].propertyName.value;
					params[j].propertyValue.value = lookupData[funcName][key];
				}
				template += SAXTemplate.createFormElements(params[j], cols);
			}
			
			for ( var j=0; j<cachingArr.length; j++ ) {
				if ( lookupData[funcName] ) {
					var key = cachingArr[j].propertyName.value;
					cachingArr[j].propertyValue.value = lookupData[funcName][key];
				} else {
					cachingArr[j].propertyValue.value = "";
				}
				template += SAXTemplate.createFormElements(cachingArr[j], cols);
			}
			
			template += textConnBtn +
								'</div>' +
							'</div>';
			
			$('#luFuncContent').append('<div id="tab_'+ funcName +'" class="tab-pane '+ active +'"><a content="'+ 'function_'+funcName +'" title="'+ funcName +'" tabindex="-1" class="po infoico margin-t-m" href="javascript:void(0)"><i class="fa fa-info-circle"></i> '+ i18N['sax.label.info'] +'</a>'+ template +'<div class="clearfix"></div></div>');
			$('input[name="CacheExpTime"]').closest('.saxtmpl-row').hide();
			$('input[name="maxLimit"]').closest('.saxtmpl-row').hide();
			$('input[name="refreshTime"]').closest('.saxtmpl-row').hide();
				cacheFunctions.push( funcName );
			
			$('input.saxtmpl-val[type="checkbox"]:last').trigger('change');
			$('.saxtmpl-val.CacheExpTime:last').attr("placeholder", i18N['sax.placeholder.pleaseEnterValue'] + ' ' + i18N['sax.label.in'] + ' ' + i18N['sax.label.minutes']);
			$('.saxtmpl-val.refreshTime:last').attr("placeholder", i18N['sax.placeholder.pleaseEnterValue'] + ' ' + i18N['sax.label.in'] + ' ' + i18N['sax.label.seconds']);
		}
		
		$('input.saxtmpl-val[type="checkbox"]:checked').trigger('change');
		$('#luFuncContent select').select2('destroy').select2({placeholder: i18N['sax.placeholder.pleaseSelect']});
	};
	
	self.createDescPopover = function(d) {
		var dtl = '';
		if ( d.functionDesc ) {
			if ( typeof d.functionDesc == 'string' ) {
				dtl = d.functionDesc;
			} else {
				dtl = '<dl class="margin-tm">';
				var funcDesc = d.functionDesc;
				$.each(funcDesc, function(key, val) {
					dtl += '<dt>' + key + '</dt>';
					if ( key == 'Parameters' ) {
						dtl += '<dd class="margin-l"><p>';
						for ( var i=0; i<val.length; i++ ) {
							$.each(val[i], function(param, paramDesc) {
								dtl += '<span><strong>'+ param +':</strong> '+ paramDesc +'</span><br />';
							});
						}
						dtl += '</p></dd>';
					} else {
						dtl += '<dd class="margin-l"><p>'+ val +'</p></dd>';
					}
				});
				
				dtl += '</dl>';
			}
		} else {
			dtl = errorObj.NO_DATA;
		}
		
		return dtl;
	};
	
	self.checkLookFuncAdded = function(elem) {
		var isSaxTmpl = elem.hasClass('saxtmpl-val');
		var configKey = '';
		
		if ( isSaxTmpl ) {
			var keyType = elem.closest('.saxtmpl-row').find('.saxtmpl-type').val();
			configKey = elem.closest('.saxtmpl-row').find('.saxtmpl-key').val();
			if ( configKey == "" ) {
				configKey = elem.closest('.saxtmpl-row').find('select.saxtmpl-key').val();
			}
		} else {
			configKey = elem.closest('.config-row').find('.config-key').val();
		}
		
		var configVal = elem.val();
		
		if ( configVal ) {
			for ( var i=0; i<lookupFunctions.length; i++ ) {
				var funcIdx = configVal.indexOf(lookupFunctions[i]);
				if ( funcIdx > -1 ) {
					if ( typeof addedFunctions[lookupFunctions[i]] === 'undefined' ) {
						addedFunctions[lookupFunctions[i]] = [];
					}
					
					if ( $.inArray(configKey, addedFunctions[lookupFunctions[i]]) === -1 ) {
						addedFunctions[lookupFunctions[i]].push( configKey )
					}
				} else {
					if ( typeof addedFunctions[lookupFunctions[i]] !== 'undefined' ) {
						addedFunctions[lookupFunctions[i]] = $.grep(addedFunctions[lookupFunctions[i]], function(val) {
							return val != configKey;
						});
						
						if ( addedFunctions[lookupFunctions[i]].length == 0 ) {
							delete addedFunctions[lookupFunctions[i]];
						}
					}
				}
			}
		}
		
		self.toggleFunctionTab();
	};
	
	self.toggleFunctionTab = function() {
		setTimeout(function() {
			if ( !$.isEmptyObject(addedFunctions) ) {
				$('#channelProperties a[href="#lookupTab"]').closest('li').removeClass('hidden');
				
				$('#luFuncTabs a[data-toggle]').each(function() {
					var tabId = $(this).attr('href');
					var fId = tabId.replace('#tab_', '$');
					if ( addedFunctions[fId] ) {
						$(this).closest('li').removeClass('hidden');
					} else {
						$(this).closest('li').addClass('hidden');
						$(tabId).find('input.saxtmpl-val').val('');
						$(tabId).find('select.saxtmpl-val').find('option:first').prop('selected', true).end().trigger('change');
						$(tabId).find('input[type="checkbox"]').prop('checked', false).trigger('change');
					}
				});
				
				$('#luFuncTabs > li:not(.hidden):first a').trigger('click');
			} else {
				$('#channelProperties a[href="#lookupTab"]').closest('li').addClass('hidden');
				$('#lookupTab').find('input.saxtmpl-val').val('');
				$('#lookupTab').find('select.saxtmpl-val').find('option:first').prop('selected', true).end().trigger('change');
				$('#lookupTab').find('input[type="checkbox"]').prop('checked', false).trigger('change');
			}
		}, 300);
	};
	
	self.saveLookupFunctions = function() {
		var data = [], expfldlst = [], funcName, funcClass, arguments;
		var reg = new RegExp("@\\{(.*?)\\}");
		
		$('#configRows .config-row').each(function() {
			var configKey = $(this).find('input.config-key').val();
			var configVal = $(this).find('input.config-value').val();
			if ( reg.test(configVal) ) {
				expfldlst.push(configKey);
			}
		});

		$('#addConFldDiv .config-row').each(function() {
			var configKey = $(this).find('input.config-key').val();
			var configVal = $(this).find('input.config-value').val();
			if ( reg.test(configVal) ) {
				expfldlst.push(configKey);
			}
		});
		
		$('.saxtmpl-row').each(function() {
			var configKey = $(this).find('.saxtmpl-key').val();
			var configVal = $(this).find('.saxtmpl-val').val();
			if ( reg.test(configVal) ) {
				expfldlst.push(configKey);
			}
		});

		$('.saxtmpl-row').each(function() {
			var configKey = $(this).find('select.saxtmpl-key').val();
			var configVal = $(this).find('.saxtmpl-val').val();
			if ( reg.test(configVal) ) {
				expfldlst.push(configKey);
			}
		});
		
		$.each(addedFunctions, function(func, arr) {
			expfldlst = $.merge(expfldlst, arr);
		});
		expfldlst = DFSubSytemDefination.unique(expfldlst);
		
		$('#luFuncContent > .tab-pane').each(function() {
			funcName = $(this).find('input[type="hidden"][name="functionName"]').val();
			funcClass = $(this).find('input[type="hidden"][name="funcClass"]').val();
			arguments = $(this).find('input[type="hidden"][name="argument"]').val();
			var udfcachekeyTemp = $(this).find('.saxtmpl-val.cachingEnabled').val();
			var tmplData = SAXTemplate.getTemplateData( $(this) );
			tmplData.funcName = funcName;
			tmplData.funcClass = funcClass;
			tmplData.arguments = arguments;
			
			if ( $.inArray(funcName, cacheFunctions) > -1 ) {
				$.each(addedFunctions, function(func, arr) {
					func = func.replace('$', '');
					if ( func == funcName && udfcachekeyTemp == 'true' ) {
						tmplData['udfcachekey'] = arr.join(',');
					}
				});
			}
			
			data.push(tmplData);
		});
		
		expfldlst = $.grep(expfldlst,function(n){ return(n) });
		return {
			'mvelfnclist': JSON.stringify(data),
			'expfldlst': expfldlst.join(',')
		};
	};
	
	self.removeExtraTabs = function() {
		$('#luFuncTabs a[data-toggle]').each(function() {
			var tabId = $(this).attr('href');
			var fId = tabId.replace('#tab_', '$');
			if ( typeof addedFunctions[fId] === 'undefined' ) {
				$(tabId).remove();
			}
		});
	};

	self.getLookupData = function(curComp) {
		for ( var i=0; i<curComp.config.length; i++ ) {
			var configLen = curComp.config[i].length;
			var colonIdx = curComp.config[i].indexOf(":");
			var configKey = curComp.config[i].substring(0, colonIdx);
			var configVal = curComp.config[i].substring(colonIdx+1, configLen).trim();
			if ( configKey == 'mvelfnclist' ) {
				var mvelfncData = JSON.parse(configVal);
				if ( mvelfncData.length > 0 ) {
					for ( var j=0; j<mvelfncData.length; j++ ) {
						var obj = mvelfncData[j];
						var funcName = obj.funcName;
						lookupData[funcName] = obj;
					}
				}
			}
		}
	};
	self.addEvents();
};

// Persister functionality
var persisterIndexerClass = new function() {
	var self = this;
	var tempJSON = {};
	tempJSON['connectionJson'] = {};
	var labelPopoverString = "";
	self.init = function( curChnl ) {
		var persisterConfigTab = '<li><a href="#persisterConfigTab1" data-toggle="tab"> '+i18N['sax.configuration']+'</a></li> ';
		var persisterConfigTabContent = '<div class="tab-pane" id="persisterConfigTab1"><div class="row margin-bs"><div class="col-md-2 control-label">'+i18N['sax.label.connection']+' <span class="req">*</span> </div><div class="col-md-9 margin-bm margin-ts margin-ls action-wrap" id="connectionFld"><label id="connectionText" data-toggle="popover" class="pull-left po connection-text margin-rs margin-lm"></label><a class="add-ico tt margin-rm" id="addNewConn" href="javascript: void(0)" data-original-title=""> <i class="fa"></i></a></div><div class="col-md-1"></div></div><div class="row"><div class="col-md-2 control-label">'+i18N['sax.label.config']+' <span class="req">*</span> </div><div class="col-md-10" id="persisterConfigContent"></div></div></div></div>';
		if ( curChnl.id == cmpIDs.activemqchannel || curChnl.id == cmpIDs.kafkachannel || curChnl.id == cmpIDs.rabbitmqchannel || curChnl.id == cmpIDs.replaychannel ) {
			$('#channelProperties > .nav.nav-tabs').find('a[href="#configTab11"]').closest('li').before( persisterConfigTab );
		} else {
			$('#channelProperties > .nav.nav-tabs').find('a[href="#configTab26"]').closest('li').before( persisterConfigTab );
			$('#channelProperties > .nav.nav-tabs').find('a[href="#configTab21"]').closest('li').remove();
		}
		
		$('#channelProperties > .tab-content').prepend( persisterConfigTabContent );
		persisterClass.connectionCount(curChnl.id);
		$("#persisterConfigContent").append( $('#configRows') );
		if ( curChnl.id == cmpIDs.hdfsemitter ) {
			$('.select-all-fields').closest('label').addClass('margin-lm-m');
		}
		$("#persisterConfigContent").append('<input type="hidden" id="selectConnObj" name="selectConnObj" class="config-value select-conn-obj" />');
		
		$('#regnSplitDefWrap').find('.col-sm-6:nth-child(2)').find('.radio-inline:nth-child(2) label').addClass('margin-lm-m');
		$('#batchEnableSelector').select2("destroy").select2({placeholder: i18N['sax.placeholder.pleaseSelect']});	
		for ( var i=0; i<curChnl.config.length; i++ ) {
			var configLen = curChnl.config[i].length;
			var colonIdx = curChnl.config[i].indexOf(":");
			configKey = curChnl.config[i].substring(0, colonIdx);
			configVal = curChnl.config[i].substring(colonIdx+1, configLen).trim();
			if ( curChnl.id == cmpIDs.hbaseemitter ) {
				if ( configKey == "zkHosts" ) 
					tempJSON.connectionJson["zkHosts"] = configVal;
					
				if ( configKey == "zkPort" )
					tempJSON.connectionJson["zkPort"]  = configVal; 
					
				if ( configKey == "connectionId" )
					tempJSON["connectionId"]  = configVal;
				
				if ( configKey == "hdfsUser" )
					tempJSON.connectionJson["hdfsUser"]  = configVal;
					
				if ( configKey == "zkRecoveryRetry" )
					tempJSON.connectionJson["zkRecoveryRetry"]  = configVal;
				
				if ( configKey == "zkParentNode" )
					tempJSON.connectionJson["zkParentNode"]  = configVal;
					
				if ( configKey == "clientRetriesNumber" )
					tempJSON.connectionJson["clientRetriesNumber"]  = configVal;
					
				if ( configKey == "connectionName" ) {
					tempJSON["connectionName"]  = configVal;
					if(configVal != "")
						$('#connectionText').text(configVal);
				}
			} else if ( curChnl.id == cmpIDs.kafkachannel || curChnl.id == cmpIDs.kafkaemitter ) {
							if ( configKey == "zkHosts" ) 
					tempJSON.connectionJson["zkHosts"] = configVal;
				
				if ( configKey == "kafkaBrokers" ) 
					tempJSON.connectionJson["kafkaBrokers"] = configVal;
				
				if ( configKey == "connectionRetries" )
					tempJSON.connectionJson["connectionRetries"]  = configVal;
				
				if ( configKey == "connectionId" )
					tempJSON["connectionId"]  = configVal;
					
				if ( configKey == "connectionName" ) {
					tempJSON["connectionName"]  = configVal;
					if(configVal != "")
						$('#connectionText').text(configVal);
				}
			} else if ( curChnl.id == cmpIDs.cassandraemitter || curChnl.id == cmpIDs.rabbitmqchannel || curChnl.id == cmpIDs.rabbitmqemitter || curChnl.id == cmpIDs.activemqchannel || curChnl.id == cmpIDs.activemqemitter || curChnl.id == cmpIDs.replaychannel ) {
				if ( configKey == "hosts" ) 
					tempJSON['connectionJson']["hosts"] = configVal;
				
				if ( curChnl.id == cmpIDs.cassandraemitter && configKey == "connectionRetries" ) 
					tempJSON['connectionJson']["connectionRetries"] = configVal;
				
				if ( configKey == "username" ) 
					tempJSON['connectionJson']["username"] = configVal;
				
				if ( configKey == "password" ) 
					tempJSON['connectionJson']["password"] = configVal;
					
				if ( configKey == "connectionId" )
					tempJSON["connectionId"]  = configVal;
					
				if ( configKey == "connectionName" ) {
					tempJSON["connectionName"]  = configVal;
					if(configVal != "")
						$('#connectionText').text(configVal);
				}
			} else if ( curChnl.id == cmpIDs.solremitter ) {
				if ( configKey == "zkHosts" ) 
					tempJSON['connectionJson']["zkHosts"] = configVal;
					
				if ( configKey == "connectionId" )
					tempJSON["connectionId"]  = configVal;
					
				if ( configKey == "connectionName" ) {
					tempJSON["connectionName"]  = configVal;
					if(configVal != "")
						$('#connectionText').text(configVal);
				}
			} else if ( curChnl.id == cmpIDs.elasticsearchemitter ) {
				if ( configKey == "hosts" ) 
					tempJSON['connectionJson']["hosts"] = configVal;
				
				if ( configKey == "clusterName" ) 
					tempJSON['connectionJson']["clusterName"] = configVal;
					
				if ( configKey == "connectionId" )
					tempJSON["connectionId"]  = configVal;
					
				if ( configKey == "connectionName" ) {
					tempJSON["connectionName"]  = configVal;
					if(configVal != "")
						$('#connectionText').text(configVal);
				}
			} else if ( curChnl.id == cmpIDs.hdfsemitter ) {
				if ( configKey == "fsURI" ) 
					tempJSON['connectionJson']["fsURI"] = configVal;
				
				if ( configKey == "username" ) 
					tempJSON['connectionJson']["username"] = configVal;
				
				if ( configKey == "haEnabled" ) 
					tempJSON['connectionJson']["haEnabled"] = configVal;
				
				if ( configKey == "nameservices" && configVal != "" ) 
					tempJSON['connectionJson']["nameservices"] = configVal;
				
				if ( configKey == "namenode1Name" && configVal != "" ) 
					tempJSON['connectionJson']["namenode1Name"] = configVal;
				
				if ( configKey == "namenode1RPCAddress" && configVal != "" ) 
					tempJSON['connectionJson']["namenode1RPCAddress"] = configVal;
				
				if ( configKey == "namenode2Name" && configVal != "" ) 
					tempJSON['connectionJson']["namenode2Name"] = configVal;
				
				if ( configKey == "namenode2RPCAddress" && configVal != "" ) 
					tempJSON['connectionJson']["namenode2RPCAddress"] = configVal;
				
				if ( configKey == "rotationPolicy" ) 
					tempJSON['connectionJson']["rotationPolicy"] = configVal;
				
				if ( configKey == "fileRotationTime" ) 
					tempJSON['connectionJson']["fileRotationTime"] = configVal;
					
				if ( configKey == "fileRotationSize" ) 
					tempJSON['connectionJson']["fileRotationSize"] = configVal;
					
				if ( configKey == "connectionId" )
					tempJSON["connectionId"]  = configVal;
					
				if ( configKey == "connectionName" ) {
					tempJSON["connectionName"]  = configVal;
					if(configVal != "")
						$('#connectionText').text(configVal);
				}
			}				
		}
		if ( !$.isEmptyObject(tempJSON) ) {
			$('#selectConnObj').val('');
			$('#selectConnObj').val(JSON.stringify(tempJSON));
			tempJSON = {};
			tempJSON['connectionJson'] = {};
		}
		self.displayLabelData();
			

		/*$(document).on('click', '#editSelectdCon', function() {
			if ( $('a[href="#persisterTab1"]').size() == 0 ) {
				persisterClass.createConnTab( curChnl );
			}
			$('a[href="#persisterTab1"]').trigger('click');
			$('#addConnectionLink').closest('.modal-body').siblings('.modal-footer').find('button#saveChannelProp').addClass('disabled');
			$('#editChkCon').trigger('click');
		}); */
		
		$(document).on('click', '#addNewConn', function() {
			setTimeout(function(){
				$('a[href="#persisterTab1"]').closest('li').siblings().find('a').removeAttr('data-toggle');
				$('a[href="#persisterTab1"]').closest('li').siblings().find('a').addClass('disabled');
			},100);
			
			if ( $('a[href="#persisterTab1"]').size() == 0 ) {
				persisterClass.createConnTab( curChnl );
				if ( addedConnListData.length == 0 ) 
					$('#addConLink').trigger('click');
			}
			$('a[href="#persisterTab1"]').trigger('click');
			$('#addConnectionLink').closest('.modal-body').siblings('.modal-footer').find('button#saveChannelProp').addClass('disabled');
		});
		
		$('[data-toggle="popover"]').popover({
				html: true,
				trigger: 'hover',
				placement: 'right',
				content: function () {
					return labelPopoverString;
				}
		});
		
		$('#channelProperties > .nav.nav-tabs').find('li:first a').trigger('click');
		
	};
	
	self.displayLabelData = function() {
		labelPopoverString = '';
		var curChnlId = $('#curChannelId').val();
		if ( $('#connectionText').text() != i18N['sax.label.selectConnection'] && $('#connectionText').text() != i18N['sax.label.addConnection'] ) {
			if ( $('#selectConnObj').val() != "" && typeof $('#selectConnObj').val() != 'undefined' ) {
				var labelObj = {};
				var labelObj = JSON.parse($('#selectConnObj').val());
				$.each( labelObj, function( key, val) {
					if (key == "connectionJson"){
							if ( typeof val == 'string' )
								val = JSON.parse(val);
							$.each( val, function( K, V) {
								if (  K != 'connectionName' && K != 'connectionId' && K != 'password'  ) {
									K = ( K == 'zkHosts' ) ? i18N['sax.label.zkHosts'] : K;
									K = ( K == 'kafkaBrokers' ) ? i18N['sax.label.kafkaBrokers'] : K;
									K = ( K == 'zkPort' ) ? i18N['sax.label.zkPort'] : K;
									K = ( K == 'hdfsUser' ) ? i18N['sax.label.hdfsUser'] : K;
									K = ( K == 'hosts' ) ? i18N['sax.host'] : K;
									K = ( K == 'username' ) ? i18N['sax.label.lookupUserName'] : K;
									K = ( K == 'fsURI' ) ? i18N['sax.label.fsuri'] : K;
									K = ( K == 'haEnabled' ) ? i18N['sax.label.haEnable'] : K;
									K = ( K == 'clusterName' ) ? i18N['sax.label.clstrName'] : K;
									
									labelPopoverString += '<span>'+K+': '+V+'</span><br>';
								}
							});
					}
				});
			}
		}
	}
	
};

var persisterClass = new function( curChnl ) {
	var self = this;
	var dTable,selectedConnName;
	var allAddedConnUrl = '',conTable, componentConnUrl='', curChnlId='', currFuncDataObj='', allAddConnUrl = '';
	var dbObj = curChnl;
	var tempConnectionName = '';
	
	self.persisterMap = {
		hbase:[
			{
				"key" : i18N['sax.label.ConnectionId'],
				"type" : "text",
				"class": "persister-connectionID",
				"dataKey": "connectionId",
				"wraperId": "connectionIDWrap",
				"uiid": "hbase-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.label.createConnName'],
				"type" : "text",
				"validation": "data-parsley-required='true' data-parsley-connNameVal='' data-parsley-maxlength='60' ",
				"class": "persister-connName",
				"dataKey": "connectionName",
				"wraperId": "connNameWrap",
				"placeholder": i18N['sax.placeholder.enterConnName'],
				"uiid": "hbase-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.label.hdfsUser'],
				"type" : "text",
				"validation": "data-parsley-required='true'",
				"class": "persister-hdfsUser",
				"dataKey": "hdfsUser",
				"wraperId": "hdfsUserWrap",
				"placeholder": "",
				"uiid": "hbase-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.label.zkHosts'],
				"type" : "textarea",
				"validation": "data-parsley-required='true' data-parsley-hostVal='' data-parsley-sameIPVal=''",
				"class": "persister-zkHosts",
				"dataKey": "zkHosts",
				"wraperId": "zkhostsWrap",
				"placeholder": i18N['sax.placeholder.enterzkHost'],
				"uiid": "hbase-emitter"
			},
			{
				"key" : i18N['sax.label.zkPort'],
				"type" : "text",
				"validation": 'data-parsley-required="true" data-parsley-pattern="^[0-9]{1,5}$" data-parsley-pattern-message="'+ i18N['sax.parsley.portValMsg'] + '" ',
				"class": "persister-zk-port",
				"dataKey": "zkPort",
				"wraperId": "zkPortWrap",
				"placeholder": "2181",
				"uiid": "hbase-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.label.zkRecoveryRetry'],
				"type" : "text",
				"validation": 'data-parsley-required="true"',
				"class": "persister-zk-recoveryRetry",
				"dataKey": "zkRecoveryRetry",
				"wraperId": "zkRecoveryRetryWrap",
				"placeholder": "",
				"uiid": "hbase-emitter",
				"value":1
			},
			{
				"key" : i18N['sax.label.zkParentNode'],
				"type" : "text",
				"validation": 'data-parsley-required="true"',
				"class": "persister-zk-parentNode",
				"dataKey": "zkParentNode",
				"wraperId": "zkParentNodeWrap",
				"placeholder": "",
				"uiid": "hbase-emitter",
				"value":'/hbase'
			},
			{
				"key" : i18N['sax.label.clientRetriesNumber'],
				"type" : "text",
				"validation": 'data-parsley-required="true"',
				"class": "persister-zk-clientRetriesNumber",
				"dataKey": "clientRetriesNumber",
				"wraperId": "clientRetriesNumberWrap",
				"placeholder": "",
				"uiid": "hbase-emitter",
				"value":1
			}
		],
		kafka:[
			{
				"key" : i18N['sax.label.ConnectionId'],
				"type" : "text",
				"class": "persister-connectionID",
				"dataKey": "connectionId",
				"wraperId": "connectionIDWrap",
				"uiid": "kafka-channel",
				"value":''
			},
			{
				"key" : i18N['sax.label.createConnName'],
				"type" : "text",
				"validation": "data-parsley-required='true' data-parsley-connNameVal='' data-parsley-maxlength='60' ",
				"class": "persister-connName",
				"dataKey": "connectionName",
				"wraperId": "connNameWrap",
				"placeholder": i18N['sax.placeholder.enterConnName'],
				"uiid": "kafka-channel",
				"value":''
			},
			{
				"key" : i18N['sax.label.zkHosts'],
				"type" : "textarea",
				"validation": "data-parsley-required='true' data-parsley-hostPortVal='' data-parsley-sameIPVal=''",
				"class": "persister-zkHosts",
				"dataKey": "zkHosts",
				"wraperId": "zkhostsWrap",
				"placeholder": i18N['sax.placeholder.enterKafkaHost'],
				"uiid": "kafka-channel"
			},
			{
				"key" : i18N['sax.label.kafkaBrokers'],
				"type" : "textarea",
				"validation": "data-parsley-required='true' data-parsley-hostPortVal='' data-parsley-sameIPVal=''",
				"class": "persister-kafkaBrokers",
				"dataKey": "kafkaBrokers",
				"wraperId": "kafkaBrokersWrap",
				"placeholder": i18N['sax.placeholder.kafkaBrokers'],
				"uiid": "kafka-channel"
			}
		],
		rabbitmq:[
			{
				"key" : i18N['sax.label.ConnectionId'],
				"type" : "text",
				"class": "persister-connectionID",
				"dataKey": "connectionId",
				"wraperId": "connectionIDWrap",
				"uiid": "rabbitmq-channel",
				"value":''
			},
			{
				"key" : i18N["sax.label.createConnName"],
				"type" : "text",
				"validation": "data-parsley-required='true' data-parsley-connNameVal='' data-parsley-maxlength='60' ",
				"class": "persister-connName",
				"dataKey": "connectionName",
				"wraperId": "connNameWrap",
				"placeholder":i18N['sax.placeholder.enterConnName'],
				"uiid": "rabbitmq-channel",
				"value":''
			},
			{
				"key" : i18N['sax.host'],
				"type" : "textarea",
				"validation": "data-parsley-required='true' data-parsley-hostPortVal='' data-parsley-sameIPVal='' ",
				"class": "persister-hosts",
				"dataKey": "hosts",
				"wraperId": "hostWrap",
				"placeholder":i18N['sax.placeholder.enterRabbitMQHost'],
				"uiid": "rabbitmq-channel"
			},
			{
				"key" : i18N['sax.label.lookupUserName'],
				"type" : "text",
				"validation": "data-parsley-required='true'",
				"class": "persister-username",
				"dataKey": "username",
				"wraperId": "userNameWrap",
				"placeholder": i18N['sax.placeholder.enterLoginName'],
				"uiid": "rabbitmq-channel",
				"value":''
			},
			{
				"key" : i18N['sax.label.password'],
				"type" : "password",
				"validation": "data-parsley-required='true'",
				"class": "persister-password",
				"dataKey": "password",
				"wraperId": "passwordWrap",
				"placeholder": i18N['sax.placeholder.enterPassoword'],
				"uiid": "rabbitmq-channel",
				"value":''
			}
		],
		activemq:[
			{
				"key" : i18N['sax.label.ConnectionId'],
				"type" : "text",
				"class": "persister-connectionID",
				"dataKey": "connectionId",
				"wraperId": "connectionIDWrap",
				"uiid": "activemq-channel",
				"value":''
			},
			{
				"key" : i18N["sax.label.createConnName"],
				"type" : "text",
				"validation": "data-parsley-required='true' data-parsley-connNameVal='' data-parsley-maxlength='60' ",
				"class": "persister-connName",
				"dataKey": "connectionName",
				"wraperId": "connNameWrap",
				"placeholder":i18N['sax.placeholder.enterConnName'],
				"uiid": "activemq-channel",
				"value":''
			},
			{
				"key" : i18N['sax.host'],
				"type" : "textarea",
				"validation": "data-parsley-required='true' data-parsley-hostPortVal='' data-parsley-sameIPVal='' ",
				"class": "persister-hosts",
				"dataKey": "hosts",
				"wraperId": "hostWrap",
				"placeholder":i18N['sax.placeholder.enterActiveMQHost'],
				"uiid": "activemq-channel"
			},
			{
				"key" : i18N['sax.label.lookupUserName'],
				"type" : "text",
				"validation": "data-parsley-required='true'",
				"class": "persister-username",
				"dataKey": "username",
				"wraperId": "userNameWrap",
				"placeholder": i18N['sax.placeholder.enterLoginName'],
				"uiid": "activemq-channel",
				"value":''
			},
			{
				"key" : i18N['sax.label.password'],
				"type" : "password",
				"validation": "data-parsley-required='true'",
				"class": "persister-password",
				"dataKey": "password",
				"wraperId": "passwordWrap",
				"placeholder": i18N['sax.placeholder.enterPassoword'],
				"uiid": "activemq-channel",
				"value":''
			}
		],
		cassandra:[
			{
				"key" : i18N['sax.label.ConnectionId'],
				"type" : "text",
				"class": "persister-connectionID",
				"dataKey": "connectionId",
				"wraperId": "connectionIDWrap",
				"uiid": "cassandra-emitter",
				"value":''
			},
			{
				"key" : i18N["sax.label.createConnName"],
				"type" : "text",
				"validation": "data-parsley-required='true' data-parsley-connNameVal='' data-parsley-maxlength='60' ",
				"class": "persister-connName",
				"dataKey": "connectionName",
				"wraperId": "connNameWrap",
				"placeholder":i18N['sax.placeholder.enterConnName'],
				"uiid": "cassandra-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.host'],
				"type" : "textarea",
				"validation": "data-parsley-required='true' data-parsley-hostPortVal='' data-parsley-sameIPVal='' ",
				"class": "persister-hosts",
				"dataKey": "hosts",
				"wraperId": "hostWrap",
				"placeholder":i18N['sax.placeholder.enterCassHost'],
				"uiid": "cassandra-emitter"
			},
			{
				"key" : i18N['sax.label.connectionRetries'],
				"type" : "text",
				"validation": "data-parsley-required='true'",
				"class": "persister-connectionRetries",
				"dataKey": "connectionRetries",
				"wraperId": "connectionRetriesWrap",
				"placeholder":'',
				"uiid": "cassandra-emitter",
				"value":300
			},
			{
				"key" : i18N['sax.label.authEnabled'],
				"type" : "checkbox",
				"validation": "",
				"class": "persister-authenticate",
				"dataKey": "authenticate",
				"wraperId": "authenticateWrap",
				"placeholder":"",
				"uiid": "cassandra-emitter",
				"value": "false"
			},
			{
				"key" : i18N['sax.label.lookupUserName'],
				"type" : "text",
				"validation": "",
				"class": "persister-username",
				"dataKey": "username",
				"wraperId": "userNameWrap",
				"placeholder": i18N['sax.placeholder.enterLoginName'],
				"uiid": "cassandra-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.label.password'],
				"type" : "password",
				"validation": "",
				"class": "persister-password",
				"dataKey": "password",
				"wraperId": "passwordWrap",
				"placeholder": i18N['sax.placeholder.enterPassoword'],
				"uiid": "cassandra-emitter",
				"value":''
			}
		],
		solr:[
			{
				"key" : i18N['sax.label.ConnectionId'],
				"type" : "text",
				"class": "persister-connectionID",
				"dataKey": "connectionId",
				"wraperId": "connectionIDWrap",
				"uiid": "solr-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.label.createConnName'],
				"type" : "text",
				"validation": "data-parsley-required='true' data-parsley-connNameVal='' data-parsley-maxlength='60' ",
				"class": "persister-connName",
				"dataKey": "connectionName",
				"wraperId": "connNameWrap",
				"placeholder": i18N['sax.placeholder.enterConnName'],
				"uiid": "solr-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.label.zkHosts'],
				"type" : "textarea",
				"validation": "data-parsley-required='true' data-parsley-hostPortVal='' data-parsley-sameIPVal=''",
				"class": "persister-zkHosts",
				"dataKey": "zkHosts",
				"wraperId": "zkHostsWrap",
				"placeholder": i18N['sax.placeholder.enterzkHost'],
				"uiid": "solr-emitter"
			}
		],
		elasticsearch:[
			{
				"key" : i18N['sax.label.ConnectionId'],
				"type" : "text",
				"class": "persister-connectionID",
				"dataKey": "connectionId",
				"wraperId": "connectionIDWrap",
				"uiid": "elasticsearch-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.label.createConnName'],
				"type" : "text",
				"validation": "data-parsley-required='true' data-parsley-connNameVal='' data-parsley-maxlength='60' ",
				"class": "persister-connName",
				"dataKey": "connectionName",
				"wraperId": "connNameWrap",
				"placeholder": i18N['sax.placeholder.enterConnName'],
				"uiid": "solr-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.label.clstrName'],
				"type" : "text",
				"validation": "data-parsley-required='true'",
				"class": "persister-connName",
				"dataKey": "clusterName",
				"wraperId": "clusterNameWrap",
				"placeholder":i18N['sax.placeholder.clstrName'],
				"uiid": "elasticsearch-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.host'],
				"type" : "textarea",
				"validation": "data-parsley-required='true' data-parsley-hostPortVal='' data-parsley-sameIPVal=''",
				"class": "persister-hosts",
				"dataKey": "hosts",
				"wraperId": "hostWrap",
				"placeholder":i18N['sax.placeholder.enterESHost'],
				"uiid": "elasticsearch-emitter"
			}
		],
		hdfs:[
			{
				"key" : i18N['sax.label.ConnectionId'],
				"type" : "text",
				"class": "persister-connectionID",
				"dataKey": "connectionId",
				"wraperId": "connectionIDWrap",
				"uiid": "elasticsearch-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.label.createConnName'],
				"type" : "text",
				"validation": "data-parsley-required='true' data-parsley-connNameVal='' data-parsley-maxlength='60' ",
				"class": "persister-connName",
				"dataKey": "connectionName",
				"wraperId": "connNameWrap",
				"placeholder": i18N['sax.placeholder.enterConnName'],
				"uiid": "solr-emitter",
				"value":''
			},
			{
				"key" : i18N['sax.label.fsuri'],
				'type': 'text',
				"validation": "data-parsley-required='true' data-parsley-pattern='^[a-zA-Z]+(:\/\/)+(((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))|([A-Za-z0-9]+((\.?[A-Za-z0-9])|(\-?[A-Za-z0-9]))*[A-Za-z0-9]+))+(|([:][0-9]{1,5}))$' data-parsley-pattern-message='"+ i18N['sax.label.parsley.pattern'] +"'",
				"class": "hdfs-fsURI",
				"dataKey": "hdfsFSURIId",
				"wraperId": "hdfsFSURIIDWrap",
				"uiid": "hdfs-emitter",
				"placeholder":"",
				"value":''
			},
			{
				"key" : i18N['sax.label.lookupUserName'],
				'type': 'text',
				"validation": "data-parsley-required='true' data-parsley-pattern='^[a-zA-Z0-9]+$' data-parsley-pattern-message='"+ i18N['sax.label.parsley.alphanum'] +"'",
				"class": "hdfs-username",
				"dataKey": "hdfsUsernameId",
				"wraperId": "hdfsUsernameIDWrap",
				"uiid": "hdfs-emitter",
				"placeholder":"",
				"value":''
			},
			{
				"key" : i18N['sax.label.haEnable'],
				'type': 'checkbox',
				"class": "hdfs-enableHA",
				"dataKey": "hdfsEnableHAId",
				"wraperId": "hdfsEnableHAIDWrap",
				"uiid": "hdfs-emitter",
				"value": "false"
			},
			{
				"key" : i18N['sax.label.nameserviceID'],
				'type': 'text',
				"validation": "data-parsley-pattern='^[a-zA-Z0-9]+$' data-parsley-pattern-message='"+ i18N['sax.label.parsley.alphanum'] +"'",
				"class": "hdfs-nameServices",
				"dataKey": "hdfsNameServicesId",
				"wraperId": "hdfsNameServicesIDWrap",
				"uiid": "hdfs-emitter",
				"placeholder":"",
				"value":''
			},
			{
				"key" : i18N['sax.label.NameNodeID1'],
				'type': 'text',
				"validation": "data-parsley-pattern='^[a-zA-Z0-9]+$' data-parsley-pattern-message='"+ i18N['sax.label.parsley.alphanum'] +"'",
				"class": "hdfs-namenode1Name",
				"dataKey": "hdfsNameNode1NameId",
				"wraperId": "hdfsNameNode1NameIDWrap",
				"uiid": "hdfs-emitter",
				"placeholder":"",
				"value":''
			},
			{
				"key" : i18N['sax.label.NameNode1RPCAdd'],
				'type': 'text',
				"validation": "data-parsley-pattern='^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))+([:][0-9]{1,5})$' data-parsley-pattern-message='"+ i18N['sax.label.parsley.pattern'] +"'",
				"class": "hdfs-namenode1RPCAddress",
				"dataKey": "hdfsNamenode1RPCAddressId",
				"wraperId": "hdfsNamenode1RPCAddressIDWrap",
				"uiid": "hdfs-emitter",
				"placeholder":"",
				"value":''
			},
			{
				"key" : i18N['sax.label.NameNodeID2'],
				'type': 'text',
				"validation": "data-parsley-pattern='^[a-zA-Z0-9]+$' data-parsley-pattern-message='"+ i18N['sax.label.parsley.alphanum'] +"'",
				"class": "hdfs-namenode2Name",
				"dataKey": "hdfsNameNode2NameId",
				"wraperId": "hdfsNameNode2NameIDWrap",
				"uiid": "hdfs-emitter",
				"placeholder":"",
				"value":''
			},
			{
				"key" : i18N['sax.label.NameNode2RPCAdd'],
				'type': 'text',
				"validation": "data-parsley-pattern='^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))+([:][0-9]{1,5})$' data-parsley-pattern-message='"+ i18N['sax.label.parsley.pattern'] +"'",
				"class": "hdfs-namenode2RPCAddress",
				"dataKey": "hdfsNamenode2RPCAddressId",
				"wraperId": "hdfsNamenode2RPCAddressIDWrap",
				"uiid": "hdfs-emitter",
				"placeholder":"",
				"value":''
			}
		]
	};
	
	self.init = function() {		
		$(document).on('click', '#addConLink', function() {
			$('#channelErrorWrap').empty();
			var curChnlId = $('#curChannelId').val();
			$('#connectionName').removeAttr('disabled');
			switch ( curChnlId ) {
			
				case cmpIDs.hbaseemitter:
					currFuncDataObj = self.persisterMap["hbase"];
					break;
				
				case cmpIDs.cassandraemitter:
					currFuncDataObj = self.persisterMap["cassandra"];
					break;
				
				case cmpIDs.rabbitmqchannel:
					currFuncDataObj = self.persisterMap["rabbitmq"];
					break;
				
				case cmpIDs.replaychannel:
					var srcSelected = $('input[name="replaySrc"]:checked').val();
					currFuncDataObj = self.persisterMap[srcSelected];
					break;
				
				case cmpIDs.rabbitmqemitter:
					currFuncDataObj = self.persisterMap["rabbitmq"];
					break;
				
				case cmpIDs.activemqchannel:
					currFuncDataObj = self.persisterMap["activemq"];
					break;
				
				case cmpIDs.activemqemitter:
					currFuncDataObj = self.persisterMap["activemq"];
					break;
				
				case cmpIDs.kafkachannel:
					currFuncDataObj = self.persisterMap["kafka"];
					break;
				
				case cmpIDs.kafkaemitter:
					currFuncDataObj = self.persisterMap["kafka"];
					break;
				
				case cmpIDs.solremitter:
					currFuncDataObj = self.persisterMap["solr"];
					break;
				
				case cmpIDs.elasticsearchemitter:
					currFuncDataObj = self.persisterMap["elasticsearch"];
					break;
				
				case cmpIDs.hdfsemitter:
					currFuncDataObj = self.persisterMap["hdfs"];
					break;
			}
			$('#selectedDBContent').html('');
			$('#selectedDBContent').html('<div class="row"><label class="col-md-12 margin-lxl"><strong>'+i18N["sax.label.createConn"]+'</strong></label></div>');
			for ( var i = 0; i < currFuncDataObj.length; i++ ) {
				var actualHtml = self.createFuncField(currFuncDataObj[i], dbObj);
				$('div#selectedDBContent').append(actualHtml);
				$("select").select2('destroy').select2();
				$('#connectionIDWrap').hide();
				$('#hdfsNameServicesIDWrap, #hdfsNameNode1NameIDWrap, #hdfsNamenode1RPCAddressIDWrap, #hdfsNameNode2NameIDWrap, #hdfsNamenode2RPCAddressIDWrap').hide();
				if ( curChnlId == cmpIDs.cassandraemitter ) {
					$('#userNameWrap, #passwordWrap').hide();
				}
				var createButton = '<div class="row"> <div class="col-md-8 margin-lm"><div class="test-loader hidden" id="testLoader"></div><button id="testConnectionBtn" type="button" class="btn btn-primary add-conn pull-right margin-tm">'+i18N["sax.label.testConnection"]+'</button> <button id="createConnectionBtn" type="button" class="btn btn-primary add-conn pull-right margin-tm margin-ls margin-rs">'+i18N["sax.create"]+'</button> <button id="updateConnectionBtn" type="button" class="btn btn-primary add-conn pull-right margin-tm margin-ls margin-rs hidden">'+i18N["sax.update"]+'</button> <button id="cancelConnectionBtn" type="button" class="btn btn-default cancel-conn pull-right margin-tm">'+i18N['sax.cancel']+'</button> </div></div>';
			}
			$('div#selectedDBContent').append(createButton);
			$('#addConnectionLink').hide();
			$('#connectionSelected').hide();
			$('#persisterTab1 .widget').hide();
			DFSubSytemDefination.initPopovers();
			/*if ( curChnlId == cmpIDs.kafkachannel ) {
				$('#kafkaBrokers').removeAttr('data-parsley-sameipval').removeAttr('data-parsley-hostportval').removeAttr('data-parsley-required');
				$('#kafkaBrokersWrap').hide()
			}*/
		});
		
		$(document).on('change', 'input[name="hdfsEnableHAId"]', function() {
			$('#channelErrorWrap').empty();
			var val = $(this).prop('checked');
			if ( val ) {
				$(this).val('true');
				$('#hdfsNameServicesIDWrap, #hdfsNameNode1NameIDWrap, #hdfsNamenode1RPCAddressIDWrap, #hdfsNameNode2NameIDWrap, #hdfsNamenode2RPCAddressIDWrap').show();
				$('#hdfsNameServicesId, #hdfsNameNode1NameId, #hdfsNamenode1RPCAddressId, #hdfsNameNode2NameId, #hdfsNamenode2RPCAddressId').attr("data-parsley-required", "true");
			} else {
				$('#hdfsNameServicesIDWrap, #hdfsNameNode1NameIDWrap, #hdfsNamenode1RPCAddressIDWrap, #hdfsNameNode2NameIDWrap, #hdfsNamenode2RPCAddressIDWrap').hide();
				$('#hdfsNameServicesId, #hdfsNameNode1NameId, #hdfsNamenode1RPCAddressId, #hdfsNameNode2NameId, #hdfsNamenode2RPCAddressId').removeAttr("data-parsley-required");
				$(this).val('false');
			}
		});
		
		$(document).on('change', 'input[name="authenticate"]', function() {
			$('#channelErrorWrap').empty();
			var val = $(this).prop('checked');
			if ( val ) {
				$(this).val('true');
				$('#userNameWrap, #passwordWrap').show();
				$('#username, #password').attr("data-parsley-required", "true");
				$('#username').val("");
				$('#password').val("");
			} else {
				$(this).val('false');
				$('#userNameWrap, #passwordWrap').hide();
				$('#username, #password').removeAttr("data-parsley-required");
			}
		});
		
		$(document).on('click', '#createConnectionBtn', function() {
			$('#channelErrorWrap').empty();
			var url='';
			var connectionName = '';
			url = componentConnUrl;
			connectionName = $('#connectionName').val();
			url = url+"/"+connectionName+"/save";
			self.saveUpdateData(url);
		});
		
		$(document).on('focus','#connectionName', function(){
			tempConnectionName = "";
			tempConnectionName = $(this).val();
		});
		
		$(document).on('blur','#connectionName', function(){
			var connName = $(this).val();
			if ( tempConnectionName != connName ) {
				var url='';
				var connectionName = '';
				url = componentConnUrl;
				connectionName = connName;
				url = url+"/"+connectionName+"/availability";
				var response = DFSubSytemDefination.postAjaxData( url, '');
				response = JSON.parse(response);
				if ( response.status == "FAILURE")	{
					self.displayAjaxMsg(response);
					$('#createConnectionBtn').attr('disabled',true);
				} else {
					$('#createConnectionBtn').removeAttr('disabled');
				}
				setTimeout(function() { 
					$('#displayResponse').html('');
				}, 5000);
			}
		});
		
		$(document).on('click', '#updateConnectionBtn', function() {
			$('#channelErrorWrap').empty();
			var url='', connectionName = '', connectionId = "";
			url = componentConnUrl;
			connectionName = $('#connectionName').val();
			connectionId = $('#connectionId').val();
			var updateStatus = DFSubSytemDefination.postAjaxData(updateConnStatusUrl,connectionId );
			if ( updateStatus == "" ) {
			url = url+"/"+connectionName+"/update";
			self.saveUpdateData(url);
			} else {
				updateStatus = JSON.parse(updateStatus);
				if ( updateStatus.status == 'STOPPED' ) {
					bootbox.confirm(updateStatus.message, function(confirmation) {
						if (confirmation) {
							url = url+"/"+connectionName+"/update";
							self.saveUpdateData(url);
						} 
					});
				} else if ( updateStatus.status == 'SUCCESS' ) {
					$('#cancelConnectionBtn').trigger('click');
					$('#channelErrorWrap').html('<div class="alert alert-danger" role="alert">'+updateStatus.message+'</div>');
				}
			}
			setTimeout(function() { 
				$('#channelErrorWrap').html('');
			}, 20000);
		});
		
		$(document).on('click', '#testConnectionBtn', function() {
			$('#channelErrorWrap').empty();
			var flag = true, validate = true, response = '';
			var url='', connectionName = '';
			url = componentConnUrl;
			connectionName = $('#connectionName').val();
			url = url+"/"+connectionName+"/test";
			$("#selectedDBContent").find("[data-parsley-required='true']").each(function() {
				flag = $(this).parsley().validate();
				if ( flag != true ) validate = false;
			});
			
			if ( validate ) {
				var connectionData={}, temp={};
				connectionData["connectionJson"] = {};
				var curChnlId = $('#curChannelId').val();
				$("#selectedDBContent").find(".config-value").each(function() {
					temp[$(this).attr('name')] = $(this).val();
				});
				
				connectionData["connectionId"] = temp.connectionId;
				connectionData["connectionName"] = temp.connectionName;
				connectionData["tenantId"] = currentTenantId;
				
				switch ( curChnlId ) {
				
					case cmpIDs.hbaseemitter:
						connectionData["componentType"] = "hbase";
						connectionData.connectionJson["zkHosts"] = temp.zkHosts.replace(/\s/g, '');
						connectionData.connectionJson["zkPort"] = temp.zkPort;
						connectionData.connectionJson["hdfsUser"] = temp.hdfsUser;
						connectionData.connectionJson["zkRecoveryRetry"] = temp.zkRecoveryRetry;
						connectionData.connectionJson["zkParentNode"] = temp.zkParentNode;
						connectionData.connectionJson["clientRetriesNumber"] = temp.clientRetriesNumber;
						break;
					
					case cmpIDs.cassandraemitter:
						connectionData["componentType"] = "cassandra";
						connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
						connectionData.connectionJson["username"] = temp.username;
						connectionData.connectionJson["password"] = temp.password;
						connectionData.connectionJson["connectionRetries"] = temp.connectionRetries;
						break;
					
					case cmpIDs.rabbitmqchannel:
						connectionData["componentType"] = "rabbitmq";
						connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
						connectionData.connectionJson["username"] = temp.username;
						connectionData.connectionJson["password"] = temp.password;
						break;
					
					case cmpIDs.replaychannel:
						var srcSelected = $('input[name="replaySrc"]:checked').val();
						if ( srcSelected == 'rabbitmq' ) {
							connectionData["componentType"] = "rabbitmq";
							connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
							connectionData.connectionJson["username"] = temp.username;
							connectionData.connectionJson["password"] = temp.password;
						} else if ( srcSelected == 'kafka' ) {
							connectionData["componentType"] = "kafka";
							connectionData.connectionJson["zkHosts"] = temp.zkHosts.replace(/\s/g, '');
							connectionData.connectionJson["kafkaBrokers"] = temp.kafkaBrokers.replace(/\s/g, '');
						}
						break;
					
					case cmpIDs.rabbitmqemitter:
						connectionData["componentType"] = "rabbitmq";
						connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
						connectionData.connectionJson["username"] = temp.username;
						connectionData.connectionJson["password"] = temp.password;
						break;
					
					case cmpIDs.activemqchannel:
						connectionData["componentType"] = "activemq";
						connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
						connectionData.connectionJson["username"] = temp.username;
						connectionData.connectionJson["password"] = temp.password;
						break;
					
					case cmpIDs.activemqemitter:
						connectionData["componentType"] = "activemq";
						connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
						connectionData.connectionJson["username"] = temp.username;
						connectionData.connectionJson["password"] = temp.password;
						break;
					
					case cmpIDs.kafkachannel:
						connectionData["componentType"] = "kafka";
						connectionData.connectionJson["zkHosts"] = temp.zkHosts.replace(/\s/g, '');
						connectionData.connectionJson["kafkaBrokers"] = temp.kafkaBrokers.replace(/\s/g, '');
						break;
					
					case cmpIDs.kafkaemitter:
						connectionData["componentType"] = "kafka";
						connectionData.connectionJson["zkHosts"] = temp.zkHosts.replace(/\s/g, '');
						connectionData.connectionJson["kafkaBrokers"] = temp.kafkaBrokers.replace(/\s/g, '');
						break;
						
					case cmpIDs.solremitter:
						connectionData["componentType"] = "solr";
						connectionData.connectionJson["zkHosts"] = temp.zkHosts.replace(/\s/g, '');
						break;
					
					case cmpIDs.elasticsearchemitter:
						connectionData["componentType"] = "elasticsearch";
						connectionData.connectionJson["clusterName"] = temp.clusterName;
						connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
						break;
					
					case cmpIDs.hdfsemitter:
						connectionData["componentType"] = "hdfs";
						connectionData.connectionJson["fsURI"] = temp.hdfsFSURIId;
						connectionData.connectionJson["username"] = temp.hdfsUsernameId;
						connectionData.connectionJson["haEnabled"] = temp.hdfsEnableHAId;
						if ( temp.hdfsEnableHAId == true || temp.hdfsEnableHAId == 'true' ) {
							connectionData.connectionJson["nameservices"] = temp.hdfsNameServicesId;
							connectionData.connectionJson["namenode1Name"] = temp.hdfsNameNode1NameId;
							connectionData.connectionJson["namenode1RPCAddress"] = temp.hdfsNamenode1RPCAddressId;
							connectionData.connectionJson["namenode2Name"] = temp.hdfsNameNode2NameId;
							connectionData.connectionJson["namenode2RPCAddress"] = temp.hdfsNamenode2RPCAddressId;
						}
						break;
				}
				connectionData.connectionJson = JSON.stringify(connectionData.connectionJson);
				connectionData = JSON.stringify(connectionData);
				$('#testLoader').removeClass('hidden');
				setTimeout(function(){
					response = DFSubSytemDefination.postAjaxData( url, connectionData);
					response = JSON.parse(response);
					$('#testLoader').addClass('hidden')
					if ( response.status == "SUCCESS" ) {
						self.displayAjaxMsg(response);
						setTimeout(function() { 
							$('#channelErrorWrap').html('');
						}, 20000);
					} else {
						self.displayAjaxMsg(response);
						setTimeout(function() { 
							$('#channelErrorWrap').html('');
						}, 20000);
					}
				},100);
			}
			setTimeout(function() { 
				$('#channelErrorWrap').html('');
			}, 20000);
		});
		
		$(document).on('click', '#connectionSelected', function() {
			$('#channelErrorWrap').empty();
			var curChnlId = $('#curChannelId').val();
			var selectedConnLabelData = {};
			selectedConnName = $('input[name="subSystemConnection"]:checked').closest('tr').find('td:nth-child(2)').text();
			//self.connectionCount( curChnlId );
			$('#selectConnObj').val('');
			for ( var i = 0; i < addedConnListData.length; i++ ) {
				if ( addedConnListData[i].connectionName == selectedConnName ) {
					$('#selectConnObj').val(JSON.stringify(addedConnListData[i]));
					$('#connectionText').text(selectedConnName);
				}
			}
			selectedConnName = '';
			persisterIndexerClass.displayLabelData();
			$('#addNewConn').find('i').removeClass('fa-plus').addClass('fa-list');
			$('a#addNewConn').removeAttr('data-original-title');
			$('a#addNewConn').attr('data-original-title', i18N['sax.label.selectConnection']);
			$(".tt").tooltip();
			setTimeout(function(){
				$('a[href="#persisterTab1"]').closest('li').siblings().find('a').attr('data-toggle','tab');
				$('a[href="#persisterTab1"]').closest('li').siblings().find('a').removeClass('disabled');
				$('a[href="#persisterConfigTab1"]').trigger('click');
				$('#persisterTab1').remove();
				$('a[href="#persisterTab1"]').closest('li').remove();
				$('.modal-body').siblings('.modal-footer').find('button#saveChannelProp').removeClass('disabled');
			},100);
		});
		
		$(document).on('click', '#editChkCon', function() {
			$('#channelErrorWrap').empty();
			var _this = $(this);
			setTimeout(function() { 
				$("#updateConnectionBtn").removeClass("hidden");
				$('#createConnectionBtn').addClass('hidden');
			},100);
			var curChnlId = $('#curChannelId').val();
			$('#addConLink').trigger('click');
			selectedConnName = _this.closest('tr').find('td:nth-child(2)').text();
			for ( var i = 0; i < addedConnListData.length; i++ ) {
				if ( typeof addedConnListData[i].connectionJson == 'string' )
					addedConnListData[i].connectionJson = JSON.parse(addedConnListData[i].connectionJson);

				if ( addedConnListData[i].connectionName == selectedConnName ) {
					if ( addedConnListData[i].connectionName == 'Default' ) {
						$('#updateConnectionBtn').addClass('disabled');
					} else {
						$('#updateConnectionBtn').removeClass('disabled');
					}
					switch ( curChnlId ) {
					
						case cmpIDs.hbaseemitter:
							$('#connectionName').val(addedConnListData[i].connectionName);
							$('#connectionId').val(addedConnListData[i].connectionId);
							$('#zkHosts').text(addedConnListData[i].connectionJson.zkHosts);
							$('#zkPort').val(addedConnListData[i].connectionJson.zkPort);
							$('#hdfsUser').val(addedConnListData[i].connectionJson.hdfsUser);
							$('#zkRecoveryRetry').val(addedConnListData[i].connectionJson.zkRecoveryRetry);
							$('#zkParentNode').val(addedConnListData[i].connectionJson.zkParentNode);
							$('#clientRetriesNumber').val(addedConnListData[i].connectionJson.clientRetriesNumber);
							break;
						
						case cmpIDs.cassandraemitter:
							$('#connectionName').val(addedConnListData[i].connectionName);
							$('#connectionId').val(addedConnListData[i].connectionId);
							$('#hosts').text(addedConnListData[i].connectionJson.hosts);
							if ( addedConnListData[i].connectionJson.username != "" )
								$('input[name="authenticate"]').trigger('click');
							$('#username').val(addedConnListData[i].connectionJson.username);
							$('#password').val(addedConnListData[i].connectionJson.password);
							$('#connectionRetries').val(addedConnListData[i].connectionJson.connectionRetries);
							
							break;
						
						case cmpIDs.rabbitmqchannel:
							$('#connectionName').val(addedConnListData[i].connectionName);
							$('#connectionId').val(addedConnListData[i].connectionId);
							$('#hosts').text(addedConnListData[i].connectionJson.hosts);
							$('#username').val(addedConnListData[i].connectionJson.username);
							$('#password').val(addedConnListData[i].connectionJson.password);
							break;
						
						case cmpIDs.replaychannel:
							var srcSelected = $('input[name="replaySrc"]:checked').val();
							$('#connectionName').val(addedConnListData[i].connectionName);
							$('#connectionId').val(addedConnListData[i].connectionId);
							if ( srcSelected == "rabbitmq" ) {
								$('#hosts').text(addedConnListData[i].connectionJson.hosts);
								$('#username').val(addedConnListData[i].connectionJson.username);
								$('#password').val(addedConnListData[i].connectionJson.password);
							} else if ( srcSelected == 'kafka' ) {
								$('#zkHosts').text(addedConnListData[i].connectionJson.zkHosts);
								$('#kafkaBrokers').text(addedConnListData[i].connectionJson.kafkaBrokers);
							}
							break;
						
						case cmpIDs.rabbitmqemitter:
							$('#connectionName').val(addedConnListData[i].connectionName);
							$('#connectionId').val(addedConnListData[i].connectionId);
							$('#hosts').text(addedConnListData[i].connectionJson.hosts);
							$('#username').val(addedConnListData[i].connectionJson.username);
							$('#password').val(addedConnListData[i].connectionJson.password);
							break;
						
						case cmpIDs.activemqchannel:
							$('#connectionName').val(addedConnListData[i].connectionName);
							$('#connectionId').val(addedConnListData[i].connectionId);
							$('#hosts').text(addedConnListData[i].connectionJson.hosts);
							$('#username').val(addedConnListData[i].connectionJson.username);
							$('#password').val(addedConnListData[i].connectionJson.password);
							break;
						
						case cmpIDs.activemqemitter:
							$('#connectionName').val(addedConnListData[i].connectionName);
							$('#connectionId').val(addedConnListData[i].connectionId);
							$('#hosts').text(addedConnListData[i].connectionJson.hosts);
							$('#username').val(addedConnListData[i].connectionJson.username);
							$('#password').val(addedConnListData[i].connectionJson.password);
							break;
						
						case cmpIDs.kafkachannel:
							$('#connectionName').val(addedConnListData[i].connectionName);
							$('#connectionId').val(addedConnListData[i].connectionId);
							$('#zkHosts').text(addedConnListData[i].connectionJson.zkHosts);
							$('#kafkaBrokers').text(addedConnListData[i].connectionJson.kafkaBrokers);
							break;
						
						case cmpIDs.kafkaemitter:
							$('#connectionName').val(addedConnListData[i].connectionName);
							$('#connectionId').val(addedConnListData[i].connectionId);
							$('#zkHosts').text(addedConnListData[i].connectionJson.zkHosts);
							$('#kafkaBrokers').text(addedConnListData[i].connectionJson.kafkaBrokers);
							break;
						
						case cmpIDs.solremitter:
							$('#connectionName').val(addedConnListData[i].connectionName);
							$('#connectionId').val(addedConnListData[i].connectionId);
							$('#zkHosts').text(addedConnListData[i].connectionJson.zkHosts);
							break;
						
						case cmpIDs.elasticsearchemitter:
							$('#connectionName').val(addedConnListData[i].connectionName);
							$('#connectionId').val(addedConnListData[i].connectionId);
							$('#hosts').text(addedConnListData[i].connectionJson.hosts);
							$('#clusterName').val(addedConnListData[i].connectionJson.clusterName);
							break;

						case cmpIDs.hdfsemitter:
							$('#connectionName').val(addedConnListData[i].connectionName);
							$('#connectionId').val(addedConnListData[i].connectionId);
							$('#hdfsFSURIId').val(addedConnListData[i].connectionJson.fsURI);
							$('#hdfsUsernameId').val(addedConnListData[i].connectionJson.username);
							$('#hdfsEnableHAId').val(addedConnListData[i].connectionJson.haEnabled);
							if ( addedConnListData[i].connectionJson.haEnabled == true || addedConnListData[i].connectionJson.haEnabled == 'true' ) {
								$('input[name="hdfsEnableHAId"]').prop('checked',true).trigger('change');
								$('#hdfsNameServicesId').val(addedConnListData[i].connectionJson.nameservices);								
								$('#hdfsNameNode1NameId').val(addedConnListData[i].connectionJson.namenode1Name);								
								$('#hdfsNamenode1RPCAddressId').val(addedConnListData[i].connectionJson.namenode1RPCAddress);
								$('#hdfsNameNode2NameId').val(addedConnListData[i].connectionJson.namenode2Name);								
								$('#hdfsNamenode2RPCAddressId').val(addedConnListData[i].connectionJson.namenode2RPCAddress);								
							}
							break;
					}
					$('#connectionName').attr('disabled','disabled');
				}
			}
			
		});
		
		$(document).on('click', '#deleteSelCon', function(elem) {
			$('#channelErrorWrap').empty();
			var curChnlName = $('#curChannelName').val();
			var curChnlType = $('#componentType').val();
			curChannelObj = {};
			if ( curChnlType == 'spout')
				curChannelObj = addedSpoutsObj[curChnlName];
			else
				curChannelObj = addedBoltsObj[curChnlName];
			var elem = $(this);	
			var response = '';
			var url='', connectionName = '';
			var nRow = elem.closest('tr');
			connectionName =  nRow.find('td:nth-child(2)').text();
			url = componentConnUrl;
			var connectionId = elem.closest('tr').find('td:first-child > input').attr('dataKey');
			url = url+"/"+connectionName+"/delete";
			var deleteStatus = DFSubSytemDefination.postAjaxData(updateConnStatusUrl,connectionId );
			if ( deleteStatus == "" ) {
					response = DFSubSytemDefination.postAjaxData(url,connectionId );
					self.loadAddedConnectionTbl();
					var response = JSON.parse(response);
					if ( response.status == "SUCCESS" ) {
						var newConfig = [];
						for ( var i = 0; i < curChannelObj.config.length; i++ ) {
							var configLen = curChannelObj.config[i].length;
							var colonIdx = curChannelObj.config[i].indexOf(":");
							var configKey = curChannelObj.config[i].substring(0, colonIdx);
							var configVal = curChannelObj.config[i].substring(colonIdx+1, configLen).trim();
							if ( configKey == "connectionId" ) {
								newConfig.push("connectionId:");
							} else if ( configKey == "connectionName" ) {
								newConfig.push("connectionName:");
							} else {
								newConfig.push(configKey + ":" + configVal);
							}
						}
						curChannelObj.config = newConfig;
						dbObj.config = newConfig;
					}
					self.displayAjaxMsg(response, nRow);
			} else {
				deleteStatus = JSON.parse(deleteStatus);
				if ( deleteStatus.status == 'STOPPED' ) {
					bootbox.confirm(deleteStatus.message, function(confirmation) {
						if (confirmation) {
							response = DFSubSytemDefination.postAjaxData(url,connectionId );
							self.loadAddedConnectionTbl();
							var response = JSON.parse(response);
							if ( response.status == "SUCCESS" ) {
								var newConfig = [];
								for ( var i = 0; i < curChannelObj.config.length; i++ ) {
									var configLen = curChannelObj.config[i].length;
									var colonIdx = curChannelObj.config[i].indexOf(":");
									var configKey = curChannelObj.config[i].substring(0, colonIdx);
									var configVal = curChannelObj.config[i].substring(colonIdx+1, configLen).trim();
									if ( configKey == "connectionId" ) {
										newConfig.push("connectionId:");
									} else if ( configKey == "connectionName" ) {
										newConfig.push("connectionName:");
									} else {
										newConfig.push(configKey + ":" + configVal);
				}
								}
								curChannelObj.config = newConfig;
								dbObj.config = newConfig;
							}
							self.displayAjaxMsg(response, nRow);
						} 
					});
				} else if ( deleteStatus.status == 'SUCCESS' ) {
					$('#channelErrorWrap').html('<div class="alert alert-danger" role="alert">'+deleteStatus.message+'</div>');
				}
			}
			self.connectionCount( curChannelObj );		
			setTimeout(function() { 
				$('#channelErrorWrap').html('');
			}, 20000);
		});
		
		$(document).on('click', '#cancelConnectionBtn', function() {
			$('#channelErrorWrap').empty();
			var curChannelId = $('#curChannelId').val();
			addedConnListData = self.connectionListCounts( curChannelId );
			if ( addedConnListData.length == 0 ) {
				$('a[href="#persisterTab1"]').closest('li').siblings().find('a').attr('data-toggle','tab');
				$('a[href="#persisterTab1"]').closest('li').siblings().find('a').removeClass('disabled');
				$('a[href="#persisterConfigTab1"]').trigger('click');
				$('#persisterTab1').remove();
				$('a[href="#persisterTab1"]').closest('li').remove();
				$('.modal-body').siblings('.modal-footer').find('button#saveChannelProp').removeClass('disabled');
				self.removeConnectionTab();
			} else {
				$('#updateConnectionBtn').addClass('hidden');
				$('#createConnectionBtn').removeClass('hidden');
				$('#addConnectionLink').show();
				$('#connectionSelected').show();
				$('#persisterTab1 .widget').show();
				$('div#selectedDBContent').html('');
				self.loadAddedConnectionTbl();
			}
		});
		
		$(document).on('change', 'input[name="subSystemConnection"]', function(){
			$('#connectionSelected').removeClass('disabled');
		});
	};
	
	self.removeConnectionTab = function() {
		var curChnlId = $('#curChannelId').val();
		var selectedConnLabelData = {};
		selectedConnName = $('input[name="subSystemConnection"]:checked').closest('tr').find('td:nth-child(2)').text();
		$('#selectConnObj').val('');
		self.connectionCount(curChnlId);
		for ( var i = 0; i < addedConnListData.length; i++ ) {
			if ( addedConnListData[i].connectionName == selectedConnName ) {
				$('#selectConnObj').val(JSON.stringify(addedConnListData[i]));
				$('#connectionText').text(selectedConnName);
			}
		}
		selectedConnName = '';
		persisterIndexerClass.displayLabelData();
		$('#persisterTab1').remove();
		$('a[href="#persisterTab1"]').closest('li').remove();
		$('.modal-footer').find('button#saveChannelProp').removeClass('disabled');
	};
	
	self.displayAjaxMsg = function ( response, nRow ) {
		$('#channelErrorWrap').html('');
		if(response.status == "SUCCESS"){
			$('#channelErrorWrap').html('<div class="alert alert-success" role="alert">'+response.message+'</div>');
		} else {
			$('#channelErrorWrap').html('<div class="alert alert-danger" role="alert">'+response.message+'</div>');
		}
	} 
	
	self.saveUpdateData = function ( url ) {
		var curChnlId = $('#curChannelId').val();
		var flag = true, validate = true, response = '';
		$("#selectedDBContent").find("[data-parsley-required='true']").each(function() {
			flag = $(this).parsley().validate();
			if ( flag != true ) validate = false;
		});
		
		if ( validate ) {
			$('#connectionSelected').removeAttr('disabled');
			var connectionData={}, temp={};
			connectionData["connectionJson"] = {};
			$("#selectedDBContent").find(".config-value").each(function() {
				temp[$(this).attr('name')] = $(this).val();
			});
			connectionData["connectionId"] = temp.connectionId;
			connectionData["connectionName"] = temp.connectionName;
			connectionData["tenantId"] = currentTenantId;
			
			switch ( curChnlId ) {
			
				case cmpIDs.hbaseemitter:
					connectionData["componentType"] = "hbase";
					connectionData.connectionJson["zkHosts"] = temp.zkHosts.replace(/\s/g, '');
					connectionData.connectionJson["zkPort"] = temp.zkPort;
					connectionData.connectionJson["hdfsUser"] = temp.hdfsUser;
					connectionData.connectionJson["zkRecoveryRetry"] = temp.zkRecoveryRetry;
					connectionData.connectionJson["zkParentNode"] = temp.zkParentNode;
					connectionData.connectionJson["clientRetriesNumber"] = temp.clientRetriesNumber;
					break;
					
				case cmpIDs.cassandraemitter:
					connectionData["componentType"] = "cassandra";
					connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
					connectionData.connectionJson["username"] = temp.username;
					connectionData.connectionJson["password"] = temp.password;
					connectionData.connectionJson["connectionRetries"] = temp.connectionRetries;
					break;
				
				case cmpIDs.rabbitmqchannel:
					connectionData["componentType"] = "rabbitmq";
					connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
					connectionData.connectionJson["username"] = temp.username;
					connectionData.connectionJson["password"] = temp.password;
					break;
				
				case cmpIDs.replaychannel:
					var srcSelected = $('input[name="replaySrc"]:checked').val();
					if ( srcSelected == "rabbitmq" ) {
						connectionData["componentType"] = "rabbitmq";
						connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
						connectionData.connectionJson["username"] = temp.username;
						connectionData.connectionJson["password"] = temp.password;
					} else if ( srcSelected == "kafka" ) {
						connectionData["componentType"] = "kafka";
						connectionData.connectionJson["zkHosts"] = temp.zkHosts.replace(/\s/g, '');
						connectionData.connectionJson["kafkaBrokers"] = temp.kafkaBrokers.replace(/\s/g, '');
					}
					break;
				
				case cmpIDs.rabbitmqemitter:
					connectionData["componentType"] = "rabbitmq";
					connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
					connectionData.connectionJson["username"] = temp.username;
					connectionData.connectionJson["password"] = temp.password;
					break;
				
				case cmpIDs.activemqchannel:
					connectionData["componentType"] = "activemq";
					connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
					connectionData.connectionJson["username"] = temp.username;
					connectionData.connectionJson["password"] = temp.password;
					break;
				
				case cmpIDs.activemqemitter:
					connectionData["componentType"] = "activemq";
					connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
					connectionData.connectionJson["username"] = temp.username;
					connectionData.connectionJson["password"] = temp.password;
					break;
				
				case cmpIDs.kafkachannel:
					connectionData["componentType"] = "kafka";
					connectionData.connectionJson["zkHosts"] = temp.zkHosts.replace(/\s/g, '');
					connectionData.connectionJson["kafkaBrokers"] = temp.kafkaBrokers.replace(/\s/g, '');
					break;
				
				case cmpIDs.kafkaemitter:
					connectionData["componentType"] = "kafka";
					connectionData.connectionJson["zkHosts"] = temp.zkHosts.replace(/\s/g, '');
					connectionData.connectionJson["kafkaBrokers"] = temp.kafkaBrokers.replace(/\s/g, '');
					break;
				
				case cmpIDs.solremitter:
					connectionData["componentType"] = "solr";
					connectionData.connectionJson["zkHosts"] = temp.zkHosts.replace(/\s/g, '');
					break;
				
				case cmpIDs.elasticsearchemitter:
					connectionData["componentType"] = "elasticsearch";
					connectionData.connectionJson["clusterName"] = temp.clusterName;
					connectionData.connectionJson["hosts"] = temp.hosts.replace(/\s/g, '');
					break;
				
				case cmpIDs.hdfsemitter:
					connectionData["componentType"] = "hdfs";
					connectionData.connectionJson["fsURI"] = temp.hdfsFSURIId;
					connectionData.connectionJson["username"] = temp.hdfsUsernameId;
					connectionData.connectionJson["haEnabled"] = temp.hdfsEnableHAId;
					if ( temp.hdfsEnableHAId == true || temp.hdfsEnableHAId == 'true' ) {
						connectionData.connectionJson["nameservices"] = temp.hdfsNameServicesId;
						connectionData.connectionJson["namenode1Name"] = temp.hdfsNameNode1NameId;
						connectionData.connectionJson["namenode1RPCAddress"] = temp.hdfsNamenode1RPCAddressId;
						connectionData.connectionJson["namenode2Name"] = temp.hdfsNameNode2NameId;
						connectionData.connectionJson["namenode2RPCAddress"] = temp.hdfsNamenode2RPCAddressId;
					}
					break;
			}
			
			connectionData.connectionJson = JSON.stringify(connectionData.connectionJson);
			connectionData = JSON.stringify(connectionData);
			response = DFSubSytemDefination.postAjaxData( url, connectionData);
			self.displayAjaxMsg(JSON.parse(response));
			setTimeout(function() { 
				$('#channelErrorWrap').html('');
			}, 20000);
			$('#addConnectionLink').show();
			$('#connectionSelected').show();
			$('#persisterTab1 .widget').show();
			$('div#selectedDBContent').html('');
			self.loadAddedConnectionTbl();
		}
	};
	
	self.createConnTab = function ( curChnl ) {
		var curChnlId = '';
		curChnlId = $('#curChannelId').val();
		var componentType = '';
		dbObj = curChnl;
		switch ( curChnlId ) {
			
				case cmpIDs.hbaseemitter:
					componentType = 'hbase';
					break;
				
				case cmpIDs.cassandraemitter:
					componentType = 'cassandra';
					break;
				
				case cmpIDs.rabbitmqchannel:
					componentType = 'rabbitmq';
					break;
				
				case cmpIDs.replaychannel:
					var srcSelected = $('input[name="replaySrc"]:checked').val();
					if  ( srcSelected == 'rabbitmq' )
						componentType = 'rabbitmq';
					else if ( srcSelected == 'kafka' ) {
						componentType = 'kafka';
					}
					break;
				
				case cmpIDs.rabbitmqemitter:
					componentType = 'rabbitmq';
					break;
				
				case cmpIDs.activemqchannel:
					componentType = 'activemq';
					break;
				
				case cmpIDs.activemqemitter:
					componentType = 'activemq';
					break;
				
				case cmpIDs.kafkachannel:
					componentType = 'kafka';
					break;
				
				case cmpIDs.kafkaemitter:
					componentType = 'kafka';
					break;
				
				case cmpIDs.solremitter:
					componentType = 'solr';
					break;
				
				case cmpIDs.elasticsearchemitter:
					componentType = 'elasticsearch';
					break;
				
				case cmpIDs.hdfsemitter:
					componentType = 'hdfs';
					break;
		}
		
		allAddedConnUrl = baseUrl+'/connections/'+componentType+'/connection/list';
		componentConnUrl = baseUrl+'/connections/'+componentType+'/connection';
		
		var persisterTab = '<li><a href="#persisterTab1" data-toggle="tab"> '+i18N['sax.label.connection']+'</a></li> ';
		var persisterTabContent = '<div class="tab-pane" id="persisterTab1"><div id="addConnectionLink" class="form-group"><div class="control-label pull-right margin-rm"><a href="javascript: void(0)" id="addConLink" class="add-ico tt margin-rs"><i class="fa fa-plus"></i> '+i18N['sax.label.addConnection']+'</a></div></div><div id="ajaxLoader"><img src="'+baseUrl+'/resources/images/ui-anim_basic_16x16.gif">'+i18N["sax.loadingMsg"]+'</div><div class="tab_container tab_container-extend"><div class="row"><div class="col-md-12"><div id="connectionTbl" class="widget"><div class="widget-title"><h3>'+i18N['sax.label.connections']+'</h3></div><div class="widget-content"><div class="widget-loader" id="connectionTblLoader"></div><div id="connWrap"><div id="manageConnTblWrap"></div></div><div class="clearfix"></div></div></div></div><div class="row"><div class="col-md-12 pull-right"><button id="connectionSelected" type="button" class="btn btn-primary pull-right margin-rm">Select</button></div></div></div></div><div class="row"><div id="selectedDBContent" class="col-md-12"></div></div></div>';
		
		$('#channelProperties > .nav.nav-tabs').append( persisterTab );
		
		$('#channelProperties > .tab-content').append( persisterTabContent );
		self.loadAddedConnectionTbl();
		DFSubSytemDefination.initPopovers();
	};
	
	self.loadAddedConnectionTbl = function() {
		addedConnListData = DFSubSytemDefination.getAjaxData(allAddedConnUrl);
		$('#connectionSelected').addClass('disabled');
		if ( typeof addedConnListData.thrownError !== "undefined" ) {
			$("#manageConnTblWrap").html('<div class="clearfix"></div><div class="alert alert-danger margin-t">' + errorObj.TABLE_RENDERING + '</div>');
			$("#connectionTblLoader").hide();
		} else if ( addedConnListData == 'null' || addedConnListData.length == 0 ) {
			$("#manageConnTblWrap").html('<div class="clearfix"></div><div class="alert alert-info margin-t">' + errorObj.NO_DATA + '</div>');
			$("#connectionTblLoader").hide();
		} else {			
			self.initConnectionList(addedConnListData);
		}	
	};
	
	self.initConnectionList = function(data) {
		$("#connectionTblLoader").hide();
		$("#manageConnTblWrap").empty();
		conTable = $('<table class="table table-bordered">').appendTo("#manageConnTblWrap");
		conTable.dataTable({
			"aaData": data,
			"bJQueryUI": false,
			"bAutoWidth": false,
			"bFilter": true,
			"bPaginate": true,
			"iDisplayLength": 10,
			"sDom": '<"datatable-header"f><"table-responsive"t><"datatable-footer"ip><"clearfix">',
			"fnDrawCallback": function(o) {
				$(".tt").tooltip();
				$('input[name="subSystemConnection"]').each( function () {
				  if ( $('#connectionText').text() == $(this).closest('td').siblings('td:nth-child(2)').text())
					$(this).attr('checked','checked').trigger('change');
				});
			},
			"aoColumns": [
				{"mData": function(obj) {			
						return'<input type = "radio" value= "'+obj.connectionName+'" dataKey= "'+obj.connectionId+'" class="radio-inline" name="subSystemConnection"/>' ;
				},"sWidth": "20px"},
				{ "sTitle": "Name", "mData" : "connectionName"},
				{ "sTitle": "Action","sWidth": "80px", "mData": function(obj) { return '<span class="action-wrap"><a href="javascript:void(0)" title="'+i18N['sax.label.edit']+'" id="editChkCon" class="ico-edit tt"><i class="fa fa-edit"></i></a><a href="javascript:void(0)" title="'+i18N['sax.label.delete']+'" id="deleteSelCon" class="ico-del tt"><i class="fa fa-trash-o"></i></a></span>' }}
			]
		});
	};
	
	self.createFuncField = function(currFuncDataObj) {
		var fieldHTML = '';
		var type = currFuncDataObj.type;
		var placeholder = currFuncDataObj.placeholder == '' ? i18N['sax.placeholder.pleaseEnterValue'] : currFuncDataObj.placeholder;
		if( type == 'text' || type == 'password' ) {
			var reqField = currFuncDataObj.validation == '' ? '' : ' <span class="req">'+i18N['sax.asteriskSign']+'</span>'
			fieldHTML = '<div id="'+currFuncDataObj.wraperId+'" class="form-group"><label class="col-sm-4 control-label margin-ls">'+currFuncDataObj.key + reqField +'</label><div class="col-sm-4 margin-ts"><input type="'+currFuncDataObj.type+'" id="'+currFuncDataObj.dataKey+'" class="form-control parsley-validate config-value '+currFuncDataObj.class+'" name="'+currFuncDataObj.dataKey+'" placeholder="'+placeholder+'" '+currFuncDataObj.validation+' /></div><a href="javascript:void(0)" tabindex="-1" class="po infoico" title="'+currFuncDataObj.key +'" content="'+currFuncDataObj.uiid+'_'+currFuncDataObj.dataKey +'"><i class="fa fa-info-circle"></i></a></div>';
			
		} else if ( type == 'select' ) {
			var options = '';
			options = createConfigOptions(dbObj.id, "rotationPolicy");
			fieldHTML = '<div id="'+currFuncDataObj.wraperId+'" class="form-group"><label class="col-sm-4 control-label margin-ls">'+currFuncDataObj.key+' <span class="req">'+i18N['sax.asteriskSign']+'</span></label><div class="col-sm-4 margin-ts"><select id="'+ currFuncDataObj.dataKey +'" class="form-control config-value tt" name="'+currFuncDataObj.dataKey+'" '+ currFuncDataObj.validation +'>'+ options +'</select></div><a href="javascript:void(0)" tabindex="-1" class="po infoico" title="'+currFuncDataObj.key +'" content="'+currFuncDataObj.uiid+'_'+currFuncDataObj.dataKey +'"><i class="fa fa-info-circle"></i></a></div>';
		} else if( type == 'textarea' ) {
				fieldHTML = '<div id="'+currFuncDataObj.wraperId+'" class="form-group"><label class="col-sm-4 control-label margin-ls">'+currFuncDataObj.key+' <span class="req">'+i18N['sax.asteriskSign']+'</span></label><div class="col-sm-4 margin-ts"><textarea id="'+currFuncDataObj.dataKey+'" placeholder="'+placeholder+'" name="'+currFuncDataObj.dataKey+'" type="text" class="form-control config-value" '+currFuncDataObj.validation+'></textarea></div><a href="javascript:void(0)" tabindex="-1" class="po infoico" title="'+currFuncDataObj.key +'" content="'+currFuncDataObj.uiid+'_'+currFuncDataObj.dataKey +'"><i class="fa fa-info-circle"></i></a></div>';
		} else if( type == 'checkbox' ) {
			fieldHTML = '<div id="'+currFuncDataObj.wraperId+'" class="form-group"><label class="col-sm-4 control-label margin-ls">'+currFuncDataObj.key+'</label><div class="col-sm-4 margin-tm"><input type="'+currFuncDataObj.type+'" id="'+currFuncDataObj.dataKey+'" class="parsley-validate config-value '+currFuncDataObj.class+'" name="'+currFuncDataObj.dataKey+'" value="'+currFuncDataObj.value+'" /></div><a href="javascript:void(0)" tabindex="-1" class="po infoico" title="'+currFuncDataObj.key +'" content="'+currFuncDataObj.uiid+'_'+currFuncDataObj.dataKey +'"><i class="fa fa-info-circle"></i></a></div>';
		} else if( type == 'radio' ) {
			fieldHTML = '<div class="row"> <div class="col-md-12"><div class="form-group"><div class="row"><label class="col-sm-2 control-label margin-ls">'+currFuncDataObj.key+' </label><div class="col-sm-4 margin-ts"> <input class="'+currFuncDataObj.class+'" name="'+currFuncDataObj.dataKey+'" checked="" type="'+currFuncDataObj.type+'" value="'+currFuncDataObj.value1+'" /> '+currFuncDataObj.text1+' &nbsp; <input class="'+currFuncDataObj.class+'" name="'+currFuncDataObj.dataKey+'" type="'+currFuncDataObj.type+'" value="'+currFuncDataObj.value2+'"> '+currFuncDataObj.text2+' </div> <div class="col-sm-1 margin-ls"><a href="javascript:void(0)" tabindex="-1" class="po infoico" title="" content="msgRegSptDef" data-original-title="'+currFuncDataObj.key+'"><i class="fa fa-info-circle"></i></a></div> </div> </div> </div><a href="javascript:void(0)" tabindex="-1" class="po infoico" title="'+currFuncDataObj.key +'" content="Desc_'+ currFuncDataObj.key +'"><i class="fa fa-info-circle"></i></a></div>';
		} else if(type == "button"){
			fieldHTML = '<div class="row lookup-content-padding"><div class="col-sm-12"><div class="row"><div class="col-md-4" id="testConnStatus"></div><div class="col-md-2 margin-tm"><button id="'+currFuncDataObj.id+'" type="button" class="btn btn-primary '+currFuncDataObj.class+' pull-right margin-tm margin-ll">'+currFuncDataObj.key+'</button></div></div></div></div>'
		}
		
		return fieldHTML;
	};
	
	self.connectionCount = function( curChannelId ) {
		addedConnListData = self.connectionListCounts( curChannelId );
		$('a#addNewConn').removeAttr('data-original-title');
		if ( addedConnListData.length == 0 ) {
			$('#connectionText').text(i18N['sax.label.addConnection']);
			$('a#addNewConn').attr('data-original-title', i18N['sax.label.addConnection']);
			$('a#addNewConn > i').addClass('fa-plus');
			$('a#addNewConn > i').removeClass('fa-list');
			$('#connectionSelected').attr('disabled',true);
		} else {
			if ( $('#connectionText').text() == i18N['sax.label.selectConnection'] || $('#connectionText').text() == "" ){
				$('#connectionText').text(i18N['sax.label.selectConnection']);
			} else {
				for ( var i = 0; i < addedConnListData.length; i++ ) {
					$('#selectConnObj').val(JSON.stringify(addedConnListData[i]));
				}
				DFSubSytemDefination.initPopovers();
			}
			$('a#addNewConn').attr('data-original-title', i18N['sax.label.selectConnection']);
			$('a#addNewConn > i').addClass('fa-list');
			$('a#addNewConn > i').removeClass('fa-plus');
			$('#connectionSelected').removeAttr('disabled');
		}
		
		$(".tt").tooltip();
	}
	
	self.connectionListCounts = function( curChannelId ) {
		var curChnlId = curChannelId;
		switch ( curChnlId ) {
			
				case cmpIDs.hbaseemitter:
					componentType = 'hbase';
					break;
				
				case cmpIDs.cassandraemitter:
					componentType = 'cassandra';
					break;
				
				case cmpIDs.rabbitmqchannel:
					componentType = 'rabbitmq';
					break;
				
				case cmpIDs.replaychannel:
					var srcSelected = $('input[name="replaySrc"]:checked').val();
					if  ( srcSelected == 'rabbitmq' )
						componentType = 'rabbitmq';
					else if ( srcSelected == 'kafka' ) {
						componentType = 'kafka';
					}else {
						componentType = 'rabbitmq';
					}
					break;
				
				case cmpIDs.rabbitmqemitter:
					componentType = 'rabbitmq';
					break;
				case cmpIDs.activemqchannel:
					componentType = 'activemq';
					break;
				
				case cmpIDs.activemqemitter:
					componentType = 'activemq';
					break;
				
				case cmpIDs.kafkachannel:
					componentType = 'kafka';
					break;
				
				case cmpIDs.kafkaemitter:
					componentType = 'kafka';
					break;
				
				case cmpIDs.solremitter:
					componentType = 'solr';
					break;
				
				case cmpIDs.elasticsearchemitter:
					componentType = 'elasticsearch';
					break;
				
				case cmpIDs.hdfsemitter:
					componentType = 'hdfs';
					break;
			}
		allAddConnUrl = baseUrl+'/connections/'+componentType+'/connection/list';
		addedConnListData = DFSubSytemDefination.getAjaxData(allAddConnUrl);
		return addedConnListData;
	}
	
	self.init();
};

// Filter Criteria Class
var filerCriteriaCls = new function() {
	var self = this;
	
	var verticalTabsWrap = '<div class="col-xs-3"> <ul id="rulesTabs" class="nav nav-tabs tabs-left"></ul> <div class="add-new-rule"> <a href="javascript:void(0)" id="addNewRule">'+i18N['sax.addNewRule']+'</a> </div> </div> <div class="col-xs-9"> <div id="rulesTabContent" class="tab-content"></div> </div>';
	
	self.init = function() {
		$(document).on("change", "select.msgTypeList", function() {
			var id = $(this).closest(".alertCriteriaWrap").attr("id");
			var value = $(this).val();
			if ( value != null ) {
				if ( value.length > 18 )
					$('#rulesTabs a[href="#'+id+'"]').text(value.substr(0, 18) + '...');
				else
					$('#rulesTabs a[href="#'+id+'"]').text(value);
				
				self.createCriteriaBulder(value, id);
			}
		});
		
		$(document).on("change", ".alertCriteria select", function() {
			var id = $(this).closest('.alertCriteriaWrap').attr("id");
			self.getAlertExpression(id);
			$(".alertCriteria select").select2('destroy').select2();
		});
		
		$(document).on("change", ".alertCriteria select.criteria_input_select", function() {
			var val = $(this).val();
			$(this).siblings("span.input_boolean").find('input.input_boolean').val(val);
			var id = $(this).closest('.alertCriteriaWrap').attr("id");
			self.getAlertExpression(id);
		});
		
		$(document).on("keyup", ".alertCriteria input[type='text']", function() {
			var id = $(this).closest('.alertCriteriaWrap').attr("id");
			self.getAlertExpression(id);
		});
		
		$(document).on("click", ".alertCriteria a", function() {
			var id = $(this).closest('.alertCriteriaWrap').attr("id");
			setTimeout(function() {
				self.getAlertExpression(id);
			}, 30);
			setTimeout(function() {
				$("#"+id).find(".criteria_wrap:last select").select2("destroy").select2({placeholder: i18N['sax.placeholder.pleaseSelect']});
			}, 3);
		});
		
		$(document).on("click", ".remove-rule", function() {
			var txt = $(this).siblings("a").text();
			var target = $(this).attr("data-target");
			var isActive = $(this).closest("li").hasClass("active");
			var streamWrap = $(this).closest("#streamIdFilterWrap").size();
			$(this).closest("li").remove();
			$(target).remove();
			
			usedMessages = jQuery.grep(usedMessages, function(value) {
				return value !== txt;
			});
			
			$("#rulesTabContent .alertCriteriaWrap").each(function() {
				$(this).find("select.msgTypeList").append('<option value="'+ txt +'">'+ txt +'</option>');
			});
			
			if ( usedMessages.length != allMessages.length )
				$("#addNewRule").show();
			else
				$("#addNewRule").hide();
				
			if ( isActive ) {
				$("#rulesTabs a:first").trigger("click");
			}
			
			// For streamId support
			var tabSize = $("#rulesTabs li").size();
			if ( tabSize == 0 ) {
				$('#streamIdFilterIntroWrap').show();
				$('#streamIdFilterWrap').empty().hide();
			} else if ( streamWrap == 0 && tabSize == 1 ) {
				$('#rulesTabs li:first').addClass('first');
				$('#rulesTabs li:first > span.remove-rule').remove();
			}
		});
		
		$(document).on("click", "#addNewRule", function() {
			usedMessages = [];
			
			var firstTabId = $('#rulesTabs li.first a').attr('href');
			$('#rulesTabs li.first').prepend('<span data-target="'+ firstTabId +'" class="remove-rule"><i class="fa fa-times"></i></span>');
			$('#rulesTabs li.first').removeClass('first');
			
			$("#rulesTabs li").each(function() {
				var id = $(this).find("a").attr('href');			
				var msg = $(id).find("select.msgTypeList").val();
				if ( jQuery.inArray(msg, usedMessages) < 0 )
					usedMessages.push(msg);
			});
			self.createCriteriaTmpl('');
			DFSubSytemDefination.initPopovers();
		});
		
		$(document).on("click", "#rulesTabs a", function() {
			var tabId = $(this).attr("href");
			
			usedMessages = [];
			$("#rulesTabs li").each(function() {
				var id = $(this).find("a").attr('href');			
				var msg = $(id).find("select.msgTypeList").val();
				if ( jQuery.inArray(msg, usedMessages) < 0 )
					usedMessages.push(msg);
			});
			
			for ( var i=0; i<allMessages.length; i++ ) {
				var isAvailable = false;
				$(tabId).find("select.msgTypeList option").each(function() {
					var txt = $(this).val();
					if ( allMessages[i] == txt ) isAvailable = true;
				});
				
				if ( !isAvailable ) {
					$(tabId).find("select.msgTypeList").append('<option value="'+ allMessages[i] +'">'+ allMessages[i] +'</option>');
				}
			}
			
			$("#rulesTabContent .alertCriteriaWrap").each(function() {
				var selOption = $(this).find("select.msgTypeList").val();		
				for ( var i=0; i<usedMessages.length; i++ ) {
					if ( selOption != usedMessages[i] )
						$(this).find("select.msgTypeList option[value='"+ usedMessages[i] +"']").remove();
				}
			});
		});
	};
	
	self.initTemplate = function(d, type) {
		usedMessages = [];
		
		if ( type == 'filterbolt' ) {
			$('#channelProperties > .nav.nav-tabs').prepend('<li> <a href="#filterTab" data-toggle="tab">'+i18N['sax.filter']+'</a> </li>');
			$('#channelProperties > .tab-content').append('<div class="tab-pane" id="filterTab"> <div class="vertical-tabs row">' + verticalTabsWrap + '</div> <div class="clearfix"> </div> </div>');
		} else {
			$('#streamIdFilterWrap').append(verticalTabsWrap);
		}
		$('#channelProperties > .nav.nav-tabs > li:first a').trigger('click');

		if ( typeof d.rules !== 'undefined' && d.rules.length > 0 ) {
			var addedCrossSign = false;
			for ( var k=0; k<d.rules.length; k++ ) {
				self.createCriteriaTmpl(d.rules[k], type);
				if ( k > 0 && !addedCrossSign ) {
					var firstTabId = $('#rulesTabs li.first a').attr('href');
					$('#rulesTabs li.first').prepend('<span data-target="'+ firstTabId +'" class="remove-rule"><i class="fa fa-times"></i></span>');
					$('#rulesTabs li.first').removeClass('first');
					addedCrossSign = true;
				}
			}
			$('#rulesTabs > li:first > a').trigger('click');
		} else {
			self.createCriteriaTmpl('', type);
		}
	};
	
	self.createCriteriaTmpl = function(d, type) {
		var msg = (d.message) ? d.message : '';
		var filterNegate = d.filterNegate;
		filterNegate = (filterNegate) ? filterNegate.toString() : 'false';
		msgOptions = '';
		for ( var j=0; j<allMessages.length; j++ ) {
			if ( jQuery.inArray(allMessages[j], usedMessages) < 0 )
				msgOptions += '<option value="'+ allMessages[j] +'">'+ allMessages[j] +'</option>';
		}
		
		var random = Math.floor(Math.random() * 1000000 + 1);
		var size = $("#rulesTabs li").size();
		tabTitle = ( msg == '' ) ? 'Please select message' : msg;
		tabCls = (size == 0) ? 'active' : '';
		if ( size==0 && type == 'filterbolt' ) {
			$("#rulesTabs").append('<li class="'+tabCls+' first"><a href="#tab'+random+'" data-toggle="tab">'+tabTitle+'</a></li>');
		} else {
			$("#rulesTabs").append('<li class="'+tabCls+'"><span class="remove-rule" data-target="#tab'+random+'"><i class="fa fa-times"></i></span><a href="#tab'+random+'" data-toggle="tab">'+tabTitle+'</a></li>');
		}
		
		$("#rulesTabContent").append('<div class="tab-pane alertCriteriaWrap '+tabCls+'" id="tab'+random+'"> <div class="row"> <div class="col-md-12"> <label class="pull-left control-label">'+i18N['sax.label.messageName']+': </label> <div class="col-sm-4"><select name="messageType" class="msgTypeList">'+msgOptions+'</select></div> <a content="filterMessageName" title="'+i18N['sax.label.messageName']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> </div> <div class="row margin-t"> <div class="col-md-12"> <label>'+i18N['sax.label.filterRule']+': </label><a content="filterRule" title="'+i18N['sax.label.filterRule']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> <div id="tab'+random+'Criteria" class="alertCriteria"></div> </div> </div> <div class="row margin-t"> <div class="col-md-12"> <label class="pull-left control-label">'+i18N['sax.label.negate']+': </label> <div class="col-sm-4"><select name="filterNegate" class="filterNegateSel"><option value="true">'+i18N['sax.option.text.true']+'</option><option value="false">'+i18N['sax.option.text.false']+'</option></select></div> <a content="filterNegate" title="'+i18N['sax.label.negate']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> </div> <div class="row margin-t hidden"> <div class="col-md-12"> <label>'+i18N['sax.label.expression']+':</label> <div class="clearfix"></div> <textarea class="alertDisplayQuery" name="alertDisplayQuery" cols="70" disabled></textarea> <textarea class="alertFilterQuery" name="alertFilterQuery" style="display: none;"></textarea> <a content="expression" title="'+i18N['sax.label.expression']+'" tabindex="-1" class="po infoico" href="javascript:void(0)"><i class="fa fa-info-circle"></i></a> </div> </div> </div>');
		
		$("#tab"+random).find('select.msgTypeList').val(tabTitle).trigger('change');
		$("#tab"+random).find('select.filterNegateSel').val(filterNegate).trigger('change');
		
		var newMsg = $("#tab"+random).find('select.msgTypeList').val();
		if ( jQuery.inArray(newMsg, usedMessages) < 0 )
				usedMessages.push(newMsg);
		
		if ( usedMessages.length == allMessages.length )
			$("#addNewRule").hide();
		else
			$("#addNewRule").show();
			
		$("#rulesTabContent .alertCriteriaWrap").each(function() {
			var selOption = $(this).find("select.msgTypeList").val();		
			for ( var i=0; i<usedMessages.length; i++ ) {
				if ( selOption != usedMessages[i] )
					$(this).find("select.msgTypeList option[value='"+ usedMessages[i] +"']").remove();
			}
		});
		
		$("#rulesTabContent select").select2("destroy").select2({placeholder: i18N['sax.placeholder.pleaseSelect']});
	};
	
	self.createCriteriaBulder = function(msg, id) {
		$("#rulesTabs").find("a[href='#" + id + "']").trigger('click');
		var idx = $("#rulesTabs").find("a[href='#" + id + "']").closest("li").index();
		
		if ( typeof available_criteria[id] === 'undefined' )
			available_criteria[id] = [];
		else
			available_criteria[id] = [];
		
		var messageFields = allMessagesData[msg];
		for ( var j=0, ln=messageFields.length; j<ln; j++ ) {
			if ( messageFields[j].fieldName != 'indexId' && messageFields[j].fieldName != 'persistId' ) {
				var fldType = messageFields[j].dataType.split(".");
				fldType = fldType[fldType.length-1].toLowerCase();
				if ( fldType != 'date' && fldType != 'geo_point' ) {
					available_criteria[id].push({
						name: messageFields[j].fieldName,
						label: messageFields[j].fieldLabel,
						type: fldType
					});
				}
			}
		}
		
		var filterJSON = [];
		if ( typeof criteriaData.rules !== 'undefined' ) {
			for ( var k=0; k<criteriaData.rules.length; k++ ) {
				if ( criteriaData.rules[k].message == msg && k == idx )
					filterJSON = criteriaData.rules[k].filterJSON;
			}
		}
		
		$("#"+id).find('.alertCriteria').empty();
		if ( filterJSON.length > 0 ) {
			for ( var i=0; i<filterJSON.length; i++ ) {
				$("#"+id+"Criteria").add_criteria();
				var row = $("#"+id).find('.alertCriteria').find(".criteria_wrap");
				$(row[i]).find("select.operand_select").val( filterJSON[i].operand ).trigger("change");
				$(row[i]).find("select.context_select").val( filterJSON[i].expressionsInfo.field ).trigger("change");
				$(row[i]).find("select.comparitor_select").val( filterJSON[i].expressionsInfo.operator ).trigger("change");
				var fldVals = filterJSON[i].expressionsInfo.fieldValue.split(",");
				$(row[i]).find(".criteria_fields > span[class^='input_']:first input").val( fldVals[0] );
				if ( fldVals.length == 2 ) {
					$(row[i]).find(".criteria_fields > span[class^='input_']:last input").val( fldVals[1] );
				}
				
				if ( $(row[i]).find(".criteria_fields > select.criteria_input_select").size() > 0 ) {
					$(row[i]).find(".criteria_fields > select.criteria_input_select").val( fldVals[0] ).trigger('change');
				}
			}
		} else {
			$("#"+id+"Criteria").add_criteria();
		}
		
		self.getAlertExpression(id);
		$("#rulesTabContent select").select2("destroy").select2({placeholder: i18N['sax.placeholder.pleaseSelect']});
	};
	
	self.getAlertExpression = function(id) {
		var filterQuery = '';
		var rows = $("#"+id).find(".alertCriteria").find(".criteria_wrap");
		for ( var i=0; i<rows.length; i++ ) {
			var operand = $(rows[i]).find("select.operand_select").find("option:selected").val();
			var field = $(rows[i]).find("select.context_select").find("option:selected").val();
			var operator = $(rows[i]).find("select.comparitor_select").find("option:selected").val();
			var fieldValue = $(rows[i]).find(".criteria_fields > span[class^='input_']:first input").val();
			var fieldValue2 = $(rows[i]).find(".criteria_fields > span[class^='input_']:last input").val();
			var type = $(rows[i]).find("select.context_select").find("option:selected").attr("data-type");
			var inputSize = $(rows[i]).find(".criteria_fields > span[class^='input_']").size();
			field = field.replace(/-/g, '_');
			
			if (operator != undefined)
				operator = operator.replace(/ /g, "_");
				
			if (i == 0) {
				operandSymbol = "";
			} else {
				operandSymbol = ( operand == "AND" ) ? " && " : " || ";
			}
			
			if ( type == "long" || type == "double" ) {
				operator = (operator == "equals") ? " == " : operator;
				operator = (operator == "not_equal") ? " != " : operator;
				operator = (operator == "less_than") ? " < " : operator;
				operator = (operator == "greater_than") ? " > " : operator;
				operator = (operator == "less_than_equal_to") ? " <= " : operator;
				operator = (operator == "greater_than_equal_to") ? " >= " : operator;
				
				if ( operator == "between" ) {
					filterQuery += operandSymbol + "(" + field + " > " + fieldValue + " && " + field + " < " + fieldValue2 + ")";
				} else {
					filterQuery += operandSymbol + field + operator + fieldValue;
				}
			} else {
				var not = "";
				fieldValue = "'" + fieldValue + "'";
				
				switch(operator) {
					case 'not_equal':
						not = '!';
						operator = 'equalsIgnoreCase';
						break;
					
					case 'equals':
						operator = 'equalsIgnoreCase';
						break;
						
					case 'contains':
						field = field + '.toLowerCase()';
						fieldValue = fieldValue + '.toLowerCase()';
						break;
						
					case 'does_not_contain':
						not = '!';
						operator = 'contains';
						field = field + '.toLowerCase()';
						fieldValue = fieldValue + '.toLowerCase()';
						break;
						
					case 'starts_with':
						operator = 'startsWith';
						field = field + '.toLowerCase()';
						fieldValue = fieldValue + '.toLowerCase()';
						break;
						
					case 'does_not_start_with':
						not = '!';
						operator = 'startsWith';
						field = field + '.toLowerCase()';
						fieldValue = fieldValue + '.toLowerCase()';
						break;
						
					case 'ends_with':
						operator = 'endsWith';
						field = field + '.toLowerCase()';
						fieldValue = fieldValue + '.toLowerCase()';
						break;
						
					case 'does_not_end_with':
						not = '!';
						operator = 'endsWith';
						field = field + '.toLowerCase()';
						fieldValue = fieldValue + '.toLowerCase()';
						break;
					
					default:
						break;
				};
				
				if ( operator == 'matches' ) {
					fieldValue = fieldValue.replace(/'/g, "");
					filterQuery += operandSymbol + "<regex>" + field +":"+ fieldValue +"</regex>";
				} else {
					filterQuery += operandSymbol + not + field + "." + operator + "(" + fieldValue + ")";
				}
			}
		}
		
		$("#"+id).find(".alertFilterQuery").html( filterQuery );
	};
	
	self.init();
};

// Enricher Bolt
var enrichProcessorCls = new function() {
	var self = this;
	var currentMsg= "", fieldListVal = "";
	
	self.init = function() {
		$(document).on('click', '#addEnrichOPField', function() {
			var isDisabled = $(this).hasClass('disabled');
			if ( !isDisabled ) {
				self.addEnrichFieldRow("output", "", "");
				self.hideRemoveIcon();
				self.updateOpFieldOptions();
			}
		});
		
		$(document).on('click', '#addEnrichConfField', function() {
			self.addEnrichFieldRow("config", "", "");
		});
		
		$(document).on('click', '.remove-saxtmpl-row', function() {
			$(this).closest('.saxtmpl-row').remove();
			self.hideRemoveIcon();
			self.updateOpFieldOptions();
			setTimeout(function() {
				addedFunctions = {};
				$("#addConFldDiv .saxtmpl-val.ui-autocomplete-input").each(function(i, fld) {
					var _this = $(fld);
					lookupClass.checkLookFuncAdded(_this);
				});
				$("#addOutputFldDiv .saxtmpl-val.ui-autocomplete-input").each(function(i, fld) {
					var _this = $(fld);
					lookupClass.checkLookFuncAdded(_this);
				});
			}, 200);
		});
		
		$(document).on('change', 'select.enrichMsseges', function() {
			currentMsg = $(this).val();
			$('#addOutputFldDiv').empty();
			fieldListVal = allMessagesData[currentMsg];
			self.addEnrichFieldRow("output", "", "");
			self.hideRemoveIcon();
			self.updateOpFieldOptions();
		});
		
		$(document).on('change', 'select.saxtmpl-key', function() {
			self.updateOpFieldOptions();
		});
	};
	
	self.updateOpFieldOptions = function() {
		var selOptions = [];
		$('#addOutputFldDiv select.saxtmpl-key').each(function() {
			var $this = $(this);
			var fld = $this.val();
			selOptions.push(fld);
			$this.closest('.saxtmpl-row').siblings('.saxtmpl-row').find('select.saxtmpl-key option[value="'+ fld +'"]').remove();
		});
		
		for ( var j=0; j<fieldListVal.length; j++ ) {
			if ( $.inArray(fieldListVal[j].fieldName, selOptions) == -1 ) {
				$('#addOutputFldDiv select.saxtmpl-key').each(function() {
					var size = $(this).find('option[value="'+ fieldListVal[j].fieldName +'"]').size();
					if ( size == 0 ) {
						$(this).append('<option value="'+ fieldListVal[j].fieldName +'">'+ fieldListVal[j].fieldLabel +'</option>');
					}
				});
			}
		}
		
		if ( selOptions.length == fieldListVal.length ) {
			$('#addEnrichOPField').addClass('disabled');
		} else {
			$('#addEnrichOPField').removeClass('disabled');
		}
	};
	
	self.hideRemoveIcon = function() {
		var count = $('#addOutputFldDiv > .saxtmpl-row').size();
		if ( count == 1 ) {
			$('#addOutputFldDiv .remove-saxtmpl-row').addClass('hidden');
		} else {
			$('#addOutputFldDiv .remove-saxtmpl-row').removeClass('hidden');
		}
	};
	
	self.createTab = function(curComp) {
		var messagesOpt = '';
		for (var i = 0; i < curComp.messageTypes.length; i++ ) {
			messagesOpt += '<option value = "'+ curComp.messageTypes[i] +'">'+ curComp.messageTypes[i] +'</option>';
		}
		
		$('#channelProperties > .nav.nav-tabs').prepend('<li> <a href="#enricherTab" data-toggle="tab">'+i18N['sax.enricher']+'</a> </li>');
		$('#channelProperties > .tab-content').append('<div class="tab-pane" id="enricherTab"> <div class="row"> <div class="col-md-12" id="enricherConfigContent"> <div class="margin-ll margin-rxl"> <h4 class="pull-left">'+i18N['sax.label.configFieldLabel']+'</h4> <a href="javascript:void(0)" id="addEnrichConfField" class="add-ico margin-tm pull-right"><i class="fa fa-plus"></i> '+i18N['sax.label.addConfigField']+'</a> <div class="clearfix"></div> <div id="addConFldDiv" class="margin-t"></div> </div> <hr> <div class="margin-ll margin-rxl"> <h4 class="pull-left">'+i18N['sax.label.outputFieldLabel']+'</h4> <div class="pull-right margin-ts"> <label class="pull-left control-label">'+i18N['sax.label.messageName']+' </label> <div class="pull-left margin-lm"> <select name="messageType" class="enrichMsseges">'+ messagesOpt +'</select> </div> <a href="javascript: void(0)" id="addEnrichOPField" class="add-ico pull-left margin-l margin-ts"><i class="fa fa-plus"></i> '+i18N['sax.label.selectFields']+'</a> </div> <div class="clearfix"></div> <div id="addOutputFldDiv" class="margin-t"></div> </div> </div> </div> </div>');
		$('a[href="#enricherTab"]').trigger('click');
		
		$('select.enrichMsseges').select2('destroy').select2({placeholder: i18N['sax.placeholder.pleaseSelect']});
		$('select.enrichMsseges').trigger('change');
		
		self.setEnrichFields(curComp);
	};
	
	self.saveEnrich = function() {
		var items = {}, enrichFlds = {}, outputFields = [], configFields = {}, outputItems = {};
		outputItems[currentMsg] = {};
		
		$('#addConFldDiv .saxtmpl-row').each(function(i, row) {
			var key = $(row).find('.saxtmpl-key').val();
			var value = $(row).find('.saxtmpl-val').val();
			configFields[key] = value;
		});
		
		$('#addOutputFldDiv .saxtmpl-row').each(function(i, row) {
			var key = $(row).find('select.saxtmpl-key').val();
			var value = $(row).find('.saxtmpl-val').val();
			outputItems[currentMsg][key] = value;
		});
		outputFields.push(outputItems);
		
		items["outputFields"] = outputFields;
		items["configFields"] = configFields;
		return JSON.stringify(items);
	};
	
	self.setEnrichFields = function(curComp) {
		var enrichFlds = '';
		for ( var t=0; t<curComp.config.length; t++ ) {
				var configLen = curComp.config[t].length;
				var colonIdx = curComp.config[t].indexOf(":");
				configKey = curComp.config[t].substring(0, colonIdx);
				configVal = curComp.config[t].substring(colonIdx+1, configLen).trim();
				if ( configKey == 'enrichFlds' &&  !$.isEmptyObject(configVal) ) {
					enrichFlds = configVal;
				}
		}

		var editEnrich = JSON.parse(enrichFlds);
		if ( !$.isEmptyObject(editEnrich) ) {
			if ( typeof editEnrich.outputFields !== 'undefined' && editEnrich.outputFields.length > 0 ) {
				$.each(editEnrich.outputFields[0], function(key, value) {
					$('select.enrichMsseges').val(key).trigger('change');
					$('#addOutputFldDiv').empty();
					setTimeout(function() {
						$.each(value, function(enKey, enVal) {
							$('#addEnrichOPField').trigger('click');
							$('#addOutputFldDiv').find('select.saxtmpl-key:last').val(enKey).trigger('change');
							$('#addOutputFldDiv').find('.saxtmpl-val.ui-autocomplete-input:last').val(enVal);
						});
					}, 200);
				});
			}
			
			if ( typeof editEnrich.configFields !== 'undefined' &&  !$.isEmptyObject(editEnrich.configFields) ) {
				$.each(editEnrich.configFields, function(confKey, confValue) {
					$('#addEnrichConfField').trigger('click');
					$('#addConFldDiv').find('input.saxtmpl-key:last').val(confKey);
					$('#addConFldDiv').find('.saxtmpl-val.ui-autocomplete-input:last').val(confValue);
				});
			}
			
			setTimeout(function() {
				$('#addConFldDiv .saxtmpl-row').each(function(i, row) {
					var _this = $(row).find('.saxtmpl-val.ui-autocomplete-input');
					lookupClass.checkLookFuncAdded(_this);
				});
				
				$('#addOutputFldDiv .saxtmpl-row').each(function(i, row) {
					var _this = $(row).find('.saxtmpl-val.ui-autocomplete-input');
					lookupClass.checkLookFuncAdded(_this);
				});
			}, 200);
		} else {
			$('#addOutputFldDiv').empty();
			$('#addEnrichOPField').trigger('click');
		}
	}
	
	self.addEnrichFieldRow = function(type, key, value) {
		var $wrap;
		var propObj = {
			"propertyName": {
				"type": "text",
				"value": key,
				"required": true
			},
			"propertyValue": {
				"type": "textarea",
				"value": value,
				"required": true
			}
		};
		
		if ( type == "output" ) {
			var selOptions = [];
			$('#addOutputFldDiv select.saxtmpl-key').each(function() {
				var fld = $(this).val();
				selOptions.push(fld);
			});
			
			var fldOpts = [];
			for ( var j=0; j<fieldListVal.length; j++ ) {
				if ( $.inArray(fieldListVal[j].fieldName, selOptions) == -1 ) {
					fldOpts.push({
						"label": fieldListVal[j].fieldLabel,
						"value": fieldListVal[j].fieldName
					});
				}
			}
			
			propObj.propertyName["type"] = "select";
			propObj.propertyName["options"] = fldOpts;
			$wrap = $("#addOutputFldDiv");
		} else {
			$wrap = $("#addConFldDiv");
		}
		
		var elemStr = SAXTemplate.createFormElements(propObj, [4, 8]);
		
		$wrap.append(elemStr);
		$wrap.find('.saxtmpl-row:last textarea.saxtmpl-val').attr('rows', '1');
		$wrap.find('.saxtmpl-row:last textarea.saxtmpl-val').css('height', '35px');
		$wrap.find('.saxtmpl-row:last').append('<a class="remove-saxtmpl-row remove-ico tt margin-ts pull-left margin-rl-m" title="'+ i18N['sax.label.remove'] +'" href="javascript:void(0)"><i class="fa fa-times"></i></a>');
		
		$wrap.find('.saxtmpl-row:last select').select2('destroy').select2({placeholder: i18N['sax.placeholder.pleaseSelect']});
		$wrap.find('.saxtmpl-row:last .saxtmpl-val').initQueryBuilder({data: fvAutoSuggestData});
	};
	
	self.init();
};

// Replay Channel
var replayLogsClass = new function() {
	var self = this;
	var curChnl = {};
	var replayChnlMap = {
		'source': {
			'validation': '',
			'type': 'radio',
			'style': 'display:none'
		},
		'requeueOnFail': {
			'validation': '',
			'type': 'text',
			'style': 'display:none'
		},
		'discardedExchangeName': {
			'validation': 'data-parsley-required="true" data-parsley-type="alphanum"',
			'type': 'text'
		},
		'discardedQueueName': {
			'validation': 'data-parsley-required="true" data-parsley-type="alphanum"',
			'type': 'text'
		},
		'exchangeName': {
			'validation': '',
			'type': 'text',
			'fieldId': 'replay_exchangeName',
			'style': 'display:none'
		},
		'queueName': {
			'validation': '',
			'type': 'text',
			'fieldId': 'replay_queueName',
			'style': 'display:none'
		},
		'routingKey': {
			'validation': '',
			'type': 'text',
			'fieldId': 'replay_routingKey',
			'style': 'display:none'
		}
	}
	
	self.init = function( curChnlObj ) {
		var replaySrcVal = "";		
		$(document).on('change', 'input[name="replaySrc"]', function(){
			replaySrcVal = $(this).val();
			if ( typeof curChnl !== 'undefined' ) {
				for( var i = 0; i < curChnl['replay-config'].source.length; i++ ) {
					if ( curChnl['replay-config'].source[i].name.toLowerCase() == replaySrcVal ) {
						$('#className').val(curChnl['replay-config'].source[i].className);
					}
				}
			}
		});
		
		$(document).on('change', '#discardMessageCB', function(){
			var isChecked = $(this).prop('checked');
			var connObj = $('#selectConnObj').val();
			connObj = JSON.parse(connObj);
			
			if ( isChecked ) {
				$('#connectionFld').closest('.row').removeClass('hidden');
				$('#deadLetterConfigRow').removeClass('hidden');
				$('.discardedExchangeName-fld, .discardedQueueName-fld').attr('data-parsley-required', 'true');
				if ( typeof connObj.connectionId === "undefined" )
					connObj['connectionId'] = "";
				
				if ( typeof connObj.connectionName === "undefined" )
					connObj['connectionName'] = "";
			} else {
				$('#connectionFld').closest('.row').addClass('hidden');
				$('#deadLetterConfigRow').addClass('hidden');
				$('.discardedExchangeName-fld, .discardedQueueName-fld').removeAttr('data-parsley-required').val('');
				delete connObj['connectionId'];
				delete connObj['connectionName'];
				connObj['connectionJson'] = {};
			}
			$('#selectConnObj').val(JSON.stringify(connObj));
		});
	};
	
	self.createFields = function( curChnlObj ) {
		curChnl = curChnlObj;
		var tempJSON = {};
		tempJSON['connectionJson'] = {};
		$('#persisterConfigTab1').append('<div class="row" id="deadLetterConfigRow"><div class="col-md-2 control-label">'+i18N['sax.label.deadLetterConfig']+'<span class="req">*</span></div><div class="col-md-10 dead-letter-config-row"></div></div><div class="row"><div class="col-md-2 control-label">'+i18N['sax.label.replayConfig']+'<span class="req">*</span></div><div class="col-md-10 replay-config-row"></div></div>');
		$('.replay-config-row').append($('#configRows'));
		$('#persisterConfigTab1').append('<input type="hidden" id="selectConnObj" name="selectConnObj" class="config-value select-conn-obj" />');
		$('input.msgtype-radio[value="single"]').trigger('click');
		var options = '<div class="radio-inline"><label class="margin-rl"><input class="radio config-value rabbitmq-fld" name="replaySrc" type="radio" value="rabbitmq">'+ i18N['sax.rabbitMq'] +'</label><label class="gray-txt"><input class="radio config-value kafka-fld" name="replaySrc" type="radio" value="kafka" disabled="disabled">'+ i18N['sax.kafka'] +'</label></div>';
		$('.replay-config-row #configRows').append(componentsProperties.funcCreateRadioFld('source','',options,replayChnlMap.source));
		$('.replay-config-row #configRows').append(componentsProperties.funcCreateTextField('exchangeName','',replayChnlMap.exchangeName,curChnl));
		$('.replay-config-row #configRows').append(componentsProperties.funcCreateTextField('queueName','',replayChnlMap.queueName, curChnl));
		$('.replay-config-row #configRows').append(componentsProperties.funcCreateTextField('routingKey','',replayChnlMap.routingKey, curChnl));
		$('#persisterConfigTab1 .row:nth-child(2)').remove();
		$('.replay-config-row .radio-inline input.radio:first').prop('checked',true).trigger('change');
		$('.dead-letter-config-row').append('<div class="col-md-11 dead-letter-flds"></div>');
		$('.dead-letter-flds').append(componentsProperties.funcCreateTextField('discardedExchangeName','',replayChnlMap['discardedExchangeName'], curChnl));
		$('.discardedExchangeName-fld').parent().append('<a href="javascript:void(0)" tabindex="-1" class="po infoico propico" title="discardedExchangeName" content="replay-channel_discardedExchangeName"><i class="fa fa-info-circle"></i></a>');
		$('.dead-letter-flds').append(componentsProperties.funcCreateTextField('discardedQueueName','',replayChnlMap['discardedQueueName'], curChnl));
		$('.discardedQueueName-fld').parent().append('<a href="javascript:void(0)" tabindex="-1" class="po infoico propico" title="discardedQueueName" content="replay-channel_discardedQueueName"><i class="fa fa-info-circle"></i></a>');
		$('.dead-letter-flds').append(componentsProperties.funcCreateTextField('requeueOnFail','false',replayChnlMap['requeueOnFail'], curChnl));
		
		var wasReplayChannel = '', hasReplayChannel = '';
		if ( !$.isEmptyObject(tmpSSData) ) {
			for ( var i=0; i<tmpSSData.spouts.length; i++ ) {
				if ( tmpSSData.spouts[i].id == cmpIDs.replaychannel ) wasReplayChannel = tmpSSData.spouts[i].name;
			}
		}

		for ( var i = 0; i < curChnl.config.length; i++ ) {
			var configLen = curChnl.config[i].length;
			var colonIdx = curChnl.config[i].indexOf(":");
			var configKey = curChnl.config[i].substring(0, colonIdx);
			var configVal = curChnl.config[i].substring(colonIdx+1, configLen).trim();
			if ( configKey == 'replayCount' ) {
				$('.replayCount-fld').val(configVal);
			} else if ( configKey == 'source' ) {
				$('input[name="replaySrc"][value="'+configVal+'"]').trigger('change');
			} else if ( configKey == 'exchangeName' ) {
				$('.exchangeName-fld').val(configVal);
			} else if ( configKey == 'queueName' ) {
				$('.queueName-fld').val(configVal);
			} else if ( configKey == 'routingKey' ) {
				$('.routingKey-fld').val(configVal);
			} else if ( configKey == 'discardedExchangeName' ) {
				$('.discardedExchangeName-fld').val(configVal);
			} else if ( configKey == 'discardedQueueName' ) {
				$('.discardedQueueName-fld').val(configVal);
			} else if ( configKey == 'requeueOnFail' ) {
				$('.requeueOnFail-fld').val('false');
			} else if ( configKey == "hosts" ) {
				tempJSON['connectionJson']["hosts"] = configVal;
			} else if ( configKey == "username" ) {
				tempJSON['connectionJson']["username"] = configVal;
			} else if ( configKey == "password" ) {
				tempJSON['connectionJson']["password"] = configVal;
			} else if ( configKey == "connectionId" ) {
				tempJSON["connectionId"]  = configVal;
			} else if ( configKey == "connectionName" ) {
				tempJSON["connectionName"]  = configVal;
				if(configVal != "")
					$('#connectionText').text(configVal);
			}
			
			if ( !$.isEmptyObject(tmpSSData) && configKey == "x-message-ttl" ) {
				if ( curChnl.id == cmpIDs.replaychannel ) {
					hasReplayChannel = curChnl.name;
				}
				
				if ( wasReplayChannel == hasReplayChannel ) {
					$('.x-message-ttl-fld').prop('disabled', true);
				}
			}
		}
		
		var isDiscardMsgUsed = false;
		if ( !$.isEmptyObject(tempJSON) ) {
			if ( tempJSON.connectionId ) {
				isDiscardMsgUsed = true;
			}
			$('#selectConnObj').val('');
			$('#selectConnObj').val(JSON.stringify(tempJSON));
			tempJSON = {};
			tempJSON['connectionJson'] = {};
		}
		
		$('#persisterConfigTab1').prepend('<div class="row margin-b"><div class="col-md-2"></div><div class="col-md-10"><div class="col-md-11"><div class="checkbox"><label><input type="checkbox" id="discardMessageCB"> '+ i18N['sax.notification.wantUseDiscardedMessage'] +'</label></div></div></div></div>');
		$('#discardMessageCB').prop('checked', isDiscardMsgUsed).trigger('change');
	};
	
	self.createReplayChnlData = function(){
		var replayChnlArr = []; 
		$('#persisterConfigTab1').find('.config-row').each(function(index, row){
			var key, val;
			key = $(row).find('.config-key').val();
			val = $(row).find('.config-value').val();
			replayChnlArr.push(key+':'+val);
		});
		
		return replayChnlArr;
	};
	
	self.schemeValue = function() {
		return curChnl.scheme;
	}
	
	self.init(curChnl);
};

// JDBC Processor Class
var jdbcProcessorCls = new function() {
	var self = this,
		schemaTableUrl = baseUrl+'/datafabric/getTableSchema';
		
	self.init = function(comp) {
		$('#configRowsWrap').after('<div class="form-group"><div class="col-sm-11 text-right"><input type="button" class="btn btn-default" id="getSchemaTableBtn" value="Fetch Schema" /></div></div><div id="schemaResultsWrap" class="form-group hidden"><div class="col-sm-12"><hr /><h4>Schema Results</h4><div id="schemaResults" class="schema-results"></div></div></div>');
		
		for ( var i=0; i<comp.config.length; i++ ) {
			if ( comp.config[i].indexOf('mappedSchema:') == 0 ) {
				var data = comp.config[i].replace('mappedSchema:', '');
				data = JSON.parse(data);
				if ( data.length > 0 )
					self.renderSchemaResults(data);
			}
		}

		$('#getSchemaTableBtn').on('click', function() {
			var validate = true, flag = true;
			$("#configRows [data-parsley-required='true']").each(function() {
				flag = $(this).parsley().validate();
				if ( flag != true ) validate = false;
			});
			
			if ( validate ) {
				var params = {
					databaseType: $('select.databaseType-fld').val(),
					connectionURL: $('.connectionURL-fld').val(),
					username: $('.username-fld').val(),
					password: $('.password-fld').val(),
					tableName: $('.tableName-fld').val()
				};
				
				params = JSON.stringify(params);
				var schemaTableData = DFSubSytemDefination.postAjaxData(schemaTableUrl, params);
				self.renderSchemaResults(schemaTableData);
			}
		});
		
		$(document).on('change', '.isIgnore', function() {
			var isChecked = $(this).prop('checked');
			if ( isChecked ) {
				$(this).closest('.config-row').find('.config-value').val('').prop('disabled', true).removeAttr('data-parsley-required');
			} else {
				$(this).closest('.config-row').find('.config-value').prop('disabled', false).attr('data-parsley-required', 'true');
			}
		});
		
		$(document).on('change', '#jdbcMsgSelector', function() {
			$('#schemaResults > .config-row').each(function() {
				$(this).find('.config-value').val('');
			});
			self.attachQueryBuilder();
		});
	};
	
	self.renderSchemaResults = function(d) {
		$('#schemaResultsWrap').removeClass('hidden');
		$('#schemaResults').empty();
		
		if ( typeof d.thrownError !== "undefined" ) {
			$('#schemaResults').html('<div class="alert alert-error alert-dismissable">' + errorObj.TABLE_RENDERING + '</div>');
			return;
		} else if ( d.length == 0 ) {
			$('#schemaResults').html('<div class="alert alert-info alert-dismissable">' + errorObj.NO_DATA + '</div>');
			return;
		}
		
		for ( var i=0; i<d.length; i++ ) {
			var val = (d[i].value == null) ? '' : d[i].value;
			var key = (d[i].isPrimaryKey == 'true') ? '<i class="fa fa-key"></i>' : '';
			var checked = (d[i].isIgnore == 'true') ? 'checked' : '';
			var disabled = (d[i].isIgnore == 'true') ? 'disabled' : '';
			$('#schemaResults')
				.append('<div class="config-row">' +
							'<div class="col-sm-3 text-right margin-ts">'+ d[i].columnName +'</div>' +
							'<div class="col-sm-4 primary-key-wrap">' +
								'<input type="text" data-parsley-required="true" placeholder="'+ i18N['sax.placeholder.pleaseEnterValue'] +'" value="'+ val +'" class="form-control config-value" data-isprimarykey="'+ d[i].isPrimaryKey +'" data-name="'+ d[i].columnName +'" data-sqltype="'+ d[i].sqlType +'" data-datatype="'+ d[i].dataType +'" data-isignore="'+ d[i].isIgnore +'" '+ disabled +'>' +
								'<span class="primary-key">' +
									key +
								'</span>' +
							'</div>' +
							'<div class="col-sm-3">' +
								'<span class="margin-lm margin-ts pull-left">' +
									d[i].dataType +
								'</span>' +
							'</div>' +
							'<div class="col-sm-2">' +
								'<div class="checkbox pull-left margin-lm">' +
									'<label>' +
										'<input type="checkbox" class="isIgnore" '+ checked +'> Ignore' +
									'</label>' +
								'</div>' +
							'</div>' +
						'</div>'
					);
		}
		
		self.attachQueryBuilder();
		
		setTimeout(function() {
			$('#schemaResults .isIgnore').trigger('change');
		}, 300);
	};
	
	self.getSchemaResults = function() {
		var obj = [];
		
		$('#schemaResults > .config-row').each(function(i, row) {
			var name = $(row).find('.config-value').data('name');
			var isPrimaryKey = $(row).find('.config-value').data('isprimarykey');
			var dataType = $(row).find('.config-value').data('datatype');
			var sqlType = $(row).find('.config-value').data('sqltype');
			var isIgnore = $(row).find('.isIgnore').prop('checked');
			var value = $(row).find('.config-value').val();
			
			obj.push({
				columnName: name,
				value: value,
				dataType: dataType,
				sqlType: parseInt(sqlType),
				isIgnore: isIgnore.toString(),
				isPrimaryKey: isPrimaryKey.toString()
			});
		});
		
		return JSON.stringify(obj);
	};
	
	self.attachQueryBuilder = function() {
		var msg = $('#jdbcMsgSelector').val();
		var autoSuggData = $.extend(true, {}, fvAutoSuggestData);
		autoSuggData['$'] = {};
		autoSuggData['@'].data = $.grep(autoSuggData['@'].data, function(obj) {
			return obj.value == 'Global' || obj.value == msg; 
		});
		
		$('#schemaResults .config-value').each(function() {
			$(this).initQueryBuilder({data: autoSuggData});
		});
	};
};