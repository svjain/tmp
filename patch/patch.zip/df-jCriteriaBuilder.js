;( function($) {
	jQuery.each(criteria_line_templates, function(name, code) {
		jQuery.template(name, code);
	});

	$.fn.append_criteria_line = function(index, options) {
		var opts = $.extend({}, $.fn.append_criteria_line.defaults, options);


		return this.each(function() {
			$('.context_select').die().live('change', function() {
				var type = $(this).find('option:selected').tmplItem().data.type;
				if ( type ) {
					var cTypes = {};
					var criteriatype = $(this).closest('.alertCriteria').data('criteriatype');
					if ( criteriatype && criteriatype == 'agg_where' ) {
						cTypes = aggWhereTypes[type];
					} else if ( criteriatype && criteriatype == 'agg_having' ) {
						cTypes = aggHavingTypes[type];
					} else {
						cTypes = types[type];
					}
					var $comparitor_select = $(this).closest(".criteria_wrap").find('select.comparitor_select');
					$comparitor_select.empty();
					jQuery.tmpl('option', cTypes).appendTo($comparitor_select).change();
				}
			});
			$('.comparitor_select').die().live('change', function() {
				var type = $(this).find('option:selected').tmplItem().data.fields;
				if ( type ) {
					var current_id = $(this).tmplItem().data.id;
					var $fields = $(this).next();
					
					var id = $(this).closest('.alertCriteriaWrap').attr("id");

					var rows = $("#"+id).find(".alertCriteria").find(".criteria_wrap");	
					var tmpArr = [];				
					for ( var i=0; i<rows.length; i++ ) {
						var fieldValue = $(rows[i]).find(".criteria_fields > span[class^='input_']:first input").val();
						var fieldValue2 = $(rows[i]).find(".criteria_fields > span[class^='input_']:last input").val();
						var inputSize = $(rows[i]).find(".criteria_fields > span[class^='input_']").size();
						
						if ( inputSize > 1 )
							fieldValue += '-'+fieldValue2;
						
						tmpArr.push(fieldValue);
					}
					$fields.empty();
					
					if ( type.join('') == 'boolean' ) {
						var $selFields = jQuery.tmpl('boolean_sel', {id: current_id}).appendTo($fields);
						jQuery.tmpl('option', boolObjList).appendTo($selFields);
						jQuery.tmpl('field_hidden', type, {id: current_id}).appendTo($fields);
						jQuery($selFields).select2('destroy').select2();
						setTimeout(function() { jQuery($selFields).trigger('change'); }, 500);
					} else {
						jQuery.tmpl('field', type, {id: current_id}).appendTo($fields);
					}

					for ( var i=0; i<tmpArr.length; i++ ) {
						var vals = (tmpArr[i]) ? tmpArr[i].split('-') : [''];
						$(rows[i]).find(".criteria_fields > span[class^='input_']:first input").val( vals[0] );
						if ( vals.length == 2 ) {
							$(rows[i]).find(".criteria_fields > span[class^='input_']:last input").val( vals[1] );
						}
					}

					if ( type != null &&  type.length > 1 ) {
						$fields.find('input').each(function(index) {
							$(this).attr('id', $(this).attr('id') + "_" + index);
						});
					}
				}
			});

			var curTabId = $(this).closest(".alertCriteriaWrap").attr("id");
			var $new_line = jQuery.tmpl('criteria_line', {id: index, context: available_criteria[curTabId]})
			$new_line.dom_attachment_method = opts.attach_method;
			$new_line.dom_attachment_method($(this)).find('select:first').change();
		});
	}


	$.fn.append_criteria_line.defaults = {
		attach_method: $().appendTo
	}
	

	var curr_criteria_index = 0;
	$.fn.add_criteria = function(options) {
		var opts = $.extend({}, $.fn.add_criteria.defaults, options);
		
		return this.each(function() {
			var $criteria_area = $(this);
			$('a.add-criteria').die().live('click', function() {
				//$criteria_area.add_criteria();
				curr_criteria_index++;
				var $criteria = jQuery.tmpl('criteria', {id: curr_criteria_index}).appendTo( $(this).closest('.criteria_wrap').parent() );
				$criteria.append_criteria_line(curr_criteria_index, {attach_method: $().prependTo});
				$("#criteria_wrapper_"+ (curr_criteria_index-1) ).hide();
				setTimeout( function() {
					$("#criteria_wrapper_"+ (curr_criteria_index-1) ).show();
				}, 5);
				$(".tt").tooltip();
			});

			$('a.del-criteria').die().live('click', function () {
				$(this).parent().remove();
				$(".criteria_wrap:first-child").find(".condition_select").remove();
			});
			curr_criteria_index++;
			var $criteria = jQuery.tmpl('criteria', {id: curr_criteria_index}).appendTo($(this));
			$criteria.append_criteria_line(curr_criteria_index, {attach_method: $().prependTo});
			$(".criteria_wrap:first-child").find(".operand_select").css({"visibility": "hidden"});
			$(".criteria_wrap:first-child").find("a.del-criteria").css({"visibility": "hidden"});
		});
	}

	$.fn.add_criteria.defaults = {
	
	}
})(jQuery);

/* The field criteria_string contains the html for a string field, and critia_date contains the html for the date fields.
 * Each is used accordingly. May need to provide them myself.
 */
var boolObjList = [
	{name: 'true', label: i18N['sax.label.true'], fields: ['boolean']},
	{name: 'false', label: i18N['sax.label.false'], fields: ['boolean']}
];


var types = {
	'string': [
		{name: 'contains', label: i18N['sax.label.contains'], fields: ['string']},
		{name: 'does not contain', label: i18N['sax.label.doesNotContain'], fields: ['string']},
		{name: "starts with", label: i18N['sax.label.startsWith'], fields: ['string']},
		{name: 'ends with', label: i18N['sax.label.endsWith'], fields: ['string']},
		{name: 'equals', label: i18N['sax.label.equals'], fields: ['string']},
		{name: 'not equal', label: i18N['sax.label.notEqual'], fields: ['string']},
		{name: "does not start with", label: i18N['sax.label.doesNotStartWith'], fields: ['string']},
		{name: 'does not end with', label: i18N['sax.label.doesNotEndWith'], fields: ['string']}
	],
	'date': [
		{name: 'equals', label: i18N['sax.label.equals'], fields: ['string']},
		{name: 'not equal', label: i18N['sax.label.notEqual'], fields: ['string']},
		{name: 'less than', label: i18N['sax.label.lessThan'], fields: ['string']},
		{name: 'greater than', label: i18N['sax.label.greaterThan'], fields: ['string']},
		{name: 'less than equal to', label: i18N['sax.label.lessThanEqualTo'], fields: ['string']},
		{name: 'greater than equal to', label: i18N['sax.label.greaterThanEqualTo'], fields: ['string']},
		{name: 'between', label: i18N['sax.label.between'], fields: ['date', 'date']}
	],
	'long': [
		{name: 'equals', label: i18N['sax.label.equals'], fields: ['int']},
		{name: 'not equal', label: i18N['sax.label.notEqual'], fields: ['int']},
		{name: 'less than', label: i18N['sax.label.lessThan'],fields: ['int']},
		{name: 'greater than', label: i18N['sax.label.greaterThan'], fields: ['int']},
		{name: 'less than equal to', label: i18N['sax.label.lessThanEqualTo'],fields: ['int']},
		{name: 'greater than equal to', label: i18N['sax.label.greaterThanEqualTo'], fields: ['int']},
		{name: 'between', label: i18N['sax.label.between'], fields: ['int', 'int']}
	],
	'double': [
		{name: 'equals', label: i18N['sax.label.equals'], fields: ['int']},
		{name: 'not equal', label: i18N['sax.label.notEqual'], fields: ['int']},
		{name: 'less than', label: i18N['sax.label.lessThan'], fields: ['int']},
		{name: 'greater than', label: i18N['sax.label.greaterThan'], fields: ['int']},
		{name: 'less than equal to', label: i18N['sax.label.lessThanEqualTo'], fields: ['int']},
		{name: 'greater than equal to', label: i18N['sax.label.greaterThanEqualTo'], fields: ['int']},
		{name: 'between', label: i18N['sax.label.between'], fields: ['int', 'int']}
	],
	'integer': [
		{name: 'equals', label: i18N['sax.label.equals'], fields: ['int']},
		{name: 'not equal', label: i18N['sax.label.notEqual'], fields: ['int']},
		{name: 'less than', label: i18N['sax.label.lessThan'], fields: ['int']},
		{name: 'greater than', label: i18N['sax.label.greaterThan'], fields: ['int']},
		{name: 'less than equal to', label: i18N['sax.label.lessThanEqualTo'], fields: ['int']},
		{name: 'greater than equal to', label: i18N['sax.label.greaterThanEqualTo'], fields: ['int']},
		{name: 'between', label: i18N['sax.label.between'], fields: ['int', 'int']}
	],
	'ip': [
		{name: 'equals', label: i18N['sax.label.equals'], fields: ['string']},
		{name: 'not equal', label: i18N['sax.label.notEqual'], fields: ['string']}/*,
		{name: 'is IP in range', label: i18N['sax.label.isIPinRange'], fields: ['string']},
		{name: 'is IP belongs to subnet', label: i18N['sax.label.isIPBelongsToSubnet'], fields: ['string']}*/
	],
	'boolean': [
		{name: 'equals', label: i18N['sax.label.equals'], fields: ['boolean']},
		{name: 'not equal', label: i18N['sax.label.notEqual'], fields: ['boolean']}
	]
};

var aggWhereTypes = {
	'string': [
		{name: 'equals', label: i18N['sax.label.equals'], fields: ['string']},
		{name: 'not equal', label: i18N['sax.label.notEqual'], fields: ['string']},
		{name: "in", label: 'in', fields: ['string']},
		{name: 'not in', label: 'not in', fields: ['string']}
	],
	'long': [
		{name: 'equals', label: i18N['sax.label.equals'], fields: ['int']},
		{name: 'not equal', label: i18N['sax.label.notEqual'], fields: ['int']},
		{name: 'less than', label: i18N['sax.label.lessThan'],fields: ['int']},
		{name: 'greater than', label: i18N['sax.label.greaterThan'], fields: ['int']},
		{name: 'less than equal to', label: i18N['sax.label.lessThanEqualTo'],fields: ['int']},
		{name: 'greater than equal to', label: i18N['sax.label.greaterThanEqualTo'], fields: ['int']},
		{name: 'between', label: i18N['sax.label.between'], fields: ['int', 'int']},
		{name: 'not between', label: 'not between', fields: ['int', 'int']}
	],
	'double': [
		{name: 'equals', label: i18N['sax.label.equals'], fields: ['int']},
		{name: 'not equal', label: i18N['sax.label.notEqual'], fields: ['int']},
		{name: 'less than', label: i18N['sax.label.lessThan'], fields: ['int']},
		{name: 'greater than', label: i18N['sax.label.greaterThan'], fields: ['int']},
		{name: 'less than equal to', label: i18N['sax.label.lessThanEqualTo'], fields: ['int']},
		{name: 'greater than equal to', label: i18N['sax.label.greaterThanEqualTo'], fields: ['int']},
		{name: 'between', label: i18N['sax.label.between'], fields: ['int', 'int']},
		{name: 'not between', label: 'not between', fields: ['int', 'int']}
	]
};

var aggHavingTypes = {
	'integer': [
		{name: 'equals', label: i18N['sax.label.equals'], fields: ['int']},
		{name: 'not equal', label: i18N['sax.label.notEqual'], fields: ['int']},
		{name: 'less than', label: i18N['sax.label.lessThan'],fields: ['int']},
		{name: 'greater than', label: i18N['sax.label.greaterThan'], fields: ['int']},
		{name: 'less than equal to', label: i18N['sax.label.lessThanEqualTo'],fields: ['int']},
		{name: 'greater than equal to', label: i18N['sax.label.greaterThanEqualTo'], fields: ['int']},
		{name: 'between', label: i18N['sax.label.between'], fields: ['int', 'int']},
		{name: 'not between', label: 'not between', fields: ['int', 'int']}
	]
};

var available_criteria = {};
