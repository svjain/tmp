/*
 *This will have code to invoke PayloadParser if no configurations are found 
 */
package com.impetus.fm.parser;

import java.io.File;
import java.io.FileInputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.fasterxml.jackson.xml.XmlMapper;
import com.streamanalytix.framework.api.storm.parser.Parser;

/** The Class SampleXmlParser is a parser class which is parsing XML Data into JSON Data. */
public class FMXmlParser implements Parser {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 5149243120057147354L;

    /** The Constant LOGGER. */
    private static final Log LOGGER = LogFactory.getLog(FMXmlParser.class);

    /** The xml mapper. */
    private transient XmlMapper xmlMapper;

    /** The object mapper. */
    private transient ObjectMapper objectMapper;
    
    /** The config map. */
    private Map<String, String> configMap;
    
    private boolean payloadParser;
    /*
     * (non-Javadoc)
     * @see com.streamanalytix.framework.api.BaseComponent#init(java.util.Map)
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void init(Map configMap) {
        xmlMapper = new XmlMapper();
        objectMapper = new ObjectMapper();
        
        //configMap = readConfigFile();//To be removed: for standalone testing only
        this.configMap = configMap;   
        
        if(this.configMap.containsKey(Constants.PAYLOAD_PARSER)){
        	this.payloadParser = Boolean.valueOf(this.configMap.get(Constants.PAYLOAD_PARSER).toString());
        }
    }
    
    public JSONObject parse(byte[] message) {
    	
        LOGGER.info("Enter parse method: FMXmlParser" );
        
        JSONObject json = new JSONObject();
        try {
            String xml = new String(message);
            xml = formatXmlString(xml);
            DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            
            //LOGGER.info("Input XML:- " + xml);
            
            //Settings for non-validating XML
            builderFactory.setValidating(false);
            builderFactory.setFeature("http://xml.org/sax/features/validation", false);
            builderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-dtd-grammar", false);
            builderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

            DocumentBuilder builder =  builderFactory.newDocumentBuilder();
             
            Document xmlDocument = builder.parse(new InputSource( new StringReader( xml ) ) );
            
            XPath xPath =  XPathFactory.newInstance().newXPath();
 
            if(!this.payloadParser){
            	LOGGER.info("##### configurations were provided for Fraud Detection Parser, hence calling #####");
            	
                FraudFields fraudFields = new FraudFields();
            	json = fraudFields.populateMap(xmlDocument, xPath, configMap, xml);
            } else {
            	LOGGER.info("##### No configurations were provided for Fraud Detection Parser, hence calling Payload XML Parser #####");
            	
                PayloadFields payloadFields = new PayloadFields();
                json = payloadFields.populateMap(xmlDocument, xPath, xml);
            }
            
            //System.out.println(json);
            LOGGER.info("json::::::: " + json);
        } catch (Exception e) {
            LOGGER.error("Exception while parsing xml to json: ", e);
            e.printStackTrace();
        }
        
        LOGGER.info("Exit parse method: FMXmlParser");
        return json;
    }
   
    
    /** This method is parsing the data from xml to list of json.
     * 
     * @param message
     *            the message is the xml data in bytes
     * @return the list */
    @SuppressWarnings("unchecked")
    public List<JSONObject> parseToArray(byte[] message) {
        LOGGER.info("Enter parseToArray method:");

        JSONArray jsonArray = null;
        try {

            String xml = new String(message);
            List<String> entries = xmlMapper.readValue(xml, List.class);
            String json = objectMapper.writeValueAsString(entries);
            jsonArray = (JSONArray) JSONValue.parse(json);

        } catch (Exception e) {
            LOGGER.error("Exception while parsing xml to json array: ", e);
        }

        List<JSONObject> jsonDataList = new ArrayList<JSONObject>();
        if (null != jsonArray && jsonArray.size() != 0) {
            for (int i = 0; i < jsonArray.size(); i++) {
                jsonDataList.add((JSONObject) jsonArray.get(i));
            }
        }
        LOGGER.info("Exit parseToArray method:");
        return jsonDataList;
    }

    /*
     * (non-Javadoc)
     * @see com.streamanalytix.framework.api.BaseComponent#cleanup()
     */

    public void cleanup() {
    }
    
    /*
     * Method for stand-alone testing
     */
    public static void main(String[] args) {
        FileInputStream fileInputStream = null;

        File file = new File("/home/IMPETUS/mmaheshwari/Downloads/Fannie Mae/Sample XML/t/POOL_7_Acquisition.xml");
        byte[] bFile = new byte[(int) file.length()];

        try {
            // convert file into array of bytes
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bFile);
            fileInputStream.close();

            Map<String, Object> configMap = new HashMap<String, Object>();
            configMap.put("payloadParser", "true");
            
            FMXmlParser parser = new FMXmlParser();
            parser.init(configMap);
            JSONObject jsonObject = parser.parse(bFile);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Removes new lines, tabs and single quotes from the incoming xml.
     * @param xml
     * @return
     */
    public String formatXmlString(String xml){
    	return xml.replaceAll(System.getProperty("line.separator"), "").replaceAll("\t", "").replaceAll("'", "");
    }
}