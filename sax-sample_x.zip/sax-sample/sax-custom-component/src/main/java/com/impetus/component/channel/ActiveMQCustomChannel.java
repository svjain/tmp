package com.impetus.component.channel;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeSet;
import java.util.concurrent.LinkedBlockingQueue;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.spout.Scheme;
import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.utils.Utils;

import com.streamanalytix.framework.api.storm.channel.Channel;

public class ActiveMQCustomChannel implements Serializable, Channel, MessageListener {

    private static final long serialVersionUID = -71711054185289348L;

    private static final Log LOGGER = LogFactory.getLog(ActiveMQCustomChannel.class);

    // JMS options
    private int jmsAcknowledgeMode = Session.AUTO_ACKNOWLEDGE;

    private boolean distributed = true;
    private LinkedBlockingQueue<Message> queue;
    private TreeSet<ActiveMQCustomChannelHelper> toCommit;
    private HashMap<ActiveMQCustomChannelHelper, Message> pendingMessages;
    private long messageSequence = 0;

    private SpoutOutputCollector collector;

    private transient Connection connection;
    private transient Session session;

    private boolean hasFailures = false;
    public final Serializable recoveryMutex = "RECOVERY_MUTEX";
    private Timer recoveryTimer = null;
    private long recoveryPeriod = -1; // default to disabled
    private String url;
    private static String subject = "TESTQUEUE";
    private Scheme serialisationScheme;

    @Override
    public void init(Map<String, Object> configMap) {
        url = "failover://tcp://172.26.32.37:61616";// ActiveMQConnection.DEFAULT_BROKER_URL;
        this.serialisationScheme = (Scheme) configMap.get("scheme");
        this.jmsAcknowledgeMode = Session.AUTO_ACKNOWLEDGE;
    }

    @Override
    public void openChannel(Map conf, TopologyContext context, SpoutOutputCollector collector) {
        Long topologyTimeout = (Long) conf.get("topology.message.timeout.secs");

        topologyTimeout = topologyTimeout == null ? 30 : topologyTimeout;
        if ((topologyTimeout.intValue() * 1000) > this.recoveryPeriod) {
            LOGGER.warn("*** WARNING *** : " + "Recovery period (" + this.recoveryPeriod + " ms.) is less then the configured "
                    + "'topology.message.timeout.secs' of " + topologyTimeout + " secs. This could lead to a message replay flood!");
        }
        this.queue = new LinkedBlockingQueue<Message>();
        this.toCommit = new TreeSet<ActiveMQCustomChannelHelper>();
        this.pendingMessages = new HashMap<ActiveMQCustomChannelHelper, Message>();
        this.collector = collector;
        try {
            ConnectionFactory cf = new ActiveMQConnectionFactory(url);

            this.connection = cf.createConnection();

            Session session = connection.createSession(false, this.jmsAcknowledgeMode);
            Destination dest = session.createQueue(subject);

            MessageConsumer consumer = session.createConsumer(dest);
            consumer.setMessageListener(this);
            this.connection.start();
            if (this.isDurableSubscription() && this.recoveryPeriod > 0) {
                this.recoveryTimer = new Timer();
                this.recoveryTimer.scheduleAtFixedRate(new RecoveryTask(), 10, this.recoveryPeriod);
            }

        } catch (Exception e) {
            LOGGER.warn("Error creating JMS connection.", e);
        }

    }

    @Override
    public void closeChannel() {
        try {
            LOGGER.debug("Closing JMS connection.");
            this.session.close();
            this.connection.close();
        } catch (Exception e) {
            LOGGER.warn("Error closing JMS connection.", e);
        }

    }

    @Override
    public void activateChannel() {
    }

    @Override
    public void deactivateChannel() {
    }

    @Override
    public void nextMessage() {
        Message msg = this.queue.poll();
        if (msg == null) {
            Utils.sleep(50);
        } else {

            LOGGER.debug("sending tuple: " + msg);
            // get the tuple from the handler
            try {
                String msgtxt = ((TextMessage) msg).getText();
                List<Object> values = serialisationScheme.deserialize(msgtxt.getBytes());
                // ack if we're not in AUTO_ACKNOWLEDGE mode, or the message
                // requests ACKNOWLEDGE
                LOGGER.info("Requested deliveryMode: " + toDeliveryModeString(msg.getJMSDeliveryMode()));
                LOGGER.info("Our deliveryMode: " + toDeliveryModeString(this.jmsAcknowledgeMode));

                if (values != null && values.size() > 0) {
                    Set<String> streamIdList = (Set<String>) values.get(1);
                    if (this.isDurableSubscription() || (msg.getJMSDeliveryMode() != Session.AUTO_ACKNOWLEDGE)) {
                        LOGGER.debug("Requesting acks.");
                        ActiveMQCustomChannelHelper messageId = new ActiveMQCustomChannelHelper(this.messageSequence++, msg.getJMSMessageID());
                        for (String streamId : streamIdList) {
                            if (!"defaultStream".equals(streamId)) {
                                collector.emit(streamId, values, messageId);
                            } else {
                                collector.emit(values, messageId);
                            }
                        }
                        // at this point we successfully emitted. Store
                        // the message and message ID so we can do a
                        // JMS acknowledge later
                        this.pendingMessages.put(messageId, msg);
                        this.toCommit.add(messageId);
                    } else {
                        for (String streamId : streamIdList) {
                            if (!"defaultStream".equals(streamId)) {
                                collector.emit(streamId, values);
                            } else {
                                collector.emit(values);
                            }
                        }
                    }

                }

            } catch (Exception e) {
                LOGGER.warn("Unable to convert JMS message: " + msg);
            }

        }

    }

    @Override
    public void acknowledge(Object msgId) {
        Message msg = this.pendingMessages.remove(msgId);
        ActiveMQCustomChannelHelper oldest = this.toCommit.first();
        if (msgId.equals(oldest)) {
            if (msg != null) {
                try {
                    LOGGER.debug("Committing...");
                    msg.acknowledge();
                    LOGGER.debug("JMS Message acked: " + msgId);
                    this.toCommit.remove(msgId);
                } catch (Exception e) {
                    LOGGER.warn("Error acknowldging JMS message: " + msgId, e);
                }
            } else {
                LOGGER.warn("Couldn't acknowledge unknown JMS message ID: " + msgId);
            }
        } else {
            this.toCommit.remove(msgId);
        }

    }

    @Override
    public void failure(Object msgId) {
        LOGGER.warn("Message failed: " + msgId);
        this.pendingMessages.clear();
        this.toCommit.clear();
        synchronized (this.recoveryMutex) {
            this.hasFailures = true;
        }

    }

    /** Sets the JMS Session acknowledgement mode for the JMS seesion associated with this spout.
     * <p/>
     * Possible values:
     * <ul>
     * <li>javax.jms.Session.AUTO_ACKNOWLEDGE</li>
     * <li>javax.jms.Session.CLIENT_ACKNOWLEDGE</li>
     * <li>javax.jms.Session.DUPS_OK_ACKNOWLEDGE</li>
     * </ul>
     * 
     * @param mode
     *            JMS Session Acknowledgement mode
     * @throws IllegalArgumentException
     *             if the mode is not recognized. */
    public void setJmsAcknowledgeMode(int mode) {
        switch (mode) {
            case Session.AUTO_ACKNOWLEDGE:
            case Session.CLIENT_ACKNOWLEDGE:
            case Session.DUPS_OK_ACKNOWLEDGE:
                break;
            default:
                throw new IllegalArgumentException("Unknown Acknowledge mode: " + mode + " (See javax.jms.Session for valid values)");

        }
        this.jmsAcknowledgeMode = mode;
    }

    /** Returns the JMS Session acknowledgement mode for the JMS seesion associated with this spout.
     * 
     * @return */
    public int getJmsAcknowledgeMode() {
        return this.jmsAcknowledgeMode;
    }

    /** <code>javax.jms.MessageListener</code> implementation.
     * <p/>
     * Stored the JMS message in an internal queue for processing by the <code>nextTuple()</code> method. */
    public void onMessage(Message msg) {
        try {
            LOGGER.debug("Queuing msg [" + msg.getJMSMessageID() + "]");
        } catch (Exception e) {
        }
        this.queue.offer(msg);
    }

    /** Returns <code>true</code> if the spout has received failures from which it has not yet recovered. */
    public boolean hasFailures() {
        return this.hasFailures;
    }

    protected void recovered() {
        this.hasFailures = false;
    }

    /** Sets the periodicity of the timer task that checks for failures and recovers the JMS session.
     * 
     * @param period */
    public void setRecoveryPeriod(long period) {
        this.recoveryPeriod = period;
    }

    public boolean isDistributed() {
        return this.distributed;
    }

    /** Sets the "distributed" mode of this spout.
     * <p/>
     * If <code>true</code> multiple instances of this spout <i>may</i> be created across the cluster (depending on the "parallelism_hint" in the
     * topology configuration).
     * <p/>
     * Setting this value to <code>false</code> essentially means this spout will run as a singleton within the cluster ("parallelism_hint" will be
     * ignored).
     * <p/>
     * In general, this should be set to <code>false</code> if the underlying JMS destination is a topic, and <code>true</code> if it is a JMS queue.
     * 
     * @param distributed */
    public void setDistributed(boolean distributed) {
        this.distributed = distributed;
    }

    private static final String toDeliveryModeString(int deliveryMode) {
        switch (deliveryMode) {
            case Session.AUTO_ACKNOWLEDGE:
                return "AUTO_ACKNOWLEDGE";
            case Session.CLIENT_ACKNOWLEDGE:
                return "CLIENT_ACKNOWLEDGE";
            case Session.DUPS_OK_ACKNOWLEDGE:
                return "DUPS_OK_ACKNOWLEDGE";
            default:
                return "UNKNOWN";

        }
    }

    protected Session getSession() {
        return this.session;
    }

    private boolean isDurableSubscription() {
        return (this.jmsAcknowledgeMode != Session.AUTO_ACKNOWLEDGE);
    }

    private class RecoveryTask extends TimerTask {

        public void run() {
            synchronized (ActiveMQCustomChannel.this.recoveryMutex) {
                if (ActiveMQCustomChannel.this.hasFailures()) {
                    try {
                        LOGGER.info("Recovering from a message failure.");
                        ActiveMQCustomChannel.this.getSession().recover();
                        ActiveMQCustomChannel.this.recovered();
                    } catch (Exception e) {
                        LOGGER.warn("Could not recover jms session.", e);
                    }
                }
            }
        }
    }

    @Override
    public void cleanup() {
    }

}
