package com.impetus.component.executor;

import java.util.Map;

import net.minidev.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.streamanalytix.framework.api.storm.processor.Processor;

/** The Class SampleProcessingExecutor. */
public class SampleProcessingExecutor implements Processor {

    /** The Constant LOGGER. */

    private static final Log LOGGER = LogFactory.getLog(SampleProcessingExecutor.class);

    /** The init method is used to initialize the configuration.
     * 
     * 
     * @param configMap
     *            the config map */
    @Override
    public void init(Map<String, Object> configMap) {
        LOGGER.info("Configuration  " + configMap);

    }

    /** The process method is used to write custom implementation.
     * 
     * @param json
     *            the json data
     * @param configMap
     *            the config map */
    @Override
    public void process(JSONObject json, Map<String, Object> configMap) {

        LOGGER.info("Json Data Before adding pC: " + json + "configuration map : " + configMap);

        double openPrice = (Double) json.get("oP");
        double currentPrice = (Double) json.get("cP");

        double changePercent = 0;

        if (openPrice > 0) {
            changePercent = ((currentPrice - openPrice) / openPrice) * 100;
        }

        json.put("pC", changePercent);

        LOGGER.info("Json Data After adding pC: " + json);
    }

    /*
     * (non-Javadoc)
     * @see com.streamanalytix.framework.api.IExecutor#cleanup()
     */
    @Override
    public void cleanup() {
    }

}
