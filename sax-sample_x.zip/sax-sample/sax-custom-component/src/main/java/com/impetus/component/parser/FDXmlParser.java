package com.impetus.component.parser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.fasterxml.jackson.xml.XmlMapper;
import com.streamanalytix.framework.api.storm.parser.Parser;

/**
 * The Class FDPayloadXmlParser1 is a parser class which is parsing XML Data
 * into JSON Data.
 */
public class FDXmlParser implements Parser {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5149243120057147354L;

	/** The Constant LOGGER. */
	private static final Log LOGGER = LogFactory.getLog(FDXmlParser.class);

	/** The xml mapper. */
	private transient XmlMapper xmlMapper;

	/** The object mapper. */
	private transient ObjectMapper objectMapper;

	/** The config map. */
	private Map<String, String> configMap;

	/** Created for internal testing */
	private Properties prop = new Properties();
	public static File file;

	/** message sub type, internal to StreamAnalytix */
	private String messageSubtype;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.streamanalytix.framework.api.BaseComponent#init(java.util.Map)
	 */
	@Override
	public void init(Map configMap) {
		xmlMapper = new XmlMapper();
		objectMapper = new ObjectMapper();

		// configMap = readConfigFile();//To be removed: for standalone testing
		// only
		this.configMap = configMap;
	}

	/**
	 * For manual testing
	 */
	public static void main(String[] args) {
		FileInputStream fileInputStream = null;

		// file = new
		// File("/home/impadmin/Desktop/Fannie Mae/XMLS/MBS_TO_EDI.xml");
		file = new File(
				"/Users/rraizada/Documents/Fannie mae/sax-sample-125/sax-custom-component/src/main/java/com/impetus/component/TestXml.xml");
		byte[] bFile = new byte[(int) file.length()];

		try {
			// convert file into array of bytes
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(bFile);
			fileInputStream.close();

			FDXmlParser parser = new FDXmlParser();
			parser.init(null);
			JSONObject jsonObject = parser.parse(bFile);
			System.out.println(jsonObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Main parsing logic goes here
	 * 
	 * @param message
	 *            the message is the XML data in bytes
	 * @return the JSON object
	 */
	public JSONObject parse(byte[] message) {

		LOGGER.info("Enter parse method: FDPayloadXmlParser1");

		if (null == configMap || configMap.isEmpty()) {
			System.out.println("No configurations done from UI");
		}

		JSONObject json = new JSONObject();
		try {
			String xml = new String(message);
			xml = formatXmlString(xml);
			DocumentBuilderFactory builderFactory = DocumentBuilderFactory
					.newInstance();

			// Settings for non-validating XML
			builderFactory.setValidating(false);
			builderFactory.setFeature("http://xml.org/sax/features/validation",
					false);
			builderFactory
					.setFeature(
							"http://apache.org/xml/features/nonvalidating/load-dtd-grammar",
							false);
			builderFactory
					.setFeature(
							"http://apache.org/xml/features/nonvalidating/load-external-dtd",
							false);

			DocumentBuilder builder = builderFactory.newDocumentBuilder();

			Document xmlDocument = builder.parse(new InputSource(
					new StringReader(xml)));

			XPath xPath = XPathFactory.newInstance().newXPath();

			if (null != configMap && !configMap.isEmpty()) {
				json = populateMap(xmlDocument, xPath, configMap, xml);
			} else {
				System.out
						.println("##### No xpaths configured for Fraud Detection XML Parser #####");
			}
			System.out.println("json::::::: " + json);
		} catch (Exception e) {
			LOGGER.error("Exception while parsing xml to json: ", e);
			e.printStackTrace();
		}
		LOGGER.info("Exit parse method: FDPayloadXmlParser1");
		return json;
	}

	/**
	 * This method is parsing the data from xml to list of json.
	 * 
	 * @param message
	 *            the message is the xml data in bytes
	 * @return the list
	 */
	@Override
	public List<JSONObject> parseToArray(byte[] message) {
		LOGGER.info("Enter parseToArray method:");

		JSONArray jsonArray = null;
		try {

			String xml = new String(message);
			List<String> entries = xmlMapper.readValue(xml, List.class);
			String json = objectMapper.writeValueAsString(entries);
			jsonArray = (JSONArray) JSONValue.parse(json);

		} catch (Exception e) {
			LOGGER.error("Exception while parsing xml to json array: ", e);
		}

		List<JSONObject> jsonDataList = new ArrayList<JSONObject>();
		if (null != jsonArray && jsonArray.size() != 0) {
			for (int i = 0; i < jsonArray.size(); i++) {
				jsonDataList.add((JSONObject) jsonArray.get(i));
			}
		}
		LOGGER.info("Exit parseToArray method:");
		return jsonDataList;
	}

	public static String getValueForExp(Document xmlDocument, XPath xPath,
			String expression) throws XPathExpressionException {
		return xPath.compile(expression).evaluate(xmlDocument);
	}

	/**
	 * Reads the external properties file. This method is created to be used for
	 * stand-alone testing.
	 * 
	 * @return configuration map
	 */
	public static Map<String, String> readConfigFile() {
		Properties prop = new Properties();
		InputStream input = null;
		Map<String, String> configMap = new HashMap<String, String>();
		try {
			input = new FileInputStream(
					"/Users/rraizada/Documents/Fannie mae/sax-sample-125/sax-custom-component/src/main/java/com/impetus/component/config.properties");
			prop.load(input);
			for (final String name : prop.stringPropertyNames())
				configMap.put(name, prop.getProperty(name));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return configMap;
	}

	/**
	 * Removes new line, tabs and single quotes from xml string
	 * 
	 * @param xml
	 *            source xml
	 * @return formatted xml
	 */
	public String formatXmlString(String xml) {
		return xml.replaceAll("\n", "").replaceAll("\t", "")
				.replaceAll("'", "");
	}

	/**
	 * Extracts the configured xpaths, evaluates the expressions and populates
	 * the json object
	 * 
	 * @param xmlDocument
	 * @param xPath
	 * @param configMap
	 * @param xml
	 * @return
	 * @throws XPathExpressionException
	 */
	public JSONObject populateMap(Document xmlDocument, XPath xPath,
			Map<String, String> configMap, String xml)
			throws XPathExpressionException {
		LOGGER.info("Enter FDXmlParser.populateMap method");
		JSONObject jsonData = new JSONObject();

		for (Map.Entry<String, String> entry : configMap.entrySet()) {
			System.out.println("Key : " + entry.getKey() + " Value : "
					+ entry.getValue());
			LOGGER.info("Key : " + entry.getKey());
			// Key SCHEMA is internal to SAX. It contains comma separated list
			// of all the configuration passed through UI
			if (!StringUtils.equalsIgnoreCase(entry.getKey(), Constants.SCHEMA)) {
				if (!StringUtils.equalsIgnoreCase(entry.getKey(),
						Constants.RAW_XML)) {
					jsonData.put(
							entry.getKey(),
							getValueForExp(xmlDocument, xPath, entry.getValue()));
				} else if (StringUtils.equalsIgnoreCase(entry.getKey(),
						Constants.RAW_XML)
						&& StringUtils.equalsIgnoreCase(entry.getValue(),
								Constants.RAW_XML_IND)) {
					LOGGER.info("Should set raw xml in json!!!!");
					jsonData.put(entry.getKey(), xml);
				}

			}
		}
		LOGGER.info("#####JSON####  " + jsonData);
		//System.out.println("#####JSON####  " + jsonData);
		LOGGER.info("Exit FDXmlParser.populateMap method");
		return jsonData;
	}

	/**
	 * Getter for messageSubType
	 * 
	 * @return messagesubtype
	 */
	public String getMessageSubtype() {
		return messageSubtype;
	}

	/**
	 * Setter for messageSubType
	 * 
	 * @param messageSubtype
	 */
	public void setMessageSubtype(String messageSubtype) {
		this.messageSubtype = messageSubtype;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.streamanalytix.framework.api.BaseComponent#cleanup()
	 */

	@Override
	public void cleanup() {
	}
}