package com.impetus.component.executor;

import java.util.Iterator;
import java.util.Map;

import net.minidev.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.tuple.Tuple;

import com.streamanalytix.framework.api.storm.processor.TimerProcessor;

/** The Class SampleTimerExecutor. */
public class SampleTimerExecutor implements TimerProcessor {

    /** The Constant LOGGER. */
    private static final Log LOGGER = LogFactory.getLog(SampleTimerExecutor.class);

    /** The init method is used to initialize the configuration.
     * 
     * @param configMap
     *            the config map */

    @Override
    public void init(Map<String, Object> configMap) {
        LOGGER.info("Configuration  " + configMap);
    }

    /** Method there user can specify the filter/condition to call the processTimedData method. If this method returns true then only processTimedData
     * method will be called
     * 
     * 
     * @param json
     *            the json data
     * @return the boolean */

    @Override
    public Boolean processByCondition(JSONObject json) {
        LOGGER.info("Time based json data: " + json);
        return true;
    }

    /** Method that will be called on every tick occurs having records for that tick frequency. so the user can apply business logic on that records
     * 
     * @param jsonList
     *            the json list
     * @param configMap
     *            the config map
     * @return the map */

    @Override
    public Map<Tuple, JSONObject> processTimedData(Map<Tuple, JSONObject> jsonList, Map<Tuple, Map<String, Object>> configMap) {
        Iterator iterator = jsonList.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry mapEntry = (Map.Entry) iterator.next();
            JSONObject jsonObject = (JSONObject) mapEntry.getValue();
            // jsonObject :: JSON that contains the fields and their values.
            LOGGER.info("Time based json data: " + jsonObject);
        }

        Iterator itr = configMap.entrySet().iterator();
        while (itr.hasNext()) {
            Map.Entry mapEntry = (Map.Entry) itr.next();
            Map<String, Object> configMapObj = (Map<String, Object>) mapEntry.getValue();
            // configMapObj :: Map that contains the configuration Keys and
            // their values.
            LOGGER.info("Time based configuration map data : " + configMapObj);
        }

        return jsonList;
    }

    /** The process method is used to write custom implementation.
     * 
     * @param json
     *            the json data
     * @param configMap
     *            the config map */
    @Override
    public void process(JSONObject json, Map<String, Object> configMap) {
        LOGGER.info("Json Data:  " + json + ", Configuration Map:: " + configMap);
    }

    /** Clean the resources. */
    @Override
    public void cleanup() {
    }

}
