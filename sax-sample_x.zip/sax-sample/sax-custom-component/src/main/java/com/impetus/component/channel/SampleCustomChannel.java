package com.impetus.component.channel;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import backtype.storm.spout.Scheme;
import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.TopologyContext;

import com.streamanalytix.framework.api.storm.channel.Channel;

/** The Class SampleCustomChannel. */

public class SampleCustomChannel implements Serializable, Channel {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 4468288111469470242L;

    /** The collector is used to emit tuples from this channel. Tuples can be emitted at any time, including the open and close methods. */
    private SpoutOutputCollector collector;

    /** The config map. */
    private Map<String, Object> configMap;

    /** The scheme is responsible for deserialize the data which will be passed as byte array. */
    private Scheme scheme;

    /** The messageId would be any unique object for tagging emitted tuples. */
    private long messageId = 0;

    /** Initialize config map or variables which all are passed from channel on ui.
     * 
     * @param configMap
     *            the config map */
    @Override
    public void init(Map<String, Object> configMap) {
        this.configMap = configMap;

        /** If scheme is instance of Scheme, then use below code snippet. */
        this.scheme = (Scheme) configMap.get("scheme");

    }

    /** Called when a task for this component is initialized within a worker on the cluster. It is called once and can also be used for creating any
     * kind of connections by using initialized config map or variables.
     * 
     * @param conf
     *            the storm configuration for this channel.
     * @param context
     *            the context can be used to get information about this task's.
     * @param collector
     *            the collector is used to emit tuples from this channel. Tuples can be emitted at any time, including the open and close methods. */
    @Override
    public void openChannel(Map conf, TopologyContext context, SpoutOutputCollector collector) {
        this.collector = collector;
    }

    /** Called when channel is going to be shutdown. */
    @Override
    public void closeChannel() {
    }

    /** Called when a channel has been activated out of a deactivated mode. nextMessage will be called on this channel as soon as message arrive on the
     * queue. */
    @Override
    public void activateChannel() {
    }

    /** Called when a channel has been deactivated. nextMessage will not be called while a channel is deactivated. */
    @Override
    public void deactivateChannel() {
    }

    /** Emits the next message from the queue as a tuple.
     * 
     * If no message is ready to emit, this will wait for message to arrive on the queue. If the channel has no tuples to emit, this method should
     * return. */
    @Override
    public void nextMessage() {

        String dummyData = "This is a sample implementation of a custom channel.";

        /** If scheme is instance of Scheme, then use below code snippet. */

        List<Object> values = scheme.deserialize(dummyData.getBytes());

        if (values != null && values.size() > 0) {
            Set<String> streamIdList = (Set<String>) values.get(1);
            for (String streamId : streamIdList) {
                /** Emits a new tuple to the default output stream with the given message ID. */
                if (!"defaultStream".equals(streamId)) {
                    collector.emit(streamId, values, ++messageId);
                } else {
                    /** Emits a new tuple to the specified output stream with the given message ID. */
                    collector.emit(values, ++messageId);
                }
            }
        }

    }

    /** Acknowledge the message with the channel.
     * 
     * @param msgId
     *            the msg id */
    @Override
    public void acknowledge(Object msgId) {
    }

    /** Tells the channel to drop the message.
     * 
     * @param msgId
     *            the msg id */
    @Override
    public void failure(Object msgId) {
    }

    /** Called to release any kind of connections. */
    @Override
    public void cleanup() {
    }
}
