package com.impetus.component.channel;

import java.io.Serializable;

public class ActiveMQCustomChannelHelper implements Comparable<ActiveMQCustomChannelHelper>, Serializable {

    private static final long serialVersionUID = 304724581362287164L;

    private String jmsID;

    private Long sequence;

    public ActiveMQCustomChannelHelper(long sequence, String jmsID) {
        this.jmsID = jmsID;
        this.sequence = sequence;
    }

    public String getJmsID() {
        return this.jmsID;
    }

    @Override
    public int compareTo(ActiveMQCustomChannelHelper jmsMessageID) {
        return (int) (this.sequence - jmsMessageID.sequence);
    }

    @Override
    public int hashCode() {
        return this.sequence.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof ActiveMQCustomChannelHelper) {
            ActiveMQCustomChannelHelper id = (ActiveMQCustomChannelHelper) o;
            return this.jmsID.equals(id.jmsID);
        } else {
            return false;
        }
    }

}
