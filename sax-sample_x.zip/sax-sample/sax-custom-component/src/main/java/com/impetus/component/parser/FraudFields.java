package com.impetus.component.parser;

import java.util.Map;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;

import net.minidev.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;

public class FraudFields {
	
    /** The Constant LOGGER. */
    private static final Log LOGGER = LogFactory.getLog(FraudFields.class);
	private String messageSubtype;
	
	public JSONObject populateMap(Document xmlDocument,XPath xPath, Map<String, String> configMap, String xml) throws XPathExpressionException{
        LOGGER.info("Enter parse method: FraudFields.populateMap()" );
		JSONObject jsonData = new JSONObject();
		
		for (Map.Entry<String, String> entry : configMap.entrySet()) {
			String key = entry.getKey();
			LOGGER.debug("key:::::####:  " + key );
			if (!StringUtils.equalsIgnoreCase(key, Constants.SCHEMA)) {
		        if (!StringUtils.equalsIgnoreCase(key, Constants.RAW_XML)) {
		          jsonData.put(key, getValueForExp(xmlDocument, xPath, (String)entry.getValue()));
		        } else if ((StringUtils.equalsIgnoreCase(key, Constants.RAW_XML)) && 
		          (StringUtils.equalsIgnoreCase(key, Constants.RAW_XML_IND))) {
		        	LOGGER.debug("rawXMLInd = Y, setting xml in jason:::::::" + xml );
		          jsonData.put(key, xml);
		        }
		      }
		}// End of for loop
		
		LOGGER.info("Exit parse method: FraudFields.populateMap()" );
		return jsonData;
	}
	
	public static String getValueForExp(Document xmlDocument, XPath xPath, String expression) throws XPathExpressionException{
    	return xPath.compile(expression).evaluate(xmlDocument);
    }
	
	public String getMessageSubtype() {
		return messageSubtype;
	}


	public void setMessageSubtype(String messageSubtype) {
		this.messageSubtype = messageSubtype;
	}
}