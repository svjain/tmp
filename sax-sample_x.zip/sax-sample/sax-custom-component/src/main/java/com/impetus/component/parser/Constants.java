package com.impetus.fm.parser;

import java.util.HashMap;
import java.util.Map;

public class Constants {
	// Constants for TestXml: START
	public static String RAW_XML = "rawXML";
	public static String RAW_XML_IND = "Y";
	public static String SCHEMA = "schema";
	// Constants for TestXml: END 
	
	public static String POOL_COUNT = "PoolCount";
	public static String LOAN_COUNT = "LoanCount";
	public static String EVENT_TYPE = "EventType";
	
	public static String MESSAGE_FORMAT = "MessageFormat";
	
	public static String PAYLOAD_TIME = "payloadTime";
	public static String COMMON_NAME = "CommonName";
	public static String ENTITY_TYPE = "EntityType";
	public static String HOUR_OF_DAY = "HourOfDay";
	public static String MESSAGE_ID = "MessageID";
	public static String RAW_MESSAGE_PAYLOAD = "RawMessagePayload";
	public static String PAYLOAD_COUNT = "PayLoaDCount";
	public static String MESSAGE_COUNT = "messageCount";
	public static String MESSAGE_SUBTYPE = "MessageSubtype";
	public static String HOUR_WO_DATE = "HourWODate";
	
	public static String PAYLOAD_TYPE_MBS_TO_EDI = "MBS2EDI";
	public static String PAYLOAD_TYPE_ADS_TO_EDI = "ADS2EDI";
	
	private static String[] mbsEventTypesForPool = {"ISSN.POOL_SHELF_OPND_DACT","ISSN.POOL_SHELF_REOPENED_DACT","ISSN.POOL_SHELF_RECLOSED_DACT","ISSN.POOL_SHELF_OPND_DACT","ISSN.POOL_CLSD_DACT",
											"ISSN.POOL_CLSD_DACT","ISSN.POOL_REOPENED_RECLSD_DACT","ISSN.POOL_REOPENED_RECLSD_DACT","ISSN.POOL_CLPSD_DACT","ISSN.POOL_SHELF_CLSD_DACT",
											"ISSN.POOL_CLSD_DACT","ISSN.POOL_REOPENED_RECLSD_DACT","ISSN.POOL_CLPSD_DACT"};
	
	private static String[] mbsEventTypesForPoolPiece = {"ISSN.PPC_CLSD_DACT","ISSN.PPC_REOPENED_RECLSD_DACT","ISSN.PPC_CLPSD_DACT"};
	
	private static String[] adsEventTypesForAcquisition = {"MBS","CASH"};

	
	public static Map<String, String> TYPE_LOOKUP = new HashMap<String,String>(); //key will be entity_eventType
	
	static{
		for(String s : mbsEventTypesForPool){
			TYPE_LOOKUP.put("POOL_" + s,PAYLOAD_TYPE_MBS_TO_EDI );
		}
		
		for(String s : mbsEventTypesForPoolPiece){
			TYPE_LOOKUP.put("POOLPIECE_" + s,PAYLOAD_TYPE_MBS_TO_EDI );
		}
		
		for(String s : adsEventTypesForAcquisition){
			TYPE_LOOKUP.put("ACQUISITION_" + s, PAYLOAD_TYPE_MBS_TO_EDI );
		}
		
		TYPE_LOOKUP.put("ACQUISITION_CASH",PAYLOAD_TYPE_ADS_TO_EDI );
		TYPE_LOOKUP.put("ACQUISITION_MBS",PAYLOAD_TYPE_ADS_TO_EDI );
	}
	
	public static String PAYLOAD_PARSER = "payloadParser";
	
	public enum EntityType{
		MBS("MBS"),
		CASH("CASH"),
		CMMPILOT_ADSTOEDI_CASH("CMMPilot_ADSToEDI_CASH"),
		CMMPILOT_ADSTOEDI_POOL("CMMPilot_ADSToEDI_POOL");


		private String entityType;
		
		private EntityType(String entityType){
			this.entityType = entityType;
		}

		public String getEntityType() {
			return entityType;
		}
	}
	
	public enum EventType{
		ACQUISITION("Acquisition"),
		CMMPROTOTYPE("CMMPrototype");
		//ACQUISITION("ISSN.POOL_CLSD_DACT");
		
		private String eventType;
		
		private EventType(String eventType){
			this.eventType = eventType;
		}

		public String getEventType() {
			return eventType;
		}
	}
	
	public static final String KEY_PREFIX = "payload_";
	
	public interface XPath{
		String MBS_POOL_LOAN_COUNT = "//DEAL_SETS/MAJOR_POOL_DETAIL/POOL_DETAIL/MBSPoolLoanCount";
		
		String MBS_POOL_LOAN_COUNT_SUM = "sum(//DEAL_SETS/DEAL_SET/POOL/POOL_DETAIL/MBSPoolLoanCount/text())";
		
		//String MBS_POOL_LOAN_COUNT_SUM = "sum(/Envelope/Body/payload/DEAL_SETS/DEAL_SET/DEALS/DEAL/LOAN/text())"; // Sent by Saurabh
		
		String ENTITY_TYPE = "/Envelope/Header/metadata/payloadIdentifier/entityType";
		
		String EVENT_TYPE = "/Envelope/Header/metadata/payloadIdentifier/eventType";
		
		//String MAJOR_POOL_DETAIL = "/Envelope/Body/DEAL_SETS/MAJOR_POOL_DETAIL";
		
		String MAJOR_POOL_DETAIL = "//DEAL_SETS/MAJOR_POOL_DETAIL"; // Sent by Saurabh
		
		//String POOL_COUNT = "count(/Envelope/Body/DEAL_SETS/DEAL_SET/POOL)";
		
		String POOL_COUNT = "count(//DEAL_SETS/DEAL_SET/POOL)"; // Sent by Saurabh
		
		String MESSAGE_ID = "/Envelope/Header/metadata/transaction/messageID";
		
		String TIMESTAMP = "/Envelope/Header/metadata/transaction/timestamp";
	}
	
	public interface Sign{
		String UNDER_SCORE = "_";
	}
}
