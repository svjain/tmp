package com.impetus.fm.parser;

import java.util.Calendar;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;

import net.minidev.json.JSONObject;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.w3c.dom.Document;

public class PayloadFields {

	private Integer poolCount;
	private Integer loanCount;
	private String eventType;
	private String entityType;
	private String hourOfDay;
	private String messageId;
	private String rawMessagePayload;
	private String messageSubtype;
	private Integer hourWODate;
	private String commonName;
	private String messageFormat;

	public JSONObject populateMap(Document xmlDocument, XPath xPath, String xml) throws XPathExpressionException {
		calculateFields(xmlDocument, xPath);
		JSONObject jsonData = new JSONObject();

		jsonData.put(Constants.POOL_COUNT, getPoolCount());
		jsonData.put(Constants.LOAN_COUNT, getLoanCount());

		jsonData.put(Constants.PAYLOAD_COUNT, 1);
		jsonData.put(Constants.MESSAGE_COUNT, 1);

		jsonData.put(Constants.EVENT_TYPE, this.getEventType());
		jsonData.put(Constants.ENTITY_TYPE, this.getEntityType());
		
		jsonData.put(Constants.MESSAGE_FORMAT, this.getMessageFormat());

		jsonData.put(Constants.PAYLOAD_TIME, Calendar.getInstance().getTimeInMillis());
		jsonData.put(Constants.COMMON_NAME, this.getCommonName());

		jsonData.put(Constants.HOUR_OF_DAY, getHourOfDay(getValueForExp(xmlDocument, xPath, Constants.XPath.TIMESTAMP)));
		jsonData.put(Constants.MESSAGE_ID, getValueForExp(xmlDocument, xPath, Constants.XPath.MESSAGE_ID));
		jsonData.put(Constants.MESSAGE_SUBTYPE, getMessageSubtype());
		jsonData.put(Constants.RAW_MESSAGE_PAYLOAD, xml);
		jsonData.put(Constants.HOUR_WO_DATE, getHourWODate(getValueForExp(xmlDocument, xPath, Constants.XPath.TIMESTAMP)));
		return jsonData;
	}

	private void calculateFields(Document xmlDocument, XPath xPath) {
		boolean majorPoolDetail = false;
		boolean poolPresent = false;
		boolean loanPresent = false;
		Integer poolCount = 0;
		Integer loanCount = 0;

		try {
			this.setEntityType(getValueForExp(xmlDocument, xPath, Constants.XPath.ENTITY_TYPE));
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			this.setEventType(getValueForExp(xmlDocument, xPath, Constants.XPath.EVENT_TYPE));
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			String majorPoolExists = getValueForExp(xmlDocument, xPath, Constants.XPath.MAJOR_POOL_DETAIL);
			if (majorPoolExists != null)
				majorPoolDetail = true;
			else
				majorPoolDetail = false;
		} catch (XPathExpressionException e) {
			e.printStackTrace();
			majorPoolDetail = false;
		}

		try {
			String val = getValueForExp(xmlDocument, xPath, Constants.XPath.POOL_COUNT);
			if (val != null) {
				poolCount = Integer.parseInt(val);
				poolPresent = poolCount > 0;
			}
		} catch (XPathExpressionException e) {
			e.printStackTrace();
			poolCount = 0;
			poolPresent = false;
		}

		String key = this.getEventType() + Constants.Sign.UNDER_SCORE + this.getEntityType();
		this.setCommonName(Constants.TYPE_LOOKUP.get(!StringUtils.isEmpty(key) ? key.toUpperCase() : key));
		
		this.setMessageFormat("ECF");

		if ((Constants.EventType.ACQUISITION.getEventType().equalsIgnoreCase(this.getEventType())) || (Constants.EventType.CMMPROTOTYPE.getEventType().equalsIgnoreCase(this.getEventType()))) {
			this.setMessageFormat("CLDF");
			
			if ((Constants.EntityType.MBS.getEntityType().equalsIgnoreCase(this.getEntityType())) || (Constants.EntityType.CMMPILOT_ADSTOEDI_POOL.getEntityType().equalsIgnoreCase(this.getEntityType()))) {
				if (majorPoolDetail) {
					this.setMessageSubtype("MAJORPOOL");

					try {
						String val = getValueForExp(xmlDocument, xPath, Constants.XPath.MBS_POOL_LOAN_COUNT);
						if (!StringUtils.isBlank(val)) {
							loanCount = Integer.parseInt(val);
							loanPresent = loanCount > 0;
						}else{
							loanCount = 0;
							loanPresent = false;
						}
					} catch (XPathExpressionException e) {
						loanCount = 0;
						loanPresent = false;
					} catch (NumberFormatException ne) {
						ne.printStackTrace();
						loanCount = 0;
						loanPresent = false;
					}
				} else {
					this.setMessageSubtype("POOL");

					try {
						String val = getValueForExp(xmlDocument, xPath, Constants.XPath.MBS_POOL_LOAN_COUNT_SUM);
						if (!StringUtils.isBlank(val)) {
							loanCount = Integer.parseInt(val);
							loanPresent = loanCount > 0;
						}else{
							loanCount = 0;
							loanPresent = false;
						}
					} catch (XPathExpressionException e) {
						loanCount = 0;
						loanPresent = false;
					} catch (NumberFormatException ne) {
						ne.printStackTrace();
						loanCount = 0;
						loanPresent = false;
					}
				}
			} else if ((Constants.EntityType.CASH.getEntityType().equalsIgnoreCase(this.getEntityType())) || (Constants.EntityType.CMMPILOT_ADSTOEDI_CASH.getEntityType().equalsIgnoreCase(this.getEntityType()))) {
				this.setMessageSubtype("LOAN");

				if (!poolPresent) {
					poolCount = 0;
					loanCount = 1;
				}
			}
		}

		this.setLoanCount(loanCount);
		this.setPoolCount(poolCount);
	}

	public static String getValueForExp(Document xmlDocument, XPath xPath, String expression) throws XPathExpressionException {
		return xPath.compile(expression).evaluate(xmlDocument);
	}

	public Integer getPoolCount() {
		return poolCount;
	}

	public void setPoolCount(Integer poolCount) {
		this.poolCount = poolCount;
	}

	public Integer getLoanCount() {
		return loanCount;
	}

	public void setLoanCount(Integer loanCount) {
		this.loanCount = loanCount;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getHourOfDay(String timestampVal) {
		if(StringUtils.isEmpty(timestampVal) || StringUtils.isBlank(timestampVal)){
			return null;
		}
		
		DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		DateTime jodatime = fmt.parseDateTime(timestampVal);
		DateTimeFormatter dtfOut = DateTimeFormat.forPattern("yyyyMMddHH");
		return dtfOut.print(jodatime);
	}

	public void setHourOfDay(String hourOfDay) {
		this.hourOfDay = hourOfDay;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getRawMessagePayload() {
		return rawMessagePayload;
	}

	public void setRawMessagePayload(String rawMessagePayload) {
		this.rawMessagePayload = rawMessagePayload;
	}

	public String getMessageSubtype() {
		return messageSubtype;
	}

	public void setMessageSubtype(String messageSubtype) {
		this.messageSubtype = messageSubtype;
	}

	public Integer getHourWODate(String timestampVal) {
		if(StringUtils.isEmpty(timestampVal) || StringUtils.isBlank(timestampVal)){
			return null;
		}
		
		DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		DateTime jodatime = fmt.parseDateTime(timestampVal);
		DateTimeFormatter dtfOut = DateTimeFormat.forPattern("HH");
		return Integer.parseInt(dtfOut.print(jodatime));
	}

	public void setHourWODate(Integer hourWODate) {
		this.hourWODate = hourWODate;
	}

	public String getCommonName() {
		return commonName;
	}

	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	public String getHourOfDay() {
		return hourOfDay;
	}

	public Integer getHourWODate() {
		return hourWODate;
	}

	public String getMessageFormat() {
		return messageFormat;
	}

	public void setMessageFormat(String messageFormat) {
		this.messageFormat = messageFormat;
	}
}
