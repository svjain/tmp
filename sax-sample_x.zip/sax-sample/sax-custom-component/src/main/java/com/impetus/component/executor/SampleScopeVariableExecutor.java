package com.impetus.component.executor;

import java.util.Map;

import net.minidev.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.streamanalytix.framework.api.storm.processor.Processor;
import com.streamanalytix.framework.api.sv.ScopeVariable;

/** The Class SampleScopeVariableExecutor. */
public class SampleScopeVariableExecutor implements Processor {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 7952280235348559499L;

    /** The name. */
    private String name = "Name";

    /** The salary. */
    private String salary = "Salary";

    /** The average. */
    private String average = "Average";

    /** The Constant LOGGER. */
    private static final Log LOGGER = LogFactory.getLog(SampleScopeVariableExecutor.class);

    /*
     * (non-Javadoc)
     * @see com.streamanalytix.framework.api.BaseComponent#init(java.util.Map)
     */
    @SuppressWarnings("rawtypes")
    @Override
    public void init(Map configMap) {
        LOGGER.info("configMap Map: " + configMap);
    }

    /*
     * (non-Javadoc)
     * @see com.streamanalytix.framework.api.storm.processor.Processor#process(net .minidev.json.JSONObject, java.util.Map)
     */
    @Override
    public void process(JSONObject json, Map<String, Object> configMap) {

        Map<String, ScopeVariable> varMap = (Map<String, ScopeVariable>) configMap.get("svMap");
        if (null != varMap.get(name)) {
            LOGGER.info("Name : " + varMap.get(name).getValue());
        }
        if (null != varMap.get(salary)) {
            LOGGER.info("Salary : " + varMap.get(salary).getValue());
        }
        if (null != varMap.get(name)) {
            LOGGER.info("Average : " + varMap.get(average).getValue());
        }
    }

    /*
     * (non-Javadoc)
     * @see com.streamanalytix.framework.api.BaseComponent#cleanup()
     */
    @Override
    public void cleanup() {

    }

}
