/*
 * Class
 * Fannie Mae Demo
 * Date - 2016-01-08
 * 
 */
 
var urlObj = {
	alerts: 'http://192.168.7.81:9200/ns_1_sax_alerts_ialias/_search',		// Alerts Index URL
	ads: 'http://192.168.7.81:9200/ns_1_adspayloaddata_ialias/_search',		// ADS Index URL
	mbs: 'http://192.168.7.81:9200/ns_1_mbspayloaddata_ialias/_search',		// MBS Index URL
	stomp: 'http://192.168.7.81:15674/stomp',								// Stomp URL
	adsPerMinuteQueue: '/queue/TwoMinData',									// ADS Per Minute Data Queue
	adsTotalQueue: '/queue/AllData1',										// ADS Total Data Queue
	alertsQueue: '/queue/FMALertsUI',										// Alerts Data Queue
	mbsPerMinuteQueue: '/queue/MBSTwoMinData',								// MBS Per Minute Data Queue
	mbsTotalQueue: '/queue/MBSAllData1',									// MBS Total Data Queue
	mqUsername: 'guest',													// Stomp User Name
	mqPassword: 'guest',													// Stomp Password
	mqHost: '/'																// Stomp Host
};

var curPage = 'ads';
var adsData = [];
var stackData = [];
var entityData = [];
var eventData = [];
var MBSStackData = [];
var ADSGroupData = [];
var MBSGroupData = [];
var loanLineData = [
	{ "label": 'Total Loan', data: [] },
	{ "label": 'Loan Per Minute', data: [] }
];
var poolLineData = [
	{ "label": 'Total Pool', data: [] },
	{ "label": 'Pool Per Minute', data: [] }
];
var mbsLineData = {
	"POOL": [
		{ "label": 'Total', data: [] },
		{ "label": 'Per Minute', data: [] }
	],
	"PPC": [
		{ "label": 'Total', data: [] },
		{ "label": 'Per Minute', data: [] }
	],
	"CMMPilot_MBSToEDI_EVENT1": [
		{ "label": 'Total', data: [] },
		{ "label": 'Per Minute', data: [] }
	],
	"CMMPilot_MBSToEDI_EVENT2": [
		{ "label": 'Total', data: [] },
		{ "label": 'Per Minute', data: [] }
	],
	"CMMPilot_MBSToEDI_EVENT3": [
		{ "label": 'Total', data: [] },
		{ "label": 'Per Minute', data: [] }
	]
};
var colorsArr = ["#93e0f8","#7a53a3","#de8ff6","#da4f12","#eadc6b","#6b988f","#29eef1","#fc68cc","#c5c164","#609c2f","#e5ce17","#905fe6","#e093a0","#e51361"];

var lineChartOptions = {
	xaxis: {
		mode: "time",
		timeformat: "%H:%M:%S",
		timezone: 'browser'
	},
	yaxis: {min:0, tickSize: 10},
	series: {
		lines: {show: true, lineWidth: 2},
		points: {show: true, radius: 1},
		shadowSize: 0
	},
	colors: ['#93e0f8', '#7a53a3'],
	grid: {
		hoverable: true,
		clickable: false,
		borderColor: "#ccc",
		borderWidth: 1,
		markings: []
	},
	legend: { show: false }
};
var loanChartOpts = $.extend(true, {}, lineChartOptions);
loanChartOpts.grid.markings = [
	{color: '#FFB31A', lineWidth: 0.8, yaxis: {from: 7, to: 7}},
	{color: '#FB1924', lineWidth: 0.8, yaxis: {from: 13, to: 13}}
];

var poolChartOpts = $.extend(true, {}, lineChartOptions);
poolChartOpts.grid.markings = [
	{color: '#FFB31A', lineWidth: 0.8, yaxis: {from: 9, to: 9}},
	{color: '#FB1924', lineWidth: 0.8, yaxis: {from: 15, to: 15}}
];

var mbsLineChartOpts = $.extend(true, {}, lineChartOptions);
mbsLineChartOpts.grid.markings = [
	{color: '#FFB31A', lineWidth: 0.8, yaxis: {from: 9, to: 9}},
	{color: '#FB1924', lineWidth: 0.8, yaxis: {from: 15, to: 15}}
];

var pieChartOptions = {
	series: {
		pie: {
			show: true,
			label: {
				show: true,
				formatter: function(label, series){
					var percent = Math.round(series.percent);
					var number = series.data[0][1];
					return ('<div class="text-center">' + number + ' <small>(' + percent + '%)</small></div>');
				}
			}
		}
	},
	grid: { clickable: true },
	colors: ['#93e0f8', '#7a53a3', '#de8ff6'],
	legend: { show: false }
};

var entityPieChartOptins = $.extend(true, {}, pieChartOptions);
entityPieChartOptins.colors = [];

var eventPieChartOptins = $.extend(true, {}, pieChartOptions);
eventPieChartOptins.colors = [];

var barGraphOptions = {
	series: {
		stack: true,
		bars: {show: true, lineWidth: .5},
		barWidth: 0.8,
		lineWidth: 0,
		lines: {show: false}
	},
	bars: {
		align: "center",
		horizontal: false,
		barWidth: .8
	},
	grid: {
		borderWidth: 0,
		borderColor: null,
		backgroundColor: null,
		labelMargin: 10,
		minBorderMargin: 10,
		aboveData: true
	},
	xaxis: { },
	colors: ['#93e0f8', '#7a53a3', '#de8ff6'],
	legend: { show: false }
};

var mbsBarGraphOptions = $.extend(true, {}, barGraphOptions);
mbsBarGraphOptions.colors = [];

var groupBarGraphOptions = {
	series: {
		bars: {
			show: true,
			barWidth: 0.3,
			order: 1,
			lineWidth: .5
		}
	},
	grid: {
		borderWidth: 0,
		borderColor: null,
		backgroundColor: null,
		labelMargin: 10,
		minBorderMargin: 10,
		aboveData: true
	},
	xaxis: {},
	colors: [],
	legend: { show: false }
};

var fannieMaeApp = new function() {
	var _this = this;
	
	_this.init = function() {
		$('#pageTabs a').on('click', function() {
			var isActive = $(this).closest('li').hasClass('active');
			if ( !isActive ) {
				curPage = $(this).closest('li').data('page');
				setTimeout(function() {				
					if ( curPage == 'mbs' ) {
						_this.getEntityPieData();
						_this.getGroupBarData();
						_this.createMBSLineChart();
					} else {
						_this.getPayloadPieData();
						_this.getLoanStackData();
						_this.getGroupBarData();
						_this.createLineChart();
						_this.getAlertData();
					}
				}, 300);
			}
		});
		
		$('#submitBtn').on('click', function() {
			var value = $('#fromDatetimepicker input').val();
			if ( value != '' ) {
				_this.adsDataRefresh();
			}
		});
		
		$('#submitBtnMBS').on('click', function() {
			var value = $('#fromDatetimepickerMBS input').val();
			if ( value != '' ) {
				_this.mbsDataRefresh();
			}
		});
		
		$('#mainNavbar a').on('click', function() {
			var target = $(this).data('target');
			$(this).closest('li')
					.addClass('active')
					.siblings('li')
					.removeClass('active');
			
			$(target).removeClass('hidden')
					.siblings('div')
					.addClass('hidden');
		});
		
		$('#fromDatetimepicker input, #fromDatetimepickerMBS input').on('keydown', function (e) {
            e.preventDefault();
            e.stopPropagation();
        });

        $('#fromDatetimepicker, #fromDatetimepickerMBS').datetimepicker({
            language: 'en',
            pick12HourFormat: true,
            endDate: new Date()
        });
		
		$('#loanLineLegends a').on('click', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateLoadLineChart();
		});
		
		$('#poolLineLegends a').on('click', function() {
			$(this).parent().toggleClass('inactive');
			_this.updatePoolLineChart();
		});
		
		$('#adsPieLegends a').on('click', function() {
			$(this).parent().toggleClass('inactive');
			_this.updatePayloadPieChart();
		});
		
		$('#stackLegends a').on('click', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateLoanBarChart();
		});
		
		$('#mbsRTLineLegends a').on('click', function() {
			$(this).parent().siblings('li').addClass('inactive');
			$(this).parent().removeClass('inactive');
			_this.createMBSLineChart();
		});
		
		$(document).on('click', '#entityTypePieLegends a', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateEntityPieChart();
		});
		
		$(document).on('click', '#eventTypePieLegends a', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateEventPieChart();
		});
		
		$(document).on('click', '#mbsStackLegends a', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateMBSStackBarChart();
		});
		
		$(document).on('click', '#adsGroupLegends a', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateADSGroupBarChart();
		});
		
		$(document).on('click', '#mbsGroupLegends a', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateMBSGroupBarChart();
		});
		
		$('#pageTabs > li:first > a').trigger('click');
	};
	
	
	/** PIE CHARTS START **/
	_this.getPayloadPieData = function() {
		var start, end, sel_date;
		var from = $("#fromDatetimepicker input[type='text']").val();
		if ( from == '' ) {
			sel_date = new Date();
		} else {
			sel_date = new Date(from);
		}

		start = sel_date.setHours(0, 0, 0, 0);
		end = sel_date.setHours(23, 59, 59, 999);

		var piePostData = {
			"size": 0,
			"query": {
				"bool": {
					"must": [{"range": {"paylaodgrp.payloadTime": {"from": start, "to": end}}}],
					"must_not": [],
					"should": []
				}
			},
			"aggs": {
				"group_by_messageSubType": {
					"terms": {
						"field": "MessageSubtype"
					}
				}
			}
		}

		jQuery.ajax({
			type: "POST",
			url: urlObj.ads,
			contentType: 'application/json; charset=utf-8',
			dataType: 'json',
			async: true,
			data: JSON.stringify(piePostData),
			success: function (data) {
				var responsePieData = data.aggregations.group_by_messageSubType.buckets;
				adsData = _this.modifyPayloadPieData(responsePieData);
				_this.createPayloadPieChart();
			},
			error: function () {
				// TODO
			}
		});
	};
	
	_this.modifyPayloadPieData = function(origData) {
		var pieData = [
			{"label": "Loan", "data": "0"},
			{"label": "Major Pool", "data": "0"},
			{"label": "Pool", "data": "0"}
		];

		for (var i = 0; i < origData.length; i++) {
			if (origData[i]["key"] == "majorpool") {
				pieData[0].data = origData[i]["doc_count"]
			}

			if (origData[i]["key"] == "pool") {
				pieData[1].data = origData[i]["doc_count"]
			}

			if (origData[i]["key"] == "loan") {
				pieData[2].data = origData[i]["doc_count"]
			}
		}

		return pieData;
	};
	
	_this.createPayloadPieChart = function() {
		var adsPieChart = $.plot('#adsPieChart', adsData, pieChartOptions);
		
		_this.warningIfNoData(adsPieChart, 'pie');
	};
	
	_this.updatePayloadPieChart = function() {
		var newPieData = $.extend(true, [], adsData);
		var newPieOpts = $.extend(true, {}, pieChartOptions);
		
		var pieActLegends = [];
		newPieOpts.colors = [];
		$('#adsPieLegends li').each(function(i, elm) {
			var isInactive = $(elm).hasClass('inactive');
			if ( !isInactive ) {
				var lbl = $(elm).find('.lbl').text();
				var clr = pieChartOptions.colors[i];
				pieActLegends.push(lbl);
				newPieOpts.colors.push(clr);
			}
		});
		
		newPieData = $.grep(newPieData, function(o) {
			return $.inArray(o.label, pieActLegends) > -1;
		});
		
		if ( newPieData.length == 0 ) {
			newPieData = [{}];
		}
		
		var adsPieChart = $.plot('#adsPieChart', newPieData, newPieOpts);
		_this.warningIfNoData(adsPieChart, 'pie');
	};	
	
	_this.getEntityPieData = function() {
		var start, end, sel_date;
		var from = $("#fromDatetimepickerMBS input[type='text']").val();
		if ( from == '' ) {
			sel_date = new Date();
		} else {
			sel_date = new Date(from);
		}

		start = sel_date.setHours(0, 0, 0, 0);
		end = sel_date.setHours(23, 59, 59, 999);

		var piePostData = {
			"size": 0, 
			"query": {
				"bool": {
					"must": [
						{
							"range": {
								"paylaodgrp.payloadTime": {
									"from": start, 
									"to": end
								}
							}
						}
					], 
					"must_not": [ ], 
					"should": [ ]
				}
			}, 
			"aggs": {
				"group_by_EntityType": {
					"terms": {
						"field": "EntityType"
					}
				}
			}
		}
		
		jQuery.ajax({
			type: "POST",
			url: urlObj.mbs,
			contentType: 'application/json; charset=utf-8',
			dataType: 'json',
			async: true,
			data: JSON.stringify(piePostData),
			success: function (data) {
				entityData = data.aggregations.group_by_EntityType.buckets;
				_this.createEntityPieChart();
				
				var entity = (entityData.length > 0) ? entityData[0].label : '';
				_this.getEventPieData(entity);
			},
			error: function () {
				// TODO
			}
		});
	};
	
	_this.createEntityPieChart = function() {
		var newData = [];
		$('#entityTypePieLegends').empty();
		for ( var i=0; i<entityData.length; i++ ) {
			$('#entityTypePieLegends').append('<li>' +
												'<a href="javascript:void(0)">' +
													'<span style="background: '+ colorsArr[i] +'" class="box"></span>' +
													'<span class="lbl">'+ entityData[i].key +'</span>' +
												'</a>' +
											'</li>');
		
			entityPieChartOptins.colors.push(colorsArr[i]);
			newData.push({"label": entityData[i].key, "data": entityData[i].doc_count});
		}
		
		entityData = newData;
		newData = (newData.length == 0) ? [{}] : newData;
		var pieChart = $.plot('#entityTypePieChart', newData, entityPieChartOptins);
		
		_this.warningIfNoData(pieChart, 'pie');
		
		$("#entityTypePieChart").bind("plotclick", function (event, pos, item) {
			if ( item ) {
				_this.getEventPieData(item.series.label);
				_this.getMBSStackBarData(item.series.label);
			}
		});
	};
	
	_this.updateEntityPieChart = function() {
		var newPieData = $.extend(true, [], entityData);
		var newPieOpts = $.extend(true, {}, entityPieChartOptins);
		
		var pieActLegends = [];
		newPieOpts.colors = [];
		$('#entityTypePieLegends li').each(function(i, elm) {
			var isInactive = $(elm).hasClass('inactive');
			if ( !isInactive ) {
				var lbl = $(elm).find('.lbl').text();
				var clr = entityPieChartOptins.colors[i];
				pieActLegends.push(lbl);
				newPieOpts.colors.push(clr);
			}
		});
		
		newPieData = $.grep(newPieData, function(o) {
			return $.inArray(o.label, pieActLegends) > -1;
		});
		
		if ( newPieData.length == 0 ) {
			newPieData = [{}];
		}
		
		var pieChart = $.plot('#entityTypePieChart', newPieData, newPieOpts);
		_this.warningIfNoData(pieChart, 'pie');
	};
	
	_this.getEventPieData = function(entity) {
		var start, end, sel_date;
		var from = $("#fromDatetimepickerMBS input[type='text']").val();
		if ( from == '' ) {
			sel_date = new Date();
		} else {
			sel_date = new Date(from);
		}

		start = sel_date.setHours(0, 0, 0, 0);
		end = sel_date.setHours(23, 59, 59, 999);

		var piePostData = {
			"size": 0, 
			"query": {
				"bool": {
					"must": [
						{
							"term": {
								"EntityType": entity
							}
						}, 
						{
							"range": {
								"payloadTime": {
									"gt": start, 
									"lt": end
								}
							}
						}
					], 
					"must_not": [ ], 
					"should": [ ]
				}
			}, 
			"aggs": {
				"group_by_Entity": {
					"terms": {
						"field": "EntityType"
					}, 
					"aggs": {
						"group_by_EventType": {
							"terms": {
								"field": "EventType"
							}
						}
					}
				}
			}
		}
		
		jQuery.ajax({
			type: "POST",
			url: urlObj.mbs,
			contentType: 'application/json; charset=utf-8',
			dataType: 'json',
			async: true,
			data: JSON.stringify(piePostData),
			success: function (data) {
				eventData = (data.aggregations.group_by_Entity.buckets.length > 0) ? data.aggregations.group_by_Entity.buckets[0].group_by_EventType.buckets : [];
				_this.createEventPieChart();
				_this.getMBSStackBarData(entity);
			},
			error: function () {
				// TODO
			}
		});
	};
	
	_this.createEventPieChart = function() {
		var newData = [];
		$('#eventTypePieLegends').empty();
		for ( var i=0; i<eventData.length; i++ ) {
			$('#eventTypePieLegends').append('<li>' +
												'<a href="javascript:void(0)">' +
													'<span style="background: '+ colorsArr[i] +'" class="box"></span>' +
													'<span class="lbl">'+ eventData[i].key +'</span>' +
												'</a>' +
											'</li>');
		
			eventPieChartOptins.colors.push(colorsArr[i]);
			newData.push({"label": eventData[i].key, "data": eventData[i].doc_count});
		}
		
		eventData = newData;
		newData = (newData.length == 0) ? [{}] : newData;
		var pieChart = $.plot('#eventTypePieChart', newData, eventPieChartOptins);
		_this.warningIfNoData(pieChart, 'pie');
	};
	
	_this.updateEventPieChart = function() {
		var newPieData = $.extend(true, [], eventData);
		var newPieOpts = $.extend(true, {}, eventPieChartOptins);
		
		var pieActLegends = [];
		newPieOpts.colors = [];
		$('#eventTypePieLegends li').each(function(i, elm) {
			var isInactive = $(elm).hasClass('inactive');
			if ( !isInactive ) {
				var lbl = $(elm).find('.lbl').text();
				var clr = eventPieChartOptins.colors[i];
				pieActLegends.push(lbl);
				newPieOpts.colors.push(clr);
			}
		});
		
		newPieData = $.grep(newPieData, function(o) {
			return $.inArray(o.label, pieActLegends) > -1;
		});
		
		if ( newPieData.length == 0 ) {
			newPieData = [{}];
		}
		
		var pieChart = $.plot('#eventTypePieChart', newPieData, newPieOpts);
		_this.warningIfNoData(pieChart, 'pie');
	};
	/** PIE CHARTS END **/
	
	
	/** BAR CHARTS START **/
	_this.getLoanStackData = function() {
		var start, end, sel_date;
		var from = $("#fromDatetimepicker input[type='text']").val();
		if ( from == '' ) {
			sel_date = new Date();
		} else {
			sel_date = new Date(from);
		}

		start = sel_date.setHours(0, 0, 0, 0);
		end = sel_date.setHours(23, 59, 59, 999);

		var stackPostData = {
			"size": 0,
			"query": {
				"bool": {
					"must": [{"range": {"paylaodgrp.payloadTime": {"from": start, "to": end}}}],
					"must_not": [],
					"should": []
				}
			},
			"aggs": {
				"group_by_Hour": {
					"terms": {
						"field": "HourWODate"
					},
					"aggs": {
						"group_by_messageSubType": {
							"terms": {
								"field": "MessageSubtype"
							}
						}
					}
				}
			}
		}

		jQuery.ajax({
			type: "POST",
			url: urlObj.ads,
			contentType: 'application/json; charset=utf-8',
			dataType: 'json',
			data: JSON.stringify(stackPostData),
			success: function (data) {
				var responseStackData = data.aggregations.group_by_Hour.buckets;
				stackData = _this.modifyLoanStackData(responseStackData);
				_this.createLoanStackedBarChart();
			},
			error: function () {

			}
		});
	};
	
	_this.modifyLoanStackData = function(origData) {
		var stackDataPool = {label: "Pool", data: []},
			stackDataLoan = {label: "Loan", data: []},
			stackDataMajorPool = {label: "Major Pool", data: []};
		var stackData = [];
		var hourKey = [];

		for (var i = 0; i < 24; i++) {
			hourKey.push([i, i]);
			stackDataMajorPool.data.push([i, 0]);
			stackDataLoan.data.push([i, 0]);
			stackDataPool.data.push([i, 0]);
		}

		for (var i = 0; i < origData.length; i++) {
			var curr_hour_key = Number(origData[i].key);

			/*hourKey.push([i, origData[i].key]);
			 stackDataMajorPool.data.push([i, 0]);
			 stackDataLoan.data.push([i, 0]);
			 stackDataPool.data.push([i, 0]);*/
			 
			origData[i].group_by_messageSubType.buckets.forEach(function (obj) {
				if (obj["key"] == "majorpool") {
					stackDataMajorPool.data[curr_hour_key][1] = obj["doc_count"];
				} else if (obj["key"] == "pool") {
					stackDataPool.data[curr_hour_key][1] = obj["doc_count"];
				} else if (obj["key"] == "loan") {
					stackDataLoan.data[curr_hour_key][1] = obj["doc_count"];
				}
			})

			stackData = [stackDataLoan, stackDataMajorPool, stackDataPool];
		}

		return {data: stackData, key: hourKey};
	};
	
	_this.createLoanStackedBarChart = function() {
		var dataset = stackData.data;
		var hourkey = stackData.key;
		
		barGraphOptions.xaxis.ticks = hourkey;
		
		var barChart = $.plot($("#barChartContainer"), dataset, barGraphOptions);
		_this.warningIfNoData(barChart, 'bar');
	};
	
	_this.updateLoanBarChart = function() {
		var newStackData = $.extend(true, [], stackData.data);
		var newBarOpts = $.extend(true, {}, barGraphOptions);
		
		var barLegends = [];
		newBarOpts.colors = [];
		$('#stackLegends li').each(function(i, elm) {
			var isInactive = $(elm).hasClass('inactive');
			if ( !isInactive ) {
				var lbl = $(elm).find('.lbl').text();
				var clr = barGraphOptions.colors[i];
				barLegends.push(lbl);
				newBarOpts.colors.push(clr);
			}
		});
		
		newStackData = $.grep(newStackData, function(o) {
			return $.inArray(o.label, barLegends) > -1;
		});
		
		/*if ( newStackData.length == 0 ) {
			newStackData = [{}];
		}*/
		
		var barChart = $.plot('#barChartContainer', newStackData, newBarOpts);
		_this.warningIfNoData(barChart, 'bar');
	};
	
	_this.getMBSStackBarData = function(entity) {
		var start, end, sel_date;
		var from = $("#fromDatetimepickerMBS input[type='text']").val();
		if ( from == '' ) {
			sel_date = new Date();
		} else {
			sel_date = new Date(from);
		}

		start = sel_date.setHours(0, 0, 0, 0);
		end = sel_date.setHours(23, 59, 59, 999);

		var stackPostData = {
			"size": 0, 
			"query": {
				"bool": {
					"must": [
						{
							"term": {
								"EntityType": entity
							}
						}, 
						{
							"range": {
								"payloadTime": {
									"gt": start, 
									"lt": end
								}
							}
						}
					], 
					"must_not": [ ], 
					"should": [ ]
				}
			}, 
			"aggs": {
				"group_by_Entity": {
					"terms": {
						"field": "EntityType"
					}, 
					"aggs": {
						"group_by_EventType": {
							"terms": {
								"field": "EventType"
							}, 
							"aggs": {
								"group_by_Hour": {
									"terms": {
										"field": "HourWODate"
									}
								}
							}
						}
					}
				}
			}
		}

		jQuery.ajax({
			type: "POST",
			url: urlObj.mbs,
			contentType: 'application/json; charset=utf-8',
			dataType: 'json',
			data: JSON.stringify(stackPostData),
			success: function (data) {
				MBSStackData = (data.aggregations.group_by_Entity.buckets.length > 0) ? data.aggregations.group_by_Entity.buckets[0].group_by_EventType.buckets : [];
				_this.createMBSStackedBarChart();
			},
			error: function () {

			}
		});
	};
	
	_this.createMBSStackedBarChart = function() {
		var newData = [];
		var hourKey = [];
		$('#mbsStackLegends').empty();
		for ( var i=0; i<MBSStackData.length; i++ ) {
			var d = [];
			var hourData = MBSStackData[i].group_by_Hour.buckets;
			for ( var j=0; j<hourData.length; j++ ) {
				d[hourData[j].key] = [hourData[j].key, hourData[j].doc_count];
			}
			
			for ( var j=0; j<24; j++ ) {
				if ( typeof d[j] === 'undefined' ) {
					d.push([j, 0]);
				}
				hourKey.push([j, j]);
			}
			newData.push({label: MBSStackData[i].key, data: d});
			mbsBarGraphOptions.colors.push(colorsArr[i]);
			
			
			$('#mbsStackLegends').append('<li>' +
												'<a href="javascript:void(0)">' +
													'<span style="background: '+ colorsArr[i] +'" class="box"></span>' +
													'<span class="lbl">'+ MBSStackData[i].key +'</span>' +
												'</a>' +
											'</li>');
		}
		
		MBSStackData = newData;
		mbsBarGraphOptions.xaxis.ticks = hourKey;
		var barChart = $.plot($("#mbsBarChartContainer"), MBSStackData, mbsBarGraphOptions);
		_this.warningIfNoData(barChart, 'bar');
	};
	
	_this.updateMBSStackBarChart = function() {
		var newStackData = $.extend(true, [], MBSStackData);
		var newBarOpts = $.extend(true, {}, mbsBarGraphOptions);
		
		var barLegends = [];
		newBarOpts.colors = [];
		$('#mbsStackLegends li').each(function(i, elm) {
			var isInactive = $(elm).hasClass('inactive');
			if ( !isInactive ) {
				var lbl = $(elm).find('.lbl').text();
				var clr = mbsBarGraphOptions.colors[i];
				barLegends.push(lbl);
				newBarOpts.colors.push(clr);
			}
		});
		
		newStackData = $.grep(newStackData, function(o) {
			return $.inArray(o.label, barLegends) > -1;
		});
		
		/*if ( newStackData.length == 0 ) {
			newStackData = [{}];
		}*/
		
		var barChart = $.plot('#mbsBarChartContainer', newStackData, newBarOpts);
		_this.warningIfNoData(barChart, 'bar');
	};
	
	_this.getGroupBarData = function() {
		var start, end, sel_date;
		if ( curPage == 'ads' ) {
			var url = urlObj.ads;
			var from = $("#fromDatetimepicker input[type='text']").val();
		} else {
			var url = urlObj.mbs;
			var from = $("#fromDatetimepickerMBS input[type='text']").val();
		}
		
		if ( from == '' ) {
			sel_date = new Date();
		} else {
			sel_date = new Date(from);
		}
		
		var month = sel_date.getMonth();
		var year = sel_date.getFullYear();
		var days = new Date(year, month+1, 0).getDate() - 1;
		
		sel_date.setDate(1);
		start = sel_date.setHours(0, 0, 0, 0);
		end = sel_date.setHours(days*24+23, 59, 59, 999);

		var groupPostData = {
			"size": 32, 
			"query": {
				"bool": {
					"must": [
						{
							"range": {
								"payloadTime": {
									"gt": start, 
									"lt": end
								}
							}
						}
					], 
					"must_not": [ ], 
					"should": [ ]
				}
			}, 
			"aggs": {
				"group_by_DayOfMonth": {
					"terms": {
						"field": "DayOfMonth"
					}, 
					"aggs": {
						"group_by_Entity": {
							"terms": {
								"field": "EntityType"
							}
						}
						/*"group_by_Event": {
							"terms": {
								"field": "EventType"
							}
						}*/
					}
				}
			}
		}
		
		jQuery.ajax({
			type: "POST",
			url: url,
			contentType: 'application/json; charset=utf-8',
			dataType: 'json',
			data: JSON.stringify(groupPostData),
			success: function (data) {
				if ( curPage == 'ads' ) {
					ADSGroupData = data.aggregations.group_by_DayOfMonth.buckets;
					_this.createADSGroupBarChart(days);
				} else {
					MBSGroupData = data.aggregations.group_by_DayOfMonth.buckets;
					_this.createMBSGroupBarChart(days);
				}
			},
			error: function () {

			}
		});
	};
	
	_this.createADSGroupBarChart = function(days) {
		var newData = [];
		var hourKey = [];
		$('#adsGroupLegends').empty();
		var obj = {};
		
		for ( var i=0; i<ADSGroupData.length; i++ ) {
			var entities = ADSGroupData[i].group_by_Entity.buckets;
			var index = ADSGroupData[i].key;
			for ( var j=0; j<entities.length; j++ ) {
				var label = entities[j].key;
				var count = entities[j].doc_count;
				if ( typeof obj[label] === 'undefined' ) {
					obj[label] = {
						label: label,
						data: []
					};
				}
				
				obj[label].data[index] = [index, count];
			}
		}
		
		days++;
		var counter=0;
		$.each(obj, function(k, d) {
			for ( var j=0; j<days; j++ ) {
				if ( typeof d.data[j] === 'undefined' ) {
					d.data[j] = [j, 0];
				}
				hourKey.push([j, j]);
			}
			newData.push(d);
			
			groupBarGraphOptions.colors.push(colorsArr[counter]);
			$('#adsGroupLegends').append('<li>' +
										'<a href="javascript:void(0)">' +
											'<span style="background: '+ colorsArr[counter] +'" class="box"></span>' +
											'<span class="lbl">'+ k +'</span>' +
										'</a>' +
									'</li>');
			
			counter++;
		});
		
		ADSGroupData = newData;
		groupBarGraphOptions.xaxis.ticks = hourKey;
		var barChart = $.plot($("#adsGroupBarChartContainer"), ADSGroupData, groupBarGraphOptions);
		_this.warningIfNoData(barChart, 'bar');
	};
	
	_this.createMBSGroupBarChart = function(days) {
		var newData = [];
		var hourKey = [];
		$('#mbsGroupLegends').empty();
		var obj = {};
		
		for ( var i=0; i<MBSGroupData.length; i++ ) {
			var entities = MBSGroupData[i].group_by_Entity.buckets;
			var index = MBSGroupData[i].key;
			for ( var j=0; j<entities.length; j++ ) {
				var label = entities[j].key;
				var count = entities[j].doc_count;
				if ( typeof obj[label] === 'undefined' ) {
					obj[label] = {
						label: label,
						data: []
					};
				}
				
				obj[label].data[index] = [index, count];
			}
		}
		
		days++;
		var counter=0;
		$.each(obj, function(k, d) {
			for ( var j=0; j<days; j++ ) {
				if ( typeof d.data[j] === 'undefined' ) {
					d.data[j] = [j, 0];
				}
				hourKey.push([j, j]);
			}
			newData.push(d);
			
			groupBarGraphOptions.colors.push(colorsArr[counter]);
			$('#mbsGroupLegends').append('<li>' +
										'<a href="javascript:void(0)">' +
											'<span style="background: '+ colorsArr[counter] +'" class="box"></span>' +
											'<span class="lbl">'+ k +'</span>' +
										'</a>' +
									'</li>');
			
			counter++;
		});
		
		MBSGroupData = newData;
		groupBarGraphOptions.xaxis.ticks = hourKey;
		var barChart = $.plot($("#mbsGroupBarChartContainer"), MBSGroupData, groupBarGraphOptions);
		_this.warningIfNoData(barChart, 'bar');
	};
	
	_this.updateADSGroupBarChart = function() {
		var newData = $.extend(true, [], ADSGroupData);
		var newBarOpts = $.extend(true, {}, groupBarGraphOptions);
		
		var barLegends = [];
		newBarOpts.colors = [];
		$('#adsGroupLegends li').each(function(i, elm) {
			var isInactive = $(elm).hasClass('inactive');
			if ( !isInactive ) {
				var lbl = $(elm).find('.lbl').text();
				var clr = groupBarGraphOptions.colors[i];
				barLegends.push(lbl);
				newBarOpts.colors.push(clr);
			}
		});
		
		newData = $.grep(newData, function(o) {
			return $.inArray(o.label, barLegends) > -1;
		});
		
		var barChart = $.plot('#adsGroupBarChartContainer', newData, newBarOpts);
		_this.warningIfNoData(barChart, 'bar');
	};
	
	_this.updateMBSGroupBarChart = function() {
		var newData = $.extend(true, [], MBSGroupData);
		var newBarOpts = $.extend(true, {}, groupBarGraphOptions);
		
		var barLegends = [];
		newBarOpts.colors = [];
		$('#mbsGroupLegends li').each(function(i, elm) {
			var isInactive = $(elm).hasClass('inactive');
			if ( !isInactive ) {
				var lbl = $(elm).find('.lbl').text();
				var clr = groupBarGraphOptions.colors[i];
				barLegends.push(lbl);
				newBarOpts.colors.push(clr);
			}
		});
		
		newData = $.grep(newData, function(o) {
			return $.inArray(o.label, barLegends) > -1;
		});
		
		var barChart = $.plot('#mbsGroupBarChartContainer', newData, newBarOpts);
		_this.warningIfNoData(barChart, 'bar');
	};
	/** BAR CHARTS END **/
	
	
	/** LINE CHARTS START **/
	_this.createLineChart = function() {
		var loanLineChartHolder = $("#loanLineChart");
		var poolLineChartHolder = $("#poolLineChart");
		poolLineChartHolder.height(230).empty();
		loanLineChartHolder.height(230).empty();
		
		var loanLineChart = $.plot(loanLineChartHolder, loanLineData, loanChartOpts);
		_this.warningIfNoData(loanLineChart, 'line');
		
		var poolLineChart = $.plot(poolLineChartHolder, poolLineData, poolChartOpts);
		_this.warningIfNoData(poolLineChart, 'line');
	};
	
	_this.updateLoadLineChart = function() {
		var newLoadLineData = $.extend(true, [], loanLineData);
		var loadActLegends = [];
		var loadLineOpts = $.extend(true, {}, loanChartOpts);
		
		loadLineOpts.colors = [];
		$('#loanLineLegends li').each(function(i, elm) {
			var isInactive = $(elm).hasClass('inactive');
			if ( !isInactive ) {
				var lbl = $(elm).find('.lbl').text();
				var clr = loanChartOpts.colors[i];
				loadActLegends.push(lbl);
				loadLineOpts.colors.push(clr);
			}
		});
		
		newLoadLineData = $.grep(newLoadLineData, function(o) {
			return $.inArray(o.label, loadActLegends) > -1;
		});
		
		var loanLineChartHolder = $("#loanLineChart");
		var loanLineChart = $.plot(loanLineChartHolder, newLoadLineData, loadLineOpts);
		_this.warningIfNoData(loanLineChart, 'line');
	};
	
	_this.updatePoolLineChart = function() {
		var newPoolLineData = $.extend(true, [], poolLineData);
		var poolActLegends = [];
		var poolLineOpts = $.extend(true, {}, poolChartOpts);
		
		poolLineOpts.colors = [];
		$('#poolLineLegends li').each(function(i, elm) {
			var isInactive = $(elm).hasClass('inactive');
			if ( !isInactive ) {
				var lbl = $(elm).find('.lbl').text();
				var clr = poolChartOpts.colors[i];
				poolActLegends.push(lbl);
				poolLineOpts.colors.push(clr);
			}
		});
		
		newPoolLineData = $.grep(newPoolLineData, function(o) {
			return $.inArray(o.label, poolActLegends) > -1;
		});
		
		var poolLineChartHolder = $("#poolLineChart");
		var poolLineChart = $.plot(poolLineChartHolder, newPoolLineData, poolLineOpts);
		_this.warningIfNoData(poolLineChart, 'line');
	};
	
	_this.updateLineData = function(d, index) {
		var timestamp = _this.getCurrentTime();
		
		if ( $.isArray(d) && d.length > 0 ) {
			for ( var i=0; i<d.length; i++ ) {
				if ( d[i].MessageSubtype == 'POOL' ) {
					poolLineData[index].data.push([timestamp, d[i].countPayLoaDCount]);
				} else if ( d[i].MessageSubtype == 'LOAN' ) {
					loanLineData[index].data.push([timestamp, d[i].countPayLoaDCount]);
				}
			}
		} else if ( !$.isEmptyObject(d) ) {
			if ( d.MessageSubtype == 'POOL' ) {
				poolLineData[index].data.push([timestamp, d.countPayLoaDCount]);
			} else if ( d.MessageSubtype == 'LOAN' ) {
				loanLineData[index].data.push([timestamp, d.countPayLoaDCount]);
			}
		}
		
		_this.updateLoadLineChart();
		_this.updatePoolLineChart();
	};
	
	_this.createMBSLineChart = function() {
		var lineChartHolder = $("#mbsRTLineChart");
		lineChartHolder.height(230).empty();
		
		var entity = $('#mbsRTLineLegends li:not(.inactive) .lbl').text();
		var data = mbsLineData[entity];
		var mbsRTLineChart = $.plot(lineChartHolder, data, mbsLineChartOpts);
		_this.warningIfNoData(mbsRTLineChart, 'line');
	};
	
	_this.updateMBSLineData = function(d, index) {
		var timestamp = _this.getCurrentTime();
		
		if ( $.isArray(d) && d.length > 0 ) {
			for ( var i=0; i<d.length; i++ ) {
				var entity = d[i].EntityType;
				mbsLineData[entity][index].data.push([timestamp, d[i].countMBSMessageCount]);
			}
		} else if ( !$.isEmptyObject(d) ) {
			var entity = d.EntityType;
			mbsLineData[entity][index].data.push([timestamp, d.countMBSMessageCount]);
		}
		
		_this.updateMBSLineChart();
	};
	
	_this.updateMBSLineChart = function() {
		var lineChartHolder = $("#mbsRTLineChart");
		var entity = $('#mbsRTLineLegends li:not(.inactive) .lbl').text();
		var data = mbsLineData[entity];
		var mbsRTLineChart = $.plot(lineChartHolder, data, mbsLineChartOpts);
		_this.warningIfNoData(mbsRTLineChart, 'line');
	};
	/** LINE CHARTS END **/
	
	
	/** ALERTS TABLE START **/
	_this.getAlertData = function() {
		var alertQueryData = {
			"query": {"bool": {"must": [{"match_all": {}}], "must_not": [], "should": []}},
			"from": 0,
			"size": 10,
			"sort": [{"timestamp": {"order": "desc", "mode": "avg"}}],
			"facets": {}
		};
		
		jQuery.ajax({
			type: "POST",
			url: urlObj.alerts,
			contentType: 'application/json; charset=utf-8',
			dataType: 'json',
			data: JSON.stringify(alertQueryData),
			success: function (data) {
				_this.createAlertTable(data.hits.hits);
			},
			error: function () {

			}
		});
	};
	
	_this.createAlertTable = function(alertData) {
		$('#alertTable tbody, #mbsAlertTable tbody').empty();
		alertData.forEach(function (obj) {
			var trElem = '';
			var hourOfDay = 0; // Todo : not received yet
			var alertInfo = jQuery.parseJSON(obj._source.data);
			var alertType, count, alertHighLowSubType, timeStamp, date, alertDesc, keyType;
			if ( alertInfo.MessageSubtype || alertInfo.EntityType ) {
				keyType = (alertInfo.MessageSubtype) ? 'MessageType' : 'EntityType';
                alertType = (alertInfo.MessageSubtype) ? alertInfo.MessageSubtype : alertInfo.EntityType;
				hourOfDay = alertInfo.HourOfDay;
				if ( alertInfo.sumPayLoaDCount > 0) {
					count = alertInfo.sumPayLoaDCount;
					alertHighLowSubType = "High";
				} else if ( alertInfo.sumMessageCount > 0 ) {
					count = alertInfo.sumMessageCount;
					alertHighLowSubType = "High";
				} else if ( alertInfo.countPayLoaDCount > 0 ) {
					count = alertInfo.countPayLoaDCount;
					alertHighLowSubType = "Low";
				} else if ( alertInfo.countMessageCount > 0 ) {
					count = alertInfo.countMessageCount;
					alertHighLowSubType = "Low";
				} else if ( alertInfo.sumMBSMessageCount > 0 ) {
					count = alertInfo.sumMBSMessageCount;
					alertHighLowSubType = "Low";
				} else if ( alertInfo.countMBSMessageCount > 0 ) {
					count = alertInfo.countMBSMessageCount;
					alertHighLowSubType = "Low";
				}

				timeStamp = Number(alertInfo.timetsamp);
				date = new Date(timeStamp);

				alertDesc = _this.generateAlertDesc(keyType , alertType, alertHighLowSubType, hourOfDay); // Todo
				trElem = trElem + '<tr>' +
					'<td>' + alertType + ' ' + alertHighLowSubType + '</td>' +
					'<td>' + date + '</td>' +
					'<td>' + alertDesc + '</td>' +
					'</tr>';
				
				$('#alertTable tbody, #mbsAlertTable tbody').append(trElem);
			}
		});
	};
	
	_this.generateAlertDesc = function(keyType , alertType, alertHighLowSubType, hourOfDay) {
		var highLowDescObj = {
			"High": "crossed",
			"Low": "fall short of",
		};

		var countLimitObj = {
			"LOAN": {
				"High": 13,
				"Low": 7
			},

			"POOL": {
				"High": 9,
				"Low": 15
			}
		}

		var msg = alertHighLowSubType + " Threshold alert occured at Hour: " + hourOfDay + " for " + keyType + " " + alertType;
		return msg;
	};
	/** ALERTS TABLE END **/
	
	
	_this.warningIfNoData = function(fChart, type) {
		var showNoData = false;
		if ( type == 'pie' ) {
			if ( fChart.getData().length == 0 || (fChart.getData()[0] && isNaN(fChart.getData()[0].percent)) ) {
				showNoData = true;
			}
		} else {
			if ( fChart.getData().length == 0 ) {
				showNoData = true;
			}
		}
		
		if ( showNoData ) {
			var canvas = fChart.getCanvas();
			var ctx = canvas.getContext("2d");
			var x = canvas.width / 2;
			var y = canvas.height / 2;
			ctx.font = '14pt Calibri';
			ctx.textAlign = 'center';
			ctx.fillStyle = '#999999';
			ctx.fillText('No Data!', x, y);
		}
	};
	
	_this.getCurrentTime = function() {
		var offset = -5.0
		var clientDate = new Date();
		var utc = clientDate.getTime() + (clientDate.getTimezoneOffset() * 60000);
		var serverDate = new Date(utc + (3600000*offset));
		return serverDate.getTime();
		
		//return new Date().getTime();
	};
	
	_this.adsDataRefresh = function() {
		_this.getPayloadPieData();
		_this.getLoanStackData();
		_this.getGroupBarData();
		_this.createLineChart();
		_this.getAlertData();
	};
	
	_this.mbsDataRefresh = function() {
		_this.getEntityPieData();
		_this.getGroupBarData();
		_this.createMBSLineChart();
	};
	
	window.onload = function() {
		_this.init();
	};
};