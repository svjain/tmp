/**
 * Created by krati.jain on 2/1/2016.
 */


var now;
var data = [];
var modifiedCashLineData = [];
var modifiedPoolLineData = [];
var lineChartTimeout;
var dataUrl = "http://172.26.32.142:9200/ns_1_payloaddatanew/_search";
var defaultAllDataObj = {
    data: [{"MessageSubtype": "POOL", "sumPayLoaDCount": 0}, {"MessageSubtype": "CASH", "sumPayLoaDCount": 0}],
    ifReceived: false
};

var defaultTwoMinDataObj = {
    data: [{"MessageSubtype": "POOL", "sumPayLoaDCount": 0}, {"MessageSubtype": "CASH", "sumPayLoaDCount": 0}],
    ifReceived: false
};

var allDataQueueObj = defaultAllDataObj.data, twoMinDataQueueObj = defaultTwoMinDataObj.data;
function init() {
    getPieData();
    getStackData();
    modifyLineChartData();
    createLineChart();
}


init();


function getCurrentTime() {
    return (new Date().getTime());
}
function createPieChart(pieData) {
    var pieChartOptions = {
        series: {
            pie: {
                show: true
            }
        },
        legend: {
            position: "se",
            margin: [-150, 0],
            noColumns: 3,
            backgroundColor: "FFFFFF",
            backgroundOpacity: 0.5

        }
    };

    $.plot('#adsPieChart', pieData, pieChartOptions);
}

function createStackedBarChart(stackDataObj) {
    var dataset = stackDataObj.data;
    var hourkey = stackDataObj.key;
    var barGraphOptions = {
        series: {
            stack: true,
            bars: {show: true},
            barWidth: 0.5
        },
        bars: {
            align: "center",
            horizontal: false,
            barWidth: .8,
            lineWidth: 0
        },
        grid: {
            borderWidth: 0,
            borderColor: null,
            backgroundColor: null,
            labelMargin: 10,
            minBorderMargin: 10
        },
        yaxis: {
            tickColor: "FFFFFF"
        },
        xaxis: {
            tickColor: "FFFFFF",
            ticks: hourkey
        }
    };

    $.plot($("#barChartContainer"), dataset, barGraphOptions);
}

// Create Line Chart
function createLineChart() {
    console.log("creating graph with data", modifiedCashLineData, modifiedPoolLineData);
    var cashLineChartHolder = $("#cashLineChart");
    var poolLineChartHolder = $("#poolLineChart");
    poolLineChartHolder.height(230).empty();
    cashLineChartHolder.height(230).empty();
    var lineChartOptions = {
        xaxis: {mode: "time"},
        yaxis: {min: 0},
        series: {
            lines: {show: true, lineWidth: 2},
            points: {show: true, radius: 1},
            shadowSize: 0
        },
        colors: ['#0672b3', '#ffdc00', '#666666', '#12b6fe'],
        grid: {
            hoverable: true,
            clickable: false,
            borderColor: "#ccc",
            borderWidth: 1,
            markings: [{color: '#fab047', lineWidth: 1, yaxis: {from: 80, to: 80}}]
        }
    };

    var cashLineChart = $.plot("#cashLineChart", modifiedCashLineData, lineChartOptions);
    var poolLineChart = $.plot(poolLineChartHolder, modifiedPoolLineData, lineChartOptions);

};
function modifyPieData(origData) {
    var pieData = [
        {"label": "Major Pool", "data": "0"},
        {"label": "Pool", "data": "0"},
        {"label": "Cash", "data": "0"}
    ]

    for (var i = 0; i < origData.length; i++) {
        if (origData[i]["key"] == "majorpool") {
            pieData[0].data = origData[i]["doc_count"]
        }

        if (origData[i]["key"] == "pool") {
            pieData[1].data = origData[i]["doc_count"]
        }

        if (origData[i]["key"] == "cash") {
            pieData[2].data = origData[i]["doc_count"]
        }
    }

    return pieData;
}


function modifyStackData(origData) {

    var stackDataPool = {label: "Pool", data: []},
        stackDataCash = {label: "Cash", data: []},
        stackDataMajorPool = {label: "Major Pool", data: []};
    var stackData = [];
    var hourKey = [];


    for (var i = 0; i < origData.length; i++) {

        hourKey.push([i, origData[i].key]);
        stackDataMajorPool.data.push([i, 0]);
        stackDataCash.data.push([i, 0]);
        stackDataPool.data.push([i, 0]);
        origData[i].group_by_messageSubType.buckets.forEach(function (obj) {

            if (obj["key"] == "majorpool") {
                stackDataMajorPool.data[i][1] = obj["doc_count"];
            }

            else if (obj["key"] == "pool") {
                stackDataPool.data[i][1] = obj["doc_count"];
            }

            else if (obj["key"] == "cash") {
                stackDataCash.data[i][1] = obj["doc_count"];
            }
        })

        stackData = [stackDataCash, stackDataMajorPool, stackDataPool];

    }

    return {data: stackData, key: hourKey};
}

function modifyLineChartData() {


    var AllDataQueue = [
        {"MessageSubType": "Total Cash", sumPayLoaDCount: 0},
        {"MessageSubType": "Total Pool", sumPayLoaDCount: 0}
    ];
    var TwiMinDataQueue = [
        {"MessageSubType": "Cash Per Minute", sumPayLoaDCount: 0},
        {"MessageSubType": "Pool Per Minute", sumPayLoaDCount: 0}
    ];
    var Queue3Data = [
        {"MessageSubType": "Cash Threshold", sumPayLoaDCount: 40},
        {"MessageSubType": "Total Threshold", sumPayLoaDCount: 80}
    ]

    modifyData(AllDataQueue);
    modifyData(TwiMinDataQueue);
}


function modifyData(queueData) {
    now = getCurrentTime();
    //Total Data at index 0
    var tempObjPool = {}, tempObjCash = {};
    tempObjCash.label = queueData[0]["MessageSubType"];
    tempObjCash.data = [[now, queueData[0]["sumPayLoaDCount"]]]
    tempObjCash.lines = {show: true}
    modifiedCashLineData.push(tempObjCash);

    // Per Minute Data at index 1
    tempObjPool.label = queueData[1]["MessageSubType"];
    tempObjPool.data = [[now, queueData[1]["sumPayLoaDCount"]]];
    tempObjPool.lines = {show: true}
    modifiedPoolLineData.push(tempObjPool);

}


function getPieData() {

    var piePostData = {
        "size": 0,
        "query": {
            "bool": {
                "must": [{"range": {"paylaodgrp.payloadTime": {"from": "1234567890", "to": "1234567898"}}}],
                "must_not": [],
                "should": []
            }
        },
        "aggs": {
            "group_by_messageSubType": {
                "terms": {
                    "field": "MessageSubtype"
                }
            }
        }
    };

    jQuery.ajax({
        type: "POST",
        url: dataUrl,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        data: JSON.stringify(piePostData),
        success: function (data) {
            var responsePieData = data.aggregations.group_by_messageSubType.buckets;
            var pieData = modifyPieData(responsePieData);
            createPieChart(pieData);
        },
        error: function () {

        }

    })


}


function getStackData() {
    var stackPostData = {
        "size": 0,
        "query": {
            "bool": {
                "must": [{"range": {"paylaodgrp.payloadTime": {"from": "1234567890", "to": "1234567898"}}}],
                "must_not": [],
                "should": []
            }
        },
        "aggs": {
            "group_by_Hour": {
                "terms": {
                    "field": "HourOfDay"
                },
                "aggs": {
                    "group_by_messageSubType": {
                        "terms": {
                            "field": "MessageSubtype"
                        }
                    }
                }
            }
        }
    }


    jQuery.ajax({
        type: "POST",
        url: dataUrl,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        data: JSON.stringify(stackPostData),
        success: function (data) {
            var responseStackData = data.aggregations.group_by_Hour.buckets;
            var stackData = modifyStackData(responseStackData);
            createStackedBarChart(stackData);
        },
        error: function () {

        }

    })

}

function updateTwoMinLineChartData() {
    var newQueueData = twoMinDataQueueObj;
// Two minute data is at 1 index
    if (newQueueData.length) {
        newQueueData.forEach(function (obj) {
            if (obj.MessageSubtype == "CASH") {
                modifiedCashLineData[1].data.push([now, obj.sumPayLoaDCount]);
            }
            else {
                modifiedPoolLineData[1].data.push([now, obj.sumPayLoaDCount]);
            }
        })
    }

    else {
        if (newQueueData.MessageSubtype == "CASH") {
            modifiedCashLineData[1].data.push([now, newQueueData.sumPayLoaDCount]);
            modifiedPoolLineData[1].data.push([now, 0]);
        }
        else {
            modifiedPoolLineData[1].data.push([now, newQueueData.sumPayLoaDCount]);
            modifiedCashLineData[1].data.push([now, 0]);
        }

    }

    twoMinDataQueueObj = defaultTwoMinDataObj.data;
}
function updateAllDataLineChartData() {
    var newQueueData = allDataQueueObj;
    var cashCount = 0, poolCount = 0;
    if (newQueueData.length) {//Array is sent , that is data for both the graphs is sent
        newQueueData.forEach(function (obj) {
            if (obj.MessageSubtype == "CASH") {
                cashCount = obj.sumPayLoaDCount;
                modifiedCashLineData[0].data.push([now, cashCount]);   // ModifiedCashLineData has TotalCount at 1 index and Perminute at 0 index
                modifiedPoolLineData[0].data.push([now, poolCount]);
            }
            else {
                poolCount = obj.sumPayLoaDCount;
                modifiedPoolLineData[0].data.push([now, poolCount]);
                modifiedCashLineData[0].data.push([now, cashCount]);
            }
        })
    }

    else {
        if (newQueueData.MessageSubtype == "CASH") {
            cashCount = newQueueData.sumPayLoaDCount;
            modifiedCashLineData[0].data.push([now, cashCount]);
        }
        else {
            poolCount = newQueueData.sumPayLoaDCount;
            modifiedPoolLineData[0].data.push([now, poolCount]);
        }

    }
    defaultAllDataObj.data[0].sumPayLoaDCount = poolCount;
    defaultAllDataObj.data[1].sumPayLoaDCount = cashCount;
    defaultAllDataObj.ifReceived = false;
}
function checkForQueueData() {
    now = getCurrentTime();
    if (defaultAllDataObj.ifReceived == false || defaultTwoMinDataObj.ifReceived == false) {
        delayLineChart();
    }
    else {
        clearTimeout(lineChartTimeout);
        defaultAllDataObj.ifReceived = false;
        defaultTwoMinDataObj.ifReceived = false;

        updateAllDataLineChartData();
        updateTwoMinLineChartData();
        createLineChart();
    }
}

function delayLineChart() {
    lineChartTimeout = setTimeout(function () {
        updateAllDataLineChartData();
        updateTwoMinLineChartData();
        createLineChart();
    }, 50000)
}