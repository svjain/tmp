/**
 * Created by krati.jain on 2/1/2016.
 */


var now;
var data = [];
var modifiedLoanLineData = [];
var modifiedPoolLineData = [];
var poolLowThreshold = 9, poolHighThreshold = 15, loanLowThreshold = 7, loanHighThreshold = 13;
var lineChartTimeout;
var dataUrl = "http://192.168.7.81:9200/ns_1_adspayloaddata_ialias/_search";
var defaultAllDataObj = {
    data: [{"MessageSubtype": "POOL", "sumPayLoaDCount": 0}, {"MessageSubtype": "LOAN", "sumPayLoaDCount": 0}],
    ifReceived: false
};

var defaultTwoMinDataObj = {
    data: [{"MessageSubtype": "POOL", "sumPayLoaDCount": 0}, {"MessageSubtype": "LOAN", "sumPayLoaDCount": 0}],
    ifReceived: false
};

var allDataQueueObj = defaultAllDataObj.data, twoMinDataQueueObj = defaultTwoMinDataObj.data;
function init() {
    getPieData();
    getStackData();
    modifyLineChartData();
    createLineChart();
    getAlertData();

    setTimeout(function () {
        $('#fromDatetimepicker input, #toDatetimepicker input').on('keydown', function (e) {
            e.preventDefault();
            e.stopPropagation();
        });

        $('#fromDatetimepicker, #toDatetimepicker').datetimepicker({
            language: 'en',
            pick12HourFormat: true,
            endDate: new Date()
        });

        $('#fromDatetimepicker').on('changeDate', function (e) {
            $('#toDatetimepicker').datetimepicker('setStartDate', e.date);
        });

        $('#toDatetimepicker').on('changeDate', function (e) {
            $('#fromDatetimepicker').datetimepicker('update');
            $('#fromDatetimepicker').datetimepicker('setEndDate', e.date);
        });

    }, 50000)
}


init();


function getCurrentTime() {
    return (new Date().getTime());
}
function createPieChart(pieData) {
    var pieChartOptions = {
        series: {
            pie: {
                show: true,
                label: {
                    show: true
                }
            }
        },
        legend: {
            position: "se",
            margin: [-150, 0],
            noColumns: 3,
            backgroundColor: "FFFFFF",
            backgroundOpacity: 0.5

        }
    };

    $.plot('#adsPieChart', pieData, pieChartOptions);
}

function createStackedBarChart(stackDataObj) {
    var dataset = stackDataObj.data;
    var hourkey = stackDataObj.key;
    var barGraphOptions = {
        series: {
            stack: true,
            bars: {show: true},
            barWidth: 0.8,
            lineWidth: 0,
            lines: {show: false}
        },
        bars: {
            align: "center",
            horizontal: false,
            barWidth: .8,
            lineWidth: 0
        },
        grid: {
            borderWidth: 0,
            borderColor: null,
            backgroundColor: null,
            labelMargin: 10,
            minBorderMargin: 10,
            aboveData: true
        },
        xaxis: {

            ticks: hourkey
        },
        legend: {
            position: "se",
            margin: [-100, 0],
            backgroundColor: "FFFFFF",
            backgroundOpacity: 0.5

        }
    };

    $.plot($("#barChartContainer"), dataset, barGraphOptions);
}

// Create Line Chart
function createLineChart() {
    var loanLineChartHolder = $("#loanLineChart");
    var poolLineChartHolder = $("#poolLineChart");
    poolLineChartHolder.height(230).empty();
    loanLineChartHolder.height(230).empty();
    var lineChartOptions = {
        xaxis: {
            mode: "time",
            timeformat: "%H:%M"
        },
        yaxis: {min: 0},
        series: {
            lines: {show: true, lineWidth: 2},
            points: {show: true, radius: 1},
            shadowSize: 0
        },
        colors: ['#0672b3', '#ffdc00', '#666666', '#12b6fe'],
        grid: {
            hoverable: true,
            clickable: false,
            borderColor: "#ccc",
            borderWidth: 1,
            markings: [{color: '#fab047', lineWidth: 1, yaxis: {from: 80, to: 80}}]
        }
    };

    var loanLineChart = $.plot("#loanLineChart", modifiedLoanLineData, lineChartOptions);
    var poolLineChart = $.plot(poolLineChartHolder, modifiedPoolLineData, lineChartOptions);

};
function modifyPieData(origData) {
    var pieData = [
        {"label": "Loan", "data": "0"},
        {"label": "Major Pool", "data": "0"},
        {"label": "Pool", "data": "0"}
    ]

    for (var i = 0; i < origData.length; i++) {
        if (origData[i]["key"] == "majorpool") {
            pieData[0].data = origData[i]["doc_count"]
        }

        if (origData[i]["key"] == "pool") {
            pieData[1].data = origData[i]["doc_count"]
        }

        if (origData[i]["key"] == "loan") {
            pieData[2].data = origData[i]["doc_count"]
        }
    }

    return pieData;
}


function modifyLineChartData() {


    var AllDataQueue = [
        {"MessageSubType": "Total Loan", sumPayLoaDCount: 0},
        {"MessageSubType": "Total Pool", sumPayLoaDCount: 0}
    ];
    var TwiMinDataQueue = [
        {"MessageSubType": "Loan Per Minute", sumPayLoaDCount: 0},
        {"MessageSubType": "Pool Per Minute", sumPayLoaDCount: 0}
    ];
    var LowThresholdDataQueue = [
        {"MessageSubType": "Loan Low", sumPayLoaDCount: 7},
        {"MessageSubType": "Pool Low", sumPayLoaDCount: 9}
    ]

    var HighThresholdDataQueue = [
        {"MessageSubType": "Loan High", sumPayLoaDCount: 13},
        {"MessageSubType": "Pool High", sumPayLoaDCount: 15}
    ]

    now = getCurrentTime();
    modifyData(AllDataQueue);
    modifyData(TwiMinDataQueue);
    modifyData(LowThresholdDataQueue);
    modifyData(HighThresholdDataQueue);

}


function modifyData(queueData) {

    //Total Data at index 0
    var tempObjPool = {}, tempObjLoan = {};
    tempObjLoan.label = queueData[0]["MessageSubType"];
    tempObjLoan.data = [[now, queueData[0]["sumPayLoaDCount"]]]
    tempObjLoan.lines = {show: true}
    modifiedLoanLineData.push(tempObjLoan);

    // Per Minute Data at index 1
    tempObjPool.label = queueData[1]["MessageSubType"];
    tempObjPool.data = [[now, queueData[1]["sumPayLoaDCount"]]];
    tempObjPool.lines = {show: true}
    modifiedPoolLineData.push(tempObjPool);


}


function getPieData(from) {
    var start, end, sel_date;
    if (from == undefined) {
        sel_date = new Date();
    }
    else {
        sel_date = new Date(from);
    }

    start = sel_date.setHours(0, 0, 0, 0);
    end = sel_date.setHours(23, 59, 59, 999);


    var piePostData = {
        "size": 0,
        "query": {
            "bool": {
                "must": [{"range": {"paylaodgrp.payloadTime": {"from": start, "to": end}}}],
                "must_not": [],
                "should": []
            }
        },
        "aggs": {
            "group_by_messageSubType": {
                "terms": {
                    "field": "MessageSubtype"
                }
            }
        }
    }


    jQuery.ajax({
        type: "POST",
        url: dataUrl,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        async: true,
        data: JSON.stringify(piePostData),
        success: function (data) {
            var responsePieData = data.aggregations.group_by_messageSubType.buckets;
            var pieData = modifyPieData(responsePieData);
            createPieChart(pieData);
        },
        error: function () {

        }

    })


}


function getStackData(from) {
    var start, end, sel_date;
    if (from == undefined) {
        sel_date = new Date();
    }
    else {
        sel_date = new Date(from);
    }

    start = sel_date.setHours(0, 0, 0, 0);
    end = sel_date.setHours(23, 59, 59, 999);

    var stackPostData = {
        "size": 0,
        "query": {
            "bool": {
                "must": [{"range": {"paylaodgrp.payloadTime": {"from": start, "to": end}}}],
                "must_not": [],
                "should": []
            }
        },
        "aggs": {
            "group_by_Hour": {
                "terms": {
                    "field": "HourWODate"
                },
                "aggs": {
                    "group_by_messageSubType": {
                        "terms": {
                            "field": "MessageSubtype"
                        }
                    }
                }
            }
        }
    }


    jQuery.ajax({
        type: "POST",
        url: dataUrl,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        data: JSON.stringify(stackPostData),
        success: function (data) {
            var responseStackData = data.aggregations.group_by_Hour.buckets;
            var stackData = modifyStackData(responseStackData);
            createStackedBarChart(stackData);
        },
        error: function () {

        }

    })

}

function updateTwoMinLineChartData() {
    var newQueueData = twoMinDataQueueObj;
// Two minute data is at 1 index
    if (newQueueData.length) {
        newQueueData.forEach(function (obj) {

            if (obj.sumPayLoaDCount == null)
                obj.sumPayLoaDCount = 0;
            if (obj.MessageSubtype == "LOAN") {
                modifiedLoanLineData[1].data.push([now, obj.sumPayLoaDCount]);
            }
            else {
                modifiedPoolLineData[1].data.push([now, obj.sumPayLoaDCount]);
            }
        })
    }

    else {

        if (newQueueData.sumPayLoaDCount == null)
            newQueueData.sumPayLoaDCount = 0;

        if (newQueueData.MessageSubtype == "LOAN") {
            modifiedLoanLineData[1].data.push([now, newQueueData.sumPayLoaDCount]);
            modifiedPoolLineData[1].data.push([now, 0]);
        }
        else {
            modifiedPoolLineData[1].data.push([now, newQueueData.sumPayLoaDCount]);
            modifiedLoanLineData[1].data.push([now, 0]);
        }

    }


    twoMinDataQueueObj = defaultTwoMinDataObj.data;
}

function updateThresholdData() {
    modifiedPoolLineData[2].data.push([now, poolLowThreshold]);
    modifiedPoolLineData[3].data.push([now, poolHighThreshold]);
    modifiedLoanLineData[2].data.push([now, loanLowThreshold]);
    modifiedLoanLineData[3].data.push([now, loanHighThreshold]);
}
function updateAllDataLineChartData() {
    var newQueueData = allDataQueueObj;
    var loanCount = 0, poolCount = 0;
    if (newQueueData.length) {//Array is sent , that is data for both the graphs is sent
        newQueueData.forEach(function (obj) {
            if (obj.sumPayLoaDCount == null)
                obj.sumPayLoaDCount = 0;

            if (obj.MessageSubtype == "LOAN") {
                loanCount = obj.sumPayLoaDCount;
                modifiedLoanLineData[0].data.push([now, loanCount]);   // ModifiedLoanLineData has TotalCount at 1 index and Perminute at 0 index

            }
            else {
                poolCount = obj.sumPayLoaDCount;
                modifiedPoolLineData[0].data.push([now, poolCount]);

            }
        })
    }

    else {

        if (newQueueData.sumPayLoaDCount == null)
            newQueueData.sumPayLoaDCount = 0;
        if (newQueueData.MessageSubtype == "LOAN") {
            loanCount = newQueueData.sumPayLoaDCount;
            modifiedLoanLineData[0].data.push([now, loanCount]);
            modifiedPoolLineData[0].data.push([now, poolCount]);
        }
        else {
            poolCount = newQueueData.sumPayLoaDCount;
            modifiedPoolLineData[0].data.push([now, poolCount]);
            modifiedLoanLineData[0].data.push([now, loanCount]);
        }

    }
    defaultAllDataObj.data[0].sumPayLoaDCount = poolCount;
    defaultAllDataObj.data[1].sumPayLoaDCount = loanCount;
    defaultAllDataObj.ifReceived = false;
}
function checkForQueueData() {
    now = getCurrentTime();
    if (defaultAllDataObj.ifReceived == false || defaultTwoMinDataObj.ifReceived == false) {
        delayLineChart();
    }
    else {
        clearTimeout(lineChartTimeout);
        defaultAllDataObj.ifReceived = false;
        defaultTwoMinDataObj.ifReceived = false;

        updateAllDataLineChartData();
        updateTwoMinLineChartData();
        updateThresholdData();
        createLineChart();
    }
}

function delayLineChart() {
    lineChartTimeout = setTimeout(function () {
        updateAllDataLineChartData();
        updateTwoMinLineChartData();
        updateThresholdData();
        createLineChart();
    }, 29000)
}

function getAlertData() {

    var alertQueryData = {
        "query": {"bool": {"must": [{"match_all": {}}], "must_not": [], "should": []}},
        "from": 0,
        "size": 10,
        "sort": [{"timestamp": {"order": "desc", "mode": "avg"}}],
        "facets": {}
    };
    /* var alertQueryUrl = "http://192.168.7.81:9200/ns_1_sax_alerts/_search ?";*/
    var alertQueryUrl = "http://172.26.32.142:9200/ns_1_sax_alerts/_search";


    jQuery.ajax({
        type: "POST",
        url: alertQueryUrl,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        data: JSON.stringify(alertQueryData),
        success: function (data) {
            createAlertTable(data.hits.hits);
        },
        error: function () {

        }

    })
}

function createAlertTable(alertData) {

    alertData.forEach(function (obj) {
        var trElem = '';
        var hourOfDay = 0; // Todo : not received yet
        var alertInfo = jQuery.parseJSON(obj._source.data);
        var alertType, count, alertHighLowSubType, timeStamp, date, alertDesc;
        if (alertInfo.MessageSubtype) {
            alertType = alertInfo.MessageSubtype;
hourOfDay = alertInfo.HourOfDay.substr(alertInfo.HourOfDay.length-2,alertInfo.HourOfDay.length-1); 

            if (alertInfo.sumPayLoaDCount > 0) {
                count = alertInfo.sumPayLoaDCount;
                alertHighLowSubType = "High";
            }
            else if (alertInfo.sumMessageCount > 0) {
                count = alertInfo.sumMessageCount;
                alertHighLowSubType = "High";
            }
            else if (alertInfo.countPayLoaDCount > 0) {
                count = alertInfo.countPayLoaDCount;
                alertHighLowSubType = "Low";
            }
            else if (alertInfo.countMessageCount > 0) {
                count = alertInfo.countMessageCount;
                alertHighLowSubType = "Low";
            }

            timeStamp = Number(alertInfo.timetsamp);
            date = new Date(timeStamp);

            alertDesc = generateAlertDesc(alertType, alertHighLowSubType, hourOfDay); // Todo
            trElem = trElem + '<tr>' +
                '<td>' + alertType + ' ' + alertHighLowSubType + '</td>' +
                '<td>' + date + '</td>' +
                '<td>' + alertDesc + '</td>' +
                '</tr>';
            $('#alertTable tbody').append(trElem);
        }

    });


}

function generateAlertDesc(alertType, alertHighLowSubType, hourOfDay) {
    var highLowDescObj = {
        "High": "crossed",
        "Low": "fall short of",
    };

    var countLimitObj = {
        "LOAN": {
            "High": 13,
            "Low": 7
        },

        "POOL": {
            "High": 9,
            "Low": 15
        }
    }

    var msg = alertHighLowSubType + " Threshold alert occured at Hour: " + hourOfDay + " for MessageType " + alertType;
    return msg;

}

function refreshData() {
    var fromDate = $("#fromDatetimepicker input[type='text']").val();
    getPieData(fromDate);
    getStackData(fromDate);
}

function modifyStackData(origData) {

    var stackDataPool = {label: "Pool", data: []},
        stackDataLoan = {label: "Loan", data: []},
        stackDataMajorPool = {label: "Major Pool", data: []};
    var stackData = [];
    var hourKey = [];

    for (var i = 0; i < 24; i++) {
        hourKey.push([i, i]);
        stackDataMajorPool.data.push([i, 0]);
        stackDataLoan.data.push([i, 0]);
        stackDataPool.data.push([i, 0]);
    }

    for (var i = 0; i < origData.length; i++) {
        var curr_hour_key = Number(origData[i].key);

        /*hourKey.push([i, origData[i].key]);
         stackDataMajorPool.data.push([i, 0]);
         stackDataLoan.data.push([i, 0]);
         stackDataPool.data.push([i, 0]);*/
        origData[i].group_by_messageSubType.buckets.forEach(function (obj) {

            if (obj["key"] == "majorpool") {
                stackDataMajorPool.data[curr_hour_key][1] = obj["doc_count"];
            }

            else if (obj["key"] == "pool") {
                stackDataPool.data[curr_hour_key][1] = obj["doc_count"];
            }

            else if (obj["key"] == "loan") {
                stackDataLoan.data[curr_hour_key][1] = obj["doc_count"];
            }
        })

        stackData = [stackDataLoan, stackDataMajorPool, stackDataPool];

    }

    return {data: stackData, key: hourKey};
}
