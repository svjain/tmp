/*
 * Class
 * Fannie Mae Demo
 * Date - 2016-01-08
 * 
 */

var bizADSPoolData = {keys: [], data: [{"label": "MBS Pool Difference", "data": []}]};
var bizADSLoanData = {keys: [], data: [{"label": "MBS Loan Difference", "data": []}, {"label": "Cash Loan Difference", "data": []}]};
var bizADSUPBData = {keys: [], data: [{"label": "MBS Loan UPB Amount Difference", "data": []}, {"label": "Cash Loan UPB Amount Difference", "data": []}]};
var bizADSMonthlyData = [];

var bizMBSLoanData = {keys: [], data: [{"label": "MBS Loan Difference", "data": []}, {"label": "Cash Loan Difference", "data": []}]};
var bizMBSUPBData = {keys: [], data: [{"label": "MBS Loan UPB Amount Difference", "data": []}, {"label": "Cash Loan UPB Amount Difference", "data": []}]};
var bizMBSMonthlyData = [];

var bizADSBarOptions = $.extend(true, {}, barGraphOptions);
bizADSBarOptions.xaxis = {
	mode: "time",
	timezone: 'browser',
	tickSize: [3, "day"]
};
bizADSBarOptions.bars.barWidth = 7 * 60 * 60 * 600;

var bizADSPoolOptions = $.extend(true, {}, bizADSBarOptions);
bizADSPoolOptions.colors = ["#93e0f8"];

var bizADSLoanOptions = $.extend(true, {}, bizADSBarOptions);
bizADSLoanOptions.colors = ["#7a53a3","#de8ff6"];

var bizADSUPBOptions = $.extend(true, {}, bizADSBarOptions);
bizADSUPBOptions.colors = ["#da4f12","#eadc6b"];

var bizMBSLoanOptions = $.extend(true, {}, bizADSBarOptions);
bizMBSLoanOptions.colors = ["#7a53a3","#de8ff6"];

var bizMBSUPBOptions = $.extend(true, {}, bizADSBarOptions);
bizMBSUPBOptions.colors = ["#da4f12","#eadc6b"];

var bizADSMonthlyColor = ["#93e0f8","#7a53a3","#de8ff6","#da4f12","#eadc6b"];
var bizADSMonthlyColumns = {
	"column1" : ["MBS Pool Difference"],
	"column2" : ["MBS Loan Difference", "Cash Loan Difference"],
	"column3" : ["MBS Loan UPB Amount Difference", "Cash Loan UPB Amount Difference"]
};

var bizMBSMonthlyColor = ["#7a53a3","#de8ff6","#da4f12","#eadc6b"];
var bizMBSMonthlyColumns = {
	"column1" : ["MBS Loan Difference", "Cash Loan Difference"],
	"column2" : ["MBS Loan UPB Amount Difference", "Cash Loan UPB Amount Difference"]
};

var fannieMaeBizApp = new function() {
	var _this = this;
	
	_this.init = function() {
		$('#page2Tabs a').on('click', function() {
			var isActive = $(this).closest('li').hasClass('active');
			if ( !isActive ) {
				curPage.business = $(this).closest('li').data('page');
				setTimeout(function() {				
					_this.getBizStackData();
					_this.getBizGroupData();
				}, 300);
				
				$('ul.legends > li.inactive').removeClass('inactive');
			}
		});
		
		$('#bizADSSubmitBtn').on('click', function() {
			var value = $('#bizADSFromDatetimepicker input').val();
			if ( value != '' ) {
				_this.bizDataRefresh();
			}
		});
		
		$('#bizMBSSubmitBtn').on('click', function() {
			var value = $('#bizMBSFromDatetimepicker input').val();
			if ( value != '' ) {
				_this.bizDataRefresh();
			}
		});
		
		$('#bizADSPoolCountLegends a').on('click', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateBizStackGraph("#bizADSPoolCountGraph", "#bizADSPoolCountLegends", bizADSPoolData, bizADSPoolOptions);
		});
		
		$('#bizADSLoanCountLegends a').on('click', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateBizStackGraph("#bizADSLoanCountGraph", "#bizADSLoanCountLegends", bizADSLoanData, bizADSLoanOptions);
		});
		
		$('#bizADSLoanUPBAmtLegends a').on('click', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateBizStackGraph("#bizADSLoanUPBAmtGraph", "#bizADSLoanUPBAmtLegends", bizADSUPBData, bizADSUPBOptions);
		});
		
		$('#bizADSMonthlyLegends a').on('click', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateBizMonthlyGraph();
		});
		
		$('#bizMBSLoanCountLegends a').on('click', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateBizStackGraph("#bizMBSLoanCountGraph", "#bizMBSLoanCountLegends", bizMBSLoanData, bizMBSLoanOptions);
		});
		
		$('#bizMBSLoanUPBAmtLegends a').on('click', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateBizStackGraph("#bizMBSLoanUPBAmtGraph", "#bizMBSLoanUPBAmtLegends", bizMBSUPBData, bizMBSUPBOptions);
		});
		
		$('#bizMBSMonthlyLegends a').on('click', function() {
			$(this).parent().toggleClass('inactive');
			_this.updateBizMonthlyGraph();
		});
	};
	
	
	/** BAR CHARTS START **/
	_this.getBizStackData = function(entity) {
		var start, end, sel_date;
		var from = '', url = '';
		
		if ( curPage.business == 'ads' ) {
			url = urlObj.bizAds;
			from = $("#bizADSFromDatetimepicker input[type='text']").val();
		} else {
			url = urlObj.bizMbs;
			from = $("#bizMBSFromDatetimepicker input[type='text']").val();
		}
		
		if ( from == '' ) {
			sel_date = new Date();
		} else {
			sel_date = new Date(from);
		}

		sel_date.setDate(sel_date.getDate() - 7);
		start = sel_date.setHours(0, 0, 0, 0);
		end = sel_date.setHours(8*24+23, 59, 59, 999);
		
		var startDt = new Date(start);
		var start = startDt.getFullYear().toString() + ('0'+(startDt.getMonth()+1)).slice(-2).toString() + ('0'+startDt.getDate()).slice(-2).toString();
		
		var endDt = new Date(end);
		end = endDt.getFullYear().toString() + ('0'+(endDt.getMonth()+1)).slice(-2).toString() + ('0'+endDt.getDate()).slice(-2).toString();
		
		var query = {
					"query": {
						"bool": {
							"must": [
								{
									"range": {
										"ReconTimestamp": {
											"gt": start, 
											"lt": end
										}
									}
								}
							], 
							"must_not": [ ], 
							"should": [ ]
						}
					}, 
					"from": 0, 
					"size": 10, 
					"sort": [ ], 
					"aggs": { }
				}

		jQuery.ajax({
			type: "POST",
			url: url,
			contentType: 'application/json; charset=utf-8',
			dataType: 'json',
			data: JSON.stringify(query),
			success: function (data) {
				data = (data.hits.hits.length > 0) ? data.hits.hits : [];
				_this.updateBizStackData(data);
			},
			error: function () {

			}
		});
	};
	
	_this.updateBizStackData = function(data) {
		if ( curPage.business == 'ads' ) {
			bizADSPoolData = {keys: [], data: [{"label": "MBS Pool Difference", "data": []}]};
			bizADSLoanData = {keys: [], data: [{"label": "MBS Loan Difference", "data": []}, {"label": "Cash Loan Difference", "data": []}]};
			bizADSUPBData = {keys: [], data: [{"label": "MBS Loan UPB Amount Difference", "data": []}, {"label": "Cash Loan UPB Amount Difference", "data": []}]};

			for ( var i=0; i<data.length; i++ ) {
				var d = data[i]._source;
				var t = d.ReconTimestamp;
				var time = t.substr(0, 4) + '/' + t.substr(4, 2) + '/' + t.substr(6, 2);
				time = new Date(time).valueOf();
				
				bizADSPoolData.keys.push(time);
				bizADSPoolData.data[0].data.push([time, d.PoolCountDelta_Pool]);
				
				bizADSLoanData.keys.push(time);
				bizADSLoanData.data[0].data.push([time, d.LoanCountDelta_Pool]);
				bizADSLoanData.data[1].data.push([time, d.LoanCountDelta_Loan]);
				
				bizADSUPBData.keys.push(time);
				bizADSUPBData.data[0].data.push([time, d.UPBAmountDelta_Pool]);
				bizADSUPBData.data[1].data.push([time, d.UPBAmountDelta_Loan]);
			}
			
			_this.createBizStackGraph("#bizADSPoolCountGraph", bizADSPoolData, bizADSPoolOptions);
			_this.createBizStackGraph("#bizADSLoanCountGraph", bizADSLoanData, bizADSLoanOptions);
			_this.createBizStackGraph("#bizADSLoanUPBAmtGraph", bizADSUPBData, bizADSUPBOptions);
		} else {
			bizMBSLoanData = {keys: [], data: [{"label": "MBS Loan Difference", "data": []}, {"label": "Cash Loan Difference", "data": []}]};
			bizMBSUPBData = {keys: [], data: [{"label": "MBS Loan UPB Amount Difference", "data": []}, {"label": "Cash Loan UPB Amount Difference", "data": []}]};
			
			for ( var i=0; i<data.length; i++ ) {
				var d = data[i]._source;
				var t = d.ReconTimestamp;
				var time = t.substr(0, 4) + '/' + t.substr(4, 2) + '/' + t.substr(6, 2);
				time = new Date(time).valueOf();
				
				bizMBSLoanData.keys.push(time);
				bizMBSLoanData.data[0].data.push([time, d.LoanCountDelta_MBS_LDNG]);
				bizMBSLoanData.data[1].data.push([time, d.LoanCountDelta_Cash_LDNG]);
				
				bizMBSUPBData.keys.push(time);
				bizMBSUPBData.data[0].data.push([time, d.UPBAmountDelta_MBS_LDNG]);
				bizMBSUPBData.data[1].data.push([time, d.UPBAmountDelta_Cash_LDNG]);				
			}
			
			_this.createBizStackGraph("#bizMBSLoanCountGraph", bizMBSLoanData, bizMBSLoanOptions);
			_this.createBizStackGraph("#bizMBSLoanUPBAmtGraph", bizMBSUPBData, bizMBSUPBOptions);
		}
	};
	
	_this.getBizGroupData = function(entity) {
		var start, end, sel_date;
		var from = '', url = '';
		
		if ( curPage.business == 'ads' ) {
			url = urlObj.bizAds;
			from = $("#bizADSFromDatetimepicker input[type='text']").val();
		} else {
			url = urlObj.bizMbs;
			from = $("#bizMBSFromDatetimepicker input[type='text']").val();
		}
		
		if ( from == '' ) {
			sel_date = new Date();
		} else {
			sel_date = new Date(from);
		}

		var month = sel_date.getMonth();
		var year = sel_date.getFullYear();
		var days = new Date(year, month+1, 0).getDate() - 1;
		
		sel_date.setDate(1);
		start = sel_date.setHours(0, 0, 0, 0);
		end = sel_date.setHours(days*24+23, 59, 59, 999);
		
		var startDt = new Date(start);
		var start = startDt.getFullYear().toString() + ('0'+(startDt.getMonth()+1)).slice(-2).toString() + ('0'+startDt.getDate()).slice(-2).toString();
		
		var endDt = new Date(end);
		end = endDt.getFullYear().toString() + ('0'+(endDt.getMonth()+1)).slice(-2).toString() + ('0'+endDt.getDate()).slice(-2).toString();
		
		var query = {
					"query": {
						"bool": {
							"must": [
								{
									"range": {
										"ReconTimestamp": {
											"gt": start, 
											"lt": end
										}
									}
								}
							], 
							"must_not": [ ], 
							"should": [ ]
						}
					}, 
					"from": 0, 
					"size": 10, 
					"sort": [ ], 
					"aggs": { }
				}

		jQuery.ajax({
			type: "POST",
			url: url,
			contentType: 'application/json; charset=utf-8',
			dataType: 'json',
			data: JSON.stringify(query),
			success: function (data) {
				data = (data.hits.hits.length > 0) ? data.hits.hits : [];
				_this.updateBizGroupData(data, days);
			},
			error: function () {

			}
		});
	};
	
	_this.updateBizGroupData = function(data, days) {
		if ( curPage.business == 'ads' ) {
			bizADSMonthlyData = [];

			for ( var i=0; i<data.length; i++ ) {
				var d = data[i]._source;
				var t = d.ReconTimestamp;
				var time = t.substr(0, 4) + '/' + t.substr(4, 2) + '/' + t.substr(6, 2);
				time = new Date(time);
				var dt = time.getDate();
				
				bizADSMonthlyData[dt] = {
					"Date": dt,
					"MBS Pool Difference": d.PoolCountDelta_Pool,
					"MBS Loan Difference": d.LoanCountDelta_Pool,
					"Cash Loan Difference": d.LoanCountDelta_Loan,
					"MBS Loan UPB Amount Difference": d.UPBAmountDelta_Pool,
					"Cash Loan UPB Amount Difference": d.UPBAmountDelta_Loan
				};
			}
		
			for ( var i=0; i<days+1; i++ ) {
				if ( typeof bizADSMonthlyData[i] === 'undefined' ) {
					bizADSMonthlyData[i] = {
						"Date": i,
						"MBS Pool Difference": 0,
						"MBS Loan Difference": 0,
						"Cash Loan Difference": 0,
						"MBS Loan UPB Amount Difference": 0,
						"Cash Loan UPB Amount Difference": 0
					}
				}
			}
		
			var newData = $.extend(true, [], bizADSMonthlyData);
			_this.createBizMonthlyGraph("#bizADSMonthlyGraph", newData, bizADSMonthlyColor, bizADSMonthlyColumns);
		} else {
			bizMBSMonthlyData = [];
			for ( var i=0; i<data.length; i++ ) {
				var d = data[i]._source;
				var t = d.ReconTimestamp;
				var time = t.substr(0, 4) + '/' + t.substr(4, 2) + '/' + t.substr(6, 2);
				time = new Date(time);
				var dt = time.getDate();
				
				bizMBSMonthlyData[dt] = {
					"Date": dt,
					"MBS Loan Difference": d.LoanCountDelta_MBS_LDNG,
					"Cash Loan Difference": d.LoanCountDelta_Cash_LDNG,
					"MBS Loan UPB Amount Difference": d.UPBAmountDelta_MBS_LDNG,
					"Cash Loan UPB Amount Difference": d.UPBAmountDelta_Cash_LDNG
				};
			}
		
			for ( var i=0; i<days+1; i++ ) {
				if ( typeof bizMBSMonthlyData[i] === 'undefined' ) {
					bizMBSMonthlyData[i] = {
						"Date": i,
						"MBS Loan Difference": 0,
						"Cash Loan Difference": 0,
						"MBS Loan UPB Amount Difference": 0,
						"Cash Loan UPB Amount Difference": 0
					}
				}
			}
		
			var newData = $.extend(true, [], bizMBSMonthlyData);
			_this.createBizMonthlyGraph("#bizMBSMonthlyGraph", newData, bizMBSMonthlyColor, bizMBSMonthlyColumns);
		}
	};
	
	/** BUSINESS STACK GRAPH **/
	_this.createBizStackGraph = function(placeholder, d, opts) {
		opts.xaxis.ticks = d.keys;
		var graph = $.plot($(placeholder), d.data, opts);
		fannieMaeApp.warningIfNoData(graph, 'bar');
	};
	
	_this.updateBizStackGraph = function(placeholder, legendsWrap, d, opts) {
		var newData = $.extend(true, [], d.data);
		var newOpts = $.extend(true, {}, opts);
		newOpts.colors = [];
		
		var actLegends = [];
		$(legendsWrap).find('li').each(function(i, elm) {
			var isInactive = $(elm).hasClass('inactive');
			if ( !isInactive ) {
				var lbl = $(elm).find('.lbl').text();
				var clr = opts.colors[i];
				actLegends.push(lbl);
				newOpts.colors.push(clr);
			}
		});
		
		newData = $.grep(newData, function(o) {
			return $.inArray(o.label, actLegends) > -1;
		});
		
		var graph = $.plot(placeholder, newData, newOpts);
		fannieMaeApp.warningIfNoData(graph, 'bar');
	};
	
	/** BUSINESS MONTHLY GRAPH **/
	_this.createBizMonthlyGraph = function(placeholder, data, colors, innerColumns) {
		$(placeholder).empty();
		
		var margin = {top: 0, right: 0, bottom: 30, left: 40},
			width = $(placeholder).width() - margin.left - margin.right,
			height = $(placeholder).height() - margin.top - margin.bottom;
		 
		var x0 = d3.scale.ordinal()
			.rangeRoundBands([0, width], 0.1);
		 
		var x1 = d3.scale.ordinal();
		 
		var y = d3.scale.linear()
			.range([height, 0]);
		 
		var xAxis = d3.svg.axis()
			.scale(x0)
			.orient("bottom");
		 
		var yAxis = d3.svg.axis()
			.scale(y)
			.orient("left")
			.tickFormat(d3.format(".2s"));
		 
		var color = d3.scale.ordinal()
			.range(colors);
		 
		var svg = d3.select(placeholder).append("svg")
			.attr("width", width + margin.left + margin.right)
			.attr("height", height + margin.top + margin.bottom)
			.append("g")
			.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
		 
		var yBegin;
		var columnHeaders = d3.keys(data[0]).filter(function(key) { return key !== "Date"; });
		color.domain(d3.keys(data[0]).filter(function(key) { return key !== "Date"; }));
		data.forEach(function(d) {
			var yColumn = new Array();
			d.columnDetails = columnHeaders.map(function(name) {
				for (ic in innerColumns) {
					if($.inArray(name, innerColumns[ic]) >= 0){
						if (!yColumn[ic]){
							yColumn[ic] = 0;
						}
						yBegin = yColumn[ic];
						yColumn[ic] += +d[name];
						return {name: name, column: ic, yBegin: yBegin, yEnd: +d[name] + yBegin,};
					}
				}
			});
			
			d.total = d3.max(d.columnDetails, function(d) { 
				return d.yEnd; 
			});
		});

		x0.domain(data.map(function(d) { return d.Date; }));
		x1.domain(d3.keys(innerColumns)).rangeRoundBands([0, x0.rangeBand()]);

		y.domain([0, d3.max(data, function(d) {
			return d.total; 
		})]);

		svg.append("g")
			.attr("class", "x axis")
			.attr("transform", "translate(0," + height + ")")
			.call(xAxis);

		svg.append("g")
			.attr("class", "y axis")
			.call(yAxis)
			.append("text")
			.attr("transform", "rotate(-90)")
			.attr("y", 6)
			.attr("dy", ".7em")
			.style("text-anchor", "end")
			.text("");

		var project_stackedbar = svg.selectAll(".project_stackedbar")
			.data(data)
			.enter().append("g")
			.attr("class", "g")
			.attr("transform", function(d) { return "translate(" + x0(d.Date) + ",0)"; });

		project_stackedbar.selectAll("rect")
			.data(function(d) { return d.columnDetails; })
			.enter().append("rect")
			.attr("width", x1.rangeBand())
			.attr("x", function(d) { 
				return x1(d.column);
			})
			.attr("y", function(d) { 
				return y(d.yEnd); 
			})
			.attr("height", function(d) { 
				return y(d.yBegin) - y(d.yEnd); 
			})
			.style("fill", function(d) { return color(d.name); })
			.style("opacity", 0.7);
	};
	
	_this.updateBizMonthlyGraph = function() {
		if ( curPage.business == 'ads' ) {
			var newData = $.extend(true, [], bizADSMonthlyData);
			var newColors = [];
			var innerColumns = $.extend(true, {}, bizADSMonthlyColumns);
			
			var inactLegends = [];
			$('#bizADSMonthlyLegends li').each(function(i, elm) {
				var isInactive = $(elm).hasClass('inactive');
				if ( !isInactive ) {
					newColors.push( bizADSMonthlyColor[i] );
				} else {
					var lbl = $(elm).find('.lbl').text();
					inactLegends.push(lbl);
					
					if ( i == 0 ) {
						innerColumns.column1.splice(0, 1);
					} else if ( i == 1 ) {
						innerColumns.column2.splice(0, 1);
					} else if ( i == 2 ) {
						innerColumns.column2.splice(1, 1);
					} else if ( i == 3 ) {
						innerColumns.column3.splice(0, 1);
					} else if ( i == 4 ) {
						innerColumns.column3.splice(1, 1);
					}
				}
			});
			
			if ( innerColumns.column1.length == 0 ) {
				delete innerColumns.column1;
			} else if ( innerColumns.column2.length == 0 ) {
				delete innerColumns.column2;
			} else if ( innerColumns.column3.length == 0 ) {
				delete innerColumns.column3;
			}
			
			for ( var i=0; i<newData.length; i++ ) {
				for ( var j=0; j<inactLegends.length; j++ ) {
					delete newData[i][inactLegends[j]];
				}
			}
			
			_this.createBizMonthlyGraph("#bizADSMonthlyGraph", newData, newColors, innerColumns);
		} else {
			var newData = $.extend(true, [], bizMBSMonthlyData);
			var newColors = [];
			var innerColumns = $.extend(true, {}, bizMBSMonthlyColumns);
			
			var inactLegends = [];
			$('#bizMBSMonthlyLegends li').each(function(i, elm) {
				var isInactive = $(elm).hasClass('inactive');
				if ( !isInactive ) {
					newColors.push( bizMBSMonthlyColor[i] );
				} else {
					var lbl = $(elm).find('.lbl').text();
					inactLegends.push(lbl);
					
					if ( i == 0 ) {
						innerColumns.column1.splice(0, 1);
					} else if ( i == 1 ) {
						innerColumns.column1.splice(1, 1);
					} else if ( i == 2 ) {
						innerColumns.column2.splice(0, 1);
					} else if ( i == 3 ) {
						innerColumns.column2.splice(1, 1);
					}
				}
			});
			
			if ( innerColumns.column1.length == 0 ) {
				delete innerColumns.column1;
			} else if ( innerColumns.column2.length == 0 ) {
				delete innerColumns.column2;
			}
			
			for ( var i=0; i<newData.length; i++ ) {
				for ( var j=0; j<inactLegends.length; j++ ) {
					delete newData[i][inactLegends[j]];
				}
			}
			
			_this.createBizMonthlyGraph("#bizMBSMonthlyGraph", newData, newColors, innerColumns);
		}
	};
	
	/** BAR CHARTS END **/
	
		
	_this.bizDataRefresh = function() {
		_this.getBizStackData();
		_this.getBizGroupData();
	};
};
