/**
 * 
 */
package com.streamanalytix.storm.core.bolt;

import java.util.HashMap;
import java.util.Map;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;

import org.apache.commons.logging.Log;

import backtype.storm.Config;
import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Tuple;

import com.streamanalytix.commons.constants.Constants;
import com.streamanalytix.commons.constants.NumberConstants;
import com.streamanalytix.commons.constants.TopologyJSONKeyConstant;
import com.streamanalytix.commons.util.LogUtil;
import com.streamanalytix.core.exception.ApplicationException;
import com.streamanalytix.core.exception.ApplicationRuntimeException;
import com.streamanalytix.core.model.TraceMessage;
import com.streamanalytix.core.tracemessage.TraceMessageConfigConstant;
import com.streamanalytix.storm.core.bolt.helper.AbstractSAXBoltHelper;
import com.streamanalytix.storm.core.bolt.helper.HDFSBoltHelper;
import com.streamanalytix.storm.core.hdfs.HDFSConstants;

/**
 * The Class HDFSBolt.
 * 
 * @author hokam
 */
public class HDFSBolt extends AbstractSAXBolt {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1329419032222514008L;

	/** The Constant LOGGER. */
	private static final Log LOGGER = LogUtil.getLogger(HDFSBolt.class);

	/** The i bolt helper. */
	private AbstractSAXBoltHelper iBoltHelper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.streamanalytix.storm.core.bolt.AbstractSAXBolt#init(java.util.Map,
	 * backtype.storm.task.TopologyContext, backtype.storm.task.OutputCollector)
	 */
	@Override
	public void init(Map stormConf, TopologyContext context,
			OutputCollector collector) {
		LOGGER.info("Enter init method");
		LOGGER.info("Exp key list: " + expKeyList);
		try {
			iBoltHelper = new HDFSBoltHelper();
			iBoltHelper.setTenantId(getTenantId());
			getConfigMap().put(HDFSConstants.TOPOLOGYNAME, topologyName);
			((HDFSBoltHelper) iBoltHelper).setContext(context);
			iBoltHelper.init(getConfigMap());

		} catch (Exception exception) {
			LOGGER.error("Exception in initializing: ", exception.getCause());
			throw new ApplicationRuntimeException(exception);
		}
		LOGGER.info("Exit init method");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.streamanalytix.storm.core.bolt.AbstractSAXBolt#process(backtype.storm
	 * .tuple.Tuple)
	 */
	@Override
	public void process(Tuple tuple) throws ApplicationException {
		LOGGER.info("Enter process method");

		TraceMessage traceMessage = super.getTraceMessage(tuple);
		Map<String, Object> traceMessageMap = new HashMap<String, Object>(); 
		try {
			JSONObject jsnData = null;
			Map<String, Object> configMap = getConfigMap();
			JSONArray hdfsPaths = (JSONArray) JSONValue.parse(String
					.valueOf(configMap.get(HDFSConstants.HDFS_PATHS)));
			if (expKeyList.size() > NumberConstants.ZERO) {
				jsnData = new JSONObject();
				jsnData.put(
						traceMessage.getJsonData().getAsString(
								TraceMessageConfigConstant.SAX_MESSAGE_TYPE),
						traceMessage.getJsonData());
			}

			if (null != udfExecuter && null != hdfsPaths
					&& !hdfsPaths.isEmpty()) {
				for (Object obj : hdfsPaths) {
					JSONObject object = (JSONObject) obj;
					for (String key : expKeyList) {

						
						String path = object.getAsString(key);
						if (path != null) {
							if (expKeyList.contains(key)) {
								traceMessage.getJsonData().put(
										key,
										udfExecuter.execute(topologyName
												+ componentName + key, path,
												jsnData));

							} else {
								traceMessage.getJsonData().put(key, path);
							}
						}
					}
				}

			}
			if (isTickTuple(tuple)) {
				LOGGER.info(" Tick tuple recieved");
				traceMessageMap.put(TraceMessageConfigConstant.TRACE_MESSAGE,
						null);
				iBoltHelper.execute(traceMessageMap);
			} else {
				
				if (null != traceMessage) {
					iBoltHelper.setConfigMap(reloadConfigMap(traceMessage
							.getJsonData()));
					traceMessageMap.put(
							TraceMessageConfigConstant.TRACE_MESSAGE,
							traceMessage);
					iBoltHelper.execute(traceMessageMap);
				}
			}

			if (!isTickTuple(tuple)) {
				emit(tuple, traceMessage);
				ack(tuple);
			}

		} catch (Exception exception) {
			exception.printStackTrace();
			super.errorLogging(getClass().getCanonicalName(), exception,
					traceMessage, tuple);
		}
		LOGGER.info("Exit process method");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.streamanalytix.storm.core.bolt.AbstractSAXBolt#declareOutputFields
	 * (backtype.storm.topology.OutputFieldsDeclarer)
	 */
	@Override
	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		LOGGER.info("Enter declareOutputFields method");
		super.declareOutputFields(declarer);
		LOGGER.info("Exit declareOutputFields method");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.streamanalytix.storm.core.bolt.AbstractSAXBolt#cleanup()
	 */
	@Override
	public void cleanup() {
		super.cleanup();
		LOGGER.info("Running clean up method of HDFSBolt ");
		iBoltHelper.cleanup();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.streamanalytix.storm.core.bolt.AbstractSAXBolt#getComponentConfiguration
	 * ()
	 */
	public Map<String, Object> getComponentConfiguration() {
		// configure how often a tick tuple will be sent to our bolt
		Map<String, Object> conf = super.getComponentConfiguration();
		if (conf == null)
			conf = new Config();
		Boolean isBatchEnable = (null != getConfigMap().get(
				Constants.IS_BATCHENABLE)) ? Boolean
				.parseBoolean(((String) getConfigMap().get(
						Constants.IS_BATCHENABLE)).trim()) : false;
		long tickTupleFrequency = (null != getConfigMap().get(
				Constants.TIME_LIMIT_IN_SECONDS)) ? Long
				.parseLong(((String) getConfigMap().get(
						Constants.TIME_LIMIT_IN_SECONDS)).trim()) : 1;

//		if (isBatchEnable) {
//			LOGGER.info("Setting Tick Tuple: " + tickTupleFrequency);
//			conf.put(Config.TOPOLOGY_TICK_TUPLE_FREQ_SECS, tickTupleFrequency);
//		}
		return conf;
	}

}
