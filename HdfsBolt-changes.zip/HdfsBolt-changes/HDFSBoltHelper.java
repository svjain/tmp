/**
 * 
 */
package com.streamanalytix.storm.core.bolt.helper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

import backtype.storm.task.TopologyContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.streamanalytix.SpecialCharacterConstants;
import com.streamanalytix.bs.message.dto.Message;
import com.streamanalytix.bs.message.dto.MessageGroup;
import com.streamanalytix.bs.metadata.impl.SchemaMetadata;
import com.streamanalytix.bs.util.MapValueLookup;
import com.streamanalytix.commons.constants.ConfigConstants;
import com.streamanalytix.commons.constants.Constants;
import com.streamanalytix.commons.constants.StringConstants;
import com.streamanalytix.commons.util.LogUtil;
import com.streamanalytix.core.exception.ApplicationException;
import com.streamanalytix.core.exception.ApplicationRuntimeException;
import com.streamanalytix.core.model.TraceMessage;
import com.streamanalytix.core.tracemessage.TraceMessageConfigConstant;
import com.streamanalytix.storm.core.hdfs.HDFSConstants;
import com.streamanalytix.storm.core.hdfs.writer.HDFSWriter;

/**
 * The Class HDFSBoltHelper.
 * 
 * @author hokam
 */
public class HDFSBoltHelper extends AbstractSAXBoltHelper {

	/** The service map. */
	private Map<String, Map<String, HDFSWriter>> serviceMap = new HashMap<String, Map<String, HDFSWriter>>();

	/** The hdfs path batch list map. */
	private Map<String, List<String>> hdfsPathBatchListMap = new HashMap<String, List<String>>();

	/** The LOGGER. */
	private static final Log LOGGER = LogUtil.getLogger(HDFSBoltHelper.class);

	/** The object mapper. */
	private static ObjectMapper mapper = new ObjectMapper();

	/** The batch size. */
	private static int batchSize;

	/** The context. */
	private TopologyContext context;

	/** The is batch enable. */
	private static boolean isBatchEnable = false;

	/** The message group map. */
	private Map<String, MessageGroup> messageGroupMap = new HashMap<String, MessageGroup>();

	/** The hdfsPathDetails. */
	private List<Map<String, Map<String, Object>>> hdfsPathDetails;

	/** The hdfsPathDetails. */
	private Map<String, Map<String, Object>> hdfsPathConf;

	/**
	 * The Enum OUTPUTFORMAT.
	 * 
	 * @author hokam
	 */
	enum OUTPUTFORMAT {

		/** The json. */
		JSON,
		/** The Delimited. */
		Delimited
	}

	/**
	 * Gets the HA properties map.
	 * 
	 * @param configMap
	 *            the config map
	 * @return the HA properties map
	 */
	private Map<String, String> getHAPropertiesMap(Map<String, Object> configMap) {

		Map<String, String> hdfsConf = new HashMap<String, String>();
		hdfsConf.put(HDFSConstants.FS_DEFAULT_NAME,
				(String) configMap.get(HDFSConstants.FS_URI));

		boolean isHAEnabled = BooleanUtils.toBoolean(configMap.get(
				HDFSConstants.HADOOP_HA_ENABLED).toString());

		if (isHAEnabled) {
			String nameServiceId = (String) configMap
					.get(ConfigConstants.HADOOP_DFS_NAMESERVICES);
			String namenode1Name = (String) configMap
					.get(ConfigConstants.HADOOP_DFS_NAMENODES1_NAME);
			String namenode2Name = (String) configMap
					.get(ConfigConstants.HADOOP_DFS_NAMENODES2_NAME);
			String namenode1RPCAddress = (String) configMap
					.get(ConfigConstants.HADOOP_DFS_NAMENODES1_RPC_ADDRESS);
			String namenode2RPCAddress = (String) configMap
					.get(ConfigConstants.HADOOP_DFS_NAMENODES2_RPC_ADDRESS);
			String namenodes = namenode1Name + Constants.COMMA_DELIMITER
					+ namenode2Name;

			hdfsConf.put(HDFSConstants.DFS_NAMESERVICES, nameServiceId);
			hdfsConf.put(HDFSConstants.DFS_HA_NAMENODES + HDFSConstants.DOT
					+ nameServiceId, namenodes);
			hdfsConf.put(HDFSConstants.DFS_NAMENODE_RPC_ADDRESS
					+ HDFSConstants.DOT + nameServiceId + HDFSConstants.DOT
					+ namenode1Name, namenode1RPCAddress);
			hdfsConf.put(HDFSConstants.DFS_NAMENODE_RPC_ADDRESS
					+ HDFSConstants.DOT + nameServiceId + HDFSConstants.DOT
					+ namenode2Name, namenode2RPCAddress);
			hdfsConf.put(HDFSConstants.DFS_CLIENT_FAILOVER_PROXY_PROVIDER
					+ HDFSConstants.DOT + nameServiceId,
					HDFSConstants.DFS_HA_CONFIGURED_FAILOVER_PROXY_PROVIDER);
		}
		return hdfsConf;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.streamanalytix.storm.core.bolt.helper.IBoltHelper#init(java.util.Map)
	 */
	@Override
	public void init(Map<String, Object> configMap) {
		LOGGER.info("inside init method: ");
		try {
			// set the hdfs conf
			configMap.put(HDFSConstants.HDFS_CONF_KEY,
					getHAPropertiesMap(configMap));

			// Initialise the service map for the provided hdfs paths.
			if (configMap.containsKey(HDFSConstants.HDFS_PATHS)) {
				initializePathsAndServices(configMap);
			}

			// Get bacth size value.
			batchSize = MapValueLookup.getIntegerValue(configMap,
					HDFSConstants.BATCH_SIZE, batchSize);

			// Get batch enable boolean flag.
			isBatchEnable = MapValueLookup.getBooleanValue(configMap,
					HDFSConstants.IS_BATCH_ENABLE, isBatchEnable);

			LOGGER.info("Batch Size is : " + batchSize);
		} catch (Exception exception) {
			LOGGER.error("Exception occurred while initializing: ", exception);
			throw new ApplicationRuntimeException(exception);
		}
		LOGGER.info("exit init method: ");
	}

	/**
	 * Initialize paths and services.
	 * 
	 * @param configMap
	 *            the config map
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws ApplicationException
	 *             the application exception
	 */
	private void initializePathsAndServices(Map<String, Object> configMap)
			throws IOException, ApplicationException {
		// Get HDFS Path to map string
		String hdfsPathMapString = configMap.get(HDFSConstants.HDFS_PATHS)
				.toString();

		// create object from the json string from the hdfs path
		hdfsPathDetails = mapper.readValue(hdfsPathMapString, List.class);
		hdfsPathConf = new HashMap<String, Map<String, Object>>();
		for (Map hdfsPathConfigMap : hdfsPathDetails) {

			LOGGER.info("inside execute method: with hdfsConfigPath: "
					+ hdfsPathConfigMap);
			hdfsPathConfigMap.putAll(configMap);
			hdfsPathConf.put(hdfsPathConfigMap.get(HDFSConstants.HDFS_PATH)
					.toString(), hdfsPathConfigMap);
			if (!hdfsPathConfigMap.get(HDFSConstants.HDFS_PATH).toString()
					.startsWith("@")) {
				// create the hdfs writer .

				// Get prefix from the configuration map.
				String hdfsFilePrefix = MapValueLookup.get(hdfsPathConfigMap,
						HDFSConstants.HDFS_FILE_PREFIX,
						StringConstants.EMPTY_STRING);

				hdfsPathConfigMap.put(HDFSConstants.HDFS_FILE_PREFIX,
						hdfsFilePrefix + SpecialCharacterConstants.HYPHEN
								+ context.getThisTaskId());

				HDFSWriter service = new HDFSWriter(hdfsPathConfigMap,
						context.getThisTaskIndex());
				Map<String, HDFSWriter> serviceHashMap = new HashMap<String, HDFSWriter>();
				serviceHashMap
						.put(service.getMetadata().getHdfsPath(), service);
				serviceMap.put(service.getMetadata().getHdfsPath(),
						serviceHashMap);
			} else {
				serviceMap.put(hdfsPathConfigMap.get("hdfsPath").toString(),
						new HashMap<String, HDFSWriter>());
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.streamanalytix.storm.core.bolt.helper.IBoltHelper#execute(java.lang
	 * .Object)
	 */
	@Override
	public void execute(Object object) throws ApplicationException {
		LOGGER.info("inside execute method: ");
		LOGGER.info("service Map: " + serviceMap);
		List<String> hdfsPathBatchList = null;
		String dynamicHdfsPath = null;
		// Cast message data to trace message object.
		Map<String, Object> objectMap = (HashMap<String, Object>) object;
		Object obj = objectMap.get(TraceMessageConfigConstant.TRACE_MESSAGE);
		TraceMessage traceMessage = null;
		if (obj != null) {
			traceMessage = (TraceMessage) obj;
			dynamicHdfsPath = traceMessage.getJsonData().getAsString(
					HDFSConstants.HDFS_PATH);
			LOGGER.info("inside execute method: with trace messsage : "
					+ traceMessage);
		} else {
			for (String hdfsPath : serviceMap.keySet()) {
				String pathKeyInServiceMap = hdfsPath;
				String actualHdfsPath = hdfsPath;
				LOGGER.info("hdfs path service key: " + hdfsPath);
				if (hdfsPath.startsWith("@")) {

					actualHdfsPath = dynamicHdfsPath;
					if (serviceMap.get(hdfsPath).get(dynamicHdfsPath) == null) {

						updateServiceMap(hdfsPath, actualHdfsPath, traceMessage);
					}
				}
				LOGGER.info("service Map after: " + serviceMap);
				hdfsPathBatchList = hdfsPathBatchListMap.get(actualHdfsPath);
				HDFSWriter hdfsWriter = serviceMap.get(pathKeyInServiceMap)
						.get(actualHdfsPath);
				if (CollectionUtils.isNotEmpty(hdfsPathBatchList)) {
					try {
						hdfsWriter.writeData(hdfsPathBatchList,
								hdfsWriter.getMessageGroup());
					} catch (IOException exception) {
						LOGGER.error(
								"Exception while processing events in ForceFlush ",
								exception);
						throw new ApplicationException(getClass()
								.getCanonicalName(), exception.getMessage(),
								exception, null);
					}
				}
				hdfsPathBatchList.clear();
			}

		}

		// if trance message is not null.
		if (null != traceMessage) {

			try {
				// Log Message.
				LOGGER.debug("Passing Map to HDFS Writer:"
						+ traceMessage.getJsonData());

				dynamicHdfsPath = traceMessage.getJsonData().getAsString(
						HDFSConstants.HDFS_PATH);

				// Get Object Value.
				Map<String, Object> recordMap = mapper.readValue(traceMessage
						.getJsonData().toString(), Map.class);

				// Tenant ID.
				String tenantId = null;

				// if it is running as multi tenant.
				// Get tenant id.
				tenantId = (String) recordMap.get(Constants.TENANT_ID_KEY);
				// If tenant id is null then throw exception for tenant id
				// is missing.
				if (tenantId == null) {
					throw new ApplicationException(getClass()
							.getCanonicalName(), "Record can't be persisted, "
							+ Constants.TENANT_ID_KEY + " field required.",
							traceMessage.getJsonData());
				}

				// Get Message type
				String messageType = (String) recordMap
						.get(TraceMessageConfigConstant.SAX_MESSAGE_TYPE);

				// if message type is empty
				if (StringUtils.isEmpty(messageType)) {
					throw new ApplicationException(getClass()
							.getCanonicalName(), "Record can't be persisted, "
							+ TraceMessageConfigConstant.SAX_MESSAGE_TYPE
							+ " field required.", traceMessage.getJsonData());
				}

				String messageGroupKey = tenantId + "-" + messageType;
				MessageGroup messageGroup = messageGroupMap
						.get(messageGroupKey);

				if (messageGroup == null) {
					// Getting message metadata information.
					Message messageBean = SchemaMetadata.getInstance()
							.getMessage(tenantId, messageType);
					messageGroup = messageBean.getMessageGroup();
					messageGroupMap.put(messageGroupKey, messageGroup);
				}

				// iterate over the HDFS path services to write the HDFS data.
				for (String hdfsPath : serviceMap.keySet()) {
					String pathKeyInServiceMap = hdfsPath;
					String actualHdfsPath = hdfsPath;
					LOGGER.info("hdfs path service key: " + hdfsPath);
					if (hdfsPath.startsWith("@")) {

						actualHdfsPath = dynamicHdfsPath;
						if (serviceMap.get(hdfsPath).get(dynamicHdfsPath) == null) {

							updateServiceMap(hdfsPath, actualHdfsPath,
									traceMessage);
						}
					}
					// Getting the hdfs path batch list.
					hdfsPathBatchList = hdfsPathBatchListMap.get(actualHdfsPath);

					// if hdsf Path batch list is null then assign it to empty
					// list
					if (hdfsPathBatchList == null) {
						hdfsPathBatchList = new ArrayList<String>();
					}

					// HDFS Writer.
					HDFSWriter hdfsWriter = serviceMap.get(pathKeyInServiceMap)
							.get(actualHdfsPath);
					hdfsWriter.setMessageGroup(messageGroup);

					// Adding the data to batch list.
					hdfsPathBatchList.add(getOuputFormatString(recordMap,
							hdfsWriter));

					// set the batch list in map.
					hdfsPathBatchListMap.put(actualHdfsPath, hdfsPathBatchList);

					// Create a batch list if enabled and then write.
					if (isBatchEnable) {
						if (hdfsPathBatchList.size() >= batchSize) {
							hdfsWriter.writeData(hdfsPathBatchList,
									messageGroup);
							hdfsPathBatchList.clear();
						}
					} else {
						hdfsWriter.writeData(hdfsPathBatchList, messageGroup);
						hdfsPathBatchList.clear();
					}
				}

				LOGGER.info("exit execute method: ");
			} catch (Exception exception) {
				LOGGER.error("Exception while processing events", exception);
				throw new ApplicationException(getClass().getCanonicalName(),
						exception.getMessage(), exception,
						traceMessage.getJsonData());
			}
		}
	}

	/**
	 * Method to get the hdfs data based on hdfs path and fields.
	 * 
	 * @param recordMap
	 *            the record map
	 * @param hdfsWriter
	 *            the hdfs writer
	 * @return the delimited output
	 */
	private String getDelimitedOutput(Map<String, Object> recordMap,
			HDFSWriter hdfsWriter) {
		// List of values
		List<String> values = new ArrayList<String>();

		// iterate over the fields.
		for (String field : hdfsWriter.getMetadata().getFields()) {
			// Get value from map.
			Object value = recordMap.get(field.trim());
			// if value is null then add an empty value in delimited string.
			if (value != null) {
				values.add(value.toString());
			} else {
				values.add("");
			}
		}

		// Returning value by joining with the delimiter value.
		return StringUtils.join(values, hdfsWriter.getMetadata()
				.getFieldDelimiter());
	}

	/**
	 * Method to get output format string.
	 * 
	 * @param recordMap
	 *            the record map
	 * @param hdfsWriter
	 *            the hdfs writer
	 * @return String * @throws Exception
	 * @throws Exception
	 *             the exception
	 */
	public String getOuputFormatString(Map<String, Object> recordMap,
			HDFSWriter hdfsWriter) throws Exception {
		// If output type is JSON then.
		if (OUTPUTFORMAT.valueOf(hdfsWriter.getMetadata().getOutputType())
				.equals(OUTPUTFORMAT.JSON)) {
			// return json data.
			return getJSONOutput(recordMap, hdfsWriter);
		} else {
			// return delimited data.
			return getDelimitedOutput(recordMap, hdfsWriter);
		}
	}

	/**
	 * Gets the JSON output.
	 * 
	 * @param recordMap
	 *            the record map
	 * @param hdfsWriter
	 *            the hdfs writer
	 * @return String * @throws Exception
	 * @throws Exception
	 *             the exception
	 */
	public String getJSONOutput(Map<String, Object> recordMap,
			HDFSWriter hdfsWriter) throws Exception {

		// Get list of fiels for the hdfs path
		List<String> fields = hdfsWriter.getMetadata().getFields();

		// List of values
		Map<String, String> json = new HashMap<String, String>();

		// iterate over the fields
		for (String field : fields) {
			// Get value from map.
			Object value = recordMap.get(field.trim());
			// if value is null then add an empty value in delimited string.
			if (value != null) {
				json.put(field.trim(), value.toString());
			}
		}

		return mapper.writeValueAsString(json);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.streamanalytix.storm.core.bolt.helper.IBoltHelper#cleanup()
	 */
	@Override
	public void cleanup() {
		LOGGER.info("Cleaning up the HDFS resources.");
		// iterate over the HDFS path services to write the HDFS data.
		for (String hdfsPath : serviceMap.keySet()) {
			for (String actualHdfsPath : serviceMap.get(hdfsPath).keySet()) {
				HDFSWriter writer = serviceMap.get(hdfsPath)
						.get(actualHdfsPath);
				try {
					writer.closeOutputFile();
				} catch (ApplicationException e) {
					LOGGER.error(
							"Failed to close output file. " + e.getMessage(), e);
				}
			}
		}
	}

	private void updateServiceMap(String hdfsPath, String actualHdfsPath,
			TraceMessage traceMessage) throws ApplicationException {
		LOGGER.info("Updating writer for the first time: ");
		Map<String, Object> hdfsPathConfigMap = hdfsPathConf.get(hdfsPath);
		hdfsPathConfigMap.put(HDFSConstants.HDFS_PATH, actualHdfsPath);
		String hdfsFilePrefix = MapValueLookup.get(hdfsPathConfigMap,
				HDFSConstants.HDFS_FILE_PREFIX, StringConstants.EMPTY_STRING);

		hdfsPathConfigMap.put(HDFSConstants.HDFS_FILE_PREFIX, hdfsFilePrefix
				+ SpecialCharacterConstants.HYPHEN + context.getThisTaskId());

		HDFSWriter service = new HDFSWriter(hdfsPathConfigMap,
				context.getThisTaskIndex());
		serviceMap.get(hdfsPath).put(actualHdfsPath, service);

	}

	/** @return the context */
	public TopologyContext getContext() {
		return context;
	}

	/**
	 * @param context
	 *            the context to set
	 */
	public void setContext(TopologyContext context) {
		this.context = context;
	}
}