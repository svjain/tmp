package com.impetus.fm.parser;

import java.util.Map;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;

import net.minidev.json.JSONObject;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;

public class FraudFields {
	
    /** The Constant LOGGER. */
    private static final Log LOGGER = LogFactory.getLog(FraudFields.class);
	private String messageSubtype;
	
	public JSONObject populateMap(Document xmlDocument,XPath xPath, Map<String, String> configMap, String xml) throws XPathExpressionException{
        LOGGER.info("Enter parse method: FraudFields.populateMap()" );
		JSONObject jsonData = new JSONObject();
		
		for (Map.Entry<String, String> entry : configMap.entrySet()) {
			String key = entry.getKey();
			
			if (StringUtils.startsWith(key, Constants.KEY_PREFIX)) {
				if (!StringUtils.equalsIgnoreCase(entry.getKey(),Constants.RAW_XML)) {
					jsonData.put( key.substring(0, Constants.RAW_XML.length()), getValueForExp(xmlDocument, xPath, entry.getValue()));
				} else if (StringUtils.equalsIgnoreCase(key, Constants.RAW_XML) && StringUtils.equalsIgnoreCase(entry.getValue(), Constants.RAW_XML_IND)) {
					jsonData.put(key.substring(0, Constants.RAW_XML.length()), xml);
				}
			}
		}// End of for loop
		
		LOGGER.info("Exit parse method: FraudFields.populateMap()" );
		return jsonData;
	}
	
	public static String getValueForExp(Document xmlDocument, XPath xPath, String expression) throws XPathExpressionException{
    	return xPath.compile(expression).evaluate(xmlDocument);
    }
	
	public String getMessageSubtype() {
		return messageSubtype;
	}


	public void setMessageSubtype(String messageSubtype) {
		this.messageSubtype = messageSubtype;
	}
}