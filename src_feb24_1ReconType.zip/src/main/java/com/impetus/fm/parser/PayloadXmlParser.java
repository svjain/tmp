/*
 * 
 */
package com.impetus.fm.parser;

import java.io.File;
import java.io.FileInputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.fasterxml.jackson.xml.XmlMapper;
import com.streamanalytix.framework.api.storm.parser.Parser;

/** The Class SampleXmlParser is a parser class which is parsing XML Data into JSON Data. */
public class PayloadXmlParser implements Parser {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 5149243120057147354L;

    /** The Constant LOGGER. */
    private static final Log LOGGER = LogFactory.getLog(PayloadXmlParser.class);

    /** The xml mapper. */
    private transient XmlMapper xmlMapper;

    /** The object mapper. */
    private transient ObjectMapper objectMapper;
    
    public static File file;
    /*
     * (non-Javadoc)
     * @see com.streamanalytix.framework.api.BaseComponent#init(java.util.Map)
     */
    @SuppressWarnings("rawtypes")
    public void init(Map configMap) {
        xmlMapper = new XmlMapper();
        objectMapper = new ObjectMapper();
    }
    
    public JSONObject parse(byte[] message) {
    	
        LOGGER.info("Enter parse method: PayloadParsing" );

        JSONObject json = new JSONObject();
        try {

            String xml = new String(message);
            
            //System.out.println("Payload xml = " + xml);
            DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            
            DocumentBuilder builder =  builderFactory.newDocumentBuilder();
             
            Document xmlDocument = builder.parse(new InputSource( new StringReader( xml ) ) );
            
            XPath xPath =  XPathFactory.newInstance().newXPath();
 
            PayloadFields p = new PayloadFields();
            json = p.populateMap(xmlDocument, xPath, xml);
        } catch (Exception e) {
            LOGGER.error("Exception while parsing xml to json: ", e);
            e.printStackTrace();
        }
        LOGGER.info("Exit parse method: PayloadParser");
        return json;

    }
   
    
    /** This method is parsing the data from xml to list of json.
     * 
     * @param message
     *            the message is the xml data in bytes
     * @return the list */
    public List<JSONObject> parseToArray(byte[] message) {
        LOGGER.info("Enter parseToArray method:");

        JSONArray jsonArray = null;
        try {

            String xml = new String(message);
            List<String> entries = xmlMapper.readValue(xml, List.class);
            String json = objectMapper.writeValueAsString(entries);
            jsonArray = (JSONArray) JSONValue.parse(json);

        } catch (Exception e) {
            LOGGER.error("Exception while parsing xml to json array: ", e);
        }

        List<JSONObject> jsonDataList = new ArrayList<JSONObject>();
        if (null != jsonArray && jsonArray.size() != 0) {
            for (int i = 0; i < jsonArray.size(); i++) {
                jsonDataList.add((JSONObject) jsonArray.get(i));
            }
        }
        LOGGER.info("Exit parseToArray method:");
        return jsonDataList;
    }

    /*
     * (non-Javadoc)
     * @see com.streamanalytix.framework.api.BaseComponent#cleanup()
     */

    public void cleanup() {
    }
    
    
    public static void main(String[] args) {
        FileInputStream fileInputStream = null;

        //file = new File("/home/impadmin/Desktop/Fannie Mae/XMLS/MBS_TO_EDI.xml");
        file = new File("D:\\work_fm\\logs\\ads_edi_pool1.xml");
        byte[] bFile = new byte[(int) file.length()];

        try {
            // convert file into array of bytes
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bFile);
            fileInputStream.close();

            PayloadXmlParser parser = new PayloadXmlParser();
            parser.init(null);
            JSONObject jsonObject = parser.parse(bFile);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static String getValueForExp(Document xmlDocument, XPath xPath, String expression) throws XPathExpressionException{
    	return xPath.compile(expression).evaluate(xmlDocument);
    }
}