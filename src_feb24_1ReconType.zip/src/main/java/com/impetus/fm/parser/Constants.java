package com.impetus.fm.parser;

import java.util.HashMap;
import java.util.Map;

public class Constants {
	// Constants for TestXml: START
	public static String RAW_XML = "rawXML";
	public static String RAW_XML_IND = "Y";
	public static String SCHEMA = "schema";
	// Constants for TestXml: END 
	
	public static String POOL_COUNT = "PoolCount";
	public static String LOAN_COUNT = "LoanCount";
	public static String EVENT_TYPE = "EventType";
	
	public static String MESSAGE_FORMAT = "MessgeFormat";
	
	public static String PAYLOAD_TIME = "payloadTime";
	public static String COMMON_NAME = "CommonName";
	public static String ENTITY_TYPE = "EntityType";
	public static String HOUR_OF_DAY = "HourOfDay";
	public static String DAY_OF_MONTH = "DayOfMonth";
	public static String MESSAGE_ID = "MessageID";
	public static String RAW_MESSAGE_PAYLOAD = "RawMessagePayload";
	public static String PAYLOAD_COUNT = "PayLoaDCount";
	public static String MESSAGE_COUNT = "messageCount";
	public static String MESSAGE_SUBTYPE = "MessageSubtype";
	public static String HOUR_WO_DATE = "HourWODate";
	
	public static String PAYLOAD_TYPE_MBS_TO_EDI = "MBS2EDI";
	public static String PAYLOAD_TYPE_ADS_TO_EDI = "ADS2EDI";
	
	public static String[] MBS_EVENT_TYPES = {"ISSN.POOL_SHELF_OPND_DACT","ISSN.POOL_SHELF_REOPENED_DACT","ISSN.POOL_SHELF_RECLOSED_DACT","ISSN.POOL_CLSD_DACT",
											"ISSN.POOL_REOPENED_RECLSD_DACT","ISSN.POOL_SHELF_CLSD_DACT", "ISSN.POOL_CLPSD_DACT", "CMMPROTOTYPE"};
	
	public static String[] MBS_ENTITY_TYPES = {"POOL", "PPC", "CMMPILOT_MBSTOEDI_EVENT1", "CMMPILOT_MBSTOEDI_EVENT2", "CMMPILOT_MBSTOEDI_EVENT3"};
	
	private static String[] ADS_EVENT_TYPES = {"ACQUISITION","CMMPROTOTYPE"};
	
	private static String[] ADS_ENTITY_TYPES = {"MBS","CASH", "CMMPILOT_ADSTOEDI_CASH", "CMMPILOT_ADSTOEDI_POOL", "POOL"};
	
	public static Map<String, String> TYPE_LOOKUP = new HashMap<String,String>(); //key will be entity_eventType
	
	static{
		for(String event : MBS_EVENT_TYPES){
			for(String entity : MBS_ENTITY_TYPES){
				TYPE_LOOKUP.put((entity + "_" + event).toUpperCase(), PAYLOAD_TYPE_MBS_TO_EDI );
			}
		}
		
		for(String entity : ADS_ENTITY_TYPES){
			for(String event : ADS_EVENT_TYPES){
				TYPE_LOOKUP.put((entity + "_" + event).toUpperCase(), PAYLOAD_TYPE_ADS_TO_EDI );
			}
		}
	}
	
	public static boolean isEventMBSToEDI(String key){
		return PAYLOAD_TYPE_MBS_TO_EDI.equals(TYPE_LOOKUP.get(key.toUpperCase())) ? true : false;
	}
	
	public static boolean isEventADSToEDI(String key){
		return PAYLOAD_TYPE_ADS_TO_EDI.equals(TYPE_LOOKUP.get(key.toUpperCase())) ? true : false;
	}
	
	public static String PAYLOAD_PARSER = "payloadParser";
	
	public enum EntityType{
		MBS("MBS"),
		
		CASH("CASH"),
		
		CMMPILOT_ADSTOEDI_CASH("CMMPilot_ADSToEDI_CASH"),
		
		CMMPILOT_ADSTOEDI_POOL("CMMPilot_ADSToEDI_POOL"),
		
		POOL("POOL");

		private String entityType;
		
		private EntityType(String entityType){
			this.entityType = entityType;
		}

		public String getEntityType() {
			return entityType;
		}
	}
	
	public enum EventType{
		ACQUISITION("Acquisition"),
		
		CMMPROTOTYPE("CMMPrototype");
		
		private String eventType;
		
		private EventType(String eventType){
			this.eventType = eventType;
		}

		public String getEventType() {
			return eventType;
		}
	}
	
	public static final String KEY_PREFIX = "payload_";
	
	public interface XPath{
		String MBS_POOL_LOAN_COUNT = "//DEAL_SETS/MAJOR_POOL_DETAIL/POOL_DETAIL/MBSPoolLoanCount";
		
		String MBS_POOL_LOAN_COUNT_SUM = "sum(//DEAL_SETS/DEAL_SET/POOL/POOL_DETAIL/MBSPoolLoanCount/text())";
		
		//String MBS_POOL_LOAN_COUNT_SUM = "sum(/Envelope/Body/payload/DEAL_SETS/DEAL_SET/DEALS/DEAL/LOAN/text())"; // Sent by Saurabh
		
		String ENTITY_TYPE = "/Envelope/Header/metadata/payloadIdentifier/entityType";
		
		String EVENT_TYPE = "/Envelope/Header/metadata/payloadIdentifier/eventType";
		
		//String MAJOR_POOL_DETAIL = "/Envelope/Body/DEAL_SETS/MAJOR_POOL_DETAIL";
		
		String MAJOR_POOL_DETAIL = "//DEAL_SETS/MAJOR_POOL_DETAIL"; // Sent by Saurabh
		
		//String POOL_COUNT = "count(/Envelope/Body/DEAL_SETS/DEAL_SET/POOL)";
		
		String POOL_COUNT = "count(//DEAL_SETS/DEAL_SET/POOL)"; // Sent by Saurabh
		
		String MESSAGE_ID = "/Envelope/Header/metadata/transaction/messageID";
		
		String TIMESTAMP = "/Envelope/Header/metadata/transaction/timestamp";
	}
	
	public interface Sign{
		String UNDER_SCORE = "_";
	}
	
	public static final String HTTP_URL = "httpUrl";
	
	public static final String BUSINESS_RECON_ENTITY_CMMPILOT_MBSTOEDI_EVENT3 = "CMMPILOT_MBSTOEDI_EVENT3";
	
	public static final String BUSINESS_RECON_EVENT_CMMPILOT_MBSTOEDI_EVENT3_CMMPROTOTYPE = "CMMPROTOTYPE";
	
	public static final String RECON_TYPE = "ReconType";
	
	public static final String RECON_TIMESTAMP = "ReconTimestamp";
	
	public static final String RECON_TYPE_LDNG_TO_ADS = "LDNG2ADS";
	
	public static final String RECON_TYPE_ADS_TO_EDI = "ADS2EDI";
	
	public static final String RECON_TYPE_BUSINESS = "Business";
	
	public static final String RECON_TYPE_PAYLOAD = "Payload";
}
