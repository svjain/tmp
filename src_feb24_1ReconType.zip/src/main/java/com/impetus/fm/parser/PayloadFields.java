package com.impetus.fm.parser;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;

import net.minidev.json.JSONObject;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;

public class PayloadFields {

	private static final Log LOGGER = LogFactory.getLog(PayloadFields.class);

	private Integer poolCount;
	private Integer loanCount;
	private String eventType;
	private String entityType;
	private String hourOfDay;
	private String messageId;
	private String rawMessagePayload;
	private String messageSubtype;
	private Integer hourWODate;
	private String commonName;
	private String messageFormat;

	public JSONObject populateMap(Document xmlDocument, XPath xPath, String xml)
			throws XPathExpressionException {
		calculateFields(xmlDocument, xPath);
		JSONObject jsonData = new JSONObject();
		
		jsonData.put(Constants.RECON_TYPE, Constants.RECON_TYPE_PAYLOAD);
		
		if(Constants.BUSINESS_RECON_ENTITY_CMMPILOT_MBSTOEDI_EVENT3.equalsIgnoreCase(this.getEntityType())){
			jsonData.put(Constants.RECON_TYPE, Constants.RECON_TYPE_ADS_TO_EDI);
			
			if(Constants.BUSINESS_RECON_EVENT_CMMPILOT_MBSTOEDI_EVENT3_CMMPROTOTYPE.equalsIgnoreCase(this.getEventType())){
				jsonData.put(Constants.RECON_TYPE, Constants.RECON_TYPE_LDNG_TO_ADS);
			}
			
			return jsonData;
		}
		
		jsonData.put(Constants.RECON_TYPE, Constants.RECON_TYPE_PAYLOAD);

		jsonData.put(Constants.POOL_COUNT, getPoolCount());
		jsonData.put(Constants.LOAN_COUNT, getLoanCount());

		jsonData.put(Constants.PAYLOAD_COUNT, 1);
		jsonData.put(Constants.MESSAGE_COUNT, 1);

		jsonData.put(Constants.EVENT_TYPE, this.getEventType());
		jsonData.put(Constants.ENTITY_TYPE, this.getEntityType());

		jsonData.put(Constants.MESSAGE_FORMAT, this.getMessageFormat());

		jsonData.put(Constants.PAYLOAD_TIME, Calendar.getInstance()
				.getTimeInMillis());
		jsonData.put(Constants.COMMON_NAME, this.getCommonName());

		jsonData.put(
				Constants.HOUR_OF_DAY,
				getHrOFDay(getValueForExp(xmlDocument, xPath,
						Constants.XPath.TIMESTAMP)));
		jsonData.put(Constants.MESSAGE_ID,
				getValueForExp(xmlDocument, xPath, Constants.XPath.MESSAGE_ID));
		jsonData.put(Constants.MESSAGE_SUBTYPE, getMessageSubtype());
		jsonData.put(
				Constants.DAY_OF_MONTH,
				getDayWODate(getValueForExp(xmlDocument, xPath,
						Constants.XPath.TIMESTAMP)));
		jsonData.put(Constants.RAW_MESSAGE_PAYLOAD, xml);
		jsonData.put(
				Constants.HOUR_WO_DATE,
				getHrWODate(getValueForExp(xmlDocument, xPath,
						Constants.XPath.TIMESTAMP)));
		return jsonData;
	}

	private void calculateFields(Document xmlDocument, XPath xPath) {
		boolean majorPoolDetail = false;
		boolean poolPresent = false;
		boolean loanPresent = false;
		Integer poolCount = 0;
		Integer loanCount = 0;

		try {
			this.setEntityType(getValueForExp(xmlDocument, xPath,
					Constants.XPath.ENTITY_TYPE));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			this.setEventType(getValueForExp(xmlDocument, xPath,
					Constants.XPath.EVENT_TYPE));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(Constants.BUSINESS_RECON_ENTITY_CMMPILOT_MBSTOEDI_EVENT3.equalsIgnoreCase(this.getEntityType())){
			return;
		}

		try {
			String majorPoolExists = getValueForExp(xmlDocument, xPath,
					Constants.XPath.MAJOR_POOL_DETAIL);
			if (!StringUtils.isBlank(majorPoolExists)) {
				majorPoolDetail = true;
			} else {
				majorPoolDetail = false;
			}
		} catch (XPathExpressionException e) {
			e.printStackTrace();
			majorPoolDetail = false;
		}

		try {
			String val = getValueForExp(xmlDocument, xPath,
					Constants.XPath.POOL_COUNT);
			if (val != null) {
				poolCount = Integer.parseInt(val);
				poolPresent = poolCount > 0;
			}
		} catch (XPathExpressionException e) {
			e.printStackTrace();
			poolCount = 0;
			poolPresent = false;
		}

		String key = this.getEntityType() + Constants.Sign.UNDER_SCORE
				+ this.getEventType();
		System.out.println("Common Name Key:- " + key);

		this.setCommonName(Constants.TYPE_LOOKUP.get(!StringUtils.isEmpty(key) ? key
				.toUpperCase() : key));

		this.setMessageFormat("ECF");

		// if
		// ((Constants.EventType.ACQUISITION.getEventType().equalsIgnoreCase(this.getEventType()))
		// ||
		// (Constants.EventType.CMMPROTOTYPE.getEventType().equalsIgnoreCase(this.getEventType())))
		// {
		if (Constants.isEventADSToEDI(key)) {
			this.setMessageFormat("CLDF");

			if ((Constants.EntityType.MBS.getEntityType().equalsIgnoreCase(this
					.getEntityType()))
					|| (Constants.EntityType.CMMPILOT_ADSTOEDI_POOL
							.getEntityType().equalsIgnoreCase(this
							.getEntityType()))) {
				if (majorPoolDetail) {
					this.setMessageSubtype("MAJORPOOL");

					try {
						String val = getValueForExp(xmlDocument, xPath,
								Constants.XPath.MBS_POOL_LOAN_COUNT);
						if (!StringUtils.isBlank(val)) {
							loanCount = Integer.parseInt(val);
							loanPresent = loanCount > 0;
						} else {
							loanCount = 0;
							loanPresent = false;
						}
					} catch (XPathExpressionException e) {
						loanCount = 0;
						loanPresent = false;
					} catch (NumberFormatException ne) {
						ne.printStackTrace();
						loanCount = 0;
						loanPresent = false;
					}
				} else {
					this.setMessageSubtype("POOL");

					try {
						String val = getValueForExp(xmlDocument, xPath,
								Constants.XPath.MBS_POOL_LOAN_COUNT_SUM);
						if (!StringUtils.isBlank(val)) {
							loanCount = Integer.parseInt(val);
							loanPresent = loanCount > 0;
						} else {
							loanCount = 0;
							loanPresent = false;
						}
					} catch (XPathExpressionException e) {
						loanCount = 0;
						loanPresent = false;
					} catch (NumberFormatException ne) {
						ne.printStackTrace();
						loanCount = 0;
						loanPresent = false;
					}
				}
			} else if ((Constants.EntityType.CASH.getEntityType()
					.equalsIgnoreCase(this.getEntityType()))
					|| (Constants.EntityType.CMMPILOT_ADSTOEDI_CASH
							.getEntityType().equalsIgnoreCase(this
							.getEntityType()))) {
				this.setMessageSubtype("LOAN");

				if (!poolPresent) {
					poolCount = 0;
					loanCount = 1;
				}
			}
		} else if (Constants.isEventMBSToEDI(key)) {
			// this.setMessageSubtype("MAJORPOOL");

			poolCount = 1;
			loanCount = 0;
		} else {
			LOGGER.info("Key [" + key + "] not found in Map");
		}

		this.setLoanCount(loanCount);
		this.setPoolCount(poolCount);
	}

	public static String getValueForExp(Document xmlDocument, XPath xPath,
			String expression) throws XPathExpressionException {
		return xPath.compile(expression).evaluate(xmlDocument);
	}

	public Integer getPoolCount() {
		return poolCount;
	}

	public void setPoolCount(Integer poolCount) {
		this.poolCount = poolCount;
	}

	public Integer getLoanCount() {
		return loanCount;
	}

	public void setLoanCount(Integer loanCount) {
		this.loanCount = loanCount;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	/*
	 * public String getHourOfDay(String timestampVal) {
	 * if(StringUtils.isEmpty(timestampVal) ||
	 * StringUtils.isBlank(timestampVal)){ return null; }
	 * 
	 * DateTimeFormatter fmt =
	 * DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ"); DateTime
	 * jodatime = fmt.parseDateTime(timestampVal);
	 * 
	 * DateTimeFormatter dtfOut = DateTimeFormat.forPattern("yyyyMMddHH");
	 * dtfOut = dtfOut.withZone(jodatime.getZone());
	 * 
	 * //System.out.println(dtfOut.print(jodatime));
	 * 
	 * return dtfOut.print(jodatime); }
	 */

	public void setHourOfDay(String hourOfDay) {
		this.hourOfDay = hourOfDay;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getRawMessagePayload() {
		return rawMessagePayload;
	}

	public void setRawMessagePayload(String rawMessagePayload) {
		this.rawMessagePayload = rawMessagePayload;
	}

	public String getMessageSubtype() {
		return messageSubtype;
	}

	public void setMessageSubtype(String messageSubtype) {
		this.messageSubtype = messageSubtype;
	}

	/*
	 * public Integer getHourWODate(String timestampVal) {
	 * if(StringUtils.isEmpty(timestampVal) ||
	 * StringUtils.isBlank(timestampVal)){ return null; }
	 * 
	 * DateTimeFormatter fmt =
	 * DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ"); DateTime
	 * jodatime = fmt.parseDateTime(timestampVal);
	 * 
	 * DateTimeFormatter dtfOut = DateTimeFormat.forPattern("HH"); dtfOut =
	 * dtfOut.withZone(jodatime.getZone());
	 * 
	 * //System.out.println("HourWODate:- " +
	 * Integer.parseInt(dtfOut.print(jodatime))); return
	 * Integer.parseInt(dtfOut.print(jodatime)); }
	 */

	private Integer getHrWODate(String timestamp_str) {
		if (!StringUtils.isBlank(timestamp_str)) {
			String timestamp = normalizeDateFormat(timestamp_str);
			String[] temp1 = timestamp.split("T");

			String hour = temp1[1].substring(0, temp1[1].indexOf(":"));
			if (!StringUtils.isBlank(hour) && hour.contains(":")) {
				hour = hour.replace(":", "");
			}

			return Integer.valueOf(hour);
		}

		return null;
	}

	// 02/19/2016 17:10:47:317
	// 2016-02-11T17:42:06.816-05:00
	private Integer getDayWODate(String timestamp_str) {
		if (!StringUtils.isBlank(timestamp_str)) {
			String timestamp = normalizeDateFormat(timestamp_str);

			if (!timestamp.contains("T")) {

			} else {

				String[] temp1 = timestamp.split("T");

				String day = temp1[0].split("-")[2];

				return Integer.valueOf(day);
			}
		}

		return null;
	}

	private String getHrOFDay(String timestamp_str) {
		if (!StringUtils.isBlank(timestamp_str)) {
			try {
				String timestamp = normalizeDateFormat(timestamp_str);
				String[] temp1 = timestamp.split("T");

				String date = temp1[0];

				SimpleDateFormat dateform = new SimpleDateFormat();

				dateform.applyPattern("yyyy-MM-dd");

				Date asdas = dateform.parse(date);

				dateform.applyPattern("yyyyMMdd");

				String formattedDate = dateform.format(asdas);

				formattedDate += temp1[1].substring(0, 2);
				System.out.println("formattedDate:- " + formattedDate);

				return formattedDate;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return null;
	}

	/*
	 * private Integer getHrWODate(String timestamp){ try{ String temp = null;
	 * boolean minus = false; boolean plus = false;
	 * 
	 * if(!StringUtils.isBlank(timestamp)){ if(timestamp.lastIndexOf('+') > -1){
	 * temp = timestamp.substring(timestamp.lastIndexOf('+'),
	 * timestamp.length()); timestamp = timestamp.substring(0,
	 * timestamp.lastIndexOf('+'));
	 * 
	 * plus = true; }else{ temp =
	 * timestamp.substring(timestamp.lastIndexOf('-'), timestamp.length());
	 * timestamp = timestamp.substring(0, timestamp.lastIndexOf('-'));
	 * 
	 * minus = true; } }
	 * 
	 * TimeZone gmtTime = TimeZone.getTimeZone("GMT"); Calendar calendar =
	 * Calendar.getInstance(TimeZone.getTimeZone("GMT")); DateFormat gmtFormat =
	 * new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
	 * 
	 * gmtFormat.setTimeZone(gmtTime); Date date = gmtFormat.parse(timestamp);
	 * System.out.println(date);
	 * 
	 * calendar.setTime(date);
	 * 
	 * if(minus){ try{ temp = temp.replace("-", ""); String[] hrsMins =
	 * temp.split(":");
	 * 
	 * int minusHrs = Integer.valueOf(hrsMins[0]); int minusMins =
	 * Integer.valueOf(hrsMins[1]);
	 * 
	 * long timeInMs = (calendar.getTimeInMillis() - ((1000 * 60 * 60 *
	 * minusHrs) + (1000 * 60 * 60 * minusMins)));
	 * calendar.setTimeInMillis(timeInMs); }catch(Exception e){
	 * e.printStackTrace(); } }else if(plus){ try{ temp = temp.replace("-", "");
	 * String[] hrsMins = temp.split(":");
	 * 
	 * double minusHrs = Double.valueOf(hrsMins[0]); double minusMins =
	 * Double.valueOf(hrsMins[1]);
	 * 
	 * long timeInMs = (long)(calendar.getTimeInMillis() + (1000 * 60 * 60 *
	 * minusHrs) + (1000 * 60 * 60 * minusMins));
	 * calendar.setTimeInMillis(timeInMs); }catch(Exception e){
	 * e.printStackTrace(); } }
	 * 
	 * System.out.println("Formatted Time:- " + calendar.getTime());
	 * 
	 * SimpleDateFormat dateform = new SimpleDateFormat("HH");
	 * System.out.println("Formatted Hour:- " +
	 * dateform.format(calendar.getTime()));
	 * 
	 * return Integer.valueOf(dateform.format(calendar.getTime()));
	 * }catch(Exception e){ e.printStackTrace(); }
	 * 
	 * return null; }
	 */

	/*
	 * private String getHrOFDay(String timestamp){ try{ String temp = null;
	 * boolean minus = false; boolean plus = false;
	 * 
	 * if(!StringUtils.isBlank(timestamp)){ if(timestamp.lastIndexOf('+') > -1){
	 * temp = timestamp.substring(timestamp.lastIndexOf('+'),
	 * timestamp.length()); timestamp = timestamp.substring(0,
	 * timestamp.lastIndexOf('+'));
	 * 
	 * plus = true; }else{ temp =
	 * timestamp.substring(timestamp.lastIndexOf('-'), timestamp.length());
	 * timestamp = timestamp.substring(0, timestamp.lastIndexOf('-'));
	 * 
	 * minus = true; } }
	 * 
	 * TimeZone gmtTime = TimeZone.getTimeZone("GMT"); Calendar calendar =
	 * Calendar.getInstance(TimeZone.getTimeZone("GMT")); DateFormat gmtFormat =
	 * new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
	 * 
	 * gmtFormat.setTimeZone(gmtTime); Date date = gmtFormat.parse(timestamp);
	 * System.out.println(date);
	 * 
	 * calendar.setTime(date);
	 * 
	 * if(minus){ try{ temp = temp.replace("-", ""); String[] hrsMins =
	 * temp.split(":");
	 * 
	 * int minusHrs = Integer.valueOf(hrsMins[0]); int minusMins =
	 * Integer.valueOf(hrsMins[1]);
	 * 
	 * long timeInMs = (calendar.getTimeInMillis() - ((1000 * 60 * 60 *
	 * minusHrs) + (1000 * 60 * 60 * minusMins)));
	 * calendar.setTimeInMillis(timeInMs); }catch(Exception e){
	 * e.printStackTrace(); } }else if(plus){ try{ temp = temp.replace("-", "");
	 * String[] hrsMins = temp.split(":");
	 * 
	 * double minusHrs = Double.valueOf(hrsMins[0]); double minusMins =
	 * Double.valueOf(hrsMins[1]);
	 * 
	 * long timeInMs = (long)(calendar.getTimeInMillis() + (1000 * 60 * 60 *
	 * minusHrs) + (1000 * 60 * 60 * minusMins));
	 * calendar.setTimeInMillis(timeInMs); }catch(Exception e){
	 * e.printStackTrace(); } }
	 * 
	 * System.out.println("Formatted Time:- " + calendar.getTime());
	 * 
	 * SimpleDateFormat dateform = new SimpleDateFormat("yyyyMMddHH");
	 * System.out.println(dateform.format(calendar.getTime()));
	 * 
	 * return dateform.format(calendar.getTime()); }catch(Exception e){
	 * e.printStackTrace(); }
	 * 
	 * return null; }
	 */

	public void setHourWODate(Integer hourWODate) {
		this.hourWODate = hourWODate;
	}

	public String getCommonName() {
		return commonName;
	}

	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	public String getHourOfDay() {
		return hourOfDay;
	}

	public Integer getHourWODate() {
		return hourWODate;
	}

	public String getMessageFormat() {
		return messageFormat;
	}

	public void setMessageFormat(String messageFormat) {
		this.messageFormat = messageFormat;
	}

	private String normalizeDateFormat(String t) {
		if (t.contains("T"))
			return t;
		else
			return new StringBuilder().append(t.substring(6, 10)).append('-')
					.append(t.substring(0, 2)).append('-')
					.append(t.substring(3, 5)).append('T')
					.append(t.substring(11, 23)).toString();
	}

	public static void main(String args[]) {
		// 02/19/2016 17:10:47:317 => 2016-02-11T17:42:06.816-05:00
		String t = "02/19/2016 17:10:47:317";
		StringBuilder t1 = new StringBuilder().append(t.substring(6, 10))
				.append('-').append(t.substring(0, 2)).append('-')
				.append(t.substring(3, 5)).append('T')
				.append(t.substring(11, 23));
		System.out.println(t1);
	}
}
