package com.impetus;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.json.JSONObject;

import com.impetus.fm.parser.Constants;

public class TestDriver {
	private static String RAW_JSON = "{'PayLoaDCount':1, 'HourWODate':4,'CommonName':'ADS2EDI','saxMessageType':'PayloadMsg','timetsamp':1454638116312,'payloadTime':1454638116285,'PoolCount':1,'EventType':'Acquisition','MessageSubtype':'MAJORPOOL','PreOutOfBusinessHrFlag':true,'MessgeFormat':'CLDF','MessageID':'ccc66701ca19414b8b5522d9f52a1ee8','PostOutOfBusinessHrFlag':false,'HourOfDay':'2015121404','EntityType':'MBS','LoanCount':0,'messageCount':1}";

	 public static final String RANDOM_NUMERS = "0123456789";
	 
	public static DateFormat DEFAULT_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

	public static DateFormat DEFAULT_DATE_FORMAT_1 = new SimpleDateFormat("yyyyMMddHH");

	//public static String[] ADS_EVENT_TYPES = { "ACQUISITION", "CMMPROTOTYPE" };

	//public static String[] ADS_ENTITY_TYPES = { "MBS", "CASH", "CMMPILOT_ADSTOEDI_CASH", "CMMPILOT_ADSTOEDI_POOL", "POOL" };

	//public static String[] MBS_EVENT_TYPES = { "ISSN.POOL_SHELF_OPND_DACT", "ISSN.POOL_SHELF_REOPENED_DACT", "ISSN.POOL_SHELF_RECLOSED_DACT", "ISSN.POOL_CLSD_DACT", "ISSN.POOL_REOPENED_RECLSD_DACT",
			//"ISSN.POOL_SHELF_CLSD_DACT", "ISSN.POOL_CLPSD_DACT", "CMMPROTOTYPE" };

	//public static String[] MBS_ENTITY_TYPES = { "POOL", "PPC", "CMMPILOT_MBSTOEDI_EVENT1", "CMMPILOT_MBSTOEDI_EVENT2", "CMMPILOT_MBSTOEDI_EVENT3" };

	public static String PAYLOAD_TYPE_MBS_TO_EDI = "MBS2EDI";
	public static String PAYLOAD_TYPE_ADS_TO_EDI = "ADS2EDI";

	public static final String chars = "abcdefghijklmonpqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	
	private static int totalRecords = 0;

	interface Bean{
		boolean getIsADS2EDI();
		
		boolean getIsMajorPool();
		
		Map<String[], String[]> getEntityEventMap();
	}
	
	static class ADS2EDIBean implements Bean{
		String[] ENTITY_TYPES_1 = { "MBS", "CASH", "POOL" };
		String[] EVENT_TYPES_1 = { "ACQUISITION"};
		
		String[] EVENT_TYPES_2 = { "CMMPROTOTYPE" };
		String[] ENTITY_TYPES_2 = { "CMMPILOT_ADSTOEDI_CASH", "CMMPILOT_ADSTOEDI_POOL"};
		
		public Map<String[], String[]> entityEventMap = new HashMap<String[], String[]>();
		
		private static ADS2EDIBean bean;
		
		private ADS2EDIBean(){
			
		}
		
		public static ADS2EDIBean getInstance(){
			if(bean == null){
				bean = new ADS2EDIBean();
				bean.entityEventMap.put(bean.ENTITY_TYPES_1, bean.EVENT_TYPES_1);
				bean.entityEventMap.put(bean.ENTITY_TYPES_2, bean.EVENT_TYPES_2);
			}
			
			return bean;
		}

		public boolean getIsADS2EDI() {
			return true;
		}

		public boolean getIsMajorPool() {
			return false;
		}

		public Map<String[], String[]> getEntityEventMap() {
			return entityEventMap;
		}
	}
	
	static class ADS2EDIBeanMajorPool implements Bean{
		String[] ENTITY_TYPES_1 = { "MBS", "CASH"}; // Entity type POOL never contains MAJOR POOL as node
		String[] EVENT_TYPES_1 = { "ACQUISITION"};
		
		String[] EVENT_TYPES_2 = { "CMMPROTOTYPE" };
		String[] ENTITY_TYPES_2 = { "CMMPILOT_ADSTOEDI_CASH", "CMMPILOT_ADSTOEDI_POOL"};
		
		public Map<String[], String[]> entityEventMap = new HashMap<String[], String[]>();
		
		private static ADS2EDIBeanMajorPool bean;
		
		private ADS2EDIBeanMajorPool(){
			
		}
		
		public static ADS2EDIBeanMajorPool getInstance(){
			if(bean == null){
				bean = new ADS2EDIBeanMajorPool();
				bean.entityEventMap.put(bean.ENTITY_TYPES_1, bean.EVENT_TYPES_1);
				bean.entityEventMap.put(bean.ENTITY_TYPES_2, bean.EVENT_TYPES_2);
			}
			
			return bean;
		}

		public boolean getIsADS2EDI() {
			return true;
		}

		public boolean getIsMajorPool() {
			return true;
		}

		public Map<String[], String[]> getEntityEventMap() {
			return entityEventMap;
		}
	}
	
	static class MBS2EDIBean implements Bean{
		String[] ENTITY_TYPES_1 = { "POOL" };
		String[] EVENT_TYPES_1 = { "ISSN.POOL_SHELF_OPND_DACT","ISSN.POOL_SHELF_REOPENED_DACT"};
		//String[] EVENT_TYPES_1 = { "ISSN.POOL_SHELF_OPND_DACT","ISSN.POOL_SHELF_REOPENED_DACT","ISSN.POOL_SHELF_RECLOSED_DACT","ISSN.POOL_SHELF_OPND_DACT","ISSN.POOL_CLSD_DACT","ISSN.POOL_CLSD_DACT","ISSN.POOL_REOPENED_RECLSD_DACT","ISSN.POOL_REOPENED_RECLSD_DACT","ISSN.POOL_CLPSD_DACT","ISSN.POOL_SHELF_CLSD_DACT","ISSN.POOL_CLSD_DACT","ISSN.POOL_REOPENED_RECLSD_DACT","ISSN.POOL_CLPSD_DACT"};
		
		String[] EVENT_TYPES_2 = { "PPC" };
		String[] ENTITY_TYPES_2 = { "ISSN.PPC_CLSD_DACT","ISSN.PPC_REOPENED_RECLSD_DACT","ISSN.PPC_CLPSD_DACT"};
		
		String[] EVENT_TYPES_3 = { "CMMPROTOTYPE" };
		String[] ENTITY_TYPES_3 = { "CMMPilot_MBSToEDI_EVENT1","CMMPilot_MBSToEDI_EVENT2","CMMPilot_MBSToEDI_EVENT3"};
		
		public Map<String[], String[]> entityEventMap = new HashMap<String[], String[]>();
		
		private static MBS2EDIBean bean;
		
		private MBS2EDIBean(){
			
		}
		
		public static MBS2EDIBean getInstance(){
			if(bean == null){
				bean = new MBS2EDIBean();
				bean.entityEventMap.put(bean.ENTITY_TYPES_1, bean.EVENT_TYPES_1);
				bean.entityEventMap.put(bean.ENTITY_TYPES_2, bean.EVENT_TYPES_2);
				bean.entityEventMap.put(bean.ENTITY_TYPES_3, bean.EVENT_TYPES_3);
			}
			
			return bean;
		}
		
		public boolean getIsADS2EDI() {
			return false;
		}

		public boolean getIsMajorPool() {
			return false;
		}

		public Map<String[], String[]> getEntityEventMap() {
			return entityEventMap;
		}
	}

	private static final String MESSAGE_DATE = "2016-02-23T14:40:32";
	
	public static void main(String[] args) throws Exception{
		TestDriver testDriver = new TestDriver();
		
		//Bean bean = ADS2EDIBean.getInstance();
		//Bean bean = ADS2EDIBeanMajorPool.getInstance();
		Bean bean = MBS2EDIBean.getInstance();
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(DEFAULT_DATE_FORMAT.parse(MESSAGE_DATE));
		
		int startDay = calendar.get(Calendar.DAY_OF_MONTH);
		int endDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);;
		//int endDay = calendar.get(Calendar.DAY_OF_MONTH);
		
		for(int i=startDay; i <= startDay; i++){
			calendar.set(Calendar.DAY_OF_MONTH, i);
			if(Calendar.SATURDAY != calendar.get(Calendar.DAY_OF_WEEK) && Calendar.SUNDAY != calendar.get(Calendar.DAY_OF_WEEK)){
				//testDriver.generateData(bean, DEFAULT_DATE_FORMAT_1.format(calendar.getTime()));
				testDriver.generateData(bean, PAYLOAD_TYPE_MBS_TO_EDI, i, calendar);
			}
		}
		
		System.out.println("Total Records:- " + totalRecords);
	}
	
	private void generateData(Bean bean, String fileName, int day, Calendar calendar){
		int count = Integer.valueOf(getRandomNumbers(2));
		while(count > 18 || count==0){
			count = Integer.valueOf(getRandomNumbers(2));
			if(count <= 18){
				break;
			}
		}
		
		int dayRecordCount = 0;
		for (int i = 0; i < count; i++) {
			for(Map.Entry<String[], String[]> entry : bean.getEntityEventMap().entrySet()){
				String[] entities = entry.getKey();
				String[] events = entry.getValue();
				
				for (String entity : entities) {
					for (String event : events) {
						JSONObject rowData = this.getRowData(bean.getIsADS2EDI(), entity, event, bean.getIsMajorPool(), calendar);
						
						try{
							//writeFile((bean.getIsADS2EDI() ? PAYLOAD_TYPE_ADS_TO_EDI : PAYLOAD_TYPE_MBS_TO_EDI) + ".txt", rowData.toString(), true, i);
							writeFile(fileName + ".txt", rowData.toString(), true, totalRecords);
							
							dayRecordCount += 1;
						}catch(Exception e){
							e.printStackTrace();
						}
					}
				}
			}
		}
	}
	
	public static String getRandomNumbers(int length) {
        Random random = new Random();
        if (length > 32 || length < 1) {
            length = 1;
        }

        char[] buf = new char[length];
        for (int i = 0; i < buf.length; i++) {
            buf[i] = RANDOM_NUMERS.charAt(random.nextInt(RANDOM_NUMERS.length()));
        }

        return new String(buf);
    }
	
	@SuppressWarnings("unchecked")
    public static <T> T getPastDate(T guiDate, int daysToGoBack, SimpleDateFormat sdk) {
        try {
            if (guiDate != null) {
                Date date = null;
                long MILLIS_IN_DAY = 1000 * 60 * 60 * 24;
                String dateStr = null;
                if (guiDate instanceof String) {
                    dateStr = (String) guiDate;
                    if (sdk == null)
                        date = DEFAULT_DATE_FORMAT.parse(dateStr);
                    else
                        date = sdk.parse(dateStr);
                }
                if (guiDate instanceof Date) {
                    if (sdk == null) {
                        dateStr = DEFAULT_DATE_FORMAT.format(guiDate);
                        date = DEFAULT_DATE_FORMAT.parse(dateStr);
                    } else {
                        dateStr = sdk.format(guiDate);
                        date = sdk.parse(dateStr);
                    }
                }

                if (date != null) {
                    if (daysToGoBack > 0) {
                        MILLIS_IN_DAY = MILLIS_IN_DAY * daysToGoBack;
                        if (guiDate instanceof Date) {
                            Calendar calender = Calendar.getInstance();
                            calender.setTimeInMillis(date.getTime() - MILLIS_IN_DAY);
                            return (T) calender.getTime();
                        }
                        return sdk == null ? (T) DEFAULT_DATE_FORMAT.format(date.getTime() - MILLIS_IN_DAY) : (T) sdk.format(date.getTime() - MILLIS_IN_DAY);
                    } else {
                        return sdk == null ? (T) DEFAULT_DATE_FORMAT.format(date.getTime()) : (T) sdk.format(date.getTime());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();;
        }

        return null;
    }

	private JSONObject getRowData(boolean adsData, String entityType, String eventType, boolean isMajorPool, Calendar calendar) {
		JSONObject rowData = new JSONObject(RAW_JSON);

		Date date = calendar.getTime();

		rowData.put("EventType", eventType);
		rowData.put("EntityType", entityType);
		rowData.put("timetsamp", Calendar.getInstance().getTimeInMillis());
		rowData.put("payloadTime", date.getTime());
		rowData.put("MessageID", getRandomCharacters(32));
		
		Integer hourWODate = calendar.get(Calendar.HOUR_OF_DAY);
		String hourOfDay = DEFAULT_DATE_FORMAT_1.format(date);
		Integer dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

		rowData.put("HourWODate", hourWODate);
		rowData.put("DayOfMonth", dayOfMonth);
		rowData.put("HourOfDay", hourOfDay);
		
		rowData.put("PreOutOfBusinessHrFlag", hourWODate.intValue() < 1 ? true : false);
		rowData.put("PostOutOfBusinessHrFlag", hourWODate.intValue() > 23 ? true : false);

		if (adsData) {
			if ((Constants.EntityType.MBS.getEntityType().equalsIgnoreCase(entityType)) || (Constants.EntityType.CMMPILOT_ADSTOEDI_POOL.getEntityType().equalsIgnoreCase(entityType))) {
				if (isMajorPool) {
					rowData.put("MessageSubtype", "MAJORPOOL");
				} else {
					rowData.put("MessageSubtype", "POOL");
				}
			} else if ((Constants.EntityType.CASH.getEntityType().equalsIgnoreCase(entityType)) || (Constants.EntityType.CMMPILOT_ADSTOEDI_CASH.getEntityType().equalsIgnoreCase(entityType))) {
				rowData.put("MessageSubtype", "LOAN");
			}

			rowData.put("CommonName", PAYLOAD_TYPE_ADS_TO_EDI);
			rowData.put("MessgeFormat", "CLDF");
		} else {
			rowData.put("CommonName", PAYLOAD_TYPE_MBS_TO_EDI);
			rowData.put("MessgeFormat", "ECF");
			rowData.put("LoanCount", 0);
			rowData.put("PoolCount", 1);

			String messageSubType = null;
			rowData.put("MessageSubtype", messageSubType);
		}

		return rowData;
	}

	public static String getRandomCharacters(int length) {
		Random random = new Random();
		if (length > 32 || length < 1) {
			length = 1;
		}

		char[] buf = new char[length];

		for (int i = 0; i < buf.length; i++) {
			buf[i] = chars.charAt(random.nextInt(chars.length()));
		}

		return new String(buf);
	}

	public void writeFile(String fileName, String data, boolean append, int count) throws Exception {
		BufferedWriter bw = null;

		try {
			File file = new File(fileName);
			if(file.exists()){
				if(count == 0){
					file.delete();
					file.createNewFile();
				}else{
					data = System.getProperty("line.separator") + data;
				}
			}
			
			totalRecords += 1;
			
			FileWriter writer = new FileWriter(file, append);
			
			bw = new BufferedWriter(writer);

			bw.write(data);
		} catch (IOException ioe) {
			throw new Exception("ERROR: Could not write to file [" + fileName + "]\n\t" + ioe.toString());
		} finally {
			if (bw != null){
				bw.close();
			}
		}
	}
}
