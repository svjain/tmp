package com.impetus.component.channel;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import backtype.storm.spout.Scheme;
import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.utils.Utils;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.impetus.fm.parser.Constants;
import com.streamanalytix.framework.api.storm.channel.Channel;

public class HttpChannel implements Serializable, Channel {
	private static final long serialVersionUID = -7647888369548335393L;

	private static final Log LOGGER = LogFactory.getLog(HttpChannel.class);

	private SpoutOutputCollector collector;

	private Scheme serialisationScheme;

	private String httpUrl;

	private HttpClient httpClient;

	private GetMethod method;

	public void closeChannel() {
		// TODO Auto-generated method stub
		if(this.method != null){
			this.method.releaseConnection();
			this.method = null;
		}
		
		if(this.httpClient != null){
			this.httpClient = null;
		}
	}

	public void init(Map<String, Object> configMap) {
		LOGGER.info("Dev: Init the HttpChannel");
		/** If scheme is instance of Scheme, then use below code snippet. */
		this.serialisationScheme = (Scheme) configMap.get("scheme");

		if (null == configMap || configMap.isEmpty()) {
			System.out.println("No configurations done from UI");
		} else {
			this.httpUrl = (String) configMap.get(Constants.HTTP_URL);
		}
	}

	@SuppressWarnings("unchecked")
	public void nextMessage() {
		if (this.httpClient == null || this.method == null) {
			Utils.sleep(50);
			this.initializeHttpClient();
		} else {
			try {
				// Execute the method.
				int statusCode = this.httpClient.executeMethod(this.method);

				if (statusCode != HttpStatus.SC_OK) {
					LOGGER.error("Invalid Response Code: " + statusCode + " and Status Line:- " + this.method.getStatusLine());
				}

				// Read the response body.
				byte[] responseBody = method.getResponseBody();
				List<Object> values = serialisationScheme.deserialize(responseBody);

				if (values != null && values.size() > 0) {
					Set<String> streamIdList = (Set<String>) values.get(1);

					for (String streamId : streamIdList) {
						if (!"defaultStream".equals(streamId)) {
							collector.emit(streamId, values);
						} else {
							collector.emit(values);
						}
					}
				}
			} catch (Exception e) {
				LOGGER.error(e);
			} finally {
				// Release the connection.
				method.releaseConnection();
			}
		}
	}

	private void initializeHttpClient() {
		try {
			if (!StringUtils.isBlank(this.httpUrl)) {
				this.httpClient = new HttpClient();

				this.method = new GetMethod(this.httpUrl);
				method.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, new DefaultHttpMethodRetryHandler(3, false));
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}
	}

	public void openChannel(Map configMap, TopologyContext context, SpoutOutputCollector collector) {
		this.collector = collector;

		this.initializeHttpClient();
	}
	
	public void deactivateChannel() {
		// TODO Auto-generated method stub

	}

	public void cleanup() {
		// TODO Auto-generated method stub

	}
	
	public void acknowledge(Object arg0) {
		// TODO Auto-generated method stub

	}

	public void failure(Object arg0) {
		// TODO Auto-generated method stub

	}
	
	public void activateChannel() {
		// TODO Auto-generated method stub

	}
	
	public static void main(String[] args){
		Map<String, Object> configMap = new HashMap<String, Object>();
		
		configMap.put("httpUrl", "http://192.168.7.81:9200");
		
		HttpChannel channel = new HttpChannel();
		channel.init(configMap);
		
		channel.openChannel(configMap, null, null);
		
		channel.nextMessage();
		
		channel.nextMessage();
	}
}
