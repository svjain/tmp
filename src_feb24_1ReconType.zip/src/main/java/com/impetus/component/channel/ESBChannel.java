package com.impetus.component.channel;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;

import backtype.storm.spout.Scheme;
import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.utils.Utils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.fanniemae.all.messaging.api.ESBClient;
import com.fanniemae.all.messaging.api.ESBClientCredentials;
import com.fanniemae.all.messaging.api.ESBClientException;
import com.fanniemae.all.messaging.api.ESBClientFactory;
import com.fanniemae.all.messaging.api.ESBMessageProcessor;
import com.fanniemae.all.messaging.message.ESBMessage;
import com.fanniemae.all.messaging.message.ESBMessageException;
import com.streamanalytix.framework.api.storm.channel.Channel;

public class ESBChannel implements Serializable, Channel, ESBMessageProcessor {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -71711054185289348L;

	private static final Log LOGGER = LogFactory.getLog(ESBChannel.class);

	private LinkedBlockingQueue<String> queue;
	private long recoveryPeriod = -1; // default to disabled

	/**
	 * The collector is used to emit tuples from this channel. Tuples can be
	 * emitted at any time, including the open and close methods.
	 */
	private SpoutOutputCollector collector;

	private Scheme serialisationScheme;

	private static final String SUPPORTED_EVENTS_STR = "SUPPORTED_EVENTS";
	private static final String SUPPORTED_ENTITY_STR = "SUPPORTED_ENTITY";
	private static final String DELIMITER_COMMA = ",";
	private List<String> supportEventTypes = null;
	private List<String> supportEntityTypes = null;

	ESBClient client; // reference to the parent ESBClient instance

	/**
	 * Initialize config map or variables which all are passed from channel on
	 * ui.
	 * 
	 * @param configMap
	 *            the config map
	 */
	public void init(Map<String, Object> configMap) {
		LOGGER.info("Dev: Init the ESBChannel");
		/** If scheme is instance of Scheme, then use below code snippet. */
		this.serialisationScheme = (Scheme) configMap.get("scheme");

		if (null == configMap || configMap.isEmpty()) {
			System.out.println("No configurations done from UI");
		} else {
//			LOGGER.info("Config Map Dump");
//			for (Map.Entry<String, Object> entry : configMap.entrySet())
//				LOGGER.info("key/value [" + entry.getKey() + ":" + entry.getValue().toString() + "]");
			Object supportedEventsVal = configMap.get(SUPPORTED_EVENTS_STR);
			Object supportedEntityVal = configMap.get(SUPPORTED_ENTITY_STR);

			if (supportedEventsVal != null) {
				supportEventTypes = Arrays.asList(supportedEventsVal.toString().split(DELIMITER_COMMA));
				LOGGER.info("Dev: supportedEventsVal [" + supportEventTypes + "]");
			} else
				LOGGER.error("missing configuration property [" + SUPPORTED_EVENTS_STR + "]");

			if (supportedEntityVal != null) {
				supportEntityTypes = Arrays.asList(supportedEntityVal.toString().split(DELIMITER_COMMA));
				LOGGER.info("Dev: supportedEventsVal [" + supportEntityTypes + "]");
			} else
				LOGGER.error("missing configuration property [" + SUPPORTED_ENTITY_STR + "]");
		}
	}

	/**
	 * Called when a task for this component is initialized within a worker on
	 * the cluster. It is called once and can also be used for creating any kind
	 * of connections by using initialized config map or variables.
	 * 
	 * @param conf
	 *            the storm configuration for this channel.
	 * @param context
	 *            the context can be used to get information about this task's.
	 * @param collector
	 *            the collector is used to emit tuples from this channel. Tuples
	 *            can be emitted at any time, including the open and close
	 *            methods.
	 */
	public void openChannel(Map conf, TopologyContext context, SpoutOutputCollector collector) {
		LOGGER.info("Dev: openChannel the ESBChannel");
		Long topologyTimeout = (Long) conf.get("topology.message.timeout.secs");

		topologyTimeout = topologyTimeout == null ? 30 : topologyTimeout;
		if ((topologyTimeout.intValue() * 1000) > this.recoveryPeriod) {
			LOGGER.warn("*** WARNING *** : " + "Recovery period (" + this.recoveryPeriod
					+ " ms.) is less then the configured " + "'topology.message.timeout.secs' of " + topologyTimeout
					+ " secs. This could lead to a message replay flood!");
		}
		this.queue = new LinkedBlockingQueue<String>();
		this.collector = collector;

		try {
			ESBClientCredentials credentials = new ESBClientCredentials() {

				public String getESBUserId() {
					return "a8ldevl";
				}

				public String getESBPassword() {
					return "DQ2_team";
				}
			};
			LOGGER.info("Dev: ESBChannel: Creating client with credentials [" + credentials.getESBUserId() + "]");
			this.client = ESBClientFactory.createESBClient(credentials);
			client.startMessageConsumer(this);
			LOGGER.info("Dev: ESBChannel: Started messageConsumer on the client");
		} catch (ESBClientException e) {
			e.printStackTrace();
			LOGGER.error("Error creating ESBClient connection.", e);
		}
	}

	// processMessage() is called to process ESBMessage consumed by ESBClient
	public boolean processMessage(ESBMessage message) {
		LOGGER.info("Dev: ESBChannel: Processing messages received by client");
		List<String> payloadIdList = message.getPayloadIds();
		LOGGER.info("Dev: ESBChannel: # of payloadIds received [" + payloadIdList.size() + "]");
		String payloadMsg = null;
		String eventType = null;
		String entityType = null;
		if (payloadIdList.size() != 0) {
			for (String payloadId : payloadIdList) {
				// assuming one payload only-else use a loop
				payloadMsg = message.getPayload(payloadId);
				eventType = message.getEventType(payloadId);
				entityType = message.getEntityType(payloadId);
			}
		} else // only one default payload
		{
			payloadMsg = message.getPayload();
			eventType = message.getEventType();
			entityType = message.getEntityType();
		}

		LOGGER.info("Dev: ESBChannel: payload received with event[" + eventType + "], entity[" + entityType + "], payload[" + payloadMsg + "]");

		if (null != payloadMsg) {
			if ((eventType != null) && (entityType != null)
					&& (supportEventTypes.contains(eventType)) && (supportEntityTypes.contains(entityType)))
			{
				LOGGER.info("Dev: Propagating the message with event/entity type [" + eventType + "," + entityType + "], since it belongs to configured event/entity[" + supportEventTypes + "]/[" + supportEntityTypes + "]");
				try {
					this.queue.offer(message.toXML());
				} catch (ESBMessageException e) {
					LOGGER.error("Dev: Failed to convert ESBMessage to XML [" + message.getPayload() +"]");
					e.printStackTrace();
				}
			}
			else
			{
				LOGGER.warn("Dev: Skipping the message with incorrect event/entity type [" + eventType + "," + entityType + "]. It does not belong to configured event/entity[" + supportEventTypes + "]/[" + supportEntityTypes + "]");
			}
		}
		return true;
	}

	/** Called when channel is going to be shutdown. */
	public void closeChannel() {
	}

	/**
	 * Called when a channel has been activated out of a deactivated mode.
	 * nextMessage will be called on this channel as soon as message arrive on
	 * the queue.
	 */
	public void activateChannel() {
	}

	/**
	 * Called when a channel has been deactivated. nextMessage will not be
	 * called while a channel is deactivated.
	 */
	public void deactivateChannel() {
	}

	/**
	 * Emits the next message from the queue as a tuple.
	 * 
	 * If no message is ready to emit, this will wait for message to arrive on
	 * the queue. If the channel has no tuples to emit, this method should
	 * return.
	 */
	public void nextMessage() {
		String msgtxt = this.queue.poll();
		if (msgtxt == null) {
			Utils.sleep(50);
		} else {

			LOGGER.debug("sending tuple: " + msgtxt);
		//	LOGGER.info("sending tuple: " + msgtxt);
			// get the tuple from the handler
			try {
				List<Object> values = serialisationScheme.deserialize(msgtxt.getBytes());

				if (values != null && values.size() > 0) {
					Set<String> streamIdList = (Set<String>) values.get(1);

					for (String streamId : streamIdList) {
						if (!"defaultStream".equals(streamId)) {
							collector.emit(streamId, values);
						} else {
							collector.emit(values);
						}
					}
				}

			} catch (Exception e) {
				LOGGER.warn("Unable to convert ESB message: " + msgtxt);
			}
		}
	}

	public void acknowledge(Object msgId) {
	}

	public void failure(Object msgId) {
		LOGGER.warn("Message failed: " + msgId);
	}

	public void cleanup() {
	}
}
